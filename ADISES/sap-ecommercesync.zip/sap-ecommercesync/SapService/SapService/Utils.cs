﻿using SAP_LIB.Controllers;
using SAP_LIB.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace SapService
{
    public static class Utils
    {
        public static string tpConfiguration = string.Empty;
        public static int interval = 0;
        public static long registroActual = 0;
        public static int RangoRegistros = 0;
        public const string MASTER = "MASTER";
        public const string OFERTA = "OFERTAS";
        public const string LIQUIDACION = "LIQUIDACIONES";
        public const string INSERT = "INSERT";
        public const string UPDATE = "UPDATE";
        public const string DELETE = "DELETE";
        #region Utilidades
        public static string parseStringBD(string str)
        {
            return $"\"{str}\"";
        }

        public static string ColumnsSelect(string[] lsString)
        {
            string returnColumns = string.Empty;

            if (lsString.Count() > 0)
                for (int index = 0; index <= lsString.Count(); index++)
                    returnColumns += index == 0 ? parseStringBD(lsString[index]) : $", {parseStringBD(lsString[index])}";
            else
                returnColumns = parseStringBD(lsString[0]);

            return "";
        }

        public static DateTime ToLocalTimeMexico()
        {
            TimeZoneInfo tm = TimeZoneInfo.FindSystemTimeZoneById("Central Standard Time (Mexico)");
            DateTime Time = TimeZoneInfo.ConvertTime(DateTime.Now, TimeZoneInfo.Local, tm);

            return Time;
        }

        public static string RemoveReservedCharacters(string strValue)
        {
            try
            {
                string output = Regex.Replace(strValue, @"[^0-9A-Za-z]", "-", RegexOptions.None);
                string output2 = "";

                output.OfType<char>().ToList().ForEach(c =>
                {
                    if (output2 != null && output2.Length > 0)
                        output2 = (output2[output2.Length - 1] != '-') ? output2 += c : (c != '-' ? output2 += c : "");
                    else
                        if (c != '-') output2 += c;
                });

                return output2;
            }
            catch (Exception ex)
            {
                string path = "C:\\SyncWooCommerce.txt";
                using (StreamWriter writer = new StreamWriter(path, true))
                {
                    writer.WriteLine(string.Format(ex.ToString()));
                    writer.Close();
                }
                return strValue;
            }
        }

        public static string RemoveAccents(string text)
        {
            StringBuilder sbReturn = new StringBuilder();
            var arrayText = text.Normalize(NormalizationForm.FormD).ToCharArray();
            foreach (char letter in arrayText)
            {
                if (CharUnicodeInfo.GetUnicodeCategory(letter) != UnicodeCategory.NonSpacingMark)
                    sbReturn.Append(letter);
            }
            return sbReturn.ToString();
        }

        public static string GetDateFormatToSap(string dateRow)
        {
            if (dateRow != "")
            {
                string newdate_created = dateRow.Replace("a. m.", "").Replace("p. m.", "");
                DateTime dtm_date = DateTime.Parse(newdate_created);
                string formatDate = dtm_date.ToString("yyyy-MM-dd HH:mm:ss");
                return formatDate;
            }
            return "";

        }
        #endregion

        #region Configuracion

        public static void getParametersConfig()
        {
            try
            {
                string query = $"SELECT {Utils.parseStringBD(zAdi_SyncConfig.zAdi_ActRegister)}, {Utils.parseStringBD(zAdi_SyncConfig.zAdi_Interval)}, {Utils.parseStringBD(zAdi_SyncConfig.zAdi_CountRegister)}";
                query += $" FROM {Utils.parseStringBD(DBConn.DB)}.{Utils.parseStringBD(DBConn.zAdi_SyncConfig)}";
                query += $" WHERE {Utils.parseStringBD(zAdi_SyncConfig.zAdi_TpConfig)} = '{tpConfiguration}'";

                //string path = "C:\\sample.txt";
                //using (StreamWriter writer = new StreamWriter(path, true))
                //{
                //    writer.WriteLine(string.Format($"Query getParameters: {query}"));
                //    writer.Close();
                //}

                DataTable tbl = DBConn.ExecQuery(query);
                if (!(tbl != null && tbl.Rows != null && tbl.Rows.Count > 0))
                {
                    PrintLog("getParametersConfig", "0", $"No se encontraron parámetros a las : {DateTime.Now.ToString()}.");
                    return;
                }
                registroActual = long.Parse(tbl.Rows[0].ItemArray[0].ToString());
                interval = int.Parse(tbl.Rows[0].ItemArray[1].ToString());
                RangoRegistros = int.Parse(tbl.Rows[0].ItemArray[2].ToString());

            }
            catch (Exception ex)
            {
                //DBConn.CloseConnection();
                PrintLog("getParametersConfig", "1", ex.ToString());
                clearParameters();
            }
        }

        public static void clearParameters()
        {
            registroActual = 0;
            interval = 0;
            RangoRegistros = 0;
        }

        #endregion

        public static void PrintLog(string function, string nivelCatch, string message)
        {
            string path = @"C:\Program Files (x86)\Adises\Logs\";
            string pathComplete = $"{path}log_{DateTime.Now.ToString("ddMMyyyy")}.txt";
            try
            {
                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);

                using (StreamWriter writer = new StreamWriter(pathComplete, true))
                {
                    writer.WriteLine($"--------------------------Start-----------------------------");

                    writer.WriteLine($"function: {function}");
                    writer.WriteLine($"nivelCatch: {nivelCatch}");
                    writer.WriteLine($"Hora: {DateTime.Now.ToString("hh:mm:ss tt")}");
                    writer.WriteLine($"message: {message}");

                    writer.WriteLine($"---------------------------Finish----------------------------\n\n");
                    writer.Close();
                }
            }
            catch (Exception ex) { }
        }
    }
}
