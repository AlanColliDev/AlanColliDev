﻿using SAP_LIB.Controllers;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace SapService.Modules
{
    class Customers
    {
        public static string itoa64 = "./0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"; //key para generar contrasenia
        #region Clients

        public void RegisterToLogCustomers()
        {
            //string pathL = "C:\\RegisterToLogClients.txt";
            try
            {
                string query_select_OCRD = $"SELECT TOP {Utils.RangoRegistros} \n";
                query_select_OCRD += $"{Utils.parseStringBD("OCRD")}.{Utils.parseStringBD("CardCode")},\n";
                query_select_OCRD += $"{Utils.parseStringBD("OCRD")}.{Utils.parseStringBD("CardName")},\n";
                query_select_OCRD += $"{Utils.parseStringBD("OCRD")}.{Utils.parseStringBD("CardType")},\n";
                query_select_OCRD += $"{Utils.parseStringBD("OCRD")}.{Utils.parseStringBD("Address")},\n";
                query_select_OCRD += $"{Utils.parseStringBD("OCRD")}.{Utils.parseStringBD("ZipCode")},\n";
                query_select_OCRD += $"{Utils.parseStringBD("OCRD")}.{Utils.parseStringBD("Phone1")},\n";
                query_select_OCRD += $"{Utils.parseStringBD("OCRD")}.{Utils.parseStringBD("CntctPrsn")},\n";
                query_select_OCRD += $"{Utils.parseStringBD("OCRD")}.{Utils.parseStringBD("LicTradNum")},\n";
                query_select_OCRD += $"{Utils.parseStringBD("OCRD")}.{Utils.parseStringBD("City")},\n";
                query_select_OCRD += $"{Utils.parseStringBD("OCRD")}.{Utils.parseStringBD("Country")},\n";
                query_select_OCRD += $"{Utils.parseStringBD("OCRD")}.{Utils.parseStringBD("E_Mail")},\n";
                query_select_OCRD += $"{Utils.parseStringBD("OCRD")}.{Utils.parseStringBD("CreateDate")},\n";
                query_select_OCRD += $"{Utils.parseStringBD("OCRD")}.{Utils.parseStringBD("State1")}\n";
                query_select_OCRD += $"FROM {Utils.parseStringBD("OCRD")}\n";
                query_select_OCRD += $"LEFT JOIN {Utils.parseStringBD("zAdi_SyncLeadSAP")} ON {Utils.parseStringBD("OCRD")}.{Utils.parseStringBD("CardCode")} = {Utils.parseStringBD("zAdi_SyncLeadSAP")}.{Utils.parseStringBD("CardCode")}\n";
                query_select_OCRD += $"WHERE {Utils.parseStringBD("zAdi_SyncLeadSAP")}.{Utils.parseStringBD("CardCode")} IS NULL AND {Utils.parseStringBD("OCRD")}.{Utils.parseStringBD("CardType")} = 'C'";
                query_select_OCRD += $" AND ({Utils.parseStringBD("OCRD")}.{Utils.parseStringBD("E_Mail")} IS NOT NULL AND {Utils.parseStringBD("OCRD")}.{Utils.parseStringBD("E_Mail")} != '')";
                query_select_OCRD += $" AND {Utils.parseStringBD("OCRD")}.{Utils.parseStringBD("CardCode")} IN ('GDL-00156', 'GDL-00170', 'GDL-00205', 'GDL-00313', 'GDL-00319', 'GDL-00422', 'GDL-00436', 'MEX-00892', 'GDL-00974', 'GDL-00402')";
                query_select_OCRD += $" AND {Utils.parseStringBD("OCRD")}.{Utils.parseStringBD("LicTradNum")} IS NOT NULL AND {Utils.parseStringBD("OCRD")}.{Utils.parseStringBD("LicTradNum")} LIKE_REGEXPR '^[a-zA-Z0-9]*$'"; //like_regexpr
                //using (StreamWriter writer = new StreamWriter(pathL, true))
                //{
                //    writer.WriteLine(string.Format($"query_select_OCRD: {query_select_OCRD}\n"));
                //    writer.Close();
                //}

                DataTable tbl_OCRD = DBConn.ExecQuery(query_select_OCRD);
                if (tbl_OCRD != null && tbl_OCRD.Rows != null && tbl_OCRD.Rows.Count > 0)
                {
                    foreach (DataRow item_OCRD in tbl_OCRD.Rows)
                    {

                        string CardCode = item_OCRD["CardCode"] != null && !string.IsNullOrEmpty(item_OCRD["CardCode"].ToString()) ? item_OCRD["CardCode"].ToString() : "";
                        string CardName = item_OCRD["CardName"] != null && !string.IsNullOrEmpty(item_OCRD["CardName"].ToString()) ? item_OCRD["CardName"].ToString() : "";
                        string CardType = item_OCRD["CardType"] != null && !string.IsNullOrEmpty(item_OCRD["CardType"].ToString()) ? item_OCRD["CardType"].ToString() : "";
                        string Address = item_OCRD["Address"] != null && !string.IsNullOrEmpty(item_OCRD["Address"].ToString()) ? item_OCRD["Address"].ToString() : "";
                        string ZipCode = item_OCRD["ZipCode"] != null && !string.IsNullOrEmpty(item_OCRD["ZipCode"].ToString()) ? item_OCRD["ZipCode"].ToString() : "";
                        string Phone1 = item_OCRD["Phone1"] != null && !string.IsNullOrEmpty(item_OCRD["Phone1"].ToString()) ? item_OCRD["Phone1"].ToString() : "";
                        string CntctPrsn = item_OCRD["CntctPrsn"] != null && !string.IsNullOrEmpty(item_OCRD["CntctPrsn"].ToString()) ? item_OCRD["CntctPrsn"].ToString() : "";
                        string LicTradNum = item_OCRD["LicTradNum"] != null && !string.IsNullOrEmpty(item_OCRD["LicTradNum"].ToString()) ? item_OCRD["LicTradNum"].ToString() : "";
                        string City = item_OCRD["City"] != null && !string.IsNullOrEmpty(item_OCRD["City"].ToString()) ? item_OCRD["City"].ToString() : "";
                        string Country = item_OCRD["Country"] != null && !string.IsNullOrEmpty(item_OCRD["Country"].ToString()) ? item_OCRD["Country"].ToString() : "";
                        string E_Mail = item_OCRD["E_Mail"] != null && !string.IsNullOrEmpty(item_OCRD["E_Mail"].ToString()) ? item_OCRD["E_Mail"].ToString() : "";
                        string CreateDate = item_OCRD["CreateDate"] != null && !string.IsNullOrEmpty(item_OCRD["CreateDate"].ToString()) ? item_OCRD["CreateDate"].ToString() : "";
                        //string State1 = item_OCRD["State1"] != null && !string.IsNullOrEmpty(item_OCRD["State1"].ToString()) ? item_OCRD["State1"].ToString() : "";
                        //State1 = returnNameState(State1);

                        /*OCPR*/
                        string OCPR_CntctCode = string.Empty;
                        string OCPR_Name = string.Empty;
                        string OCPR_Tel1 = string.Empty;
                        string OCPR_E_MailL = string.Empty;
                        string OCPR_updateDate = string.Empty;
                        string OCPR_CreateDate = string.Empty;

                        string select_OCPR = "SELECT TOP 1 \n";
                        select_OCPR += $"{Utils.parseStringBD("CntctCode")},\n";
                        select_OCPR += $"{Utils.parseStringBD("Name")},\n";
                        select_OCPR += $"{Utils.parseStringBD("Tel1")},\n";
                        select_OCPR += $"{Utils.parseStringBD("E_MailL")},\n";
                        select_OCPR += $"{Utils.parseStringBD("updateDate")},\n";
                        select_OCPR += $"{Utils.parseStringBD("CreateDate")}\n";
                        select_OCPR += $"FROM {Utils.parseStringBD("OCPR")}\n";
                        select_OCPR += $"WHERE {Utils.parseStringBD("CardCode")} = '{CardCode}'";

                        //using (StreamWriter writer = new StreamWriter(pathL, true))
                        //{
                        //    writer.WriteLine(string.Format($"select_OCRP: {select_OCPR}\n"));
                        //    writer.Close();
                        //}
                        DataTable item_OCRP = DBConn.ExecQuery(select_OCPR);

                        if (item_OCRP != null && item_OCRP.Rows != null && item_OCRP.Rows.Count > 0)
                        {
                            OCPR_CntctCode = item_OCRP.Rows[0]["CntctCode"] != null && !string.IsNullOrEmpty(item_OCRP.Rows[0]["CntctCode"].ToString()) ? item_OCRP.Rows[0]["CntctCode"].ToString() : "";
                            OCPR_Name = item_OCRP.Rows[0]["Name"] != null && !string.IsNullOrEmpty(item_OCRP.Rows[0]["Name"].ToString()) ? item_OCRP.Rows[0]["Name"].ToString() : "";
                            OCPR_Tel1 = item_OCRP.Rows[0]["Tel1"] != null && !string.IsNullOrEmpty(item_OCRP.Rows[0]["Tel1"].ToString()) ? item_OCRP.Rows[0]["Tel1"].ToString() : "";
                            //OCPR_E_MailL = item_OCRP.Rows[0]["E_MailL"] != null && !string.IsNullOrEmpty(item_OCRP.Rows[0]["E_MailL"].ToString()) ? item_OCRP.Rows[0]["E_MailL"].ToString() : "";
                            OCPR_updateDate = item_OCRP.Rows[0]["updateDate"] != null && !string.IsNullOrEmpty(item_OCRP.Rows[0]["updateDate"].ToString()) ? item_OCRP.Rows[0]["updateDate"].ToString() : "";
                            OCPR_CreateDate = item_OCRP.Rows[0]["CreateDate"] != null && !string.IsNullOrEmpty(item_OCRP.Rows[0]["CreateDate"].ToString()) ? item_OCRP.Rows[0]["CreateDate"].ToString() : "";
                        }

                        /*CRD1*/
                        string CRD1_Address = string.Empty;
                        string CRD1_Street = string.Empty;
                        string CRD1_Block = string.Empty;
                        string CRD1_ZipCode = string.Empty;
                        string CRD1_City = string.Empty;
                        string CRD1_Country = string.Empty;
                        string CRD1_State = string.Empty;
                        string CRD1_CreateDate = string.Empty;
                        string State1 = string.Empty;

                        string select_CRD1 = "SELECT TOP 1 \n";
                        select_CRD1 += $"{Utils.parseStringBD("Address")}, \n";
                        select_CRD1 += $"{Utils.parseStringBD("Street")}, \n";
                        select_CRD1 += $"{Utils.parseStringBD("Block")}, \n";
                        select_CRD1 += $"{Utils.parseStringBD("ZipCode")}, \n";
                        select_CRD1 += $"{Utils.parseStringBD("City")}, \n";
                        select_CRD1 += $"{Utils.parseStringBD("Country")}, \n";
                        select_CRD1 += $"{Utils.parseStringBD("State")}, \n";
                        select_CRD1 += $"{Utils.parseStringBD("CreateDate")} \n";
                        select_CRD1 += $" FROM {Utils.parseStringBD("CRD1")} WHERE {Utils.parseStringBD("CardCode")} = '{CardCode}'";

                        //using (StreamWriter writer = new StreamWriter(pathL, true))
                        //{
                        //    writer.WriteLine(string.Format($"select_CRD1: {select_CRD1}\n"));
                        //    writer.Close();
                        //}
                        DataTable item_CRD1 = DBConn.ExecQuery(select_CRD1);

                        if (item_CRD1 != null && item_CRD1.Rows != null && item_CRD1.Rows.Count > 0)
                        {
                            CRD1_Address = item_CRD1.Rows[0]["Address"] != null & !string.IsNullOrEmpty(item_CRD1.Rows[0]["Address"].ToString()) ? item_CRD1.Rows[0]["Address"].ToString() : "";
                            CRD1_Street = item_CRD1.Rows[0]["Street"] != null & !string.IsNullOrEmpty(item_CRD1.Rows[0]["Street"].ToString()) ? item_CRD1.Rows[0]["Street"].ToString() : "";
                            CRD1_Block = item_CRD1.Rows[0]["Block"] != null & !string.IsNullOrEmpty(item_CRD1.Rows[0]["Block"].ToString()) ? item_CRD1.Rows[0]["Block"].ToString() : "";
                            CRD1_ZipCode = item_CRD1.Rows[0]["ZipCode"] != null & !string.IsNullOrEmpty(item_CRD1.Rows[0]["ZipCode"].ToString()) ? item_CRD1.Rows[0]["ZipCode"].ToString() : "";
                            CRD1_City = item_CRD1.Rows[0]["City"] != null & !string.IsNullOrEmpty(item_CRD1.Rows[0]["City"].ToString()) ? item_CRD1.Rows[0]["City"].ToString() : "";
                            CRD1_Country = item_CRD1.Rows[0]["Country"] != null & !string.IsNullOrEmpty(item_CRD1.Rows[0]["Country"].ToString()) ? item_CRD1.Rows[0]["Country"].ToString() : "";
                            CRD1_State = item_CRD1.Rows[0]["State"] != null & !string.IsNullOrEmpty(item_CRD1.Rows[0]["State"].ToString()) ? item_CRD1.Rows[0]["State"].ToString() : "";
                            State1 = returnNameState(CRD1_State);
                            CRD1_CreateDate = item_CRD1.Rows[0]["CreateDate"] != null & !string.IsNullOrEmpty(item_CRD1.Rows[0]["CreateDate"].ToString()) ? item_CRD1.Rows[0]["CreateDate"].ToString() : "";
                        }


                        string insert_client_toLog = $"INSERT INTO {Utils.parseStringBD("zAdi_SyncLeadSAP")} (";
                        //insert_client_toLog += $"{Utils.parseStringBD("idSyncLead")},";
                        //insert_client_toLog += $"{Utils.parseStringBD("idClient")},";
                        insert_client_toLog += $"{Utils.parseStringBD("CardCode")},\n";
                        insert_client_toLog += $"{Utils.parseStringBD("CardName")},\n";
                        insert_client_toLog += $"{Utils.parseStringBD("CardType")},\n";
                        insert_client_toLog += $"{Utils.parseStringBD("Address")},\n";
                        insert_client_toLog += $"{Utils.parseStringBD("ZipCode")},\n";
                        insert_client_toLog += $"{Utils.parseStringBD("MailAddress")},\n";
                        insert_client_toLog += $"{Utils.parseStringBD("Phone1")},\n";
                        insert_client_toLog += $"{Utils.parseStringBD("Contact")},\n";
                        insert_client_toLog += $"{Utils.parseStringBD("CURP")},\n";
                        insert_client_toLog += $"{Utils.parseStringBD("City")},\n";
                        insert_client_toLog += $"{Utils.parseStringBD("Country")},\n";
                        insert_client_toLog += $"{Utils.parseStringBD("CreateDate")},\n";
                        insert_client_toLog += $"{Utils.parseStringBD("UpdateDate")},\n";
                        insert_client_toLog += $"{Utils.parseStringBD("State1")},\n";
                        insert_client_toLog += $"{Utils.parseStringBD("action")},\n";
                        insert_client_toLog += $"{Utils.parseStringBD("flagSend")},\n";
                        //insert_client_toLog += $"{Utils.parseStringBD("dateSend")},\n";
                        insert_client_toLog += $"{Utils.parseStringBD("dateRegister")},\n";
                        insert_client_toLog += $"{Utils.parseStringBD("FlagLead")},\n";
                        insert_client_toLog += $"{Utils.parseStringBD("Address_2")})";
                        insert_client_toLog += $"VALUES(";
                        //insert_client_toLog += $" '{insert_idSyncLead.ToString()}',";
                        //insert_client_toLog += $" '{insert_idClient.ToString()}',";
                        insert_client_toLog += $" '{CardCode}',\n"; //CardCode
                        insert_client_toLog += $" '{CardName}',\n"; //CardName
                        insert_client_toLog += $" '{CardType}',\n"; //CardType
                        insert_client_toLog += $" '{CRD1_Street}',\n"; //Address
                        insert_client_toLog += $" '{CRD1_ZipCode}',\n"; //ZipCode
                        insert_client_toLog += $" '{E_Mail}',\n"; //MailAddress
                        insert_client_toLog += $" '{Phone1}',\n"; //Phone1
                        insert_client_toLog += $" '{OCPR_Name}',\n"; //Contact
                        insert_client_toLog += $" '{LicTradNum}',\n";//CURP
                        insert_client_toLog += $" '{CRD1_City}',\n";//City
                        insert_client_toLog += $" '{CRD1_Country}',\n";//Country
                        insert_client_toLog += $" CURRENT_DATE,\n";//CreateDate
                        insert_client_toLog += $" CURRENT_DATE,\n";//UpdateDate
                        insert_client_toLog += $" '{State1}',\n";//State1
                        insert_client_toLog += $" 'INSERT',\n";//action
                        insert_client_toLog += $" FALSE,\n";//flagSend
                        //insert_client_toLog += $" NULL,\n";//dateSend
                        insert_client_toLog += $" CURRENT_DATE,\n";//dateRegister
                        insert_client_toLog += $" FALSE,\n";//FlagLead
                        insert_client_toLog += $" '{CRD1_Block}'";//FlagLead
                        insert_client_toLog += $");";

                        //using (StreamWriter writer = new StreamWriter(pathL, true))
                        //{
                        //    writer.WriteLine(string.Format($"insert_client_toLog: {insert_client_toLog}\n"));
                        //    writer.Close();
                        //}

                        bool fgInsert = DBConn.ExecQueryInsert(insert_client_toLog);
                        if (!fgInsert)
                        {
                            Utils.PrintLog("RegisterToLogClients", "0", $"No fue posible realizar la sincronización del cliente {CardCode}");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("RegisterToLogClients", "1", ex.ToString());
            }
        }

        public void SyncCustomersToWooCommerce()
        {
            //string pathL = "C:\\SyncClientsToWooCommerce.txt";

            try
            {
                string select_SyncClient = $"SELECT TOP {Utils.RangoRegistros} * FROM {Utils.parseStringBD("zAdi_SyncLeadSAP")}  WHERE {Utils.parseStringBD("action")} = '{Utils.INSERT}' AND {Utils.parseStringBD("flagSend")} = FALSE AND {Utils.parseStringBD("FlagLead")} = FALSE";
                //using (StreamWriter writer = new StreamWriter(pathL, true))
                //{
                //    writer.WriteLine(string.Format($"select_SyncClient: {select_SyncClient}\n"));
                //    writer.Close();
                //}
                DataTable tbl_SyncClient = DBConn.ExecQuery(select_SyncClient);
                if (tbl_SyncClient != null && tbl_SyncClient.Rows != null && tbl_SyncClient.Rows.Count > 0)
                {
                    foreach (DataRow item_client in tbl_SyncClient.Rows)
                    {
                        string idSyncLead = item_client["idSyncLead"] != null && !string.IsNullOrEmpty(item_client["idSyncLead"].ToString()) ? item_client["idSyncLead"].ToString() : "";
                        string CardCode = item_client["CardCode"] != null && !string.IsNullOrEmpty(item_client["CardCode"].ToString()) ? item_client["CardCode"].ToString() : "";
                        string CardName = item_client["CardName"] != null && !string.IsNullOrEmpty(item_client["CardName"].ToString()) ? item_client["CardName"].ToString() : "";
                        string CardType = item_client["CardType"] != null && !string.IsNullOrEmpty(item_client["CardType"].ToString()) ? item_client["CardType"].ToString() : "";
                        string Address = item_client["Address"] != null && !string.IsNullOrEmpty(item_client["Address"].ToString()) ? item_client["Address"].ToString() : "";
                        string State1 = item_client["State1"] != null && !string.IsNullOrEmpty(item_client["State1"].ToString()) ? item_client["State1"].ToString() : "";
                        string ZipCode = item_client["ZipCode"] != null && !string.IsNullOrEmpty(item_client["ZipCode"].ToString()) ? item_client["ZipCode"].ToString() : "";
                        string MailAddress = item_client["MailAddress"] != null && !string.IsNullOrEmpty(item_client["MailAddress"].ToString()) ? item_client["MailAddress"].ToString() : "";
                        string Phone1 = item_client["Phone1"] != null && !string.IsNullOrEmpty(item_client["Phone1"].ToString()) ? item_client["Phone1"].ToString() : "";
                        string Contact = item_client["Contact"] != null && !string.IsNullOrEmpty(item_client["Contact"].ToString()) ? item_client["Contact"].ToString() : "";
                        string CURP = item_client["CURP"] != null && !string.IsNullOrEmpty(item_client["CURP"].ToString()) ? item_client["CURP"].ToString() : "";
                        string City = item_client["City"] != null && !string.IsNullOrEmpty(item_client["City"].ToString()) ? item_client["City"].ToString() : "";
                        string Country = item_client["Country"] != null && !string.IsNullOrEmpty(item_client["Country"].ToString()) ? item_client["Country"].ToString() : "";
                        string CreateDate = item_client["CreateDate"] != null && !string.IsNullOrEmpty(item_client["CreateDate"].ToString()) ? item_client["CreateDate"].ToString() : "";
                        string UpdateDate = item_client["UpdateDate"] != null && !string.IsNullOrEmpty(item_client["UpdateDate"].ToString()) ? item_client["UpdateDate"].ToString() : "";
                        string Address_2 = item_client["Address_2"] != null && !string.IsNullOrEmpty(item_client["Address_2"].ToString()) ? item_client["Address_2"].ToString() : "";

                        string user_nicename = !string.IsNullOrEmpty(MailAddress) && MailAddress.Length > 0 ? MailAddress.Any(x => x == '@') ? MailAddress.Substring(0, MailAddress.IndexOf("@")) : "" : "";
                        string display_name = !string.IsNullOrEmpty(Contact) && Contact.Length > 0 ? (Contact.Any(x => x == ' ') ? (Contact.Substring(0, Contact.IndexOf(Contact.First(x => x == ' ')))) : Contact) : "";


                        //using (StreamWriter writer = new StreamWriter(pathL, true))
                        //{
                        //    writer.WriteLine(string.Format($"inicio contraseña \n"));
                        //    writer.Close();
                        //}
                        //string password = MD5Encode(user_nicename);
                        string password = MD5Encode(CURP);

                        //using (StreamWriter writer = new StreamWriter(pathL, true))
                        //{
                        //    writer.WriteLine(string.Format($"fin contraseña \n"));
                        //    writer.Close();
                        //}

                        string insert_dsq_user = $"INSERT INTO `dsq_users` \n";
                        insert_dsq_user += $"(`ID`, \n";
                        insert_dsq_user += $"`user_login`, \n";
                        insert_dsq_user += $"`user_pass`, \n";
                        insert_dsq_user += $"`user_nicename`, \n";
                        insert_dsq_user += $"`user_email`, \n";
                        insert_dsq_user += $"`user_url`, \n";
                        insert_dsq_user += $"`user_registered`, \n";
                        insert_dsq_user += $"`user_activation_key`, \n";
                        insert_dsq_user += $"`user_status`, \n";
                        insert_dsq_user += $"`display_name`) \n";
                        insert_dsq_user += $"VALUES \n";
                        insert_dsq_user += $"(NULL, \n"; //ID
                        insert_dsq_user += $"'{CURP}', \n"; //user_login
                        insert_dsq_user += $"'{password}', \n"; //user_pass
                        insert_dsq_user += $"'{user_nicename}', \n"; //user_nicename
                        insert_dsq_user += $"'{MailAddress}', \n"; //user_email
                        insert_dsq_user += $"'', \n"; //user_url
                        insert_dsq_user += $" curdate(), \n"; //user_registered
                        insert_dsq_user += $" '1619116385:$P$Bu0Wik7lwit2IPYq52BK3IFXjVtM5f/', \n"; //user_activation_key
                        insert_dsq_user += $"0, \n"; //user_status
                        insert_dsq_user += $"'{Contact}');\n"; //display_name
                        //using (StreamWriter writer = new StreamWriter(pathL, true))
                        //{
                        //    writer.WriteLine(string.Format($"insert_dsq_user: {insert_dsq_user}\n"));
                        //    writer.Close();
                        //}
                        bool fgInset = DBConnMysql.ExecQueryInsert(insert_dsq_user);

                        if (fgInset)
                        {
                            string select_dsq_user = $"SELECT ID FROM dsq_users WHERE user_login = '{CURP}' AND user_email = '{MailAddress}' LIMIT 1";
                            //using (StreamWriter writer = new StreamWriter(pathL, true))
                            //{
                            //    writer.WriteLine(string.Format($"select_dsq_user: {select_dsq_user}\n"));
                            //    writer.Close();
                            //}
                            DataTable tbl_ID = DBConnMysql.ExecQuery(select_dsq_user);
                            string ID = tbl_ID != null && tbl_ID.Rows != null && tbl_ID.Rows.Count > 0 ? !string.IsNullOrEmpty(tbl_ID.Rows[0]["ID"].ToString()) ? tbl_ID.Rows[0]["ID"].ToString() : "0" : "0";

                            #region UPDATE SAP

                            string update_SAP = $"UPDATE {Utils.parseStringBD("zAdi_SyncLeadSAP")} SET {Utils.parseStringBD("flagSend")} = TRUE, {Utils.parseStringBD("dateSend")} = NOW(), {Utils.parseStringBD("idClient")} = {ID}";
                            update_SAP += $" WHERE {Utils.parseStringBD("idSyncLead")} = {idSyncLead}";
                            //using (StreamWriter writer = new StreamWriter(pathL, true))
                            //{
                            //    writer.WriteLine(string.Format($"update_SAP: {update_SAP}\n"));
                            //    writer.Close();
                            //}
                            DBConn.ExecQueryUpdate(update_SAP);
                            #endregion

                            string insert_meta = string.Empty;

                            string submitted = string.Empty;
                            submitted += "a:39:{s:13:\"billing_state\";s:" + State1.Length + ":\"" + State1 + "\";s:11:\"formadepago\";s:0:\"\";s:4:\"cfdi\";s:0:\"\";s:11:\"localfisico\";a:1:{i:0;s:0:\"\";}s:17:\"registromayorista\";a:1:{i:0;s:0:\"\";}";
                            submitted += "s:16:\"medio_publicidad\";s:0:\"\";s:17:\"lineas_de_interes\";a:1:{i:0;s:0:\"\";}s:14:\"area_actividad\";s:0:\"\";s:8:\"sucursal\";s:0:\"\";s:10:\"asesor_gdl\";s:0:\"\";s:11:";
                            submitted += "\"asesor_cdmx\";s:0:\"\";s:10:\"asesor_mty\";s:0:\"\";s:11:\"asesor_leon\";s:0:\"\";s:10:\"asesor_mer\";s:0:\"\";s:10:\"asesor_tij\";s:0:\"\";s:25:\"avisoprivacidadintegrador\";a:0:{}";
                            submitted += "s:7:\"form_id\";s:4:\"2545\";s:10:\"um_request\";s:0:\"\";s:8:\"_wpnonce\";s:10:\"b7a2f90052\";s:16:\"_wp_http_referer\";s:41:\"/clientes/solicitud-de-alta-distribuidor/\";s:16:\"_billing_company\";";
                            submitted += "s:" + CardName.Length + ":\"" + CardName + "\";s:8:\"nickname\";s:" + CardCode.Length + ":\"" + CardCode + "\";s:8:\"username\";s:" + CURP.Length + ":\"" + CURP + "\";s:18:\"_billing_address_1\";s:" + Address.Length + ":\"" + Address + "\";s:9:\"municipio\";s:" + City.Length + ":\"" + City + "\";";
                            submitted += "s:18:\"_billing_address_2\";s:" + Address_2.Length + ":\"" + Address_2 + "\";s:16:\"billing_postcode\";s:" + ZipCode.Length + ":\"" + ZipCode + "\";s:13:\"_billing_city\";s:" + City.Length + ":\"" + City + "\";s:14:\"_billing_email\";s:0:\"\";s:13:\"billing_phone\";";
                            submitted += "s:" + Phone1.Length + ":\"" + Phone1 + "\";s:12:\"cedulafiscal\";s:0:\"\";s:10:\"first_name\";s:21:\"dayan nombre completo\";s:10:\"user_email\";s:" + MailAddress.Length + ":\"" + MailAddress + "\";";
                            //submitted += "s:" + Phone1.Length + ":\"" + Phone1 + "\";s:12:\"cedulafiscal\";s:58:\"file_2d398ab0_9da2d7f267b2709257c9be78ce5b6d899a7d9e94.pdf\";s:10:\"first_name\";s:21:\"dayan nombre completo\";s:10:\"user_email\";s:" + MailAddress.Length + ":\"" + MailAddress + "\";";
                            submitted += "s:9:\"empleados\";s:0:\"\";s:4:\"giro\";s:0:\"\";s:16:\"nombremayoristas\";s:0:\"\";s:8:\"sitioweb\";s:0:\"\";s:10:\"user_login\";s:" + CURP.Length + ":\"" + CURP + "\";s:9:\"timestamp\";i:1619018814;}";

                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'nickname', '{CardCode}');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'first_name', '{Contact}');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'last_name', '');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'description', '');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'rich_editing', 'true');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'syntax_highlighting', 'true');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'comment_shortcuts', 'false');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'admin_color', 'fresh');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'use_ssl', '0');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'show_admin_bar_front', 'true');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'locale', '');\n";
                            insert_meta += "INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES(" + ID + ", 'dsq_capabilities', 'a:1:{s:" + ("customer").Length + ":\"customer\";b:1;}');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES(" + ID + ", 'dsq_user_level', '0');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'synced_gravatar_hashed_id', 'e6d7c26996107b630c5664826a7dafa3');\n";
                            insert_meta += "INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES(" + ID + ", 'um_member_directory_data', 'a:5:{s:14:\"account_status\";s:8:\"approved\"; s:15:\"hide_in_members\"; b:0;s:13:\"profile_photo\"; b:0;s:11:\"cover_photo\"; b:0;s:8:\"verified\"; b:0;}');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'submitted', '{submitted}');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'billing_state', '{State1}');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'formadepago', '');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'cfdi', '');\n";
                            insert_meta += "INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES(" + ID + ", 'localfisico', 'a:1:{i:0;s:0:\"\";}');\n";
                            insert_meta += "INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES(" + ID + ", 'registromayorista', 'a:1:{i:0;s:0:\"\";}');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'medio_publicidad', '');\n";
                            insert_meta += "INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES(" + ID + ", 'lineas_de_interes', 'a:1:{i:0;s:0:\"\";}');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'area_actividad', '');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'sucursal', '');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'asesor_gdl', '');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'asesor_cdmx', '');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'asesor_mty', '');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'asesor_leon', '');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'asesor_mer', '');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'asesor_tij', '');\n";
                            insert_meta += "INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES(" + ID + ", 'avisoprivacidadintegrador', 'a:0:{}');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'form_id', '2545');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'um_request', '');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, '_wpnonce', 'b7a2f90052');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, '_wp_http_referer', '/clientes/solicitud-de-alta-distribuidor/');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, '_billing_company', '{CardName}');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'username', '{CURP}');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, '_billing_address_1', '{Address}');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'municipio', '{City}');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, '_billing_address_2', '{Address_2}');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'billing_postcode', '{ZipCode}');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, '_billing_city', '{City}');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, '_billing_email', '');\n";
                            //insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, '_billing_email', '{MailAddress}');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'billing_phone', '{Phone1}');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'cedulafiscal', '');\n";
                            //insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'cedulafiscal', 'file_2d398ab0_9da2d7f267b2709257c9be78ce5b6d899a7d9e94.pdf');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'last_update', '1619116385');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'empleados', '');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'giro', '');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'nombremayoristas', '');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'sitioweb', '');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'timestamp', '1619018814');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'um_user_profile_url_slug_user_id', '2591');\n";
                            insert_meta += "INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES(" + ID + ", 'cedulafiscal_metadata', 'a:7:{s:4:\"name\";s:0:\"\";s:13:\"original_name\";s:0:\"\";s:8:\"basename\";s:0:\"\";s:3:\"ext\";s:3:\"pdf\";s:4:\"type\";s:15:\"application/pdf\";s:4:\"size\";i:178765;s:11:\"size_format\";s:0:\"\";}');\n";
                            //insert_meta += "INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES(" + ID + ", 'cedulafiscal_metadata', 'a:7:{s:4:\"name\";s:108:\"https://adises.link/wp-content/uploads/ultimatemember/temp/file_9da2d7f267b2709257c9be78ce5b6d899a7d9e94.pdf\";s:13:\"original_name\";s:15:\"SyncClients.pdf\";s:8:\"basename\";s:49:\"file_9da2d7f267b2709257c9be78ce5b6d899a7d9e94.pdf\";s:3:\"ext\";s:3:\"pdf\";s:4:\"type\";s:15:\"application/pdf\";s:4:\"size\";i:178765;s:11:\"size_format\";s:6:\"175 KB\";}');\n";
                            //insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES({ID}, 'account_status', 'awaiting_admin_review');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES ({ID}, 'billing_first_name', '{Contact}'); \n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES ({ID}, 'billing_last_name', ''); \n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES ({ID}, 'billing_company', '{CardName}'); \n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES ({ID}, 'billing_address_1', '{Address}'); \n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES ({ID}, 'billing_address_2', '{Address_2}'); \n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES ({ID}, 'billing_city', '{City}'); \n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES ({ID}, 'billing_country', '{Country}'); \n";
                            //insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES ({ID}, 'billing_email', '{MailAddress}'); \n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES ({ID}, 'billing_email', ''); \n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES ({ID}, 'shipping_first_name', ''); \n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES ({ID}, 'shipping_last_name', ''); \n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES ({ID}, 'shipping_company', ''); \n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES ({ID}, 'shipping_address_1', ''); \n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES ({ID}, 'shipping_address_2', ''); \n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES ({ID}, 'shipping_city', ''); \n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES ({ID}, 'shipping_postcode', ''); \n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES ({ID}, 'shipping_country', ''); \n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES ({ID}, 'shipping_state', ''); \n";
                            //para que el usaurio esté como aprobado.
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES ( {ID}, 'account_status', 'approved');\n";
                            insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES ( {ID}, 'wc_last_active', '1619049600');\n";
                            //insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES ( {ID}, '_um_last_login', '1619094953');\n";
                            //insert_meta += $"INSERT INTO dsq_usermeta(user_id, meta_key, meta_value) VALUES ( {ID}, 'wfls-last-login', '	1619116553');\n";

                            //using (StreamWriter writer = new StreamWriter(pathL, true))
                            //{
                            //    writer.WriteLine($"insert_meta: {insert_meta}\n");
                            //    writer.Close();
                            //}
                            DBConnMysql.ExecQueryInsert(insert_meta);
                        }
                        else
                        {
                            Utils.PrintLog("SyncClientsToWooCommerce", "0", $"No fue posible realizar la sincronización del cliente {CURP}");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("SyncClientsToWooCommerce", "1", ex.ToString());
            }
        }

        public string returnNameState(string CodeState)
        {
            try
            {
                #region UpdateState1
                if (string.IsNullOrEmpty(CodeState)) return "";
                string query_GetState = $@"SELECT TOP 1 {Utils.parseStringBD("Name")}";
                query_GetState += $" FROM {Utils.parseStringBD("OCST")}";
                query_GetState += $" WHERE {Utils.parseStringBD("Code")} = '{CodeState}'";

                DataTable tbl_State1 = DBConn.ExecQuery(query_GetState);
                if (tbl_State1 != null && tbl_State1.Rows != null && tbl_State1.Rows.Count > 0)
                    return tbl_State1.Rows[0]["Name"] != null && !string.IsNullOrEmpty(tbl_State1.Rows[0]["Name"].ToString()) ? tbl_State1.Rows[0]["Name"].ToString() : "";
                #endregion
                return "";

            }
            catch (Exception ex)
            {
                Utils.PrintLog("returnNameState", "1", ex.ToString());
                return "";
            }
        }

        public void SyncUpdateCustomersToWooCommerce()
        {
            //string pathL = "C:\\SyncUpdateClientsToWooCommerce.txt";
            try
            {

                //string select_SyncClient = $"SELECT TOP {Utils.RangoRegistros} * FROM {Utils.parseStringBD("zAdi_SyncLeadSAP")}  WHERE {Utils.parseStringBD("Action")} = '{Utils.UPDATE}' AND {Utils.parseStringBD("flagSend")} = FALSE AND {Utils.parseStringBD("FlagLead")} = FALSE";
                string select_SyncClient = $"SELECT TOP {Utils.RangoRegistros} * FROM {Utils.parseStringBD("zAdi_SyncLeadSAP")}  WHERE {Utils.parseStringBD("action")} = '{Utils.UPDATE}' AND {Utils.parseStringBD("flagSend")} = FALSE";
                //using (StreamWriter writer = new StreamWriter(pathL, true))
                //{
                //    writer.WriteLine(string.Format($"select_SyncClient: {select_SyncClient}\n"));
                //    writer.Close();
                //}
                DataTable tbl_SyncClient = DBConn.ExecQuery(select_SyncClient);
                if (tbl_SyncClient != null && tbl_SyncClient.Rows != null && tbl_SyncClient.Rows.Count > 0)
                {
                    foreach (DataRow item_client in tbl_SyncClient.Rows)
                    {
                        string idSyncLead = item_client["idSyncLead"] != null && !string.IsNullOrEmpty(item_client["idSyncLead"].ToString()) ? item_client["idSyncLead"].ToString() : "";
                        string CardCode = item_client["CardCode"] != null && !string.IsNullOrEmpty(item_client["CardCode"].ToString()) ? item_client["CardCode"].ToString() : "";
                        string CardName = item_client["CardName"] != null && !string.IsNullOrEmpty(item_client["CardName"].ToString()) ? item_client["CardName"].ToString() : "";
                        string CardType = item_client["CardType"] != null && !string.IsNullOrEmpty(item_client["CardType"].ToString()) ? item_client["CardType"].ToString() : "";
                        string Address = item_client["Address"] != null && !string.IsNullOrEmpty(item_client["Address"].ToString()) ? item_client["Address"].ToString() : "";
                        string Address_2 = item_client["Address_2"] != null && !string.IsNullOrEmpty(item_client["Address_2"].ToString()) ? item_client["Address_2"].ToString() : "";
                        string State1 = item_client["State1"] != null && !string.IsNullOrEmpty(item_client["State1"].ToString()) ? item_client["State1"].ToString() : "";
                        string ZipCode = item_client["ZipCode"] != null && !string.IsNullOrEmpty(item_client["ZipCode"].ToString()) ? item_client["ZipCode"].ToString() : "";
                        string MailAddress = item_client["MailAddress"] != null && !string.IsNullOrEmpty(item_client["MailAddress"].ToString()) ? item_client["MailAddress"].ToString() : "";
                        string Phone1 = item_client["Phone1"] != null && !string.IsNullOrEmpty(item_client["Phone1"].ToString()) ? item_client["Phone1"].ToString() : "";
                        string Contact = item_client["Contact"] != null && !string.IsNullOrEmpty(item_client["Contact"].ToString()) ? item_client["Contact"].ToString() : "";
                        string CURP = item_client["CURP"] != null && !string.IsNullOrEmpty(item_client["CURP"].ToString()) ? item_client["CURP"].ToString() : "";
                        string City = item_client["City"] != null && !string.IsNullOrEmpty(item_client["City"].ToString()) ? item_client["City"].ToString() : "";
                        string Country = item_client["Country"] != null && !string.IsNullOrEmpty(item_client["Country"].ToString()) ? item_client["Country"].ToString() : "";
                        string CreateDate = item_client["CreateDate"] != null && !string.IsNullOrEmpty(item_client["CreateDate"].ToString()) ? item_client["CreateDate"].ToString() : "";
                        string UpdateDate = item_client["UpdateDate"] != null && !string.IsNullOrEmpty(item_client["UpdateDate"].ToString()) ? item_client["UpdateDate"].ToString() : "";
                        string ID = item_client["idClient"] != null && !string.IsNullOrEmpty(item_client["idClient"].ToString()) ? item_client["idClient"].ToString() : "0";

                        string user_nicename = !string.IsNullOrEmpty(MailAddress) && MailAddress.Length > 0 ? MailAddress.Any(x => x == '@') ? MailAddress.Substring(0, MailAddress.IndexOf("@")) : "" : "";
                        string display_name = !string.IsNullOrEmpty(Contact) && Contact.Length > 0 ? (Contact.Any(x => x == ' ') ? (Contact.Substring(0, Contact.IndexOf(Contact.First(x => x == ' ')))) : Contact) : "";

                        /*dsq_users*/
                        string update_dsq_user = $"UPDATE dsq_users SET";
                        update_dsq_user += $" user_login = '{CURP}',";
                        update_dsq_user += $" user_nicename = '{user_nicename}',";
                        update_dsq_user += $" user_email = '{MailAddress}',";
                        //update_dsq_user += $"user_login = '{MailAddress}',";
                        update_dsq_user += $" display_name = '{Contact}'";
                        update_dsq_user += $" WHERE ID = {ID};\n";

                        string submitted = string.Empty;
                        submitted += "a:39:{s:13:\"billing_state\";s:" + State1.Length + ":\"" + State1 + "\";s:11:\"formadepago\";s:0:\"\";s:4:\"cfdi\";s:0:\"\";s:11:\"localfisico\";a:1:{i:0;s:0:\"\";}s:17:\"registromayorista\";a:1:{i:0;s:0:\"\";}";
                        submitted += "s:16:\"medio_publicidad\";s:0:\"\";s:17:\"lineas_de_interes\";a:1:{i:0;s:0:\"\";}s:14:\"area_actividad\";s:0:\"\";s:8:\"sucursal\";s:0:\"\";s:10:\"asesor_gdl\";s:0:\"\";s:11:";
                        submitted += "\"asesor_cdmx\";s:0:\"\";s:10:\"asesor_mty\";s:0:\"\";s:11:\"asesor_leon\";s:0:\"\";s:10:\"asesor_mer\";s:0:\"\";s:10:\"asesor_tij\";s:0:\"\";s:25:\"avisoprivacidadintegrador\";a:0:{}";
                        submitted += "s:7:\"form_id\";s:4:\"2545\";s:10:\"um_request\";s:0:\"\";s:8:\"_wpnonce\";s:10:\"b7a2f90052\";s:16:\"_wp_http_referer\";s:41:\"/clientes/solicitud-de-alta-distribuidor/\";s:16:\"_billing_company\";";
                        submitted += "s:" + CardName.Length + ":\"" + CardName + "\";s:8:\"nickname\";s:" + CardCode.Length + ":\"" + CardCode + "\";s:8:\"username\";s:" + CURP.Length + ":\"" + CURP + "\";s:18:\"_billing_address_1\";s:" + Address.Length + ":\"" + Address + "\";s:9:\"municipio\";s:" + City.Length + ":\"" + City + "\";";
                        submitted += "s:18:\"_billing_address_2\";s:" + Address_2.Length + ":\"" + Address_2 + "\";s:16:\"billing_postcode\";s:" + ZipCode.Length + ":\"" + ZipCode + "\";s:13:\"_billing_city\";s:" + City.Length + ":\"" + City + "\";s:14:\"_billing_email\";s:0:\"\";s:13:\"billing_phone\";";
                        submitted += "s:" + Phone1.Length + ":\"" + Phone1 + "\";s:12:\"cedulafiscal\";s:0:\"\";s:10:\"first_name\";s:21:\"dayan nombre completo\";s:10:\"user_email\";s:" + MailAddress.Length + ":\"" + MailAddress + "\";";
                        //submitted += "s:" + Phone1.Length + ":\"" + Phone1 + "\";s:12:\"cedulafiscal\";s:58:\"file_2d398ab0_9da2d7f267b2709257c9be78ce5b6d899a7d9e94.pdf\";s:10:\"first_name\";s:21:\"dayan nombre completo\";s:10:\"user_email\";s:" + MailAddress.Length + ":\"" + MailAddress + "\";";
                        submitted += "s:9:\"empleados\";s:0:\"\";s:4:\"giro\";s:0:\"\";s:16:\"nombremayoristas\";s:0:\"\";s:8:\"sitioweb\";s:0:\"\";s:10:\"user_login\";s:" + CURP.Length + ":\"" + CURP + "\";s:9:\"timestamp\";i:1619018814;}";
                        /*dsq_usermeta*/
                        update_dsq_user += $"UPDATE dsq_usermeta SET meta_value = '{CardCode}' WHERE meta_key = 'nickname' AND user_id = {ID};\n";
                        update_dsq_user += $"UPDATE dsq_usermeta SET meta_value = '{Contact}' WHERE meta_key = 'first_name' AND user_id = {ID};\n";
                        update_dsq_user += $"UPDATE dsq_usermeta SET meta_value = '{submitted}' WHERE meta_key = 'submitted' AND user_id = {ID};\n";
                        update_dsq_user += $"UPDATE dsq_usermeta SET meta_value = '{State1}' WHERE meta_key = 'billing_state' AND user_id = {ID};\n";
                        update_dsq_user += $"UPDATE dsq_usermeta SET meta_value = '{CardName}' WHERE meta_key = '_billing_company' AND user_id = {ID};\n";
                        update_dsq_user += $"UPDATE dsq_usermeta SET meta_value = '{CURP}' WHERE meta_key = 'username' AND user_id = {ID};\n";
                        update_dsq_user += $"UPDATE dsq_usermeta SET meta_value = '{Address}' WHERE meta_key = '_billing_address_1' AND user_id = {ID};\n";
                        update_dsq_user += $"UPDATE dsq_usermeta SET meta_value = '{City}' WHERE meta_key = 'municipio' AND user_id = {ID};\n";
                        update_dsq_user += $"UPDATE dsq_usermeta SET meta_value = '{Address_2}' WHERE meta_key = '_billing_address_2' AND user_id = {ID};\n";
                        update_dsq_user += $"UPDATE dsq_usermeta SET meta_value = '{ZipCode}' WHERE meta_key = 'billing_postcode' AND user_id = {ID};\n";
                        update_dsq_user += $"UPDATE dsq_usermeta SET meta_value = '{City}' WHERE meta_key = '_billing_city' AND user_id = {ID};\n";
                        //update_dsq_user += $"UPDATE dsq_usermeta SET meta_value = '{MailAddress}' WHERE meta_key = '_billing_email' AND user_id = {ID};\n";
                        //update_dsq_user += $"UPDATE dsq_usermeta SET meta_value = '{MailAddress}' WHERE meta_key = 'billing_email' AND user_id = {ID};\n";
                        update_dsq_user += $"UPDATE dsq_usermeta SET meta_value = '{Phone1}' WHERE meta_key = 'billing_phone' AND user_id = {ID};\n";
                        update_dsq_user += $"UPDATE dsq_usermeta SET meta_value = '{Contact}' WHERE meta_key = 'billing_first_name' AND user_id = {ID};\n";
                        update_dsq_user += $"UPDATE dsq_usermeta SET meta_value = '{Contact}' WHERE meta_key = 'billing_first_name' AND user_id = {ID};\n";
                        update_dsq_user += $"UPDATE dsq_usermeta SET meta_value = '{CardName}' WHERE meta_key = 'billing_company' AND user_id = {ID};\n";
                        update_dsq_user += $"UPDATE dsq_usermeta SET meta_value = '{Address}' WHERE meta_key = 'billing_address_1' AND user_id = {ID};\n";
                        update_dsq_user += $"UPDATE dsq_usermeta SET meta_value = '{Address_2}' WHERE meta_key = 'billing_address_2' AND user_id = {ID};\n";
                        update_dsq_user += $"UPDATE dsq_usermeta SET meta_value = '{City}' WHERE meta_key = 'billing_city' AND user_id = {ID};\n";
                        update_dsq_user += $"UPDATE dsq_usermeta SET meta_value = '{Country}' WHERE meta_key = 'billing_country' AND user_id = {ID};\n";


                        //update_dsq_user += $"UPDATE dsq_usermeta SET meta_value = '{City}' WHERE meta_key = 'City' AND user_id = {ID};\n";

                        try
                        {
                            //using (StreamWriter writer = new StreamWriter(pathL, true))
                            //{
                            //    writer.WriteLine($"update_dsq_user: {update_dsq_user}\n");
                            //    writer.Close();
                            //}
                            DBConnMysql.ExecQueryUpdate(update_dsq_user);

                            string update_SAP = $"UPDATE {Utils.parseStringBD("zAdi_SyncLeadSAP")} SET {Utils.parseStringBD("flagSend")} = TRUE, {Utils.parseStringBD("dateSend")} = NOW()";
                            update_SAP += $" WHERE {Utils.parseStringBD("idSyncLead")} = {idSyncLead}";
                            //using (StreamWriter writer = new StreamWriter(pathL, true))
                            //{
                            //    writer.WriteLine(string.Format($"update_SAP: {update_SAP}\n"));
                            //    writer.Close();
                            //}
                            DBConn.ExecQueryUpdate(update_SAP);
                        }
                        catch (Exception ex)
                        {
                            Utils.PrintLog("SyncUpdateClientsToWooCommerce", "2", ex.ToString());
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("SyncUpdateClientsToWooCommerce", "1", ex.ToString());
            }
        }

        #region generar contrasenia

        static string MD5Encode(string password)
        {
            string output = "*0";
            string hash = "$P$BeqnB1m75e1BOiB6Zpvtl48EO4ylPX0."; //Contraseña por default
            if (hash == null)
            {
                return output;
            }

            if (hash.StartsWith(output))
                output = "*1";

            string id = hash.Substring(0, 3);
            // We use "$P$", phpBB3 uses "$H$" for the same thing
            if (id != "$P$" && id != "$H$")
                return output;

            // get who many times will generate the hash
            int count_log2 = itoa64.IndexOf(hash[3]);
            if (count_log2 < 7 || count_log2 > 30)
                return output;

            int count = 1 << count_log2;

            string salt = hash.Substring(4, 8);
            if (salt.Length != 8)
                return output;

            byte[] hashBytes = { };
            using (MD5 md5Hash = MD5.Create())
            {
                hashBytes = md5Hash.ComputeHash(Encoding.ASCII.GetBytes(salt + password));
                byte[] passBytes = Encoding.ASCII.GetBytes(password);
                do
                {
                    hashBytes = md5Hash.ComputeHash(hashBytes.Concat(passBytes).ToArray());
                } while (--count > 0);
            }

            output = hash.Substring(0, 12);
            string newHash = Encode64(hashBytes, 16);

            return output + newHash;
        }

        static string Encode64(byte[] input, int count)
        {
            StringBuilder sb = new StringBuilder();
            int i = 0;
            do
            {
                int value = (int)input[i++];
                sb.Append(itoa64[value & 0x3f]); // to uppercase
                if (i < count)
                    value = value | ((int)input[i] << 8);
                sb.Append(itoa64[(value >> 6) & 0x3f]);
                if (i++ >= count)
                    break;
                if (i < count)
                    value = value | ((int)input[i] << 16);
                sb.Append(itoa64[(value >> 12) & 0x3f]);
                if (i++ >= count)
                    break;
                sb.Append(itoa64[(value >> 18) & 0x3f]);
            } while (i < count);

            return sb.ToString();
        }

        #endregion
        #endregion
        public static Customers getInstance => new Customers();
    }
}
