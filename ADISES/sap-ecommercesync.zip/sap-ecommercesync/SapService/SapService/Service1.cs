﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Threading;
using System.IO;
using SAP_LIB.Models;
using SAP_LIB.Controllers;
using System.Text.RegularExpressions;
using System.Globalization;
using System.Security.Cryptography;
using SapService.Modules;

namespace SapService
{
    public partial class Service1 : ServiceBase
    {
       
        int scheduleTime = Convert.ToInt32(ConfigurationSettings.AppSettings["ThreadTime"].ToString());
        Thread Worker = null;
        DateTime? dt_tpCambio = null;
        
        public Service1()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            try
            {
                Utils.tpConfiguration = TipoConfiguracion.Productos.ToString();
                ThreadStart start = new ThreadStart(Working);
                Worker = new Thread(start);
                Worker.Start();
            }
            catch (Exception ex)
            {

            }
        }

        private void Working()
        {
            while (true)
            {
                Utils.getParametersConfig();

                if (Utils.RangoRegistros > 0 && Utils.interval > 0)
                {
                    //PriceRules.getInstance.updateId();

                    #region EXCHANGE RATE
                    sync_tpCambio();
                    #endregion

                    #region PRODUCTS
                    Products.getInstance.RegisterProductToLog_v2();
                    Products.getInstance.SyncProductsToWooCommerce_v2();
                    Products.getInstance.SyncUpdateProductsToWoocommerce_v2();
                    #endregion

                    #region INVENTORY
                    Products.getInstance.RegisterLogInventory_v2();
                    Products.getInstance.SyncInventoryToWooCommerce_v2();
                    Products.getInstance.SyncUpdateInvToWooCommerce_v2();

                    #endregion

                    #region PRICING

                    #region DESC_CLI_MARCA_PROD
                    PriceRules.getInstance.RegisterLogPricing_DESC_CLI_MARCA_PROD();
                    PriceRules.getInstance.SyncPricing_DESC_CLI_MARCA_PROD();
                    PriceRules.getInstance.SyncPricingUpdate_DESC_CLI_MARCA_PROD();
                    #endregion
                    #region DESC_PROD_PER_CANT
                    PriceRules.getInstance.RegisterLogPricing_DESC_PROD_PER_CANT();
                    PriceRules.getInstance.SyncPricing_DESC_PROD_PER_CANT();
                    PriceRules.getInstance.SyncPricingUpdate_DESC_PROD_PER_CANT();
                    #endregion
                    #region DESC_BY_MARCA
                    PriceRules.getInstance.RegisterLogPricingDESC_BY_MARCA();
                    PriceRules.getInstance.SyncPricing_BY_MARCA();
                    PriceRules.getInstance.SyncPricingUpdate_DESC_BY_MARCA();
                    #endregion

                    PriceRules.getInstance.SyncPricingDelete();
                    #endregion

                    #region ORDERS
                    //Orders.getInstance.RegisterFromMysqlBitacoraToSap();
                    //Orders.getInstance.SyncLogsToOrders();
                    //Orders.getInstance.SynUpdateOrdersToWooCommerce();
                    #endregion

                    #region LEADS
                    Leads.getInstance.RegisterLeadsBitacoraToSap();
                    Leads.getInstance.InsertNativeLead(0);
                    #endregion

                    #region CLIENTS
                    Customers.getInstance.RegisterToLogCustomers();
                    Customers.getInstance.SyncCustomersToWooCommerce();
                    Customers.getInstance.SyncUpdateCustomersToWooCommerce();
                    #endregion


                    Utils.clearParameters();
                }

                Thread.Sleep((Utils.interval > 0 ? Utils.interval : this.scheduleTime) * 60 * 1000);
                //Thread.Sleep(30000);
            }
        }

        protected override void OnStop()
        {
            try
            {
                if ((Worker != null) && Worker.IsAlive)
                {
                    Worker.Abort();
                }
            }
            catch (Exception ex)
            {

            }
        }

        #region EXCHANGE RATE

        private void sync_tpCambio()
        {
            try
            {

                if (dt_tpCambio == null)
                    dt_tpCambio = DateTime.Now;
                else
                {
                    if (dt_tpCambio.Value.ToShortDateString() == DateTime.Now.ToShortDateString())
                        return;
                    else
                        dt_tpCambio = DateTime.Now;
                }

                string query_TC_Comercial = $"SELECT TOP 1 {Utils.parseStringBD("U_Fecha")}, {Utils.parseStringBD("U_TC_Comercial")} FROM {Utils.parseStringBD("@TC_COMERCIAL")} ORDER BY TO_DATE(REPLACE(REPLACE({Utils.parseStringBD("U_Fecha")}, '/', ''), '-', ''), 'DDMMYYYY') DESC";
                DataTable tbl_tc_comercial = DBConn.ExecQuery(query_TC_Comercial);
                string tc_Comercial = tbl_tc_comercial != null && tbl_tc_comercial.Rows != null && tbl_tc_comercial.Rows.Count > 0 ? tbl_tc_comercial.Rows[0]["U_TC_Comercial"].ToString() : "1";
                string fe_tc_Comercial = tbl_tc_comercial != null && tbl_tc_comercial.Rows != null && tbl_tc_comercial.Rows.Count > 0 ? tbl_tc_comercial.Rows[0]["U_Fecha"].ToString() : "";
                fe_tc_Comercial = fe_tc_Comercial.Replace("-", "/");

                //tc_Comercial = "25.56";

                string option_valuechangeCurrency = string.Empty;
                option_valuechangeCurrency += "a:39:{s:6:\"enable\";s:1:\"1\";s:14:\"price_switcher\";s:1:\"2\";s:28:\"enable_switch_currency_by_js\";s:1:\"1\";s:16:\"currency_default\";s:3:\"USD\";";
                option_valuechangeCurrency += "s:15:\"currency_hidden\";a:2:{i:0;s:1:\"0\";i:1;s:1:\"0\";}s:8:\"currency\";a:2:{i:0;s:3:\"USD\";i:1;s:3:\"MXN\";}s:12:\"currency_pos\";";
                option_valuechangeCurrency += "a:2:{i:0;s:4:\"left\";i:1;s:4:\"left\";}s:13:\"currency_rate\";a:2:{i:0;s:1:\"1\";i:1;s:" + tc_Comercial.Length + ":\"" + tc_Comercial + "\";}s:17:\"currency_rate_fee\";";
                option_valuechangeCurrency += "a:2:{i:0;s:1:\"0\";i:1;s:1:\"0\";}s:22:\"currency_rate_fee_type\";a:2:{i:0;s:5:\"fixed\";i:1;s:5:\"fixed\";}s:17:\"currency_decimals\";";
                option_valuechangeCurrency += "a:2:{i:0;s:1:\"2\";i:1;s:1:\"2\";}s:15:\"currency_custom\";a:2:{i:0;s:5:\"USD $\";i:1;s:5:\"MXN $\";}s:11:\"auto_detect\";s:1:\"0\";";
                option_valuechangeCurrency += "s:19:\"approximately_label\";s:14:\"Approximately:\";s:22:\"approximately_priority\";s:1:\"0\";s:7:\"geo_api\";s:1:\"0\";s:12:\"design_title\";";
                option_valuechangeCurrency += "s:14:\"Tipo de cambio\";s:15:\"design_position\";s:1:\"1\";s:10:\"max_height\";s:0:\"\";s:10:\"text_color\";s:7:\"#ffffff\";s:13:\"sidebar_style\";";
                option_valuechangeCurrency += "s:1:\"0\";s:10:\"main_color\";s:7:\"#177cb0\";s:16:\"background_color\";s:7:\"#212121\";s:16:\"conditional_tags\";s:0:\"\";s:11:\"flag_custom\";";
                option_valuechangeCurrency += "s:0:\"\";s:15:\"shortcode_color\";s:7:\"#212121\";s:18:\"shortcode_bg_color\";s:7:\"#ffffff\";s:22:\"shortcode_active_color\";s:7:\"#212121\";";
                option_valuechangeCurrency += "s:25:\"shortcode_active_bg_color\";s:7:\"#ffffff\";s:10:\"custom_css\";s:0:\"\";s:17:\"checkout_currency\";s:3:\"USD\";s:22:\"checkout_currency_args\";";
                option_valuechangeCurrency += "a:2:{i:0;s:1:\"0\";i:1;s:3:\"USD\";}s:31:\"currency_by_payment_method_bacs\";s:0:\"\";s:25:\"billing_shipping_currency\";s:1:\"0\";s:20:\"update_exchange_rate\";";
                option_valuechangeCurrency += "s:1:\"0\";s:11:\"finance_api\";s:1:\"0\";s:13:\"rate_decimals\";s:1:\"3\";s:12:\"email_custom\";s:0:\"\";s:3:\"key\";s:0:\"\";}";

                string update_tc = $"UPDATE dsq_options SET option_value = '{option_valuechangeCurrency}' WHERE option_name = 'woo_multi_currency_params'";
                bool fgUpdate = DBConnMysql.ExecQueryUpdate(update_tc);
                if (!fgUpdate)
                    Utils.PrintLog("sync_tpCambio", "0", $"No es posible actualizar el tipo de cambio.\n query: {update_tc}");
                else
                    Utils.PrintLog("sync_tpCambio", "0", "update correcto.");

            }
            catch (Exception ex)
            {
                Utils.PrintLog("sync_tpCambio", "1", ex.ToString());
            }
        }

        #endregion

    }
}
