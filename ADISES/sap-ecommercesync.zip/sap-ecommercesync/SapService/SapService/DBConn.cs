﻿using Sap.Data.Hana;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SapService
{
    public class DBConn
    {
        public static DBConn getInstance() => new DBConn();

        private HanaConnection hanaConnection;
        private bool OpenConnection()
        {
            bool fgConnection = false;

            try
            {
                this.hanaConnection = new HanaConnection(System.Configuration.ConfigurationManager.ConnectionStrings["Hana"].ConnectionString);
                this.hanaConnection.Open();
                Console.WriteLine("Conexión realizada con éxito.");
                fgConnection = true;
            }
            catch (HanaException ex)
            {
                Console.WriteLine(ex.ToString());
                fgConnection = false;
            }

            return fgConnection;
        }
        private bool CloseConnection()
        {
            bool fgClose = false;

            try
            {
                if (this.hanaConnection != null)
                {
                    this.hanaConnection.Close();
                    Console.Write("Conexión cerrada con éxito.");
                    fgClose = true;
                }
            }
            catch (HanaException ex)
            {
                Console.Write(ex.ToString());
                fgClose = false;
            }

            return fgClose;
        }
        public DataTable ExecQuery(string query)
        {
            DataTable result = new DataTable();

            if (!this.OpenConnection())
            {
                Console.WriteLine("No es posible conectar con la base de datos.");
                return (DataTable)null;
            }

            HanaDataAdapter hanaDataAdapter = new HanaDataAdapter(query, hanaConnection);
            hanaDataAdapter.Fill(result);
            this.CloseConnection();
            return result;
        }
        public bool ExecQueryInsert(string query)
        {
            if (!this.OpenConnection())
            {
                Console.WriteLine("No es posible conectar con la base de datos.");
                return false;
            }

            try
            {
                HanaCommand hanaCommand = new HanaCommand(query, this.hanaConnection);
                hanaCommand.CommandType = CommandType.Text;
                hanaCommand.ExecuteNonQuery();
                this.CloseConnection();
                return true;
            }
            catch (HanaException ex)
            {
                Console.Write(ex.ToString());
                return false;
            }

            return true;
        }
        public bool ExecQueryDelete(string query)
        {
            if (!this.OpenConnection())
            {
                Console.WriteLine("No es posible conectar con la base de datos.");
                return false;
            }

            try
            {
                HanaCommand hanaCommand = new HanaCommand(query, this.hanaConnection);
                hanaCommand.CommandType = CommandType.Text;
                hanaCommand.ExecuteNonQuery();
                this.CloseConnection();
                return true;
            }
            catch (HanaException ex)
            {
                Console.Write(ex.ToString());
                return false;
            }

            return true;
        }
        public bool ExecQueryUpdate(string query)
        {
            if (!this.OpenConnection())
            {
                Console.WriteLine("No es posible conectar con la base de datos.");
                return false;
            }

            try
            {
                HanaCommand hanaCommand = new HanaCommand(query, this.hanaConnection);
                hanaCommand.CommandType = CommandType.Text;
                hanaCommand.ExecuteNonQuery();
                this.CloseConnection();
                return true;
            }
            catch (HanaException ex)
            {
                Console.Write(ex.ToString());
                return false;
            }

            return true;
        }
    }
}
