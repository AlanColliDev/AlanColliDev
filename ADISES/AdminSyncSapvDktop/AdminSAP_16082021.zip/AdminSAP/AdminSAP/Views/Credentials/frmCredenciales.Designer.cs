﻿namespace AdminSAP.Views.Credentials
{
    partial class frmCredenciales
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lblCerrar = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtDirectorio = new MetroFramework.Controls.MetroTextBox();
            this.txtServidor = new MetroFramework.Controls.MetroTextBox();
            this.txtBaseDatos = new MetroFramework.Controls.MetroTextBox();
            this.txtUsuario = new MetroFramework.Controls.MetroTextBox();
            this.txtContrasenia = new MetroFramework.Controls.MetroTextBox();
            this.btnCancelar = new MetroFramework.Controls.MetroButton();
            this.btnGuardar = new MetroFramework.Controls.MetroButton();
            this.btnProbarConexión = new MetroFramework.Controls.MetroButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.label12 = new System.Windows.Forms.Label();
            this.txtBdBit = new MetroFramework.Controls.MetroTextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.label7 = new System.Windows.Forms.Label();
            this.btnProbarConexionMysql = new MetroFramework.Controls.MetroButton();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtServidorMysql = new MetroFramework.Controls.MetroTextBox();
            this.txtBaseDatosMysql = new MetroFramework.Controls.MetroTextBox();
            this.txtUsuarioMysql = new MetroFramework.Controls.MetroTextBox();
            this.txtContraseniaMysql = new MetroFramework.Controls.MetroTextBox();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label11 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txtCvSecreta = new MetroFramework.Controls.MetroTextBox();
            this.txtUrl = new MetroFramework.Controls.MetroTextBox();
            this.txtCvCliente = new MetroFramework.Controls.MetroTextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoSize = true;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.lblCerrar, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.Padding = new System.Windows.Forms.Padding(0, 5, 0, 5);
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1325, 39);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // lblCerrar
            // 
            this.lblCerrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCerrar.AutoSize = true;
            this.lblCerrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblCerrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCerrar.Location = new System.Drawing.Point(1291, 5);
            this.lblCerrar.Name = "lblCerrar";
            this.lblCerrar.Size = new System.Drawing.Size(31, 29);
            this.lblCerrar.TabIndex = 0;
            this.lblCerrar.Text = "X";
            this.lblCerrar.Click += new System.EventHandler(this.lblCerrar_Click);
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(1282, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Credenciales";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(650, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Directorio*";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(476, 17);
            this.label3.TabIndex = 1;
            this.label3.Text = "Servidor*";
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(319, 17);
            this.label4.TabIndex = 1;
            this.label4.Text = "Base de datos primaria*";
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 106);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(476, 17);
            this.label5.TabIndex = 1;
            this.label5.Text = "Usuario*";
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 159);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(476, 17);
            this.label6.TabIndex = 1;
            this.label6.Text = "Contraseña*";
            // 
            // txtDirectorio
            // 
            this.txtDirectorio.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel6.SetColumnSpan(this.txtDirectorio, 2);
            // 
            // 
            // 
            this.txtDirectorio.CustomButton.Image = null;
            this.txtDirectorio.CustomButton.Location = new System.Drawing.Point(1279, 2);
            this.txtDirectorio.CustomButton.Name = "";
            this.txtDirectorio.CustomButton.Size = new System.Drawing.Size(25, 25);
            this.txtDirectorio.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtDirectorio.CustomButton.TabIndex = 1;
            this.txtDirectorio.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtDirectorio.CustomButton.UseSelectable = true;
            this.txtDirectorio.CustomButton.Visible = false;
            this.txtDirectorio.Lines = new string[0];
            this.txtDirectorio.Location = new System.Drawing.Point(3, 20);
            this.txtDirectorio.MaxLength = 32767;
            this.txtDirectorio.Name = "txtDirectorio";
            this.txtDirectorio.PasswordChar = '\0';
            this.txtDirectorio.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtDirectorio.SelectedText = "";
            this.txtDirectorio.SelectionLength = 0;
            this.txtDirectorio.SelectionStart = 0;
            this.txtDirectorio.ShortcutsEnabled = true;
            this.txtDirectorio.Size = new System.Drawing.Size(1307, 30);
            this.txtDirectorio.TabIndex = 2;
            this.txtDirectorio.UseSelectable = true;
            this.txtDirectorio.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtDirectorio.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtServidor
            // 
            this.txtServidor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel4.SetColumnSpan(this.txtServidor, 2);
            // 
            // 
            // 
            this.txtServidor.CustomButton.Image = null;
            this.txtServidor.CustomButton.Location = new System.Drawing.Point(616, 2);
            this.txtServidor.CustomButton.Name = "";
            this.txtServidor.CustomButton.Size = new System.Drawing.Size(25, 25);
            this.txtServidor.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtServidor.CustomButton.TabIndex = 1;
            this.txtServidor.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtServidor.CustomButton.UseSelectable = true;
            this.txtServidor.CustomButton.Visible = false;
            this.txtServidor.Lines = new string[0];
            this.txtServidor.Location = new System.Drawing.Point(3, 20);
            this.txtServidor.MaxLength = 32767;
            this.txtServidor.Name = "txtServidor";
            this.txtServidor.PasswordChar = '\0';
            this.txtServidor.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtServidor.SelectedText = "";
            this.txtServidor.SelectionLength = 0;
            this.txtServidor.SelectionStart = 0;
            this.txtServidor.ShortcutsEnabled = true;
            this.txtServidor.Size = new System.Drawing.Size(644, 30);
            this.txtServidor.TabIndex = 1;
            this.txtServidor.UseSelectable = true;
            this.txtServidor.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtServidor.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtBaseDatos
            // 
            this.txtBaseDatos.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            // 
            // 
            // 
            this.txtBaseDatos.CustomButton.Image = null;
            this.txtBaseDatos.CustomButton.Location = new System.Drawing.Point(291, 2);
            this.txtBaseDatos.CustomButton.Name = "";
            this.txtBaseDatos.CustomButton.Size = new System.Drawing.Size(25, 25);
            this.txtBaseDatos.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtBaseDatos.CustomButton.TabIndex = 1;
            this.txtBaseDatos.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtBaseDatos.CustomButton.UseSelectable = true;
            this.txtBaseDatos.CustomButton.Visible = false;
            this.txtBaseDatos.Lines = new string[0];
            this.txtBaseDatos.Location = new System.Drawing.Point(3, 20);
            this.txtBaseDatos.MaxLength = 32767;
            this.txtBaseDatos.Name = "txtBaseDatos";
            this.txtBaseDatos.PasswordChar = '\0';
            this.txtBaseDatos.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtBaseDatos.SelectedText = "";
            this.txtBaseDatos.SelectionLength = 0;
            this.txtBaseDatos.SelectionStart = 0;
            this.txtBaseDatos.ShortcutsEnabled = true;
            this.txtBaseDatos.Size = new System.Drawing.Size(319, 30);
            this.txtBaseDatos.TabIndex = 1;
            this.txtBaseDatos.UseSelectable = true;
            this.txtBaseDatos.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtBaseDatos.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtUsuario
            // 
            this.txtUsuario.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel4.SetColumnSpan(this.txtUsuario, 2);
            // 
            // 
            // 
            this.txtUsuario.CustomButton.Image = null;
            this.txtUsuario.CustomButton.Location = new System.Drawing.Point(616, 2);
            this.txtUsuario.CustomButton.Name = "";
            this.txtUsuario.CustomButton.Size = new System.Drawing.Size(25, 25);
            this.txtUsuario.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtUsuario.CustomButton.TabIndex = 1;
            this.txtUsuario.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtUsuario.CustomButton.UseSelectable = true;
            this.txtUsuario.CustomButton.Visible = false;
            this.txtUsuario.Lines = new string[0];
            this.txtUsuario.Location = new System.Drawing.Point(3, 126);
            this.txtUsuario.MaxLength = 32767;
            this.txtUsuario.Name = "txtUsuario";
            this.txtUsuario.PasswordChar = '\0';
            this.txtUsuario.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtUsuario.SelectedText = "";
            this.txtUsuario.SelectionLength = 0;
            this.txtUsuario.SelectionStart = 0;
            this.txtUsuario.ShortcutsEnabled = true;
            this.txtUsuario.Size = new System.Drawing.Size(644, 30);
            this.txtUsuario.TabIndex = 3;
            this.txtUsuario.UseSelectable = true;
            this.txtUsuario.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtUsuario.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtContrasenia
            // 
            this.txtContrasenia.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel4.SetColumnSpan(this.txtContrasenia, 2);
            // 
            // 
            // 
            this.txtContrasenia.CustomButton.Image = null;
            this.txtContrasenia.CustomButton.Location = new System.Drawing.Point(616, 2);
            this.txtContrasenia.CustomButton.Name = "";
            this.txtContrasenia.CustomButton.Size = new System.Drawing.Size(25, 25);
            this.txtContrasenia.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtContrasenia.CustomButton.TabIndex = 1;
            this.txtContrasenia.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtContrasenia.CustomButton.UseSelectable = true;
            this.txtContrasenia.CustomButton.Visible = false;
            this.txtContrasenia.Lines = new string[0];
            this.txtContrasenia.Location = new System.Drawing.Point(3, 179);
            this.txtContrasenia.MaxLength = 32767;
            this.txtContrasenia.Name = "txtContrasenia";
            this.txtContrasenia.PasswordChar = '●';
            this.txtContrasenia.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtContrasenia.SelectedText = "";
            this.txtContrasenia.SelectionLength = 0;
            this.txtContrasenia.SelectionStart = 0;
            this.txtContrasenia.ShortcutsEnabled = true;
            this.txtContrasenia.Size = new System.Drawing.Size(644, 30);
            this.txtContrasenia.TabIndex = 4;
            this.txtContrasenia.UseSelectable = true;
            this.txtContrasenia.UseSystemPasswordChar = true;
            this.txtContrasenia.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtContrasenia.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // btnCancelar
            // 
            this.btnCancelar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancelar.Location = new System.Drawing.Point(1179, 694);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(134, 30);
            this.btnCancelar.TabIndex = 7;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseSelectable = true;
            // 
            // btnGuardar
            // 
            this.btnGuardar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnGuardar.Location = new System.Drawing.Point(1039, 694);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(134, 30);
            this.btnGuardar.TabIndex = 6;
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.UseSelectable = true;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // btnProbarConexión
            // 
            this.btnProbarConexión.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnProbarConexión.Location = new System.Drawing.Point(485, 215);
            this.btnProbarConexión.Name = "btnProbarConexión";
            this.btnProbarConexión.Size = new System.Drawing.Size(162, 30);
            this.btnProbarConexión.TabIndex = 5;
            this.btnProbarConexión.Text = "Probar conexión";
            this.btnProbarConexión.UseSelectable = true;
            this.btnProbarConexión.Click += new System.EventHandler(this.btnProbarConexión_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.AutoSize = true;
            this.groupBox1.Controls.Add(this.tableLayoutPanel4);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(3, 83);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(656, 269);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Credenciales SAP";
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.AutoSize = true;
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel4.Controls.Add(this.label3, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.btnProbarConexión, 1, 7);
            this.tableLayoutPanel4.Controls.Add(this.label6, 0, 5);
            this.tableLayoutPanel4.Controls.Add(this.txtContrasenia, 0, 6);
            this.tableLayoutPanel4.Controls.Add(this.label5, 0, 3);
            this.tableLayoutPanel4.Controls.Add(this.txtUsuario, 0, 4);
            this.tableLayoutPanel4.Controls.Add(this.txtServidor, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel7, 0, 2);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 18);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 8;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(650, 248);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.AutoSize = true;
            this.tableLayoutPanel7.ColumnCount = 2;
            this.tableLayoutPanel4.SetColumnSpan(this.tableLayoutPanel7, 2);
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.Controls.Add(this.label4, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.label12, 1, 0);
            this.tableLayoutPanel7.Controls.Add(this.txtBaseDatos, 0, 1);
            this.tableLayoutPanel7.Controls.Add(this.txtBdBit, 1, 1);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(0, 53);
            this.tableLayoutPanel7.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 2;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel7.Size = new System.Drawing.Size(650, 53);
            this.tableLayoutPanel7.TabIndex = 2;
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(328, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(319, 17);
            this.label12.TabIndex = 1;
            this.label12.Text = "Base de datos de bitácoras*";
            // 
            // txtBdBit
            // 
            this.txtBdBit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            // 
            // 
            // 
            this.txtBdBit.CustomButton.Image = null;
            this.txtBdBit.CustomButton.Location = new System.Drawing.Point(291, 2);
            this.txtBdBit.CustomButton.Name = "";
            this.txtBdBit.CustomButton.Size = new System.Drawing.Size(25, 25);
            this.txtBdBit.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtBdBit.CustomButton.TabIndex = 1;
            this.txtBdBit.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtBdBit.CustomButton.UseSelectable = true;
            this.txtBdBit.CustomButton.Visible = false;
            this.txtBdBit.Lines = new string[0];
            this.txtBdBit.Location = new System.Drawing.Point(328, 20);
            this.txtBdBit.MaxLength = 32767;
            this.txtBdBit.Name = "txtBdBit";
            this.txtBdBit.PasswordChar = '\0';
            this.txtBdBit.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtBdBit.SelectedText = "";
            this.txtBdBit.SelectionLength = 0;
            this.txtBdBit.SelectionStart = 0;
            this.txtBdBit.ShortcutsEnabled = true;
            this.txtBdBit.Size = new System.Drawing.Size(319, 30);
            this.txtBdBit.TabIndex = 2;
            this.txtBdBit.UseSelectable = true;
            this.txtBdBit.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtBdBit.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // groupBox2
            // 
            this.groupBox2.AutoSize = true;
            this.groupBox2.Controls.Add(this.tableLayoutPanel3);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox2.Location = new System.Drawing.Point(665, 83);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(657, 263);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Credenciales WooCommerce";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.AutoSize = true;
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.Controls.Add(this.label7, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.btnProbarConexionMysql, 1, 8);
            this.tableLayoutPanel3.Controls.Add(this.label8, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.label9, 0, 4);
            this.tableLayoutPanel3.Controls.Add(this.label10, 0, 6);
            this.tableLayoutPanel3.Controls.Add(this.txtServidorMysql, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.txtBaseDatosMysql, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.txtUsuarioMysql, 0, 5);
            this.tableLayoutPanel3.Controls.Add(this.txtContraseniaMysql, 0, 7);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 18);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 9;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.Size = new System.Drawing.Size(651, 242);
            this.tableLayoutPanel3.TabIndex = 0;
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(477, 17);
            this.label7.TabIndex = 1;
            this.label7.Text = "Servidor*";
            // 
            // btnProbarConexionMysql
            // 
            this.btnProbarConexionMysql.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnProbarConexionMysql.Location = new System.Drawing.Point(486, 209);
            this.btnProbarConexionMysql.Name = "btnProbarConexionMysql";
            this.btnProbarConexionMysql.Size = new System.Drawing.Size(162, 30);
            this.btnProbarConexionMysql.TabIndex = 5;
            this.btnProbarConexionMysql.Text = "Probar conexión";
            this.btnProbarConexionMysql.UseSelectable = true;
            this.btnProbarConexionMysql.Click += new System.EventHandler(this.btnProbarConexionMysql_Click);
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(3, 53);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(477, 17);
            this.label8.TabIndex = 1;
            this.label8.Text = "Base de datos*";
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(3, 103);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(477, 17);
            this.label9.TabIndex = 1;
            this.label9.Text = "Usuario*";
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(3, 153);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(477, 17);
            this.label10.TabIndex = 1;
            this.label10.Text = "Contraseña*";
            // 
            // txtServidorMysql
            // 
            this.txtServidorMysql.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel3.SetColumnSpan(this.txtServidorMysql, 2);
            // 
            // 
            // 
            this.txtServidorMysql.CustomButton.Image = null;
            this.txtServidorMysql.CustomButton.Location = new System.Drawing.Point(617, 2);
            this.txtServidorMysql.CustomButton.Name = "";
            this.txtServidorMysql.CustomButton.Size = new System.Drawing.Size(25, 25);
            this.txtServidorMysql.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtServidorMysql.CustomButton.TabIndex = 1;
            this.txtServidorMysql.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtServidorMysql.CustomButton.UseSelectable = true;
            this.txtServidorMysql.CustomButton.Visible = false;
            this.txtServidorMysql.Lines = new string[0];
            this.txtServidorMysql.Location = new System.Drawing.Point(3, 20);
            this.txtServidorMysql.MaxLength = 32767;
            this.txtServidorMysql.Name = "txtServidorMysql";
            this.txtServidorMysql.PasswordChar = '\0';
            this.txtServidorMysql.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtServidorMysql.SelectedText = "";
            this.txtServidorMysql.SelectionLength = 0;
            this.txtServidorMysql.SelectionStart = 0;
            this.txtServidorMysql.ShortcutsEnabled = true;
            this.txtServidorMysql.Size = new System.Drawing.Size(645, 30);
            this.txtServidorMysql.TabIndex = 1;
            this.txtServidorMysql.UseSelectable = true;
            this.txtServidorMysql.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtServidorMysql.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtBaseDatosMysql
            // 
            this.txtBaseDatosMysql.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel3.SetColumnSpan(this.txtBaseDatosMysql, 2);
            // 
            // 
            // 
            this.txtBaseDatosMysql.CustomButton.Image = null;
            this.txtBaseDatosMysql.CustomButton.Location = new System.Drawing.Point(619, 1);
            this.txtBaseDatosMysql.CustomButton.Name = "";
            this.txtBaseDatosMysql.CustomButton.Size = new System.Drawing.Size(25, 25);
            this.txtBaseDatosMysql.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtBaseDatosMysql.CustomButton.TabIndex = 1;
            this.txtBaseDatosMysql.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtBaseDatosMysql.CustomButton.UseSelectable = true;
            this.txtBaseDatosMysql.CustomButton.Visible = false;
            this.txtBaseDatosMysql.Lines = new string[0];
            this.txtBaseDatosMysql.Location = new System.Drawing.Point(3, 73);
            this.txtBaseDatosMysql.MaxLength = 32767;
            this.txtBaseDatosMysql.Name = "txtBaseDatosMysql";
            this.txtBaseDatosMysql.PasswordChar = '\0';
            this.txtBaseDatosMysql.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtBaseDatosMysql.SelectedText = "";
            this.txtBaseDatosMysql.SelectionLength = 0;
            this.txtBaseDatosMysql.SelectionStart = 0;
            this.txtBaseDatosMysql.ShortcutsEnabled = true;
            this.txtBaseDatosMysql.Size = new System.Drawing.Size(645, 27);
            this.txtBaseDatosMysql.TabIndex = 2;
            this.txtBaseDatosMysql.UseSelectable = true;
            this.txtBaseDatosMysql.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtBaseDatosMysql.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtUsuarioMysql
            // 
            this.txtUsuarioMysql.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel3.SetColumnSpan(this.txtUsuarioMysql, 2);
            // 
            // 
            // 
            this.txtUsuarioMysql.CustomButton.Image = null;
            this.txtUsuarioMysql.CustomButton.Location = new System.Drawing.Point(619, 1);
            this.txtUsuarioMysql.CustomButton.Name = "";
            this.txtUsuarioMysql.CustomButton.Size = new System.Drawing.Size(25, 25);
            this.txtUsuarioMysql.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtUsuarioMysql.CustomButton.TabIndex = 1;
            this.txtUsuarioMysql.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtUsuarioMysql.CustomButton.UseSelectable = true;
            this.txtUsuarioMysql.CustomButton.Visible = false;
            this.txtUsuarioMysql.Lines = new string[0];
            this.txtUsuarioMysql.Location = new System.Drawing.Point(3, 123);
            this.txtUsuarioMysql.MaxLength = 32767;
            this.txtUsuarioMysql.Name = "txtUsuarioMysql";
            this.txtUsuarioMysql.PasswordChar = '\0';
            this.txtUsuarioMysql.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtUsuarioMysql.SelectedText = "";
            this.txtUsuarioMysql.SelectionLength = 0;
            this.txtUsuarioMysql.SelectionStart = 0;
            this.txtUsuarioMysql.ShortcutsEnabled = true;
            this.txtUsuarioMysql.Size = new System.Drawing.Size(645, 27);
            this.txtUsuarioMysql.TabIndex = 3;
            this.txtUsuarioMysql.UseSelectable = true;
            this.txtUsuarioMysql.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtUsuarioMysql.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtContraseniaMysql
            // 
            this.txtContraseniaMysql.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel3.SetColumnSpan(this.txtContraseniaMysql, 2);
            // 
            // 
            // 
            this.txtContraseniaMysql.CustomButton.Image = null;
            this.txtContraseniaMysql.CustomButton.Location = new System.Drawing.Point(617, 2);
            this.txtContraseniaMysql.CustomButton.Name = "";
            this.txtContraseniaMysql.CustomButton.Size = new System.Drawing.Size(25, 25);
            this.txtContraseniaMysql.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtContraseniaMysql.CustomButton.TabIndex = 1;
            this.txtContraseniaMysql.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtContraseniaMysql.CustomButton.UseSelectable = true;
            this.txtContraseniaMysql.CustomButton.Visible = false;
            this.txtContraseniaMysql.Lines = new string[0];
            this.txtContraseniaMysql.Location = new System.Drawing.Point(3, 173);
            this.txtContraseniaMysql.MaxLength = 32767;
            this.txtContraseniaMysql.Name = "txtContraseniaMysql";
            this.txtContraseniaMysql.PasswordChar = '●';
            this.txtContraseniaMysql.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtContraseniaMysql.SelectedText = "";
            this.txtContraseniaMysql.SelectionLength = 0;
            this.txtContraseniaMysql.SelectionStart = 0;
            this.txtContraseniaMysql.ShortcutsEnabled = true;
            this.txtContraseniaMysql.Size = new System.Drawing.Size(645, 30);
            this.txtContraseniaMysql.TabIndex = 4;
            this.txtContraseniaMysql.UseSelectable = true;
            this.txtContraseniaMysql.UseSystemPasswordChar = true;
            this.txtContraseniaMysql.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtContraseniaMysql.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.AutoSize = true;
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Controls.Add(this.groupBox4, 0, 2);
            this.tableLayoutPanel5.Controls.Add(this.groupBox3, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.groupBox1, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.groupBox2, 1, 1);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(0, 39);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 3;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel5.Size = new System.Drawing.Size(1325, 541);
            this.tableLayoutPanel5.TabIndex = 7;
            // 
            // groupBox4
            // 
            this.groupBox4.AutoSize = true;
            this.tableLayoutPanel5.SetColumnSpan(this.groupBox4, 2);
            this.groupBox4.Controls.Add(this.tableLayoutPanel2);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox4.Location = new System.Drawing.Point(3, 358);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(1319, 180);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Credenciales REST API Woocommerce";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.AutoSize = true;
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.Controls.Add(this.label11, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.label13, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.label14, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.txtCvSecreta, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.txtUrl, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.txtCvCliente, 0, 3);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 18);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 9;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1313, 159);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(3, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(111, 17);
            this.label11.TabIndex = 1;
            this.label11.Text = "Dirección URL";
            // 
            // label13
            // 
            this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(3, 106);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(111, 17);
            this.label13.TabIndex = 1;
            this.label13.Text = "Clave secreta";
            // 
            // label14
            // 
            this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(3, 53);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(111, 17);
            this.label14.TabIndex = 1;
            this.label14.Text = "Clave del cliente";
            // 
            // txtCvSecreta
            // 
            this.txtCvSecreta.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel2.SetColumnSpan(this.txtCvSecreta, 2);
            // 
            // 
            // 
            this.txtCvSecreta.CustomButton.Image = null;
            this.txtCvSecreta.CustomButton.Location = new System.Drawing.Point(1279, 2);
            this.txtCvSecreta.CustomButton.Name = "";
            this.txtCvSecreta.CustomButton.Size = new System.Drawing.Size(25, 25);
            this.txtCvSecreta.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtCvSecreta.CustomButton.TabIndex = 1;
            this.txtCvSecreta.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtCvSecreta.CustomButton.UseSelectable = true;
            this.txtCvSecreta.CustomButton.Visible = false;
            this.txtCvSecreta.Lines = new string[0];
            this.txtCvSecreta.Location = new System.Drawing.Point(3, 126);
            this.txtCvSecreta.MaxLength = 32767;
            this.txtCvSecreta.Name = "txtCvSecreta";
            this.txtCvSecreta.PasswordChar = '\0';
            this.txtCvSecreta.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtCvSecreta.SelectedText = "";
            this.txtCvSecreta.SelectionLength = 0;
            this.txtCvSecreta.SelectionStart = 0;
            this.txtCvSecreta.ShortcutsEnabled = true;
            this.txtCvSecreta.Size = new System.Drawing.Size(1307, 30);
            this.txtCvSecreta.TabIndex = 3;
            this.txtCvSecreta.UseSelectable = true;
            this.txtCvSecreta.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtCvSecreta.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtUrl
            // 
            this.txtUrl.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel2.SetColumnSpan(this.txtUrl, 2);
            // 
            // 
            // 
            this.txtUrl.CustomButton.Image = null;
            this.txtUrl.CustomButton.Location = new System.Drawing.Point(1279, 2);
            this.txtUrl.CustomButton.Name = "";
            this.txtUrl.CustomButton.Size = new System.Drawing.Size(25, 25);
            this.txtUrl.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtUrl.CustomButton.TabIndex = 1;
            this.txtUrl.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtUrl.CustomButton.UseSelectable = true;
            this.txtUrl.CustomButton.Visible = false;
            this.txtUrl.Lines = new string[0];
            this.txtUrl.Location = new System.Drawing.Point(3, 20);
            this.txtUrl.MaxLength = 32767;
            this.txtUrl.Name = "txtUrl";
            this.txtUrl.PasswordChar = '\0';
            this.txtUrl.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtUrl.SelectedText = "";
            this.txtUrl.SelectionLength = 0;
            this.txtUrl.SelectionStart = 0;
            this.txtUrl.ShortcutsEnabled = true;
            this.txtUrl.Size = new System.Drawing.Size(1307, 30);
            this.txtUrl.TabIndex = 1;
            this.txtUrl.UseSelectable = true;
            this.txtUrl.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtUrl.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtCvCliente
            // 
            this.txtCvCliente.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel2.SetColumnSpan(this.txtCvCliente, 2);
            // 
            // 
            // 
            this.txtCvCliente.CustomButton.Image = null;
            this.txtCvCliente.CustomButton.Location = new System.Drawing.Point(1279, 2);
            this.txtCvCliente.CustomButton.Name = "";
            this.txtCvCliente.CustomButton.Size = new System.Drawing.Size(25, 25);
            this.txtCvCliente.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtCvCliente.CustomButton.TabIndex = 1;
            this.txtCvCliente.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtCvCliente.CustomButton.UseSelectable = true;
            this.txtCvCliente.CustomButton.Visible = false;
            this.txtCvCliente.Lines = new string[0];
            this.txtCvCliente.Location = new System.Drawing.Point(3, 73);
            this.txtCvCliente.MaxLength = 32767;
            this.txtCvCliente.Name = "txtCvCliente";
            this.txtCvCliente.PasswordChar = '\0';
            this.txtCvCliente.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtCvCliente.SelectedText = "";
            this.txtCvCliente.SelectionLength = 0;
            this.txtCvCliente.SelectionStart = 0;
            this.txtCvCliente.ShortcutsEnabled = true;
            this.txtCvCliente.Size = new System.Drawing.Size(1307, 30);
            this.txtCvCliente.TabIndex = 2;
            this.txtCvCliente.UseSelectable = true;
            this.txtCvCliente.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtCvCliente.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // groupBox3
            // 
            this.groupBox3.AutoSize = true;
            this.tableLayoutPanel5.SetColumnSpan(this.groupBox3, 2);
            this.groupBox3.Controls.Add(this.tableLayoutPanel6);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox3.Location = new System.Drawing.Point(3, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1319, 74);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Ruta de archivo de configuración";
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.AutoSize = true;
            this.tableLayoutPanel6.ColumnCount = 2;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.Controls.Add(this.txtDirectorio, 0, 1);
            this.tableLayoutPanel6.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 18);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 2;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel6.Size = new System.Drawing.Size(1313, 53);
            this.tableLayoutPanel6.TabIndex = 0;
            // 
            // frmCredenciales
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1325, 736);
            this.Controls.Add(this.tableLayoutPanel5);
            this.Controls.Add(this.btnGuardar);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.tableLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmCredenciales";
            this.Text = "frmCredenciales";
            this.Load += new System.EventHandler(this.frmCredenciales_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel7.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label lblCerrar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private MetroFramework.Controls.MetroTextBox txtDirectorio;
        private MetroFramework.Controls.MetroTextBox txtServidor;
        private MetroFramework.Controls.MetroTextBox txtBaseDatos;
        private MetroFramework.Controls.MetroTextBox txtUsuario;
        private MetroFramework.Controls.MetroTextBox txtContrasenia;
        private MetroFramework.Controls.MetroButton btnCancelar;
        private MetroFramework.Controls.MetroButton btnGuardar;
        private MetroFramework.Controls.MetroButton btnProbarConexión;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private MetroFramework.Controls.MetroTextBox txtServidorMysql;
        private MetroFramework.Controls.MetroTextBox txtBaseDatosMysql;
        private MetroFramework.Controls.MetroTextBox txtUsuarioMysql;
        private MetroFramework.Controls.MetroTextBox txtContraseniaMysql;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private MetroFramework.Controls.MetroButton btnProbarConexionMysql;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private MetroFramework.Controls.MetroTextBox txtCvSecreta;
        private MetroFramework.Controls.MetroTextBox txtUrl;
        private MetroFramework.Controls.MetroTextBox txtCvCliente;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.Label label12;
        private MetroFramework.Controls.MetroTextBox txtBdBit;
    }
}