﻿using SAP_LIB.Controllers;
using SAP_LIB.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace SapService
{
    public static class Utils
    {
        static string ruta = @"C:\Program Files (x86)\Adises\";
        static string rutacompleta = @"C:\Program Files (x86)\Adises\credenciales.xml";

        public static string tpConfiguration = string.Empty;
        public static long registroActual = 0;

        public static int interval = 0;
        public static bool fgSegundos = false;

        public static bool fgSyncProd = false;
        public static int RangoRegistros_prod = 1;

        public static bool fgSyncPricing = false;
        public static int rangoRegistros_pricing = 1;

        public static bool fgSyncLeads = false;
        public static int rangoRegistros_Leads = 1;

        public static bool fgSyncClientes = false;
        public static int rangoRegistros_Clientes = 1;

        public static bool fgSyncPedidos = false;
        public static int rangoRegistros_Pedidos = 1;

        public static bool fgSyncTipoCambio = false;
        public static int rangoRegistros_TipoCambio = 1;

        public static string UrlApi = string.Empty;
        public static string cvCliente = string.Empty;
        public static string cvSecreta = string.Empty;

        public static string UrlDIApi = string.Empty;
        public static string TokenDIApi = string.Empty;


        public const string MASTER = "MASTER";
        public const string OFERTA = "OFERTAS";
        public const string LIQUIDACION = "LIQUIDACIONES";
        public const string INSERT = "INSERT";
        public const string UPDATE = "UPDATE";
        public const string DELETE = "DELETE";
        #region Utilidades
        public static string parseStringBD(string str)
        {
            return $"\"{str}\"";
        }

        public static string ColumnsSelect(string[] lsString)
        {
            string returnColumns = string.Empty;

            if (lsString.Count() > 0)
                for (int index = 0; index <= lsString.Count(); index++)
                    returnColumns += index == 0 ? parseStringBD(lsString[index]) : $", {parseStringBD(lsString[index])}";
            else
                returnColumns = parseStringBD(lsString[0]);

            return "";
        }

        public static DateTime ToLocalTimeMexico()
        {
            TimeZoneInfo tm = TimeZoneInfo.FindSystemTimeZoneById("Central Standard Time (Mexico)");
            DateTime Time = TimeZoneInfo.ConvertTime(DateTime.Now, TimeZoneInfo.Local, tm);

            return Time;
        }

        public static string RemoveReservedCharacters(string strValue)
        {
            try
            {
                string output = Regex.Replace(strValue, @"[^0-9A-Za-z]", "", RegexOptions.None);
                string output2 = "";

                output.OfType<char>().ToList().ForEach(c =>
                {
                    if (output2 != null && output2.Length > 0)
                        output2 = (output2[output2.Length - 1] != '-') ? output2 += c : (c != '-' ? output2 += c : "");
                    else
                        if (c != '-') output2 += c;
                });

                return output2;
            }
            catch (Exception ex)
            {
                PrintLog("RemoveReservedCharacters", "1", ex.ToString());
                return strValue;
            }
        }

        public static string RemoveAccents(string text)
        {
            StringBuilder sbReturn = new StringBuilder();
            var arrayText = text.Normalize(NormalizationForm.FormD).ToCharArray();
            foreach (char letter in arrayText)
            {
                if (CharUnicodeInfo.GetUnicodeCategory(letter) != UnicodeCategory.NonSpacingMark)
                    sbReturn.Append(letter);
            }
            return sbReturn.ToString();
        }

        public static string GetDateFormatToSap(string dateRow)
        {
            if (dateRow != "")
            {
                string newdate_created = dateRow.Replace("a. m.", "").Replace("p. m.", "");
                DateTime dtm_date = DateTime.Parse(newdate_created);
                string formatDate = dtm_date.ToString("yyyy-MM-dd HH:mm:ss");
                return formatDate;
            }
            return "";

        }
        #endregion

        #region Configuracion

        public static void getParametersConfig()
        {
            try
            {
                //string query = $"SELECT {Utils.parseStringBD(zAdi_SyncConfig.zAdi_ActRegister)}, {Utils.parseStringBD(zAdi_SyncConfig.zAdi_Interval)}, {Utils.parseStringBD(zAdi_SyncConfig.zAdi_CountRegister)}";
                string query = $"SELECT *";
                query += $" FROM {Utils.parseStringBD(DBConn.zAdi_SyncConfig)}";
                //query += $" WHERE {Utils.parseStringBD(zAdi_SyncConfig.zAdi_TpConfig)} = '{tpConfiguration}'";

                DataTable tbl = DBConn.ExecQuery(query, DBConn.ConectionDB.Bitacoras);
                if (!(tbl != null && tbl.Rows != null && tbl.Rows.Count > 0))
                {
                    PrintLog("getParametersConfig", "0", $"No se encontraron parámetros a las : {DateTime.Now.ToString()}.");
                    return;
                }
                registroActual = long.Parse(tbl.Rows[0].ItemArray[0].ToString());
                interval = int.Parse(tbl.Rows[0]["zAdi_Interval"] != null && !string.IsNullOrEmpty(tbl.Rows[0]["zAdi_Interval"].ToString()) ? tbl.Rows[0]["zAdi_Interval"].ToString() : "1");
                fgSegundos = tbl.Rows[0]["zAdi_FlagSeconds"] != null && !string.IsNullOrEmpty(tbl.Rows[0]["zAdi_FlagSeconds"].ToString()) ? Convert.ToBoolean(int.Parse(tbl.Rows[0]["zAdi_FlagSeconds"].ToString().Trim())) : false;


                foreach (DataRow row in tbl.Rows)
                {
                    string zAdi_TpConfig = row["zAdi_TpConfig"] != null && !string.IsNullOrEmpty(row["zAdi_TpConfig"].ToString()) ? row["zAdi_TpConfig"].ToString() : "";
                    string zAdi_CountRegister = row["zAdi_CountRegister"] != null && !string.IsNullOrEmpty(row["zAdi_CountRegister"].ToString()) ? row["zAdi_CountRegister"].ToString() : "";
                    bool zAdi_FlagSync = row["zAdi_FlagSync"] != null && !string.IsNullOrEmpty(row["zAdi_FlagSync"].ToString()) ? Convert.ToBoolean(int.Parse(row["zAdi_FlagSync"].ToString().Trim())) : false;

                    switch (zAdi_TpConfig)
                    {
                        case "Productos":
                            RangoRegistros_prod = int.Parse(zAdi_CountRegister);
                            fgSyncProd = zAdi_FlagSync;
                            break;
                        case "Leads":
                            rangoRegistros_Leads = int.Parse(zAdi_CountRegister);
                            fgSyncLeads = zAdi_FlagSync;
                            break;
                        case "Clientes":
                            rangoRegistros_Clientes = int.Parse(zAdi_CountRegister);
                            fgSyncClientes = zAdi_FlagSync;
                            break;
                        case "Reglas de precio":
                            rangoRegistros_pricing = int.Parse(zAdi_CountRegister);
                            fgSyncPricing = zAdi_FlagSync;
                            break;
                        case "Pedidos":
                            rangoRegistros_Pedidos = int.Parse(zAdi_CountRegister);
                            fgSyncPedidos = zAdi_FlagSync;
                            break;
                        case "Tipo de cambio":
                            rangoRegistros_TipoCambio = int.Parse(zAdi_CountRegister);
                            fgSyncTipoCambio = zAdi_FlagSync;
                            break;
                        default:

                            break;
                    }
                }

                ReadXML();

            }
            catch (Exception ex)
            {
                //DBConn.CloseConnection();
                PrintLog("getParametersConfig", "1", ex.ToString());
                clearParameters();
            }
        }

        public static void clearParameters()
        {
            registroActual = 0;
            interval = 0;
            //RangoRegistros = 0;

            rangoRegistros_Clientes = 1;
            rangoRegistros_Leads = 1;
            rangoRegistros_Pedidos = 1;
            rangoRegistros_pricing = 1;
            RangoRegistros_prod = 1;
            rangoRegistros_TipoCambio = 1;

            fgSyncClientes = false;
            fgSyncLeads = false;
            fgSyncPedidos = false;
            fgSyncPricing = false;
            fgSyncProd = false;
            fgSyncTipoCambio = false;

            fgSegundos = false;

            UrlApi = string.Empty;
            cvSecreta = string.Empty;
            cvCliente = string.Empty;

            UrlDIApi = string.Empty;
            TokenDIApi = string.Empty;
        }


        private static void ReadXML()
        {
            try
            {
                if (!Directory.Exists(ruta)) // Revisa si existe el directorio
                    return;

                if (!File.Exists(rutacompleta)) // Revisa si existe el archivo
                    return;

                XDocument xml = XDocument.Load(rutacompleta, LoadOptions.None);

                XElement credenciales = xml.Element("credenciales");
                XElement credencialesRestApi = credenciales.Element("RestApi");
                UrlApi = credencialesRestApi.Element("UrlApi").Value;
                cvCliente = credencialesRestApi.Element("ClaveCliente").Value;
                cvSecreta = credencialesRestApi.Element("ClaveSecreta").Value;

                XElement DIServerNode = credenciales.Element("DIServerAPI");
                UrlDIApi = DIServerNode.Element("UrlDIApi").Value;
                TokenDIApi = DIServerNode.Element("TokenDIApi").Value;


                //Utils.PrintLog("ReadXML", "0", $"UrlDIApi : {UrlDIApi}, TokenDIApi: {TokenDIApi}");
            }
            catch (Exception ex)
            {
                UrlApi = string.Empty;
                cvCliente = string.Empty;
                cvSecreta = string.Empty;

                UrlDIApi = string.Empty;
                TokenDIApi = string.Empty;
            }
        }
        #endregion

        public static void PrintLog(string function, string nivelCatch, string message)
        {
            string path = @"C:\Program Files (x86)\Adises\Logs\";
            string pathComplete = $"{path}log_{DateTime.Now.ToString("ddMMyyyy")}.txt";
            try
            {
                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);

                using (StreamWriter writer = new StreamWriter(pathComplete, true))
                {
                    writer.WriteLine($"--------------------------Start-----------------------------");

                    writer.WriteLine($"function: {function}");
                    writer.WriteLine($"nivelCatch: {nivelCatch}");
                    writer.WriteLine($"Hora: {DateTime.Now.ToString("hh:mm:ss tt")}");
                    writer.WriteLine($"message: {message}");

                    writer.WriteLine($"---------------------------Finish----------------------------\n\n");
                    writer.Close();
                }
            }
            catch (Exception ex) { }
        }
    }
}
