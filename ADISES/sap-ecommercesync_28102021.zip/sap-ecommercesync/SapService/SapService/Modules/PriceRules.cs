﻿using SAP_LIB.Controllers;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SapService.Modules
{
    class PriceRules
    {
        #region Pricing

        #region DESC_CLI_MARCA_PROD

        public void RegisterLogPricing_DESC_CLI_MARCA_PROD()
        {
            //string path = "C:\\RegisterLogPricing_DESC_CLI_MARCA_PROD.txt";
            try
            {
                string select_DESC_CLI_MARCA_PROD = $"SELECT TOP {Utils.rangoRegistros_pricing} DISTINCT";
                #region campos
                select_DESC_CLI_MARCA_PROD += $" {Utils.parseStringBD("Code")},";
                select_DESC_CLI_MARCA_PROD += $" {Utils.parseStringBD("U_Cliente")},";
                select_DESC_CLI_MARCA_PROD += $" {Utils.parseStringBD("U_Marca")},";
                select_DESC_CLI_MARCA_PROD += $" {Utils.parseStringBD("U_Producto")},";
                select_DESC_CLI_MARCA_PROD += $" {Utils.parseStringBD("U_PorcentajeDesc")}";
                #endregion
                select_DESC_CLI_MARCA_PROD += $" FROM {Utils.parseStringBD("@DESC_CLI_MARCA_PROD")}";
                select_DESC_CLI_MARCA_PROD += $" WHERE ((SELECT COUNT(*) FROM {Utils.parseStringBD("zAdi_SyncItems")} WHERE {Utils.parseStringBD("zAdi_SyncItems")}.{Utils.parseStringBD("zAdi_ItemCode")} = TRIM(replace(replace({Utils.parseStringBD("U_Producto")}, '''',''),'\\', ''))) > 0 AND (SELECT COUNT(*) FROM {Utils.parseStringBD(DBConn.DBBitacoras)}.{Utils.parseStringBD("zAdi_SyncPricing")} WHERE {Utils.parseStringBD("zAdi_CodeRule")} = {Utils.parseStringBD("Code")} AND {Utils.parseStringBD("zAdi_TypeDesc")} = 'DESC_CLI_MARCA_PROD') = 0) ";
                select_DESC_CLI_MARCA_PROD += $" OR (({Utils.parseStringBD("U_Producto")} IS NULL OR {Utils.parseStringBD("U_Producto")} = '') AND (SELECT COUNT(*) FROM {Utils.parseStringBD(DBConn.DBBitacoras)}.{Utils.parseStringBD("zAdi_SyncPricing")} WHERE {Utils.parseStringBD("zAdi_CodeRule")} = {Utils.parseStringBD("Code")}) = 0)";

                DataTable tbl_DESC_CLI_MARCA_PROD = DBConn.ExecQuery(select_DESC_CLI_MARCA_PROD);
                if (tbl_DESC_CLI_MARCA_PROD != null && tbl_DESC_CLI_MARCA_PROD.Rows != null && tbl_DESC_CLI_MARCA_PROD.Rows.Count > 0)
                {
                    foreach (DataRow row_DESC_CLI_MARCA_PROD in tbl_DESC_CLI_MARCA_PROD.Rows)
                    {
                        string Code = row_DESC_CLI_MARCA_PROD.ItemArray[0].ToString();
                        string U_Cliente = row_DESC_CLI_MARCA_PROD.ItemArray[1].ToString();
                        string U_Marca = row_DESC_CLI_MARCA_PROD.ItemArray[2] != null ? row_DESC_CLI_MARCA_PROD.ItemArray[2].ToString() : "";
                        string U_Producto = row_DESC_CLI_MARCA_PROD.ItemArray[3] != null ? row_DESC_CLI_MARCA_PROD.ItemArray[3].ToString() : "";
                        double U_Porcentaje = row_DESC_CLI_MARCA_PROD.ItemArray[4] != null ? double.Parse(row_DESC_CLI_MARCA_PROD[4].ToString()) : 0;

                        U_Producto = string.Join("", U_Producto.Split('\''));
                        U_Producto = U_Producto.Replace("'", "");
                        U_Producto = U_Producto.Trim(new char[] { '\\', ' ' });

                        string insert_DESC_CLI_MARCA_PROD = string.Empty;

                        if (!string.IsNullOrEmpty(U_Marca) && !string.IsNullOrEmpty(U_Producto))
                        {
                            //Significado de sufijos
                            // M : Marca
                            // P : Producto

                            /*Validación marca*/
                            string select_exist_register = $"SELECT * FROM {Utils.parseStringBD("zAdi_SyncPricing")} WHERE {Utils.parseStringBD("zAdi_NameRule")} = '{Code} M' AND {Utils.parseStringBD("zAdi_Client")} = '{U_Cliente}' AND {Utils.parseStringBD("zAdi_Brand")} = '{U_Marca}'";
                            DataTable tbl_exist_M = DBConn.ExecQuery(select_exist_register, DBConn.ConectionDB.Bitacoras);
                            if (tbl_exist_M != null && tbl_exist_M.Rows != null && tbl_exist_M.Rows.Count > 0) continue;

                            insert_DESC_CLI_MARCA_PROD = $"INSERT INTO {Utils.parseStringBD("zAdi_SyncPricing")} (";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_TypeDesc")},";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_NameRule")},";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_Client")},";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_Brand")},";
                            //insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_ItemCode")},";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_PercentDesc")},";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_Comision")},";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_DateRegister")},";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_FlagSend")},";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_Action")},";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_OldNameRule")},";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_FlagEnable")},";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_CodeRule")}";
                            insert_DESC_CLI_MARCA_PROD += $")";
                            insert_DESC_CLI_MARCA_PROD += $" VALUES (";
                            insert_DESC_CLI_MARCA_PROD += $" 'DESC_CLI_MARCA_PROD',";
                            insert_DESC_CLI_MARCA_PROD += $" '{Code} M',";
                            insert_DESC_CLI_MARCA_PROD += $" '{U_Cliente}',";
                            insert_DESC_CLI_MARCA_PROD += $" '{U_Marca}',";
                            //insert_DESC_CLI_MARCA_PROD += $" '{U_Producto}',";
                            insert_DESC_CLI_MARCA_PROD += $" {U_Porcentaje},";
                            insert_DESC_CLI_MARCA_PROD += $" 1,";
                            insert_DESC_CLI_MARCA_PROD += $" NOW(),";
                            insert_DESC_CLI_MARCA_PROD += $" FALSE,";
                            insert_DESC_CLI_MARCA_PROD += $" 'INSERT',";
                            insert_DESC_CLI_MARCA_PROD += $"'{Code} M',";
                            insert_DESC_CLI_MARCA_PROD += $" TRUE,";
                            insert_DESC_CLI_MARCA_PROD += $" '{Code}'";
                            insert_DESC_CLI_MARCA_PROD += $"); \n";

                            bool fgInsert = DBConn.ExecQueryInsert(insert_DESC_CLI_MARCA_PROD, DBConn.ConectionDB.Bitacoras);
                            if (!fgInsert)
                                Utils.PrintLog("RegisterLogPricing_DESC_CLI_MARCA_PROD", "0", $"No fue posible realizar la sincronización de la regla de precio {Code}-{U_Marca}");

                            /*Validación producto*/
                            select_exist_register = $"SELECT * FROM {Utils.parseStringBD("zAdi_SyncPricing")} WHERE {Utils.parseStringBD("zAdi_NameRule")} = '{Code} P' AND {Utils.parseStringBD("zAdi_ItemCode")} = '{U_Producto}'";
                            DataTable tbl_exist_P = DBConn.ExecQuery(select_exist_register, DBConn.ConectionDB.Bitacoras);
                            if (tbl_exist_P != null && tbl_exist_P.Rows != null && tbl_exist_P.Rows.Count > 0) continue;

                            insert_DESC_CLI_MARCA_PROD = $"INSERT INTO {Utils.parseStringBD("zAdi_SyncPricing")} (";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_TypeDesc")},";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_NameRule")},";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_Client")},";
                            //insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_Brand")},";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_ItemCode")},";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_PercentDesc")},";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_Comision")},";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_DateRegister")},";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_FlagSend")},";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_Action")},";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_OldNameRule")},";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_FlagEnable")},";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_CodeRule")}";
                            insert_DESC_CLI_MARCA_PROD += $")";
                            insert_DESC_CLI_MARCA_PROD += $" VALUES (";
                            insert_DESC_CLI_MARCA_PROD += $" 'DESC_CLI_MARCA_PROD',";
                            insert_DESC_CLI_MARCA_PROD += $" '{Code} P',";
                            insert_DESC_CLI_MARCA_PROD += $" '{U_Cliente}',";
                            //insert_DESC_CLI_MARCA_PROD += $" '{U_Marca}',";
                            insert_DESC_CLI_MARCA_PROD += $" '{U_Producto}',";
                            insert_DESC_CLI_MARCA_PROD += $" {U_Porcentaje},";
                            insert_DESC_CLI_MARCA_PROD += $" 1,";
                            insert_DESC_CLI_MARCA_PROD += $" NOW(),";
                            insert_DESC_CLI_MARCA_PROD += $" FALSE,";
                            insert_DESC_CLI_MARCA_PROD += $" 'INSERT',";
                            insert_DESC_CLI_MARCA_PROD += $"'{Code} P',";
                            insert_DESC_CLI_MARCA_PROD += $" TRUE,";
                            insert_DESC_CLI_MARCA_PROD += $" '{Code}'";
                            insert_DESC_CLI_MARCA_PROD += $");";

                            bool fgInsert2 = DBConn.ExecQueryInsert(insert_DESC_CLI_MARCA_PROD, DBConn.ConectionDB.Bitacoras);
                            if (!fgInsert2)
                                Utils.PrintLog("RegisterLogPricing_DESC_CLI_MARCA_PROD", "0", $"No fue posible realizar la sincronización de la regla de precio {Code}-{U_Producto}");
                        }
                        else if (!string.IsNullOrEmpty(U_Marca))
                        {
                            /*Validación marca*/
                            string select_exist_register = $"SELECT * FROM {Utils.parseStringBD("zAdi_SyncPricing")} WHERE {Utils.parseStringBD("zAdi_NameRule")} = '{Code} M' AND {Utils.parseStringBD("zAdi_Client")} = '{U_Cliente}' AND {Utils.parseStringBD("zAdi_Brand")} = '{U_Marca}'";
                            DataTable tbl_exist_M = DBConn.ExecQuery(select_exist_register, DBConn.ConectionDB.Bitacoras);
                            if (tbl_exist_M != null && tbl_exist_M.Rows != null && tbl_exist_M.Rows.Count > 0) continue;

                            insert_DESC_CLI_MARCA_PROD = $"INSERT INTO {Utils.parseStringBD("zAdi_SyncPricing")} (";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_TypeDesc")},";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_NameRule")},";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_Client")},";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_Brand")},";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_PercentDesc")},";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_Comision")},";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_DateRegister")},";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_FlagSend")},";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_Action")},";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_OldNameRule")},";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_FlagEnable")},";
                            insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_CodeRule")}";
                            insert_DESC_CLI_MARCA_PROD += $")";
                            insert_DESC_CLI_MARCA_PROD += $" VALUES (";
                            insert_DESC_CLI_MARCA_PROD += $" 'DESC_CLI_MARCA_PROD',";
                            insert_DESC_CLI_MARCA_PROD += $" '{Code}',";
                            insert_DESC_CLI_MARCA_PROD += $" '{U_Cliente}',";
                            insert_DESC_CLI_MARCA_PROD += $" '{U_Marca}',";
                            insert_DESC_CLI_MARCA_PROD += $" {U_Porcentaje},";
                            insert_DESC_CLI_MARCA_PROD += $" 1,";
                            insert_DESC_CLI_MARCA_PROD += $" NOW(),";
                            insert_DESC_CLI_MARCA_PROD += $" FALSE,";
                            insert_DESC_CLI_MARCA_PROD += $" 'INSERT',";
                            insert_DESC_CLI_MARCA_PROD += $"'{Code}',";
                            insert_DESC_CLI_MARCA_PROD += $" TRUE,";
                            insert_DESC_CLI_MARCA_PROD += $" '{Code}'";
                            insert_DESC_CLI_MARCA_PROD += $");";

                            bool fgInsert = DBConn.ExecQueryInsert(insert_DESC_CLI_MARCA_PROD, DBConn.ConectionDB.Bitacoras);
                            if (!fgInsert)
                                Utils.PrintLog("RegisterLogPricing_DESC_CLI_MARCA_PROD", "0", $"No fue posible realizar la sincronización de la regla de precio {Code}");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("RegisterLogPricing_DESC_CLI_MARCA_PROD", "1", ex.ToString());
            }
        }

        public void SyncPricing_DESC_CLI_MARCA_PROD()
        {
            try
            {

                string select_DESC_CLI_MARCA_PROD = $"SELECT TOP {Utils.rangoRegistros_pricing}";
                select_DESC_CLI_MARCA_PROD += $" {Utils.parseStringBD("zAdi_SyncPricingId")},";
                select_DESC_CLI_MARCA_PROD += $" {Utils.parseStringBD("zAdi_NameRule")},";
                select_DESC_CLI_MARCA_PROD += $" {Utils.parseStringBD("zAdi_Client")},";
                select_DESC_CLI_MARCA_PROD += $" {Utils.parseStringBD("zAdi_Brand")},";
                select_DESC_CLI_MARCA_PROD += $" {Utils.parseStringBD("zAdi_ItemCode")},";
                select_DESC_CLI_MARCA_PROD += $" {Utils.parseStringBD("zAdi_PercentDesc")},";
                select_DESC_CLI_MARCA_PROD += $" {Utils.parseStringBD("zAdi_Comision")}";
                select_DESC_CLI_MARCA_PROD += $" FROM {Utils.parseStringBD("zAdi_SyncPricing")}";
                select_DESC_CLI_MARCA_PROD += $" WHERE {Utils.parseStringBD("zAdi_FlagSend")} = FALSE AND {Utils.parseStringBD("zAdi_Action")} = 'INSERT' AND {Utils.parseStringBD("zAdi_TypeDesc")} = 'DESC_CLI_MARCA_PROD'";
                DataTable tbl_select_DESC_CLI_MARCA_PROD = DBConn.ExecQuery(select_DESC_CLI_MARCA_PROD, DBConn.ConectionDB.Bitacoras);

                if (tbl_select_DESC_CLI_MARCA_PROD != null && tbl_select_DESC_CLI_MARCA_PROD.Rows != null && tbl_select_DESC_CLI_MARCA_PROD.Rows.Count > 0)
                {
                    foreach (DataRow row_select_DESC_CLI_MARCA_PROD in tbl_select_DESC_CLI_MARCA_PROD.Rows)
                    {
                        string select_validate_exist = $"SELECT * FROM dsq_wdp_rules WHERE title = '{row_select_DESC_CLI_MARCA_PROD.ItemArray[0].ToString()}' AND deleted != 1";
                        DataTable validate_exist = DBConnMysql.ExecQuery(select_validate_exist);

                        if (!(validate_exist != null && validate_exist.Rows != null && validate_exist.Rows.Count > 0))
                        {
                            long zAdi_IdSyncPricing = long.Parse(row_select_DESC_CLI_MARCA_PROD["zAdi_SyncPricingId"].ToString());
                            string zAdi_NameRule = row_select_DESC_CLI_MARCA_PROD["zAdi_NameRule"].ToString();
                            string zAdi_Client = row_select_DESC_CLI_MARCA_PROD["zAdi_Client"].ToString();
                            string zAdi_Brand = row_select_DESC_CLI_MARCA_PROD["zAdi_Brand"].ToString();
                            string zAdi_ItemCode = row_select_DESC_CLI_MARCA_PROD["zAdi_ItemCode"] != null && row_select_DESC_CLI_MARCA_PROD["zAdi_ItemCode"].ToString() != "" ? row_select_DESC_CLI_MARCA_PROD["zAdi_ItemCode"].ToString() : "";
                            double zAdi_PercentDesc = double.Parse(row_select_DESC_CLI_MARCA_PROD["zAdi_PercentDesc"].ToString());
                            double zAdi_Comision = double.Parse(row_select_DESC_CLI_MARCA_PROD["zAdi_Comision"].ToString());

                            string max_priotity = "SELECT MAX(priority) FROM dsq_wdp_rules";
                            DataTable tbl_max_priority = DBConnMysql.ExecQuery(max_priotity);
                            string insert_dsq_wdp_rules = "INSERT INTO `dsq_wdp_rules` VALUES(";
                            insert_dsq_wdp_rules += "NULL,";
                            insert_dsq_wdp_rules += "0,";
                            insert_dsq_wdp_rules += "1,";
                            insert_dsq_wdp_rules += "1,";
                            insert_dsq_wdp_rules += "'package',";
                            /*tittle*/
                            insert_dsq_wdp_rules += Convert.ToString($"'{zAdi_NameRule}',");
                            /*priority*/
                            insert_dsq_wdp_rules += Convert.ToString($"{(tbl_max_priority != null && tbl_max_priority.Rows != null ? int.Parse(tbl_max_priority.Rows[0].ItemArray[0].ToString()) + 1 : 0)},");
                            /*options*/
                            insert_dsq_wdp_rules += Convert.ToString("'a:2:{s:6:\"repeat\";s:2:\"-1\";s:8:\"apply_to\";s:8:\"appeared\";}',"); //listo
                            /*aditional*/      //listo
                            insert_dsq_wdp_rules += Convert.ToString("'a:5:{s:19:\"trigger_coupon_code\";s:0:\"\";s:12:\"replace_name\";s:0:\"\";s:19:\"sortable_apply_mode\";s:12:\"consistently\";s:26:\"free_products_replace_name\";s:0:\"\";s:23:\"conditions_relationship\";s:2:\"or\";}',");
                            /*conditions*/
                            insert_dsq_wdp_rules += Convert.ToString("'a:1:{i:0;a:2:{s:4:\"type\";s:8:\"usermeta\";s:7:\"options\";a:4:{i:0;s:1:\"1\";i:3;s:0:\"\";i:1;s:7:\"in_list\";i:2;a:1:{i:0;s:" + (9 + zAdi_Client.Length) + ":\"nickname=" + zAdi_Client + "\";}}}}',"); //listo
                            /*filters*******/
                            if (!string.IsNullOrEmpty(zAdi_Brand))
                                insert_dsq_wdp_rules += " 'a:1:{i:0;a:6:{s:3:\"qty\";s:1:\"1\";s:4:\"type\";s:21:\"product_custom_fields\";s:10:\"limitation\";s:4:\"none\";s:6:\"method\";s:7:\"in_list\";s:5:\"value\";a:1:{i:0;s:" + (zAdi_Brand.Length + 6) + ":\"marca=" + zAdi_Brand + "\";}s:15:\"product_exclude\";a:1:{s:10:\"on_wc_sale\";s:1:\"1\";}}}',";
                            else if (!string.IsNullOrEmpty(zAdi_ItemCode))
                                insert_dsq_wdp_rules += " 'a:1:{i:1;a:6:{s:3:\"qty\";s:1:\"1\";s:4:\"type\";s:11:\"product_sku\";s:10:\"limitation\";s:4:\"none\";s:6:\"method\";s:7:\"in_list\";s:5:\"value\";a:1:{i:0;s:" + zAdi_ItemCode.Length + ":\"" + zAdi_ItemCode + "\";}s:15:\"product_exclude\";a:1:{s:10:\"on_wc_sale\";s:1:\"1\";}}}',";
                            else
                                insert_dsq_wdp_rules += " '',";

                            /*limits*/
                            insert_dsq_wdp_rules += Convert.ToString("'a:0:{}',");
                            /*product_adjustments******/
                            if (!string.IsNullOrEmpty(zAdi_Brand))
                                insert_dsq_wdp_rules += "'a:4:{s:4:\"type\";s:5:\"total\";s:5:\"total\";a:2:{s:4:\"type\";s:20:\"discount__percentage\";s:5:\"value\";s:" + zAdi_PercentDesc.ToString().Length + ":\"" + zAdi_PercentDesc + "\";}s:5:\"split\";a:1:{i:0;a:2:{s:4:\"type\";s:16:\"discount__amount\";s:5:\"value\";s:0:\"\";}}s:16:\"max_discount_sum\";s:0:\"\";}',";
                            else if (!string.IsNullOrEmpty(zAdi_ItemCode))
                                insert_dsq_wdp_rules += " 'a:4:{s:4:\"type\";s:5:\"total\";s:5:\"total\";a:2:{s:4:\"type\";s:20:\"discount__percentage\";s:5:\"value\";s:" + zAdi_PercentDesc.ToString().Length + ":\"" + zAdi_PercentDesc + "\";}s:5:\"split\";a:1:{i:1;a:2:{s:4:\"type\";s:16:\"discount__amount\";s:5:\"value\";s:0:\"\";}}s:16:\"max_discount_sum\";s:0:\"\";}',";
                            else
                                insert_dsq_wdp_rules += " '',";

                            /*sortable_blocks_priority*/
                            insert_dsq_wdp_rules += Convert.ToString("'a:2:{i:0;s:5:\"roles\";i:1;s:16:\"bulk-adjustments\";}',");
                            /*bulk_adjustments*/
                            insert_dsq_wdp_rules += Convert.ToString("'a:2:{s:4:\"type\";s:4:\"bulk\";s:13:\"table_message\";s:0:\"\";}',");
                            /*role_discounts*/
                            insert_dsq_wdp_rules += Convert.ToString("'a:0:{}',");
                            /*cart_adjustments*/
                            insert_dsq_wdp_rules += Convert.ToString("'a:0:{}',");
                            /*get_products*/
                            insert_dsq_wdp_rules += Convert.ToString("'a:2:{s:6:\"repeat\";s:2:\"-1\";s:15:\"repeat_subtotal\";s:0:\"\";}')");

                            try
                            {
                                DBConnMysql.ExecQueryInsert(insert_dsq_wdp_rules);
                                string select_dsq_wdp_rules = $"SELECT id FROM dsq_wdp_rules WHERE title = '{zAdi_NameRule}' AND deleted != 1 LIMIT 1";
                                DataTable tbl_select_dsq_wdp_rules = DBConnMysql.ExecQuery(select_dsq_wdp_rules);
                                if (tbl_select_dsq_wdp_rules != null && tbl_select_dsq_wdp_rules.Rows != null && tbl_select_dsq_wdp_rules.Rows.Count > 0)
                                {
                                    #region UPDATE SAP HANA

                                    string update_SyncPricing = $"UPDATE {Utils.parseStringBD("zAdi_SyncPricing")}";
                                    update_SyncPricing += $" SET {Utils.parseStringBD("zAdi_DateSend")} = NOW(), {Utils.parseStringBD("zAdi_FlagSend")} = TRUE, {Utils.parseStringBD("zAdi_IdRuleWooCommerce")} = {tbl_select_dsq_wdp_rules.Rows[0]["id"].ToString()}";
                                    update_SyncPricing += $" WHERE {Utils.parseStringBD("zAdi_SyncPricingId")} = {zAdi_IdSyncPricing}";

                                    DBConn.ExecQueryUpdate(update_SyncPricing, DBConn.ConectionDB.Bitacoras);
                                    #endregion
                                }
                                else
                                {
                                    Utils.PrintLog("SyncPricing_DESC_CLI_MARCA_PROD", "0", $"No fue posible realizar la sincronización de la regla de precio {zAdi_NameRule}");
                                }
                            }
                            catch (Exception ex)
                            {
                                Utils.PrintLog("SyncPricing_DESC_CLI_MARCA_PROD", "2", ex.ToString());
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("SyncPricing_DESC_CLI_MARCA_PROD", "1", ex.ToString());
            }
        }

        public void SyncPricingUpdate_DESC_CLI_MARCA_PROD()
        {
            //string path = "C:\\SyncPricingUPDATE_DESC_CLI_MARCA_PROD.txt";
            try
            {
                string select_DESC_CLI_MARCA_PROD = $"SELECT TOP {Utils.rangoRegistros_pricing}";
                select_DESC_CLI_MARCA_PROD += $" {Utils.parseStringBD("zAdi_NameRule")},";
                select_DESC_CLI_MARCA_PROD += $" {Utils.parseStringBD("zAdi_Client")},";
                select_DESC_CLI_MARCA_PROD += $" {Utils.parseStringBD("zAdi_Brand")},";
                select_DESC_CLI_MARCA_PROD += $" {Utils.parseStringBD("zAdi_ItemCode")},";
                select_DESC_CLI_MARCA_PROD += $" {Utils.parseStringBD("zAdi_PercentDesc")},";
                select_DESC_CLI_MARCA_PROD += $" {Utils.parseStringBD("zAdi_IdRuleWooCommerce")},";
                select_DESC_CLI_MARCA_PROD += $" {Utils.parseStringBD("zAdi_OldNameRule")},";
                select_DESC_CLI_MARCA_PROD += $" {Utils.parseStringBD("zAdi_FlagEnable")}";
                select_DESC_CLI_MARCA_PROD += $" FROM {Utils.parseStringBD("zAdi_SyncPricing")}";
                select_DESC_CLI_MARCA_PROD += $" WHERE {Utils.parseStringBD("zAdi_FlagSend")} = FALSE AND {Utils.parseStringBD("zAdi_Action")} = 'UPDATE' AND {Utils.parseStringBD("zAdi_TypeDesc")} = 'DESC_CLI_MARCA_PROD'";
                DataTable tbl_select_DESC_CLI_MARCA_PROD = DBConn.ExecQuery(select_DESC_CLI_MARCA_PROD, DBConn.ConectionDB.Bitacoras);

                if (tbl_select_DESC_CLI_MARCA_PROD != null && tbl_select_DESC_CLI_MARCA_PROD.Rows != null && tbl_select_DESC_CLI_MARCA_PROD.Rows.Count > 0)
                {
                    foreach (DataRow row_select_DESC_CLI_MARCA_PROD in tbl_select_DESC_CLI_MARCA_PROD.Rows)
                    {
                        string zAdi_nameRule = row_select_DESC_CLI_MARCA_PROD.ItemArray[0] != null ? row_select_DESC_CLI_MARCA_PROD.ItemArray[0].ToString() : "";
                        string zAdi_Client = row_select_DESC_CLI_MARCA_PROD.ItemArray[1] != null ? row_select_DESC_CLI_MARCA_PROD.ItemArray[1].ToString() : "";
                        string zAdi_Brand = row_select_DESC_CLI_MARCA_PROD.ItemArray[2] != null ? row_select_DESC_CLI_MARCA_PROD.ItemArray[2].ToString() : "";
                        string zAdi_ItemCode = row_select_DESC_CLI_MARCA_PROD["zAdi_ItemCode"] != null ? row_select_DESC_CLI_MARCA_PROD["zAdi_ItemCode"].ToString() : "";
                        double zAdi_PercentDesc = double.Parse(row_select_DESC_CLI_MARCA_PROD["zAdi_PercentDesc"] != null ? row_select_DESC_CLI_MARCA_PROD["zAdi_PercentDesc"].ToString() : "0");
                        long idRule = long.Parse(row_select_DESC_CLI_MARCA_PROD["zAdi_IdRuleWooCommerce"] != null ? row_select_DESC_CLI_MARCA_PROD["zAdi_IdRuleWooCommerce"].ToString() : "0");
                        string zAdi_OldName = row_select_DESC_CLI_MARCA_PROD["zAdi_OldNameRule"] != null ? row_select_DESC_CLI_MARCA_PROD["zAdi_OldNameRule"].ToString() : "";
                        //using (StreamWriter writer = new StreamWriter(path, true))
                        //{
                        //    writer.WriteLine(string.Format($"zAdi_FlagEnable: {row_select_DESC_CLI_MARCA_PROD["zAdi_FlagEnable"].ToString()} \n"));
                        //    writer.Close();
                        //}
                        bool zAdi_FlagEnable = row_select_DESC_CLI_MARCA_PROD["zAdi_FlagEnable"] != null ? (row_select_DESC_CLI_MARCA_PROD["zAdi_FlagEnable"].ToString() == "1") : false;

                        if (idRule > 0)
                        {
                            if (!zAdi_FlagEnable)
                            {
                                string update = $"UPDATE dsq_wdp_rules SET enabled = 0 WHERE id = {idRule}";
                                //using (StreamWriter writer = new StreamWriter(path, true))
                                //{
                                //    writer.WriteLine(string.Format($"Query update mysql: {update} \n"));
                                //    writer.Close();
                                //}
                                DBConnMysql.ExecQueryUpdate(update);

                                #region UPDATE FROM DB SAP HANA

                                string update_SAP = $"UPDATE {Utils.parseStringBD("zAdi_SyncPricing")} SET";
                                update_SAP += $" {Utils.parseStringBD("zAdi_DateSend")} = NOW(), {Utils.parseStringBD("zAdi_FlagSend")} = TRUE";
                                update_SAP += $" WHERE {Utils.parseStringBD("zAdi_NameRule")} = '{zAdi_nameRule}' AND  {Utils.parseStringBD("zAdi_Action")} = 'UPDATE' AND {Utils.parseStringBD("zAdi_FlagSend")} = FALSE AND {Utils.parseStringBD("zAdi_TypeDesc")} = 'DESC_CLI_MARCA_PROD'";
                                //using (StreamWriter writer = new StreamWriter(path, true))
                                //{
                                //    writer.WriteLine(string.Format($"Query update_SAP mysql: {update_SAP} \n"));
                                //    writer.Close();
                                //}
                                DBConn.ExecQueryUpdate(update_SAP, DBConn.ConectionDB.Bitacoras);
                                #endregion
                                continue;
                            }

                            string update_dsq = $"UPDATE dsq_wdp_rules SET";
                            update_dsq += $" title = '{zAdi_nameRule}',";
                            update_dsq += " conditions = 'a:1:{i:0;a:2:{s:4:\"type\";s:8:\"usermeta\";s:7:\"options\";a:4:{i:0;s:1:\"1\";i:3;s:0:\"\";i:1;s:7:\"in_list\";i:2;a:1:{i:0;s:" + (9 + zAdi_Client.Length) + ":\"nickname=" + zAdi_Client + "\";}}}}',";
                            if (!string.IsNullOrEmpty(zAdi_Brand) && string.IsNullOrEmpty(zAdi_ItemCode))
                            {
                                update_dsq += " filters = 'a:1:{i:0;a:6:{s:3:\"qty\";s:1:\"1\";s:4:\"type\";s:21:\"product_custom_fields\";s:10:\"limitation\";s:4:\"none\";s:6:\"method\";s:7:\"in_list\";s:5:\"value\";a:1:{i:0;s:" + (zAdi_Brand.Length + 6) + ":\"marca=" + zAdi_Brand + "\";}s:15:\"product_exclude\";a:1:{s:10:\"on_wc_sale\";s:1:\"1\";}}}',";
                                update_dsq += " product_adjustments = 'a:4:{s:4:\"type\";s:5:\"total\";s:5:\"total\";a:2:{s:4:\"type\";s:20:\"discount__percentage\";s:5:\"value\";s:" + zAdi_PercentDesc.ToString().Length + ":\"" + zAdi_PercentDesc + "\";}s:5:\"split\";a:1:{i:0;a:2:{s:4:\"type\";s:16:\"discount__amount\";s:5:\"value\";s:0:\"\";}}s:16:\"max_discount_sum\";s:0:\"\";}'";
                            }
                            else if (!string.IsNullOrEmpty(zAdi_ItemCode) && !string.IsNullOrEmpty(zAdi_Brand))
                            {
                                update_dsq += " filters = 'a:1:{i:1;a:6:{s:3:\"qty\";s:1:\"1\";s:4:\"type\";s:11:\"product_sku\";s:10:\"limitation\";s:4:\"none\";s:6:\"method\";s:7:\"in_list\";s:5:\"value\";a:1:{i:0;s:" + zAdi_ItemCode.Length + ":\"" + zAdi_ItemCode + "\";}s:15:\"product_exclude\";a:1:{s:10:\"on_wc_sale\";s:1:\"1\";}}}',";
                                update_dsq += " product_adjustments = 'a:4:{s:4:\"type\";s:5:\"total\";s:5:\"total\";a:2:{s:4:\"type\";s:20:\"discount__percentage\";s:5:\"value\";s:" + zAdi_PercentDesc.ToString().Length + ":\"" + zAdi_PercentDesc + "\";}s:5:\"split\";a:1:{i:1;a:2:{s:4:\"type\";s:16:\"discount__amount\";s:5:\"value\";s:0:\"\";}}s:16:\"max_discount_sum\";s:0:\"\";}'";
                            }


                            update_dsq += $" WHERE id = {idRule}";

                            try
                            {
                                DBConnMysql.ExecQueryUpdate(update_dsq);

                                #region UPDATE FROM DB SAP HANA

                                string update_SAP = $"UPDATE {Utils.parseStringBD("zAdi_SyncPricing")} SET";
                                update_SAP += $" {Utils.parseStringBD("zAdi_DateSend")} = NOW(), {Utils.parseStringBD("zAdi_FlagSend")} = TRUE";
                                update_SAP += $" WHERE {Utils.parseStringBD("zAdi_NameRule")} = '{zAdi_nameRule}' AND  {Utils.parseStringBD("zAdi_Action")} = 'UPDATE' AND {Utils.parseStringBD("zAdi_FlagSend")} = FALSE AND {Utils.parseStringBD("zAdi_TypeDesc")} = 'DESC_CLI_MARCA_PROD'";

                                DBConn.ExecQueryUpdate(update_SAP, DBConn.ConectionDB.Bitacoras);
                                #endregion
                            }
                            catch (Exception ex)
                            {
                                Utils.PrintLog("SyncPricingUpdate_DESC_CLI_MARCA_PROD", "2", ex.ToString());

                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("SyncPricingUpdate_DESC_CLI_MARCA_PROD", "1", ex.ToString());
            }
        }

        #region v2

        public void SyncLogPricing_DESC_CLI_MARCA()
        {
            try
            {
                string select_desc_cli_marca = $"SELECT TOP {Utils.rangoRegistros_pricing} ";
                select_desc_cli_marca += $"{Utils.parseStringBD("Code")},";
                select_desc_cli_marca += $"{Utils.parseStringBD("U_Cliente")},";
                select_desc_cli_marca += $"{Utils.parseStringBD("U_Marca")},";
                select_desc_cli_marca += $"{Utils.parseStringBD("U_PorcentajeDesc")}";
                select_desc_cli_marca += $" FROM {Utils.parseStringBD("@DESC_CLI_MARCA_PROD")}";
                select_desc_cli_marca += $" LEFT JOIN {Utils.parseStringBD(DBConn.DBBitacoras)}.{Utils.parseStringBD("zAdi_SyncPricing")} ON {Utils.parseStringBD("Code")} = {Utils.parseStringBD("zAdi_CodeRule")}";
                select_desc_cli_marca += $" WHERE {Utils.parseStringBD("U_Cliente")} IS NOT NULL AND {Utils.parseStringBD("U_Marca")} IS NOT NULL AND {Utils.parseStringBD("U_Producto")} IS NULL AND {Utils.parseStringBD("zAdi_CodeRule")} IS NULL";

                //Utils.PrintLog("SyncLogPricing_DESC_CLI_MARCA", "0", $"select_desc_cli_marca: {select_desc_cli_marca}");
                DataTable tbl_desc = DBConn.ExecQuery(select_desc_cli_marca);
                if(tbl_desc != null && tbl_desc.Rows != null && tbl_desc.Rows.Count > 0)
                {
                    foreach(DataRow row in tbl_desc.Rows)
                    {
                        string Code = row["Code"].ToString();
                        string Cliente = row["U_Cliente"].ToString();
                        string Marca = row["U_Marca"].ToString();
                        string Porcentaje = row["U_PorcentajeDesc"] != null && !string.IsNullOrEmpty(row["U_PorcentajeDesc"].ToString()) ? row["U_PorcentajeDesc"].ToString() : "0";

                        string insert_DESC_CLI_MARCA_PROD = string.Empty;
                        insert_DESC_CLI_MARCA_PROD = $"INSERT INTO {Utils.parseStringBD("zAdi_SyncPricing")} (";
                        insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_TypeDesc")},";
                        insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_NameRule")},";
                        insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_Client")},";
                        insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_Brand")},";
                        insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_PercentDesc")},";
                        insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_Comision")},";
                        insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_DateRegister")},";
                        insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_FlagSend")},";
                        insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_Action")},";
                        insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_OldNameRule")},";
                        insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_FlagEnable")},";
                        insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_CodeRule")}";
                        insert_DESC_CLI_MARCA_PROD += $")";
                        insert_DESC_CLI_MARCA_PROD += $" VALUES (";
                        insert_DESC_CLI_MARCA_PROD += $" 'DESC_CLI_MARCA_PROD',";//zAdi_TypeDesc
                        insert_DESC_CLI_MARCA_PROD += $" '{Code}',";//zAdi_NameRule
                        insert_DESC_CLI_MARCA_PROD += $" '{Cliente}',";//zAdi_Client
                        insert_DESC_CLI_MARCA_PROD += $" '{Marca}',";//zAdi_Brand
                        insert_DESC_CLI_MARCA_PROD += $" {Porcentaje},";//zAdi_PercentDesc
                        insert_DESC_CLI_MARCA_PROD += $" 1,";//zAdi_Comision
                        insert_DESC_CLI_MARCA_PROD += $" NOW(),";//zAdi_DateRegister
                        insert_DESC_CLI_MARCA_PROD += $" FALSE,";//zAdi_FlagSend
                        insert_DESC_CLI_MARCA_PROD += $" 'INSERT',";//zAdi_Action
                        insert_DESC_CLI_MARCA_PROD += $"'{Code}',";//zAdi_OldNameRule
                        insert_DESC_CLI_MARCA_PROD += $" TRUE,";//zAdi_FlagEnable
                        insert_DESC_CLI_MARCA_PROD += $" '{Code}'";//zAdi_CodeRule
                        insert_DESC_CLI_MARCA_PROD += $");";
                        //Utils.PrintLog("RegisterLogPricing_DESC_CLI_MARCA_PROD", "0", $"insert_DESC_CLI_MARCA_PROD: {insert_DESC_CLI_MARCA_PROD}");
                        bool fgInsert = DBConn.ExecQueryInsert(insert_DESC_CLI_MARCA_PROD, DBConn.ConectionDB.Bitacoras);
                        if (!fgInsert)
                            Utils.PrintLog("RegisterLogPricing_DESC_CLI_MARCA_PROD", "0", $"No fue posible realizar la sincronización de la regla de precio {Code}");

                    }
                }
            }
            catch(Exception ex)
            {
                Utils.PrintLog("SyncPricing_DESC_CLI_MARCA", "1", ex.ToString());
            }
        }

        public void SyncLogPricing_DESC_CLI_MARCA_PROD()
        {
            try
            {
                string select_desc_cli_marca = $"SELECT TOP {Utils.rangoRegistros_pricing} ";
                select_desc_cli_marca += $"{Utils.parseStringBD("Code")},";
                select_desc_cli_marca += $" {Utils.parseStringBD("U_Cliente")},";
                select_desc_cli_marca += $" {Utils.parseStringBD("U_Marca")},";
                select_desc_cli_marca += $" {Utils.parseStringBD("U_Producto")},";
                select_desc_cli_marca += $" {Utils.parseStringBD("U_PorcentajeDesc")}";
                select_desc_cli_marca += $" FROM {Utils.parseStringBD("@DESC_CLI_MARCA_PROD")}";
                select_desc_cli_marca += $" LEFT JOIN {Utils.parseStringBD(DBConn.DBBitacoras)}.{Utils.parseStringBD("zAdi_SyncPricing")} ON {Utils.parseStringBD("Code")} = {Utils.parseStringBD("zAdi_CodeRule")}";
                select_desc_cli_marca += $" WHERE {Utils.parseStringBD("U_Cliente")} IS NOT NULL AND {Utils.parseStringBD("U_Marca")} IS NOT NULL AND {Utils.parseStringBD("U_Producto")} IS NOT NULL AND {Utils.parseStringBD("zAdi_CodeRule")} IS NULL";
                //Utils.PrintLog("SyncLogPricing_DESC_CLI_MARCA_PROD", "0", $"select_desc_cli_marca: {select_desc_cli_marca}");
                DataTable tbl_desc = DBConn.ExecQuery(select_desc_cli_marca);
                if (tbl_desc != null && tbl_desc.Rows != null && tbl_desc.Rows.Count > 0)
                {
                    foreach(DataRow row in tbl_desc.Rows)
                    {
                        string Code = row["Code"].ToString();
                        string Cliente = row["U_Cliente"].ToString();
                        string Marca = row["U_Marca"].ToString();
                        string Producto = row["U_Producto"].ToString();
                        string Porcentaje = row["U_PorcentajeDesc"] != null && !string.IsNullOrEmpty(row["U_PorcentajeDesc"].ToString()) ? row["U_PorcentajeDesc"].ToString() : "0";

                        string insert_DESC_CLI_MARCA_PROD = string.Empty;
                        insert_DESC_CLI_MARCA_PROD = $"INSERT INTO {Utils.parseStringBD("zAdi_SyncPricing")} (";
                        insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_TypeDesc")},";
                        insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_NameRule")},";
                        insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_Client")},";
                        insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_Brand")},";
                        insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_ItemCode")},";
                        insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_PercentDesc")},";
                        insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_Comision")},";
                        insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_DateRegister")},";
                        insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_FlagSend")},";
                        insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_Action")},";
                        insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_OldNameRule")},";
                        insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_FlagEnable")},";
                        insert_DESC_CLI_MARCA_PROD += $"{Utils.parseStringBD("zAdi_CodeRule")}";
                        insert_DESC_CLI_MARCA_PROD += $")";
                        insert_DESC_CLI_MARCA_PROD += $" VALUES (";
                        insert_DESC_CLI_MARCA_PROD += $" 'DESC_CLI_MARCA_PROD',"; //zAdi_TypeDesc
                        insert_DESC_CLI_MARCA_PROD += $" '{Code} P',";//zAdi_NameRule
                        insert_DESC_CLI_MARCA_PROD += $" '{Cliente}',";//zAdi_Client
                        insert_DESC_CLI_MARCA_PROD += $" '{Marca}',";//zAdi_Brand
                        insert_DESC_CLI_MARCA_PROD += $" '{Producto}',";//zAdi_ItemCode
                        insert_DESC_CLI_MARCA_PROD += $" {Porcentaje},";//zAdi_PercentDesc
                        insert_DESC_CLI_MARCA_PROD += $" 1,";//zAdi_Comision
                        insert_DESC_CLI_MARCA_PROD += $" NOW(),";//zAdi_DateRegister
                        insert_DESC_CLI_MARCA_PROD += $" FALSE,";//zAdi_FlagSend
                        insert_DESC_CLI_MARCA_PROD += $" 'INSERT',";//zAdi_Action
                        insert_DESC_CLI_MARCA_PROD += $"'{Code} P',";//zAdi_OldNameRule
                        insert_DESC_CLI_MARCA_PROD += $" TRUE,";//zAdi_FlagEnable
                        insert_DESC_CLI_MARCA_PROD += $" '{Code}'";//zAdi_CodeRule
                        insert_DESC_CLI_MARCA_PROD += $");";

                        bool fgInsert = DBConn.ExecQueryInsert(insert_DESC_CLI_MARCA_PROD, DBConn.ConectionDB.Bitacoras);
                        if (!fgInsert)
                            Utils.PrintLog("RegisterLogPricing_DESC_CLI_MARCA_PROD", "0", $"No fue posible realizar la sincronización de la regla de precio {Code}");
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("SyncLogPricing_DESC_CLI_MARCA_PROD", "1", ex.ToString());
            }
        }

        public void SyncPricing_DESC_CLI_MARCA_PROD_v2()
        {
            try
            {

                string select_DESC_CLI_MARCA_PROD = $"SELECT TOP {Utils.rangoRegistros_pricing}";
                select_DESC_CLI_MARCA_PROD += $" {Utils.parseStringBD("zAdi_SyncPricingId")},";
                select_DESC_CLI_MARCA_PROD += $" {Utils.parseStringBD("zAdi_NameRule")},";
                select_DESC_CLI_MARCA_PROD += $" {Utils.parseStringBD("zAdi_Client")},";
                select_DESC_CLI_MARCA_PROD += $" {Utils.parseStringBD("zAdi_Brand")},";
                select_DESC_CLI_MARCA_PROD += $" {Utils.parseStringBD("zAdi_ItemCode")},";
                select_DESC_CLI_MARCA_PROD += $" {Utils.parseStringBD("zAdi_PercentDesc")},";
                select_DESC_CLI_MARCA_PROD += $" {Utils.parseStringBD("zAdi_Comision")}";
                select_DESC_CLI_MARCA_PROD += $" FROM {Utils.parseStringBD("zAdi_SyncPricing")}";
                select_DESC_CLI_MARCA_PROD += $" WHERE {Utils.parseStringBD("zAdi_FlagSend")} = FALSE AND {Utils.parseStringBD("zAdi_Action")} = 'INSERT' AND {Utils.parseStringBD("zAdi_TypeDesc")} = 'DESC_CLI_MARCA_PROD'";

                DataTable tbl_select_DESC_CLI_MARCA_PROD = DBConn.ExecQuery(select_DESC_CLI_MARCA_PROD, DBConn.ConectionDB.Bitacoras);
                if (tbl_select_DESC_CLI_MARCA_PROD != null && tbl_select_DESC_CLI_MARCA_PROD.Rows != null && tbl_select_DESC_CLI_MARCA_PROD.Rows.Count > 0)
                {
                    foreach (DataRow row_select_DESC_CLI_MARCA_PROD in tbl_select_DESC_CLI_MARCA_PROD.Rows)
                    {
                        string select_validate_exist = $"SELECT * FROM dsq_wdp_rules WHERE title = '{row_select_DESC_CLI_MARCA_PROD.ItemArray[0].ToString()}' AND deleted != 1";

                        DataTable validate_exist = DBConnMysql.ExecQuery(select_validate_exist);

                        if (!(validate_exist != null && validate_exist.Rows != null && validate_exist.Rows.Count > 0))
                        {
                            long zAdi_IdSyncPricing = long.Parse(row_select_DESC_CLI_MARCA_PROD["zAdi_SyncPricingId"].ToString());
                            string zAdi_NameRule = row_select_DESC_CLI_MARCA_PROD["zAdi_NameRule"].ToString();
                            string zAdi_Client = row_select_DESC_CLI_MARCA_PROD["zAdi_Client"].ToString();
                            string zAdi_Brand = row_select_DESC_CLI_MARCA_PROD["zAdi_Brand"].ToString();
                            string zAdi_ItemCode = row_select_DESC_CLI_MARCA_PROD["zAdi_ItemCode"] != null && row_select_DESC_CLI_MARCA_PROD["zAdi_ItemCode"].ToString() != "" ? row_select_DESC_CLI_MARCA_PROD["zAdi_ItemCode"].ToString() : "";
                            double zAdi_PercentDesc = double.Parse(row_select_DESC_CLI_MARCA_PROD["zAdi_PercentDesc"].ToString());
                            double zAdi_Comision = double.Parse(row_select_DESC_CLI_MARCA_PROD["zAdi_Comision"].ToString());

                            string max_priotity = "SELECT MAX(priority) FROM dsq_wdp_rules";
                            DataTable tbl_max_priority = DBConnMysql.ExecQuery(max_priotity);
                            string insert_dsq_wdp_rules = "INSERT INTO `dsq_wdp_rules` VALUES(";
                            insert_dsq_wdp_rules += "NULL,";
                            insert_dsq_wdp_rules += "0,";
                            insert_dsq_wdp_rules += "1,";
                            insert_dsq_wdp_rules += "1,";
                            insert_dsq_wdp_rules += "'package',";
                            /*tittle*/
                            insert_dsq_wdp_rules += Convert.ToString($"'{zAdi_NameRule}',");
                            /*priority*/
                            insert_dsq_wdp_rules += Convert.ToString($"{(tbl_max_priority != null && tbl_max_priority.Rows != null ? int.Parse(tbl_max_priority.Rows[0].ItemArray[0].ToString()) + 1 : 0)},");
                            /*options*/
                            insert_dsq_wdp_rules += Convert.ToString("'a:2:{s:6:\"repeat\";s:2:\"-1\";s:8:\"apply_to\";s:8:\"appeared\";}',"); 
                            /*aditional*/      //listo
                            insert_dsq_wdp_rules += Convert.ToString("'a:5:{s:19:\"trigger_coupon_code\";s:0:\"\";s:12:\"replace_name\";s:0:\"\";s:19:\"sortable_apply_mode\";s:12:\"consistently\";s:26:\"free_products_replace_name\";s:0:\"\";s:23:\"conditions_relationship\";s:2:\"or\";}',");
                            /*conditions*/
                            insert_dsq_wdp_rules += Convert.ToString("'a:1:{i:0;a:2:{s:4:\"type\";s:8:\"usermeta\";s:7:\"options\";a:4:{i:0;s:1:\"1\";i:3;s:0:\"\";i:1;s:7:\"in_list\";i:2;a:1:{i:0;s:" + (9 + zAdi_Client.Length) + ":\"nickname=" + zAdi_Client + "\";}}}}',"); //listo
                            /*filters*******/
                            if (!string.IsNullOrEmpty(zAdi_Brand) && string.IsNullOrEmpty(zAdi_ItemCode))
                                insert_dsq_wdp_rules += " 'a:1:{i:0;a:6:{s:3:\"qty\";s:1:\"1\";s:4:\"type\";s:21:\"product_custom_fields\";s:10:\"limitation\";s:4:\"none\";s:6:\"method\";s:7:\"in_list\";s:5:\"value\";a:1:{i:0;s:" + (zAdi_Brand.Length + 6) + ":\"marca=" + zAdi_Brand + "\";}s:15:\"product_exclude\";a:1:{s:10:\"on_wc_sale\";s:1:\"1\";}}}',";
                            else if (!string.IsNullOrEmpty(zAdi_ItemCode) && !string.IsNullOrEmpty(zAdi_Brand))
                                insert_dsq_wdp_rules += " 'a:1:{i:1;a:6:{s:3:\"qty\";s:1:\"1\";s:4:\"type\";s:11:\"product_sku\";s:10:\"limitation\";s:4:\"none\";s:6:\"method\";s:7:\"in_list\";s:5:\"value\";a:1:{i:0;s:" + zAdi_ItemCode.Length + ":\"" + zAdi_ItemCode + "\";}s:15:\"product_exclude\";a:1:{s:10:\"on_wc_sale\";s:1:\"1\";}}}',";
                            else
                                insert_dsq_wdp_rules += " '',";

                            /*limits*/
                            insert_dsq_wdp_rules += Convert.ToString("'a:0:{}',");
                            /*product_adjustments******/
                            if (!string.IsNullOrEmpty(zAdi_Brand) && string.IsNullOrEmpty(zAdi_ItemCode))
                                insert_dsq_wdp_rules += "'a:4:{s:4:\"type\";s:5:\"total\";s:5:\"total\";a:2:{s:4:\"type\";s:20:\"discount__percentage\";s:5:\"value\";s:" + zAdi_PercentDesc.ToString().Length + ":\"" + zAdi_PercentDesc + "\";}s:5:\"split\";a:1:{i:0;a:2:{s:4:\"type\";s:16:\"discount__amount\";s:5:\"value\";s:0:\"\";}}s:16:\"max_discount_sum\";s:0:\"\";}',";
                            else if (!string.IsNullOrEmpty(zAdi_ItemCode) && !string.IsNullOrEmpty(zAdi_Brand))
                                insert_dsq_wdp_rules += " 'a:4:{s:4:\"type\";s:5:\"total\";s:5:\"total\";a:2:{s:4:\"type\";s:20:\"discount__percentage\";s:5:\"value\";s:" + zAdi_PercentDesc.ToString().Length + ":\"" + zAdi_PercentDesc + "\";}s:5:\"split\";a:1:{i:1;a:2:{s:4:\"type\";s:16:\"discount__amount\";s:5:\"value\";s:0:\"\";}}s:16:\"max_discount_sum\";s:0:\"\";}',";
                            else
                                insert_dsq_wdp_rules += " '',";

                            /*sortable_blocks_priority*/
                            insert_dsq_wdp_rules += Convert.ToString("'a:2:{i:0;s:5:\"roles\";i:1;s:16:\"bulk-adjustments\";}',");
                            /*bulk_adjustments*/
                            insert_dsq_wdp_rules += Convert.ToString("'a:2:{s:4:\"type\";s:4:\"bulk\";s:13:\"table_message\";s:0:\"\";}',");
                            /*role_discounts*/
                            insert_dsq_wdp_rules += Convert.ToString("'a:0:{}',");
                            /*cart_adjustments*/
                            insert_dsq_wdp_rules += Convert.ToString("'a:0:{}',");
                            /*get_products*/
                            insert_dsq_wdp_rules += Convert.ToString("'a:2:{s:6:\"repeat\";s:2:\"-1\";s:15:\"repeat_subtotal\";s:0:\"\";}')");

                            try
                            {
                                DBConnMysql.ExecQueryInsert(insert_dsq_wdp_rules);
                                string select_dsq_wdp_rules = $"SELECT id FROM dsq_wdp_rules WHERE title = '{zAdi_NameRule}' AND deleted != 1 LIMIT 1";
                                DataTable tbl_select_dsq_wdp_rules = DBConnMysql.ExecQuery(select_dsq_wdp_rules);
                                if (tbl_select_dsq_wdp_rules != null && tbl_select_dsq_wdp_rules.Rows != null && tbl_select_dsq_wdp_rules.Rows.Count > 0)
                                {
                                    #region UPDATE SAP HANA

                                    string update_SyncPricing = $"UPDATE {Utils.parseStringBD("zAdi_SyncPricing")}";
                                    update_SyncPricing += $" SET {Utils.parseStringBD("zAdi_DateSend")} = NOW(), {Utils.parseStringBD("zAdi_FlagSend")} = TRUE, {Utils.parseStringBD("zAdi_IdRuleWooCommerce")} = {tbl_select_dsq_wdp_rules.Rows[0]["id"].ToString()}";
                                    update_SyncPricing += $" WHERE {Utils.parseStringBD("zAdi_SyncPricingId")} = {zAdi_IdSyncPricing}";
                                    //update_SyncPricing += $" WHERE {Utils.parseStringBD("zAdi_NameRule")} = '{zAdi_NameRule}' AND {Utils.parseStringBD("zAdi_Action")} = 'INSERT' AND {Utils.parseStringBD("zAdi_Client")} = '{zAdi_Client}'  AND {Utils.parseStringBD("zAdi_Brand")} = '{zAdi_Brand}'";

                                    DBConn.ExecQueryUpdate(update_SyncPricing, DBConn.ConectionDB.Bitacoras);
                                    #endregion
                                }
                                else
                                {
                                    Utils.PrintLog("SyncPricing_DESC_CLI_MARCA_PROD", "0", $"No fue posible realizar la sincronización de la regla de precio {zAdi_NameRule}. query : {insert_dsq_wdp_rules}");
                                }
                            }
                            catch (Exception ex)
                            {
                                Utils.PrintLog("SyncPricing_DESC_CLI_MARCA_PROD", "2", ex.ToString());
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("SyncPricing_DESC_CLI_MARCA_PROD", "1", ex.ToString());
            }
        }
        #endregion

        #endregion

        #region DESC_MARCA
        public void RegisterLogPricingDESC_BY_MARCA()
        {
            try
            {

                string select_DESC_BY_MARCA = $"SELECT TOP {Utils.rangoRegistros_pricing}";
                #region campos
                select_DESC_BY_MARCA += $" {Utils.parseStringBD("U_Marca")},";
                select_DESC_BY_MARCA += $" {Utils.parseStringBD("U_Descuento")}";
                #endregion
                select_DESC_BY_MARCA += $" FROM {Utils.parseStringBD("@DESC_MARCA")}";
                select_DESC_BY_MARCA += $" WHERE {Utils.parseStringBD("@DESC_MARCA")}.{Utils.parseStringBD("U_Marca")} IS NOT NULL";
                select_DESC_BY_MARCA += $" AND { Utils.parseStringBD("@DESC_MARCA")}.{Utils.parseStringBD("U_Descuento")} IS NOT NULL";
                select_DESC_BY_MARCA += $" AND NOT EXISTS (SELECT DISTINCT {Utils.parseStringBD("zAdi_SyncPricing")}.{Utils.parseStringBD("zAdi_Brand")} FROM {Utils.parseStringBD(DBConn.DBBitacoras)}.{Utils.parseStringBD("zAdi_SyncPricing")} WHERE {Utils.parseStringBD("zAdi_SyncPricing")}.{Utils.parseStringBD("zAdi_TypeDesc")} = 'DESC_BY_MARCA' AND {Utils.parseStringBD("@DESC_MARCA")}.{Utils.parseStringBD("U_Marca")} = {Utils.parseStringBD("zAdi_SyncPricing")}.{Utils.parseStringBD("zAdi_Brand")} )";

                DataTable tbl_DESC_BY_MARCA = tbl_DESC_BY_MARCA = DBConn.ExecQuery(select_DESC_BY_MARCA);

                if (tbl_DESC_BY_MARCA != null && tbl_DESC_BY_MARCA.Rows != null && tbl_DESC_BY_MARCA.Rows.Count > 0)
                {
                    foreach (DataRow row_DESC_BY_MARCA in tbl_DESC_BY_MARCA.Rows)
                    {
                        string U_Marca = row_DESC_BY_MARCA.ItemArray[0] != null ? row_DESC_BY_MARCA.ItemArray[0].ToString() : "";
                        string U_Descuento = row_DESC_BY_MARCA.ItemArray[1] != null ? row_DESC_BY_MARCA.ItemArray[1].ToString() : "";

                        string insert_DESC_BY_MARCA = $"INSERT INTO {Utils.parseStringBD("zAdi_SyncPricing")} (";
                        insert_DESC_BY_MARCA += $"{Utils.parseStringBD("zAdi_Brand")},";
                        insert_DESC_BY_MARCA += $"{Utils.parseStringBD("zAdi_PercentDesc")},";
                        insert_DESC_BY_MARCA += $"{Utils.parseStringBD("zAdi_TypeDesc")},";
                        insert_DESC_BY_MARCA += $"{Utils.parseStringBD("zAdi_Comision")},";
                        insert_DESC_BY_MARCA += $"{Utils.parseStringBD("zAdi_DateRegister")},";
                        insert_DESC_BY_MARCA += $"{Utils.parseStringBD("zAdi_FlagSend")},";
                        insert_DESC_BY_MARCA += $"{Utils.parseStringBD("zAdi_Action")},";
                        insert_DESC_BY_MARCA += $"{Utils.parseStringBD("zAdi_NameRule")},";
                        insert_DESC_BY_MARCA += $"{Utils.parseStringBD("zAdi_FlagEnable")}";
                        insert_DESC_BY_MARCA += $")";
                        insert_DESC_BY_MARCA += $" VALUES (";
                        insert_DESC_BY_MARCA += $" '{U_Marca}',";
                        insert_DESC_BY_MARCA += $" '{U_Descuento}',";
                        insert_DESC_BY_MARCA += $" 'DESC_BY_MARCA',";
                        insert_DESC_BY_MARCA += $" 1,";
                        insert_DESC_BY_MARCA += $" NOW(),";
                        insert_DESC_BY_MARCA += $" FALSE,";
                        insert_DESC_BY_MARCA += $" 'INSERT',";
                        insert_DESC_BY_MARCA += $" 'DESCUENTO DE MARCA {U_Marca.ToString()}',";
                        insert_DESC_BY_MARCA += $" TRUE";
                        insert_DESC_BY_MARCA += $");";

                        bool fgInsert = DBConn.ExecQueryInsert(insert_DESC_BY_MARCA, DBConn.ConectionDB.Bitacoras);
                        if (!fgInsert)
                        {
                            Utils.PrintLog("RegisterLogPricingDESC_BY_MARCA", "0", $"No fue posible realizar la sincronización la regla de precio {U_Marca}. \n query: {insert_DESC_BY_MARCA}");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("RegisterLogPricingDESC_BY_MARCA", "1", ex.ToString());
            }
        }

        public void SyncPricing_BY_MARCA()
        {
            //string path = "C:\\SyncPricingAlan_BY_MARCA.txt";
            try
            {
                string select_DESC_BY_MARCA = $"SELECT TOP {Utils.rangoRegistros_pricing}";
                #region campos

                select_DESC_BY_MARCA += $" {Utils.parseStringBD("zAdi_Brand")},";
                select_DESC_BY_MARCA += $" {Utils.parseStringBD("zAdi_PercentDesc")},";
                select_DESC_BY_MARCA += $" {Utils.parseStringBD("zAdi_TypeDesc")},";
                select_DESC_BY_MARCA += $" {Utils.parseStringBD("zAdi_Comision")},";
                //select_DESC_BY_MARCA += $" {Utils.parseStringBD("zAdi_DateRegiste")},";
                //select_DESC_BY_MARCA += $" {Utils.parseStringBD("zAdi_FlagSend")},";
                //select_DESC_BY_MARCA += $" {Utils.parseStringBD("zAdi_Action")},";
                select_DESC_BY_MARCA += $" {Utils.parseStringBD("zAdi_NameRule")}";
                #endregion
                select_DESC_BY_MARCA += $" FROM {Utils.parseStringBD("zAdi_SyncPricing")}";
                select_DESC_BY_MARCA += $" WHERE {Utils.parseStringBD("zAdi_FlagSend")} = FALSE AND {Utils.parseStringBD("zAdi_Action")} = 'INSERT' AND {Utils.parseStringBD("zAdi_TypeDesc")} = 'DESC_BY_MARCA'";


                DataTable tbl_select_DESC_BY_MARCA = DBConn.ExecQuery(select_DESC_BY_MARCA, DBConn.ConectionDB.Bitacoras);
                if (tbl_select_DESC_BY_MARCA != null && tbl_select_DESC_BY_MARCA.Rows != null && tbl_select_DESC_BY_MARCA.Rows.Count > 0)
                {
                    foreach (DataRow row_select_DESC_BY_MARCA in tbl_select_DESC_BY_MARCA.Rows)
                    {
                        string zAdi_Brand = row_select_DESC_BY_MARCA.ItemArray[0].ToString();
                        double zAdi_PercentDesc = double.Parse(row_select_DESC_BY_MARCA.ItemArray[1].ToString());
                        string zAdi_TypeDesc = row_select_DESC_BY_MARCA.ItemArray[2].ToString();
                        double zAdi_Comision = double.Parse(row_select_DESC_BY_MARCA.ItemArray[3].ToString());
                        string zAdi_NameRule = row_select_DESC_BY_MARCA.ItemArray[4].ToString();

                        string select_validate_exist = $"SELECT id FROM dsq_wdp_rules WHERE title = '{row_select_DESC_BY_MARCA.ItemArray[4].ToString()}' AND deleted != 1 LIMIT 1";

                        DataTable validate_exist = DBConnMysql.ExecQuery(select_validate_exist);

                        if (!(validate_exist != null && validate_exist.Rows != null && validate_exist.Rows.Count > 0))
                        {

                            

                            string max_priotity = "SELECT MAX(priority) FROM dsq_wdp_rules";
                            DataTable tbl_max_priority = DBConnMysql.ExecQuery(max_priotity);

                            string insert_dsq_wdp_rules = "INSERT INTO `dsq_wdp_rules` VALUES(";
                            insert_dsq_wdp_rules += "NULL,";
                            insert_dsq_wdp_rules += "0,";
                            insert_dsq_wdp_rules += "1,";
                            insert_dsq_wdp_rules += "0,";
                            insert_dsq_wdp_rules += "'package',";
                            /*tittle*/
                            insert_dsq_wdp_rules += Convert.ToString($"'{zAdi_NameRule}',");
                            /*priority*/
                            insert_dsq_wdp_rules += Convert.ToString($"{(tbl_max_priority != null && tbl_max_priority.Rows != null ? int.Parse(tbl_max_priority.Rows[0].ItemArray[0].ToString()) + 1 : 0)},");
                            /*options*/
                            insert_dsq_wdp_rules += Convert.ToString("'a:2:{s:6:\"repeat\";s:2:\"-1\";s:8:\"apply_to\";s:8:\"appeared\";}',"); //listo
                            /*aditional*/      //listo
                            insert_dsq_wdp_rules += Convert.ToString("'a:5:{s:19:\"trigger_coupon_code\";s:0:\"\";s:12:\"replace_name\";s:0:\"\";s:19:\"sortable_apply_mode\";s:12:\"consistently\";s:26:\"free_products_replace_name\";s:0:\"\";s:23:\"conditions_relationship\";s:2:\"or\";}',");
                            /*conditions*/
                            //insert_dsq_wdp_rules += Convert.ToString("'a:1:{i:0;a:2:{s:4:\"type\";s:14:\"customer_users\";s:7:\"options\";a:2:{i:0;s:7:\"in_list\";i:1;a:1:{i:0;s:1:\"1\";}}}}',"); //listo
                            insert_dsq_wdp_rules += Convert.ToString("'a:0:{}',"); //listo
                                                                                   /*filters*******/
                            insert_dsq_wdp_rules += " 'a:1:{i:0;a:6:{s:3:\"qty\";s:1:\"1\";s:4:\"type\";s:21:\"product_custom_fields\";s:10:\"limitation\";s:4:\"none\";s:6:\"method\";s:7:\"in_list\";s:5:\"value\";a:1:{i:0;s:" + (zAdi_Brand.Length + 6) + ":\"marca=" + zAdi_Brand + "\";}s:15:\"product_exclude\";a:1:{s:10:\"on_wc_sale\";s:1:\"1\";}}}',";

                            /*limits*/
                            insert_dsq_wdp_rules += Convert.ToString("'a:0:{}',");
                            /*product_adjustments******/
                            insert_dsq_wdp_rules += "'a:4:{s:4:\"type\";s:5:\"total\";s:5:\"total\";a:2:{s:4:\"type\";s:20:\"discount__percentage\";s:5:\"value\";s:" + zAdi_PercentDesc.ToString().Length + ":\"" + zAdi_PercentDesc + "\";}s:5:\"split\";a:1:{i:0;a:2:{s:4:\"type\";s:16:\"discount__amount\";s:5:\"value\";s:0:\"\";}}s:16:\"max_discount_sum\";s:0:\"\";}',";

                            /*sortable_blocks_priority*/
                            insert_dsq_wdp_rules += Convert.ToString("'a:2:{i:0;s:5:\"roles\";i:1;s:16:\"bulk-adjustments\";}',");
                            /*bulk_adjustments*/
                            insert_dsq_wdp_rules += Convert.ToString("'a:2:{s:4:\"type\";s:4:\"bulk\";s:13:\"table_message\";s:0:\"\";}',");
                            /*role_discounts*/
                            insert_dsq_wdp_rules += Convert.ToString("'a:0:{}',");
                            /*cart_adjustments*/
                            insert_dsq_wdp_rules += Convert.ToString("'a:0:{}',");
                            /*get_products*/
                            insert_dsq_wdp_rules += Convert.ToString("'a:2:{s:6:\"repeat\";s:2:\"-1\";s:15:\"repeat_subtotal\";s:0:\"\";}')");

                            try
                            {
                                DBConnMysql.ExecQueryInsert(insert_dsq_wdp_rules);
                                string select_dsq_wdp_rules = $"SELECT id FROM dsq_wdp_rules WHERE title = '{zAdi_NameRule}' AND deleted = 0 LIMIT 1";
                                DataTable tbl_select_dsq_wdp_rules = DBConnMysql.ExecQuery(select_dsq_wdp_rules);
                                if (tbl_select_dsq_wdp_rules != null && tbl_select_dsq_wdp_rules.Rows != null && tbl_select_dsq_wdp_rules.Rows.Count > 0)
                                {
                                    #region UPDATE SAP HANA

                                    string update_SyncPricing = $"UPDATE {Utils.parseStringBD("zAdi_SyncPricing")}";
                                    update_SyncPricing += $" SET {Utils.parseStringBD("zAdi_DateSend")} = NOW(), {Utils.parseStringBD("zAdi_FlagSend")} = TRUE, {Utils.parseStringBD("zAdi_IdRuleWooCommerce")} = {tbl_select_dsq_wdp_rules.Rows[0].ItemArray[0]}";
                                    update_SyncPricing += $" WHERE {Utils.parseStringBD("zAdi_TypeDesc")} = '{zAdi_TypeDesc}' AND {Utils.parseStringBD("zAdi_NameRule")} = '{zAdi_NameRule}' AND {Utils.parseStringBD("zAdi_Action")} = 'INSERT' AND {Utils.parseStringBD("zAdi_Brand")} = '{zAdi_Brand}'";

                                    DBConn.ExecQueryUpdate(update_SyncPricing, DBConn.ConectionDB.Bitacoras);
                                    #endregion
                                }
                                else
                                {
                                    Utils.PrintLog("SyncPricing_BY_MARCA", "0", $"No fue posible realizar la sincronización de la regla de precio {zAdi_NameRule}");
                                }
                            }
                            catch (Exception ex)
                            {
                                Utils.PrintLog("SyncPricing_BY_MARCA", "2", ex.ToString());
                            }
                        }
                        else
                        {
                            #region UPDATE SAP HANA

                            string update_SyncPricing = $"UPDATE {Utils.parseStringBD("zAdi_SyncPricing")}";
                            update_SyncPricing += $" SET {Utils.parseStringBD("zAdi_DateSend")} = NOW(), {Utils.parseStringBD("zAdi_FlagSend")} = TRUE, {Utils.parseStringBD("zAdi_IdRuleWooCommerce")} = {validate_exist.Rows[0]["id"].ToString()}";
                            update_SyncPricing += $" WHERE {Utils.parseStringBD("zAdi_TypeDesc")} = 'DESC_BY_MARCA' AND {Utils.parseStringBD("zAdi_NameRule")} = '{zAdi_NameRule}' AND {Utils.parseStringBD("zAdi_Action")} = 'INSERT' AND {Utils.parseStringBD("zAdi_Brand")} = '{zAdi_Brand}'";

                            DBConn.ExecQueryUpdate(update_SyncPricing, DBConn.ConectionDB.Bitacoras);
                            #endregion
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("SyncPricing_BY_MARCA", "1", ex.ToString());
            }
        }

        public void SyncPricingUpdate_DESC_BY_MARCA()
        {
            try
            {
                string select_DESC_BY_MARCA = $"SELECT TOP {Utils.rangoRegistros_pricing}";
                select_DESC_BY_MARCA += $" {Utils.parseStringBD("zAdi_Brand")},";
                select_DESC_BY_MARCA += $" {Utils.parseStringBD("zAdi_PercentDesc")},";
                select_DESC_BY_MARCA += $" {Utils.parseStringBD("zAdi_Comision")},";
                select_DESC_BY_MARCA += $" {Utils.parseStringBD("zAdi_NameRule")},";
                select_DESC_BY_MARCA += $" {Utils.parseStringBD("zAdi_IdRuleWooCommerce")}";
                select_DESC_BY_MARCA += $" FROM {Utils.parseStringBD("zAdi_SyncPricing")}";
                select_DESC_BY_MARCA += $" WHERE {Utils.parseStringBD("zAdi_FlagSend")} = FALSE AND {Utils.parseStringBD("zAdi_Action")} = 'UPDATE' AND {Utils.parseStringBD("zAdi_TypeDesc")} = 'DESC_BY_MARCA'";

                DataTable tbl_select_DESC_BY_MARCA = DBConn.ExecQuery(select_DESC_BY_MARCA, DBConn.ConectionDB.Bitacoras);
                if (tbl_select_DESC_BY_MARCA != null && tbl_select_DESC_BY_MARCA.Rows != null && tbl_select_DESC_BY_MARCA.Rows.Count > 0)
                {
                    foreach (DataRow row_select_DESC_BY_MARCA in tbl_select_DESC_BY_MARCA.Rows)
                    {
                        if (row_select_DESC_BY_MARCA["zAdi_IdRuleWooCommerce"] != null && !string.IsNullOrEmpty(row_select_DESC_BY_MARCA["zAdi_IdRuleWooCommerce"].ToString()))
                        {
                            string zAdi_Brand = row_select_DESC_BY_MARCA["zAdi_Brand"].ToString();
                            double zAdi_PercentDesc = double.Parse(row_select_DESC_BY_MARCA["zAdi_PercentDesc"].ToString());
                            double zAdi_Comision = double.Parse(row_select_DESC_BY_MARCA["zAdi_Comision"].ToString());
                            string zAdi_NameRule = row_select_DESC_BY_MARCA["zAdi_NameRule"].ToString();
                            int zAdi_IdRuleWooCommerce = int.Parse(row_select_DESC_BY_MARCA["zAdi_IdRuleWooCommerce"].ToString());


                            string update_dsq_wdp_rules = $"UPDATE dsq_wdp_rules SET";
                            /*title*/
                            update_dsq_wdp_rules += $" title = '{zAdi_NameRule}',";
                            /*filters*******/
                            if (!string.IsNullOrEmpty(zAdi_Brand))
                            {
                                //if (!string.IsNullOrEmpty(zAdi_ItemCode))
                                //    update_dsq_wdp_rules += " filters = 'a:2:{i:0;a:6:{s:3:\"qty\";s:1:\"1\";s:4:\"type\";s:21:\"product_custom_fields\";s:10:\"limitation\";s:4:\"none\";s:6:\"method\";s:7:\"in_list\";s:5:\"value\";a:1:{i:0;s:" + (zAdi_Brand.Length + 6) + ":\"marca=" + zAdi_Brand + "\";}s:15:\"product_exclude\";a:1:{s:10:\"on_wc_sale\";s:1:\"1\";}}i:1;a:6:{s:3:\"qty\";s:1:\"1\";s:4:\"type\";s:11:\"product_sku\";s:10:\"limitation\";s:4:\"none\";s:6:\"method\";s:7:\"in_list\";s:5:\"value\";a:1:{i:0;s:" + zAdi_ItemCode.Length + ":\"" + zAdi_ItemCode + "\";}s:15:\"product_exclude\";a:1:{s:10:\"on_wc_sale\";s:1:\"1\";}}}',";
                                //else
                                update_dsq_wdp_rules += " filters = 'a:1:{i:0;a:6:{s:3:\"qty\";s:1:\"1\";s:4:\"type\";s:21:\"product_custom_fields\";s:10:\"limitation\";s:4:\"none\";s:6:\"method\";s:7:\"in_list\";s:5:\"value\";a:1:{i:0;s:" + (zAdi_Brand.Length + 6) + ":\"marca=" + zAdi_Brand + "\";}s:15:\"product_exclude\";a:1:{s:10:\"on_wc_sale\";s:1:\"1\";}}}',";
                            }
                            else
                            {
                                update_dsq_wdp_rules += " filters = '',";
                            }
                            /*product_adjustments******/
                            if (!string.IsNullOrEmpty(zAdi_Brand))
                            {
                                update_dsq_wdp_rules += " product_adjustments = 'a:4:{s:4:\"type\";s:5:\"total\";s:5:\"total\";a:2:{s:4:\"type\";s:20:\"discount__percentage\";s:5:\"value\";s:" + zAdi_PercentDesc.ToString().Length + ":\"" + zAdi_PercentDesc + "\";}s:5:\"split\";a:1:{i:0;a:2:{s:4:\"type\";s:16:\"discount__amount\";s:5:\"value\";s:0:\"\";}}s:16:\"max_discount_sum\";s:0:\"\";}'";
                            }
                            else
                            {
                                update_dsq_wdp_rules += " product_adjustments = ''";
                            }
                            update_dsq_wdp_rules += $" WHERE id = {zAdi_IdRuleWooCommerce}";

                            try
                            {
                                bool fgUpdate = DBConnMysql.ExecQueryUpdate(update_dsq_wdp_rules);
                                if (!fgUpdate)
                                {
                                    Utils.PrintLog("SyncPricingUpdate_DESC_BY_MARCA", "0", $"No fue posible actualizar la regla de precio {zAdi_NameRule}. query: {update_dsq_wdp_rules}");
                                }
                                else
                                {

                                    #region UPDATE SAP HANA

                                    string update_SyncPricing = $"UPDATE {Utils.parseStringBD("zAdi_SyncPricing")}";
                                    update_SyncPricing += $" SET {Utils.parseStringBD("zAdi_DateSend")} = NOW(), {Utils.parseStringBD("zAdi_FlagSend")} = TRUE";
                                    update_SyncPricing += $" WHERE {Utils.parseStringBD("zAdi_IdRuleWooCommerce")} = {zAdi_IdRuleWooCommerce} AND {Utils.parseStringBD("zAdi_Action")} = 'UPDATE'";
                                    DBConn.ExecQueryUpdate(update_SyncPricing, DBConn.ConectionDB.Bitacoras);
                                    #endregion

                                }
                            }
                            catch (Exception ex)
                            {
                                Utils.PrintLog("SyncPricingUpdate_DESC_BY_MARCA", "2", ex.ToString());
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("SyncPricingUpdate_DESC_BY_MARCA", "1", ex.ToString());
            }
        }
        #endregion

        #region DESC_PROD_PER_CANT

        public void RegisterLogPricing_DESC_PROD_PER_CANT()
        {
            //string path = "C:\\RegisterLogPricing_DESC_PROD_PER_CANT.txt";

            try
            {
                string select_OSPP = $"SELECT TOP {Utils.rangoRegistros_pricing} DISTINCT";
                #region campos
                select_OSPP += $" {Utils.parseStringBD("ItemCode")},";
                select_OSPP += $" {Utils.parseStringBD("Price")},";
                select_OSPP += $" {Utils.parseStringBD("Currency")}";
                #endregion
                select_OSPP += $" FROM {Utils.parseStringBD("OSPP")}";
                select_OSPP += $" WHERE (SELECT COUNT(*) FROM {Utils.parseStringBD(DBConn.DBBitacoras)}.{Utils.parseStringBD("zAdi_SyncItems")} WHERE {Utils.parseStringBD("zAdi_SyncItems")}.{Utils.parseStringBD("zAdi_ItemCode")} = {Utils.parseStringBD("ItemCode")}) > 0";
                select_OSPP += $" AND (SELECT COUNT(*) FROM {Utils.parseStringBD(DBConn.DBBitacoras)}.{Utils.parseStringBD("zAdi_SyncPricing")} WHERE {Utils.parseStringBD("zAdi_CodeRule")} = {Utils.parseStringBD("ItemCode")} AND {Utils.parseStringBD("zAdi_TypeDesc")} = 'DESC_PROD_PER_CANT') = 0";
                DataTable tbl_OSPP = DBConn.ExecQuery(select_OSPP);
                if (tbl_OSPP != null && tbl_OSPP.Rows != null && tbl_OSPP.Rows.Count > 0)
                {
                    foreach (DataRow row_select_OSPP in tbl_OSPP.Rows)
                    {
                        string itemCode = row_select_OSPP.ItemArray[0].ToString();
                        double price = double.Parse(row_select_OSPP.ItemArray[1] != null ? row_select_OSPP.ItemArray[1].ToString() : "0");
                        string currency = row_select_OSPP.ItemArray[2].ToString();

                        // table PERIOD
                        string select_SPP1 = $"SELECT {Utils.parseStringBD("Price")}, {Utils.parseStringBD("Currency")}, {Utils.parseStringBD("Discount")}, {Utils.parseStringBD("FromDate")}, {Utils.parseStringBD("ToDate")}, {Utils.parseStringBD("U_Comision")}";
                        select_SPP1 += $" FROM {Utils.parseStringBD("SPP1")} WHERE {Utils.parseStringBD("ItemCode")} = '{itemCode}'";
                        DataTable tbl_SPP1 = DBConn.ExecQuery(select_SPP1);

                        //table quantity
                        string select_SPP2 = $" SELECT {Utils.parseStringBD("Amount")}, {Utils.parseStringBD("Price")}, {Utils.parseStringBD("Currency")}, {Utils.parseStringBD("Discount")}, {Utils.parseStringBD("U_Comision")}";
                        select_SPP2 += $" FROM {Utils.parseStringBD("SPP2")} WHERE {Utils.parseStringBD("ItemCode")} = '{itemCode}'";
                        DataTable tbl_SPP2 = DBConn.ExecQuery(select_SPP2);

                        string insert_DESC_PROD_PER_CANT = $"INSERT INTO {Utils.parseStringBD("zAdi_SyncPricing")} (";
                        insert_DESC_PROD_PER_CANT += $"{Utils.parseStringBD("zAdi_TypeDesc")},";
                        insert_DESC_PROD_PER_CANT += $" {Utils.parseStringBD("zAdi_NameRule")},";
                        insert_DESC_PROD_PER_CANT += $" {Utils.parseStringBD("zAdi_ItemCode")},";
                        insert_DESC_PROD_PER_CANT += $" {Utils.parseStringBD("zAdi_Price")},";
                        insert_DESC_PROD_PER_CANT += $" {Utils.parseStringBD("zAdi_Currency")},";
                        //insert_DESC_PROD_PER_CANT += $" {Utils.parseStringBD("zAdi_PercentDesc")},";
                        insert_DESC_PROD_PER_CANT += $" {Utils.parseStringBD("zAdi_Comision")},";
                        insert_DESC_PROD_PER_CANT += $" {Utils.parseStringBD("zAdi_DateRegister")},";
                        insert_DESC_PROD_PER_CANT += $" {Utils.parseStringBD("zAdi_FlagSend")},";
                        insert_DESC_PROD_PER_CANT += $" {Utils.parseStringBD("zAdi_Action")},";
                        insert_DESC_PROD_PER_CANT += $" {Utils.parseStringBD("zAdi_OldNameRule")},";
                        insert_DESC_PROD_PER_CANT += $" {Utils.parseStringBD("zAdi_CodeRule")},";
                        insert_DESC_PROD_PER_CANT += $" {Utils.parseStringBD("zAdi_FlagEnable")}) VALUES (";
                        insert_DESC_PROD_PER_CANT += $" 'DESC_PROD_PER_CANT',";
                        insert_DESC_PROD_PER_CANT += $" 'DESCUENTO PRODUCTO {itemCode}',";
                        insert_DESC_PROD_PER_CANT += $" '{itemCode}',";
                        insert_DESC_PROD_PER_CANT += $" {price},";
                        insert_DESC_PROD_PER_CANT += $"'{currency}',";
                        insert_DESC_PROD_PER_CANT += $" 1,";
                        insert_DESC_PROD_PER_CANT += $" NOW(),";
                        insert_DESC_PROD_PER_CANT += $" FALSE,";
                        insert_DESC_PROD_PER_CANT += $" 'INSERT',";
                        insert_DESC_PROD_PER_CANT += $" 'DESCUENTO PRODUCTO {itemCode}',";
                        insert_DESC_PROD_PER_CANT += $" '{itemCode}',";
                        insert_DESC_PROD_PER_CANT += $" TRUE);";

                        try
                        {
                            bool fgInsert = DBConn.ExecQueryInsert(insert_DESC_PROD_PER_CANT, DBConn.ConectionDB.Bitacoras);
                            if (!fgInsert)
                            {
                                Utils.PrintLog("RegisterLogPricing_DESC_PROD_PER_CANT", "0", $"No fue posible realizar la sincronización de la regla de precio DESCUENTO PRODUCTO {itemCode}");
                            }

                            if ((tbl_SPP1 != null && tbl_SPP1.Rows != null && tbl_SPP1.Rows.Count > 0) || (tbl_SPP2 != null && tbl_SPP2.Rows != null && tbl_SPP2.Rows.Count > 0))
                            {
                                string select_id = $"SELECT TOP 1 {Utils.parseStringBD("zAdi_SyncPricingId")} FROM {Utils.parseStringBD("zAdi_SyncPricing")} WHERE {Utils.parseStringBD("zAdi_ItemCode")} = '{itemCode}' AND {Utils.parseStringBD("zAdi_TypeDesc")} = 'DESC_PROD_PER_CANT'";
                                DataTable tbl_id = DBConn.ExecQuery(select_id, DBConn.ConectionDB.Bitacoras);
                                if (tbl_id != null && tbl_id.Rows != null && tbl_id.Rows.Count > 0)
                                {
                                    long id = long.Parse(tbl_id.Rows[0].ItemArray[0].ToString());

                                    if (tbl_SPP1 != null && tbl_SPP1.Rows != null && tbl_SPP1.Rows.Count > 0)
                                    {
                                        foreach (DataRow row_SPP1 in tbl_SPP1.Rows)
                                        {
                                            double price_SPP1 = double.Parse(row_SPP1.ItemArray[0] != null && !string.IsNullOrEmpty(row_SPP1.ItemArray[0].ToString()) ? row_SPP1.ItemArray[0].ToString() : "0");
                                            string currency_SPP1 = row_SPP1.ItemArray[1] != null && !string.IsNullOrEmpty(row_SPP1.ItemArray[1].ToString()) ? row_SPP1.ItemArray[1].ToString() : " ";
                                            double discount = double.Parse(row_SPP1.ItemArray[2] != null && !string.IsNullOrEmpty(row_SPP1.ItemArray[2].ToString()) ? row_SPP1.ItemArray[2].ToString() : "0");
                                            DateTime? dateFrom = null;
                                            DateTime? dateTo = null;
                                            if (row_SPP1.ItemArray[3] != null && !string.IsNullOrEmpty(row_SPP1.ItemArray[3].ToString()))
                                            {
                                                dateFrom = DateTime.Parse(row_SPP1.ItemArray[3].ToString());
                                            }
                                            if (row_SPP1.ItemArray[4] != null && !string.IsNullOrEmpty(row_SPP1.ItemArray[4].ToString()))
                                            {
                                                dateTo = DateTime.Parse(row_SPP1.ItemArray[4].ToString());
                                            }

                                            double u_comision = double.Parse(row_SPP1.ItemArray[5] != null && !string.IsNullOrEmpty(row_SPP1.ItemArray[5].ToString()) ? row_SPP1.ItemArray[5].ToString() : "0");
                                            string insert_SPP1 = string.Empty;
                                            if (dateFrom != null && dateTo != null)
                                            {
                                                insert_SPP1 = $"INSERT INTO {Utils.parseStringBD("zAdi_SyncPricingByPeriod")} ({Utils.parseStringBD("zAdi_SyncPricingId")}, {Utils.parseStringBD("zAdi_ItemCode")}, {Utils.parseStringBD("zAdi_DateValidFrom")}, {Utils.parseStringBD("zAdi_DateValidTo")}, {Utils.parseStringBD("zAdi_Price")}, {Utils.parseStringBD("zAdi_Currency")}, {Utils.parseStringBD("zAdi_PercentDesc")}, {Utils.parseStringBD("zAdi_Comision")}, {Utils.parseStringBD("zAdi_DateRegister")})";
                                                insert_SPP1 += $" VALUES ({id}, '{itemCode}', '{(dateFrom != null ? dateFrom.Value.ToString("yyyMMdd") : "")}', '{(dateTo != null ? dateTo.Value.ToString("yyyMMdd") : "")}', {price_SPP1}, '{currency_SPP1}', {discount}, {u_comision}, NOW())";
                                            }
                                            else
                                            {
                                                insert_SPP1 = $"INSERT INTO {Utils.parseStringBD("zAdi_SyncPricingByPeriod")} ({Utils.parseStringBD("zAdi_SyncPricingId")}, {Utils.parseStringBD("zAdi_ItemCode")}, {Utils.parseStringBD("zAdi_DateValidFrom")}, {Utils.parseStringBD("zAdi_Price")}, {Utils.parseStringBD("zAdi_Currency")}, {Utils.parseStringBD("zAdi_PercentDesc")}, {Utils.parseStringBD("zAdi_Comision")}, {Utils.parseStringBD("zAdi_DateRegister")})";
                                                insert_SPP1 += $" VALUES ({id}, '{itemCode}', '{(dateFrom != null ? dateFrom.Value.ToString("yyyMMdd") : "")}', {price_SPP1}, '{currency_SPP1}', {discount}, {u_comision}, NOW())";
                                            }
                                            try
                                            {
                                                DBConn.ExecQueryInsert(insert_SPP1, DBConn.ConectionDB.Bitacoras);
                                            }
                                            catch (Exception ex) { }
                                        }
                                    }

                                    if (tbl_SPP2 != null && tbl_SPP2.Rows != null && tbl_SPP2.Rows.Count > 0)
                                    {
                                        foreach (DataRow row_SPP2 in tbl_SPP2.Rows)
                                        {
                                            double amount = double.Parse((row_SPP2["Amount"] != null && !string.IsNullOrEmpty(row_SPP2["Amount"].ToString()) ? row_SPP2["Amount"].ToString() : "0"));
                                            double price_SPP2 = double.Parse((row_SPP2["Price"] != null && !string.IsNullOrEmpty(row_SPP2["Price"].ToString()) ? row_SPP2["Price"].ToString() : "0"));
                                            string currency_SPP2 = row_SPP2["Currency"] != null && !string.IsNullOrEmpty(row_SPP2["Currency"].ToString()) ? row_SPP2["Currency"].ToString() : "";
                                            double discount = double.Parse((row_SPP2["Discount"] != null && !string.IsNullOrEmpty(row_SPP2["Discount"].ToString()) ? row_SPP2["Discount"].ToString() : "0"));
                                            double u_comision = double.Parse((row_SPP2["U_Comision"] != null && !string.IsNullOrEmpty(row_SPP2["U_Comision"].ToString()) ? row_SPP2["U_Comision"].ToString() : "0"));

                                            string inser_SPP2 = $"INSERT INTO {Utils.parseStringBD("zAdi_SyncPricingByQuantity")} ({Utils.parseStringBD("zAdi_SyncPricingId")}, {Utils.parseStringBD("zAdi_ItemCode")}, {Utils.parseStringBD("zAdi_Price")}, {Utils.parseStringBD("zAdi_Currency")}, {Utils.parseStringBD("zAdi_PercentDesc")}, {Utils.parseStringBD("zAdi_Quantity")}, {Utils.parseStringBD("zAdi_Comision")}, {Utils.parseStringBD("zAdi_DateRegister")})";
                                            inser_SPP2 += $" VALUES ({id}, '{itemCode}', {price_SPP2}, '{currency_SPP2}', {discount}, {amount}, {u_comision}, NOW());";
                                            try
                                            {
                                                DBConn.ExecQueryInsert(inser_SPP2, DBConn.ConectionDB.Bitacoras);
                                            }
                                            catch (Exception ex)
                                            {
                                                Utils.PrintLog("RegisterLogPricing_DESC_PROD_PER_CANT", "3", ex.ToString());
                                            }

                                        }
                                    }
                                }

                            }
                        }
                        catch (Exception ex)
                        {
                            Utils.PrintLog("RegisterLogPricing_DESC_PROD_PER_CANT", "2", ex.ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("RegisterLogPricing_DESC_PROD_PER_CANT", "1", ex.ToString());
            }
        }

        public void SyncPricing_DESC_PROD_PER_CANT()
        {
            try
            {
                string select_DESC_PROD_PER_CANT = $"SELECT TOP {Utils.rangoRegistros_pricing} {Utils.parseStringBD("zAdi_SyncPricingId")}, {Utils.parseStringBD("zAdi_NameRule")}, {Utils.parseStringBD("zAdi_ItemCode")}, {Utils.parseStringBD("zAdi_Price")}, {Utils.parseStringBD("zAdi_Currency")} FROM {Utils.parseStringBD("zAdi_SyncPricing")}";
                select_DESC_PROD_PER_CANT += $" WHERE {Utils.parseStringBD("zAdi_FlagSend")} = FALSE AND {Utils.parseStringBD("zAdi_Action")} = 'INSERT' AND {Utils.parseStringBD("zAdi_TypeDesc")} = 'DESC_PROD_PER_CANT'";
                DataTable tbl_DES_PROD_PER_CANT = DBConn.ExecQuery(select_DESC_PROD_PER_CANT, DBConn.ConectionDB.Bitacoras);
                if (tbl_DES_PROD_PER_CANT != null && tbl_DES_PROD_PER_CANT.Rows != null && tbl_DES_PROD_PER_CANT.Rows.Count > 0)
                {
                    foreach (DataRow row_DESC_PROD_PER_CANT in tbl_DES_PROD_PER_CANT.Rows)
                    {
                        long zAdi_SyncPricingId = long.Parse(row_DESC_PROD_PER_CANT["zAdi_SyncPricingId"].ToString());
                        string zAdi_NameRule = row_DESC_PROD_PER_CANT["zAdi_NameRule"].ToString();
                        string zAdi_ItemCode = row_DESC_PROD_PER_CANT["zAdi_ItemCode"].ToString();
                        double zAdi_Price = double.Parse(row_DESC_PROD_PER_CANT["zAdi_Price"].ToString());

                        string select_validate_exist = $"SELECT * FROM dsq_wdp_rules WHERE title = '{zAdi_NameRule}' AND deleted != 1";
                        DataTable validate_exist = DBConnMysql.ExecQuery(select_validate_exist);
                        if (!(validate_exist != null && validate_exist.Rows != null && validate_exist.Rows.Count > 0))
                        {
                            //PERIODO
                            string select_syncpricing_period = $"SELECT TOP 1 {Utils.parseStringBD("zAdi_DateValidFrom")}, {Utils.parseStringBD("zAdi_DateValidTo")}, {Utils.parseStringBD("zAdi_Price")}, {Utils.parseStringBD("zAdi_Currency")}, {Utils.parseStringBD("zAdi_PercentDesc")} FROM {Utils.parseStringBD("zAdi_SyncPricingByPeriod")} WHERE {Utils.parseStringBD("zAdi_SyncPricingId")} = {zAdi_SyncPricingId}";
                            DataTable tbl_syncPricing_period = DBConn.ExecQuery(select_syncpricing_period, DBConn.ConectionDB.Bitacoras);

                            //CANTIDAD
                            string select_syncPricing_cantidad = $"SELECT {Utils.parseStringBD("zAdi_Price")}, {Utils.parseStringBD("zAdi_Currency")}, {Utils.parseStringBD("zAdi_PercentDesc")}, {Utils.parseStringBD("zAdi_Quantity")} FROM {Utils.parseStringBD("zAdi_SyncPricingByQuantity")} WHERE {Utils.parseStringBD("zAdi_SyncPricingId")} = {zAdi_SyncPricingId}";
                            DataTable tbl_syncPricing_cantidad = DBConn.ExecQuery(select_syncPricing_cantidad, DBConn.ConectionDB.Bitacoras);

                            string max_priotity = "SELECT MAX(priority) FROM dsq_wdp_rules";

                            DataTable tbl_max_priority = DBConnMysql.ExecQuery(max_priotity);
                            int priority = tbl_max_priority != null && tbl_max_priority.Rows != null ? int.Parse(tbl_max_priority.Rows[0].ItemArray[0].ToString()) + 1 : 0;

                            string insert_dsq_wdp_rules = "INSERT INTO `dsq_wdp_rules` VALUES(";
                            insert_dsq_wdp_rules += "NULL,";
                            insert_dsq_wdp_rules += "0,";
                            insert_dsq_wdp_rules += "1,";
                            insert_dsq_wdp_rules += "0,";
                            insert_dsq_wdp_rules += "'package',";
                            //title
                            insert_dsq_wdp_rules += Convert.ToString($"'{zAdi_NameRule}',");
                            //priority
                            insert_dsq_wdp_rules += $" {priority},";
                            //options
                            insert_dsq_wdp_rules += " 'a:2:{s:6:\"repeat\";s:2:\"-1\";s:8:\"apply_to\";s:8:\"appeared\";}',";
                            //aditional
                            insert_dsq_wdp_rules += " 'a:5:{s:19:\"trigger_coupon_code\";s:0:\"\";s:12:\"replace_name\";s:0:\"\";s:19:\"sortable_apply_mode\";s:12:\"consistently\";s:26:\"free_products_replace_name\";s:0:\"\";s:23:\"conditions_relationship\";s:3:\"and\";}',";
                            //conditions
                            if (tbl_syncPricing_period != null && tbl_syncPricing_period.Rows != null && tbl_syncPricing_period.Rows.Count > 0)
                            {
                                DateTime? dateFrom = null;
                                if (tbl_syncPricing_period.Rows[0]["zAdi_DateValidFrom"] != null && !string.IsNullOrEmpty(tbl_syncPricing_period.Rows[0]["zAdi_DateValidFrom"].ToString())) dateFrom = DateTime.Parse(tbl_syncPricing_period.Rows[0]["zAdi_DateValidFrom"].ToString());
                                DateTime? dateTo = null;
                                if (tbl_syncPricing_period.Rows[0]["zAdi_DateValidTo"] != null && !string.IsNullOrEmpty(tbl_syncPricing_period.Rows[0]["zAdi_DateValidTo"].ToString())) dateTo = DateTime.Parse(tbl_syncPricing_period.Rows[0]["zAdi_DateValidTo"].ToString());

                                if (dateFrom != null && dateTo != null)
                                {

                                    insert_dsq_wdp_rules += " 'a:2:{i:0;a:2:{s:4:\"type\";s:4:\"date\";s:7:\"options\";a:2:{i:0;s:4:\"from\";i:1;s:" + (dateFrom != null ? "10" : "0") + ":\"" + (dateFrom != null ? dateFrom.Value.ToString("yyyy-MM-dd") : "") + "\";}}i:1;a:2:{s:4:\"type\";s:4:\"date\";s:7:\"options\";a:2:{i:0;s:2:\"to\";i:1;s:" + (dateTo != null ? "10" : "0") + ":\"" + (dateTo != null ? dateTo.Value.ToString("yyyy-MM-dd") : "") + "\";}}}',";
                                }
                                else if (dateFrom != null)
                                {
                                    insert_dsq_wdp_rules += " 'a:1:{i:0;a:2:{s:4:\"type\";s:4:\"date\";s:7:\"options\";a:2:{i:0;s:4:\"from\";i:1;s:10:\"" + dateFrom.Value.ToString("yyyy-MM-dd") + "\";}}}',";
                                }
                                else insert_dsq_wdp_rules += " '',";
                            }
                            else
                                insert_dsq_wdp_rules += " '',";
                            //filters
                            insert_dsq_wdp_rules += " 'a:1:{i:0;a:6:{s:3:\"qty\";s:1:\"1\";s:4:\"type\";s:11:\"product_sku\";s:10:\"limitation\";s:4:\"none\";s:6:\"method\";s:7:\"in_list\";s:5:\"value\";a:1:{i:0;s:" + zAdi_ItemCode.Length + ":\"" + zAdi_ItemCode + "\";}s:15:\"product_exclude\";a:1:{s:10:\"on_wc_sale\";s:1:\"1\";}}}',";
                            //limits
                            insert_dsq_wdp_rules += " 'a:0:{}',";
                            //product_adjustments
                            insert_dsq_wdp_rules += " 'a:4:{s:4:\"type\";s:5:\"total\";s:5:\"total\";a:2:{s:4:\"type\";s:12:\"price__fixed\";s:5:\"value\";s:" + zAdi_Price.ToString().Length + ":\"" + zAdi_Price + "\";}s:5:\"split\";a:1:{i:0;a:2:{s:4:\"type\";s:12:\"price__fixed\";s:5:\"value\";s:2:\"30\";}}s:16:\"max_discount_sum\";s:0:\"\";}',";
                            //sortable_blocks_priority
                            insert_dsq_wdp_rules += " 'a:2:{i:0;s:5:\"roles\";i:1;s:16:\"bulk-adjustments\";}',";
                            //bulk_adjustments
                            if (tbl_syncPricing_cantidad != null && tbl_syncPricing_cantidad.Rows != null && tbl_syncPricing_cantidad.Rows.Count > 0)
                            {
                                insert_dsq_wdp_rules += " 'a:5:{s:4:\"type\";s:4:\"tier\";s:9:\"qty_based\";s:7:\"product\";s:13:\"discount_type\";s:20:\"discount__percentage\";s:6:\"ranges\";a:" + tbl_syncPricing_cantidad.Rows.Count + ":{";
                                foreach (DataRow row_cantidad in tbl_syncPricing_cantidad.Rows)
                                {
                                    double quantity = double.Parse(row_cantidad["zAdi_Quantity"].ToString());
                                    double discount = double.Parse(row_cantidad["zAdi_PercentDesc"].ToString());
                                    
                                    insert_dsq_wdp_rules += "i:" + tbl_syncPricing_cantidad.Rows.IndexOf(row_cantidad) + ";a:3:{s:4:\"from\";s:" + quantity.ToString().Length + ":\"" + quantity + "\";s:2:\"to\";s:0:\"\";s:5:\"value\";s:" + discount.ToString().Length + ":\"" + discount + "\";}";
                                }
                                insert_dsq_wdp_rules += "}s:13:\"table_message\";s:0:\"\";}',";
                            }
                            else
                                insert_dsq_wdp_rules += " '',";
                            //role_discounts
                            insert_dsq_wdp_rules += " 'a:0:{}',";
                            //cart_adjustments
                            insert_dsq_wdp_rules += " 'a:0:{}',";
                            //get_products
                            insert_dsq_wdp_rules += " 'a:2:{s:6:\"repeat\";s:2:\"-1\";s:15:\"repeat_subtotal\";s:0:\"\";}')";

                            try
                            {
                                DBConnMysql.ExecQueryInsert(insert_dsq_wdp_rules);
                                string select_dsq_wdp_rules = $"SELECT id FROM dsq_wdp_rules WHERE title = '{zAdi_NameRule}' AND deleted != 1 LIMIT 1";
                                DataTable tbl_select_dsq_wdp_rules = DBConnMysql.ExecQuery(select_dsq_wdp_rules);
                                if (tbl_select_dsq_wdp_rules != null && tbl_select_dsq_wdp_rules.Rows != null && tbl_select_dsq_wdp_rules.Rows.Count > 0)
                                {
                                    string update_SyncPricing = $"UPDATE {Utils.parseStringBD("zAdi_SyncPricing")}";
                                    update_SyncPricing += $" SET {Utils.parseStringBD("zAdi_DateSend")} = NOW(), {Utils.parseStringBD("zAdi_FlagSend")} = TRUE, {Utils.parseStringBD("zAdi_IdRuleWooCommerce")} = {tbl_select_dsq_wdp_rules.Rows[0].ItemArray[0]}";
                                    update_SyncPricing += $" WHERE {Utils.parseStringBD("zAdi_SyncPricingId")} = {zAdi_SyncPricingId}";
                                    DBConn.ExecQueryUpdate(update_SyncPricing, DBConn.ConectionDB.Bitacoras);
                                }
                            }
                            catch (Exception ex)
                            {
                                Utils.PrintLog("SyncPricing_DESC_PROD_PER_CANT", "2", ex.ToString());
                            }
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("SyncPricing_DESC_PROD_PER_CANT", "1", ex.ToString());
            }
        }

        public void SyncPricingUpdate_DESC_PROD_PER_CANT()
        {
            //string path = "C:\\SyncPricingUpdate_DESC_PROD_PER_CANT.txt";
            try
            {
                string select_DESC_PROD_PER_CANT = $"SELECT TOP {Utils.rangoRegistros_pricing} {Utils.parseStringBD("zAdi_SyncPricingId")}, {Utils.parseStringBD("zAdi_NameRule")}, {Utils.parseStringBD("zAdi_ItemCode")}, {Utils.parseStringBD("zAdi_Price")}, {Utils.parseStringBD("zAdi_Currency")}, {Utils.parseStringBD("zAdi_IdRuleWooCommerce")} FROM {Utils.parseStringBD("zAdi_SyncPricing")}";
                select_DESC_PROD_PER_CANT += $" WHERE {Utils.parseStringBD("zAdi_FlagSend")} = FALSE AND {Utils.parseStringBD("zAdi_Action")} = 'UPDATE' AND {Utils.parseStringBD("zAdi_TypeDesc")} = 'DESC_PROD_PER_CANT'";
                DataTable tbl_DESC_PROD_PER_CANT = DBConn.ExecQuery(select_DESC_PROD_PER_CANT, DBConn.ConectionDB.Bitacoras);
                if (tbl_DESC_PROD_PER_CANT != null && tbl_DESC_PROD_PER_CANT.Rows != null && tbl_DESC_PROD_PER_CANT.Rows.Count > 0)
                {
                    foreach (DataRow row_DESC_PROD_PER_CANT in tbl_DESC_PROD_PER_CANT.Rows)
                    {
                        long SyncPricingId = long.Parse(row_DESC_PROD_PER_CANT["zAdi_SyncPricingId"].ToString());
                        string NameRule = row_DESC_PROD_PER_CANT["zAdi_NameRule"].ToString();
                        string ItemCode = row_DESC_PROD_PER_CANT["zAdi_ItemCode"].ToString();
                        double Price = double.Parse(row_DESC_PROD_PER_CANT["zAdi_Price"].ToString());
                        string Currency = row_DESC_PROD_PER_CANT["zAdi_Currency"].ToString();
                        long idRule = long.Parse(row_DESC_PROD_PER_CANT["zAdi_IdRuleWooCommerce"] != null && !string.IsNullOrEmpty(row_DESC_PROD_PER_CANT["zAdi_IdRuleWooCommerce"].ToString()) ? row_DESC_PROD_PER_CANT["zAdi_IdRuleWooCommerce"].ToString() : "0");

                        if (!(idRule > 0)) continue;

                        //PERIODO
                        string select_syncpricing_period = $"SELECT TOP 1 {Utils.parseStringBD("zAdi_DateValidFrom")}, {Utils.parseStringBD("zAdi_DateValidTo")}, {Utils.parseStringBD("zAdi_Price")}, {Utils.parseStringBD("zAdi_Currency")}, {Utils.parseStringBD("zAdi_PercentDesc")} FROM {Utils.parseStringBD("zAdi_SyncPricingByPeriod")} WHERE {Utils.parseStringBD("zAdi_SyncPricingId")} = {SyncPricingId}";
                        DataTable tbl_syncPricing_period = DBConn.ExecQuery(select_syncpricing_period, DBConn.ConectionDB.Bitacoras);

                        //CANTIDAD
                        string select_syncPricing_cantidad = $"SELECT {Utils.parseStringBD("zAdi_Price")}, {Utils.parseStringBD("zAdi_Currency")}, {Utils.parseStringBD("zAdi_PercentDesc")}, {Utils.parseStringBD("zAdi_Quantity")} FROM {Utils.parseStringBD("zAdi_SyncPricingByQuantity")} WHERE {Utils.parseStringBD("zAdi_SyncPricingId")} = {SyncPricingId}";
                        DataTable tbl_syncPricing_cantidad = DBConn.ExecQuery(select_syncPricing_cantidad, DBConn.ConectionDB.Bitacoras);

                        string update_dsq_rules = $"UPDATE dsq_wdp_rules SET";
                        update_dsq_rules += $" title = '{NameRule}'";
                        if (tbl_syncPricing_period != null && tbl_syncPricing_period.Rows != null && tbl_syncPricing_period.Rows.Count > 0)
                        {
                            DateTime? dateFrom = null;
                            if (tbl_syncPricing_period.Rows[0]["zAdi_DateValidFrom"] != null && !string.IsNullOrEmpty(tbl_syncPricing_period.Rows[0]["zAdi_DateValidFrom"].ToString())) dateFrom = DateTime.Parse(tbl_syncPricing_period.Rows[0]["zAdi_DateValidFrom"].ToString());
                            DateTime? dateTo = null;
                            if (tbl_syncPricing_period.Rows[0]["zAdi_DateValidTo"] != null && !string.IsNullOrEmpty(tbl_syncPricing_period.Rows[0]["zAdi_DateValidTo"].ToString())) dateTo = DateTime.Parse(tbl_syncPricing_period.Rows[0]["zAdi_DateValidTo"].ToString());


                            if (dateFrom != null && dateTo != null)
                            {

                                update_dsq_rules += ", conditions = 'a:2:{i:0;a:2:{s:4:\"type\";s:4:\"date\";s:7:\"options\";a:2:{i:0;s:4:\"from\";i:1;s:" + (dateFrom != null ? "10" : "0") + ":\"" + (dateFrom != null ? dateFrom.Value.ToString("yyyy-MM-dd") : "") + "\";}}i:1;a:2:{s:4:\"type\";s:4:\"date\";s:7:\"options\";a:2:{i:0;s:2:\"to\";i:1;s:" + (dateTo != null ? "10" : "0") + ":\"" + (dateTo != null ? dateTo.Value.ToString("yyyy-MM-dd") : "") + "\";}}}',";
                            }
                            else if (dateFrom != null)
                            {
                                update_dsq_rules += ", conditions = 'a:1:{i:0;a:2:{s:4:\"type\";s:4:\"date\";s:7:\"options\";a:2:{i:0;s:4:\"from\";i:1;s:10:\"" + dateFrom.Value.ToString("yyyy-MM-dd") + "\";}}}',";
                            }
                            else update_dsq_rules += ", conditions = '',";

                            //update_dsq_rules += ", conditions = 'a:2:{i:0;a:2:{s:4:\"type\";s:4:\"date\";s:7:\"options\";a:2:{i:0;s:4:\"from\";i:1;s:" + (dateFrom != null ? "10" : "0") + ":\"" + (dateFrom != null ? dateFrom.Value.ToString("yyyy-MM-dd") : "") + "\";}}i:1;a:2:{s:4:\"type\";s:4:\"date\";s:7:\"options\";a:2:{i:0;s:2:\"to\";i:1;s:" + (dateTo != null ? "10" : "0") + ":\"" + (dateTo != null ? dateTo.Value.ToString("yyyy-MM-dd") : "") + "\";}}}'";
                        }
                        update_dsq_rules += ", filters = 'a:1:{i:0;a:6:{s:3:\"qty\";s:1:\"1\";s:4:\"type\";s:11:\"product_sku\";s:10:\"limitation\";s:4:\"none\";s:6:\"method\";s:7:\"in_list\";s:5:\"value\";a:1:{i:0;s:" + ItemCode.Length + ":\"" + ItemCode + "\";}s:15:\"product_exclude\";a:1:{s:10:\"on_wc_sale\";s:1:\"1\";}}}'";
                        update_dsq_rules += ", product_adjustments = 'a:4:{s:4:\"type\";s:5:\"total\";s:5:\"total\";a:2:{s:4:\"type\";s:12:\"price__fixed\";s:5:\"value\";s:" + Price.ToString().Length + ":\"" + Price + "\";}s:5:\"split\";a:1:{i:0;a:2:{s:4:\"type\";s:12:\"price__fixed\";s:5:\"value\";s:2:\"30\";}}s:16:\"max_discount_sum\";s:0:\"\";}'";
                        if (tbl_syncPricing_cantidad != null && tbl_syncPricing_cantidad.Rows != null && tbl_syncPricing_cantidad.Rows.Count > 0)
                        {
                            update_dsq_rules += ", bulk_adjustments = 'a:5:{s:4:\"type\";s:4:\"tier\";s:9:\"qty_based\";s:7:\"product\";s:13:\"discount_type\";s:20:\"discount__percentage\";s:6:\"ranges\";a:" + tbl_syncPricing_cantidad.Rows.Count + ":{";
                            foreach (DataRow row_cantidad in tbl_syncPricing_cantidad.Rows)
                            {
                                double amount = double.Parse(row_cantidad.ItemArray[0].ToString());
                                //double price = double.Parse(row_cantidad.ItemArray[1].ToString());
                                double discount = double.Parse(row_cantidad.ItemArray[3].ToString());
                                update_dsq_rules += "i:" + tbl_syncPricing_cantidad.Rows.IndexOf(row_cantidad) + ";a:3:{s:4:\"from\";s:" + amount.ToString().Length + ":\"" + amount + "\";s:2:\"to\";s:0:\"\";s:5:\"value\";s:" + discount.ToString().Length + ":\"" + discount + "\";}";
                            }
                            update_dsq_rules += "}s:13:\"table_message\";s:0:\"\";}'";
                        }
                        update_dsq_rules += $" WHERE id = {idRule}";

                        try
                        {

                            DBConnMysql.ExecQueryUpdate(update_dsq_rules);
                            #region UPDATE SAP
                            string update_SAP = $"UPDATE {Utils.parseStringBD("zAdi_SyncPricing")} SET {Utils.parseStringBD("zAdi_DateSend")} = NOW(), {Utils.parseStringBD("zAdi_FlagSend")} = TRUE WHERE {Utils.parseStringBD("zAdi_SyncPricingId")} = {SyncPricingId}";
                            DBConn.ExecQueryUpdate(update_SAP, DBConn.ConectionDB.Bitacoras);
                            #endregion
                        }
                        catch (Exception ex)
                        {
                            Utils.PrintLog("SyncPricingUpdate_DESC_PROD_PER_CANT", "2", ex.ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("SyncPricingUpdate_DESC_PROD_PER_CANT", "1", ex.ToString());
            }
        }

        #endregion
        public void SyncPricingDelete()
        {
            //string path = "C:\\SyncPricingDelete.txt";
            try
            {
                string select_DESC_CLI_MARCA_PROD = $"SELECT TOP {Utils.rangoRegistros_pricing} * FROM {Utils.parseStringBD("zAdi_SyncPricing")} WHERE {Utils.parseStringBD("zAdi_Action")} = 'DELETE' AND {Utils.parseStringBD("zAdi_FlagSend")} = FALSE";
                DataTable tbl_DESC_CLI_MARCA_PROD = DBConn.ExecQuery(select_DESC_CLI_MARCA_PROD, DBConn.ConectionDB.Bitacoras);
                if (tbl_DESC_CLI_MARCA_PROD != null && tbl_DESC_CLI_MARCA_PROD.Rows != null && tbl_DESC_CLI_MARCA_PROD.Rows.Count > 0)
                {
                    foreach (DataRow row_DESC_CLI_MARCA_PROD in tbl_DESC_CLI_MARCA_PROD.Rows)
                    {
                        long idPricing = long.Parse(row_DESC_CLI_MARCA_PROD["zAdi_SyncPricingId"].ToString());
                        long idRule = long.Parse(row_DESC_CLI_MARCA_PROD["zAdi_IdRuleWooCommerce"] != null ? row_DESC_CLI_MARCA_PROD["zAdi_IdRuleWooCommerce"].ToString() : "0");
                        string typeDesc = row_DESC_CLI_MARCA_PROD["zAdi_TypeDesc"].ToString();
                        string nameRule = row_DESC_CLI_MARCA_PROD["zAdi_NameRule"].ToString();
                        if (idRule > 0)
                        {
                            string delete_dsq_wdp_rules = $"DELETE FROM dsq_wdp_rules WHERE id = {idRule}";
                            try
                            {
                                bool delete = DBConnMysql.ExecQueryDelete(delete_dsq_wdp_rules);
                                if (delete)
                                {
                                    #region UPDATE SAP HANA

                                    string update_SAP = $"UPDATE {Utils.parseStringBD("zAdi_SyncPricing")} SET {Utils.parseStringBD("zAdi_FlagSend")} = TRUE, {Utils.parseStringBD("zAdi_DateSend")} = NOW() WHERE {Utils.parseStringBD("zAdi_SyncPricingId")} = {idPricing}";
                                    DBConn.ExecQueryUpdate(update_SAP, DBConn.ConectionDB.Bitacoras);

                                    #endregion

                                    if (typeDesc == "DESC_PROD_PER_CANT")
                                    {
                                        string delete_sap = $"DELETE FROM {Utils.parseStringBD("zAdi_SyncPricing")} WHERE {Utils.parseStringBD("zAdi_NameRule")} = '{nameRule}' AND {Utils.parseStringBD("zAdi_TypeDesc")} = 'DESC_PROD_PER_CANT'";
                                        DBConn.ExecQuery(delete_sap);

                                        RegisterLogPricing_DESC_PROD_PER_CANT();
                                        SyncPricing_DESC_PROD_PER_CANT();
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                Utils.PrintLog("SyncPricingDelete", "2", ex.ToString());
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("SyncPricingDelete", "1", ex.ToString());
            }
        }
        #endregion

        bool fg = false;
        public void updateId()
        {
            string path = "C:\\updateId.txt";

            try
            {
                if (fg) return;
                string query = $"SELECT * FROM {Utils.parseStringBD("zAdi_SyncPricing")} WHERE {Utils.parseStringBD("zAdi_Action")} = 'INSERT'";
                DataTable tbl = DBConn.ExecQuery(query);
                if (tbl != null && tbl.Rows != null && tbl.Rows.Count > 0)
                {
                    foreach (DataRow row in tbl.Rows)
                    {
                        string nameRule = row["zAdi_NameRule"].ToString();
                        string id = row["zAdi_SyncPricingId"].ToString();
                        string select_validate_exist = $"SELECT * FROM dsq_wdp_rules WHERE title = '{nameRule}'";

                        DataTable validate_exist = DBConnMysql.ExecQuery(select_validate_exist);
                        if (validate_exist != null && validate_exist.Rows != null && validate_exist.Rows.Count > 0)
                        {
                            if (validate_exist.Rows.Count > 1)
                            {
                                string ids = string.Empty;
                                validate_exist.Rows.OfType<DataRow>().ToList().ForEach(x =>
                                    ids += validate_exist.Rows.IndexOf(x) == 0 ? $"{x["id"].ToString()}" : $", {x["id"].ToString()}"
                                );
                                using (StreamWriter writer = new StreamWriter(path, true))
                                {
                                    writer.WriteLine($"regla de descuento {nameRule} duplicada, id's: {ids}");
                                    writer.Close();
                                }
                            }

                            select_validate_exist = string.Empty;
                            select_validate_exist = $"SELECT id FROM dsq_wdp_rules WHERE title = '{nameRule}' AND deleted = 0 ORDER BY id DESC LIMIT 1";

                            validate_exist = new DataTable();
                            validate_exist = DBConnMysql.ExecQuery(select_validate_exist);
                            if (validate_exist != null && validate_exist.Rows != null && validate_exist.Rows.Count > 0)
                            {
                                string update = $"UPDATE {Utils.parseStringBD("zAdi_SyncPricing")} SET {Utils.parseStringBD("zAdi_IdRuleWooCommerce")} = {validate_exist.Rows[0]["id"].ToString()} WHERE {Utils.parseStringBD("zAdi_NameRule")} = '{nameRule}'";
                                using (StreamWriter writer = new StreamWriter("C:\\querys.txt", true))
                                {
                                    writer.WriteLine($"update: {update}\n");
                                    writer.Close();
                                }
                                DBConn.ExecQuery(update);
                            }
                        }
                        else
                        {
                            select_validate_exist = string.Empty;
                            select_validate_exist = $"SELECT id FROM dsq_wdp_rules WHERE title = '{nameRule}' AND deleted = 0 ORDER BY id DESC LIMIT 1";
                            validate_exist = new DataTable();
                            validate_exist = DBConnMysql.ExecQuery(select_validate_exist);
                            if (validate_exist != null && validate_exist.Rows != null && validate_exist.Rows.Count > 0)
                            {
                                string update = $"UPDATE {Utils.parseStringBD("zAdi_SyncPricing")} SET {Utils.parseStringBD("zAdi_IdRuleWooCommerce")} = {validate_exist.Rows[0]["id"].ToString()} WHERE {Utils.parseStringBD("zAdi_NameRule")} = '{nameRule}'";
                                using (StreamWriter writer = new StreamWriter("C:\\querys.txt", true))
                                {
                                    writer.WriteLine($"update: {update}\n");
                                    writer.Close();
                                }
                                DBConn.ExecQuery(update);
                            }
                        }
                    }

                    using (StreamWriter writer = new StreamWriter(path, true))
                    {
                        writer.WriteLine($"Recorrido terminado.\n");
                        writer.Close();
                    }
                    fg = true;
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("updateId", "1", ex.ToString());
            }
        }

        public static PriceRules getInstance => new PriceRules();
    }
}
