﻿using Newtonsoft.Json.Linq;
using SAP_LIB.Controllers;
using SAP_LIB.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;


namespace SapService.Modules
{
    public class Products
    {
        #region products

        public void RegisterProductToLog_v2()
        {
            //string path = "C:\\RegisterLog_v2.txt";
            try
            {
                if (!ValidateExistProdNoSync()) return;

                string querySelect = $@"SELECT TOP {Utils.RangoRegistros_prod} 
                {Utils.parseStringBD(DBConn.OITM)}.{Utils.parseStringBD(OITM.ItemCode)}, 
                {Utils.parseStringBD(DBConn.OITM)}.{Utils.parseStringBD(OITM.ItemName)}, 
                {Utils.parseStringBD(DBConn.OITM)}.{Utils.parseStringBD(OITM.StockValue)}, 
                {Utils.parseStringBD(DBConn.OITM)}.{Utils.parseStringBD(OITM.AvgPrice)}, 
                {Utils.parseStringBD(DBConn.OITM)}.{Utils.parseStringBD("NCMCode")}, 
                {Utils.parseStringBD(DBConn.OITM)}.{Utils.parseStringBD("U_Descripcion2")},
                {Utils.parseStringBD(DBConn.OITM)}.{Utils.parseStringBD("FirmCode")},
                {Utils.parseStringBD(DBConn.OITM)}.{Utils.parseStringBD("UserText")},
                {Utils.parseStringBD("@PROP_ECOM")}.{Utils.parseStringBD("U_Nivel1")},
                {Utils.parseStringBD("@PROP_ECOM")}.{Utils.parseStringBD("U_Nivel2")},
                {Utils.parseStringBD("@PROP_ECOM")}.{Utils.parseStringBD("U_Nivel3")},
                {Utils.parseStringBD("@PROP_ECOM")}.{Utils.parseStringBD("U_Nivel4")},
                {Utils.parseStringBD("@PROP_ECOM")}.{Utils.parseStringBD("U_Nivel5")},
                {Utils.parseStringBD("@PROP_ECOM")}.{Utils.parseStringBD("U_Nivel6")},
                {Utils.parseStringBD("@PROP_ECOM")}.{Utils.parseStringBD("U_Nivel7")},
                {Utils.parseStringBD("@PROP_ECOM")}.{Utils.parseStringBD("U_Nivel8")},
                {Utils.parseStringBD("@PROP_ECOM")}.{Utils.parseStringBD("U_Nivel9")}";
                querySelect += $" FROM {Utils.parseStringBD(DBConn.DBPrimaria)}.{Utils.parseStringBD(DBConn.OITM)}";
                querySelect += $" LEFT JOIN {Utils.parseStringBD(DBConn.DBPrimaria)}.{Utils.parseStringBD("@PROP_ECOM")} ON {Utils.parseStringBD("@PROP_ECOM")}.{Utils.parseStringBD("Name")} = {Utils.parseStringBD("OITM")}.{Utils.parseStringBD("ItemCode")}";
                querySelect += $" LEFT JOIN {Utils.parseStringBD(DBConn.DBBitacoras)}.{Utils.parseStringBD(DBConn.zAdi_SyncItems)} ON TRIM(replace(replace({Utils.parseStringBD(DBConn.OITM)}.{Utils.parseStringBD(OITM.ItemCode)}, '''',''),'\\', '')) = {Utils.parseStringBD(DBConn.zAdi_SyncItems)}.{Utils.parseStringBD(zAdi_SyncItems.zAdi_ItemCode)}";
                querySelect += $" WHERE {Utils.parseStringBD("@PROP_ECOM")}.{Utils.parseStringBD("Name")} IS NOT NULL AND {Utils.parseStringBD(DBConn.zAdi_SyncItems)}.{Utils.parseStringBD(zAdi_SyncItems.zAdi_ItemCode)} IS NULL ";
                //querySelect += $" AND {Utils.parseStringBD("OITM")}.{Utils.parseStringBD("ItemCode")} IN ('PL-AD1000I')";

                //Utils.PrintLog("RegisterProductToLog_v2", "0", $"querySelect: {querySelect}");
                DataTable tblProducts = DBConn.ExecQuery(querySelect);
                if (tblProducts != null && tblProducts.Rows != null && tblProducts.Rows.Count > 0)
                {
                    foreach (DataRow row in tblProducts.Rows)
                    {
                        
                        string itemCode = row["ItemCode"] != null ? row["ItemCode"].ToString() : "";
                        string ItemName = row["ItemName"] != null ? row["ItemName"].ToString() : "";
                        ItemName = ItemName.Replace("'", "");
                        string NCMCode = row["NCMCode"] != null && !string.IsNullOrEmpty(row["NCMCode"].ToString()) ? row["NCMCode"].ToString() : "0";
                        string FirmCode = row["FirmCode"] != null ? row["FirmCode"].ToString() : "";
                        string nivel1 = row["U_Nivel1"] != null ? row["U_Nivel1"].ToString() : "";
                        string nivel2 = row["U_Nivel2"] != null ? row["U_Nivel2"].ToString() : "";
                        string nivel3 = row["U_Nivel3"] != null ? row["U_Nivel3"].ToString() : "";
                        string nivel4 = row["U_Nivel4"] != null ? row["U_Nivel4"].ToString() : "";
                        string nivel5 = row["U_Nivel5"] != null ? row["U_Nivel5"].ToString() : "";
                        string nivel6 = row["U_Nivel6"] != null ? row["U_Nivel6"].ToString() : "";
                        string nivel7 = row["U_Nivel7"] != null ? row["U_Nivel7"].ToString() : "";
                        string nivel8 = row["U_Nivel8"] != null ? row["U_Nivel8"].ToString() : "";
                        string nivel9 = row["U_Nivel9"] != null ? row["U_Nivel9"].ToString() : "";
                        //string nivel10 = row["U_Nivel10"] != null ? row["U_Nivel10"].ToString() : "";


                        itemCode = string.Join("", itemCode.Split('\''));
                        itemCode = itemCode.Replace("'", "");
                        itemCode = itemCode.Trim(new char[] { '\\', ' '});

                        ItemName = string.Join("", ItemName.Split('\''));
                        ItemName = ItemName.Replace("'", "");
                        ItemName = ItemName.Trim(new char[] { '\\'});


                        #region Price

                        string queryPrice = $"SELECT {Utils.parseStringBD("PriceList")}, {Utils.parseStringBD("Price")}, {Utils.parseStringBD("Currency")} FROM {Utils.parseStringBD("ITM1")} WHERE TRIM(replace(replace({Utils.parseStringBD("ItemCode")}, '''',''),'\\', '')) = '{itemCode}' AND {Utils.parseStringBD("PriceList")} IN (1, 4, 5)";
                        DataTable tblPrice = DBConn.ExecQuery(queryPrice);

                        string Currency = tblPrice != null && tblPrice.Rows != null && tblPrice.Rows.Count > 0 ? tblPrice.Rows[0]["Currency"] != null ? tblPrice.Rows[0]["Currency"].ToString() : "USD" : "USD";

                        Double Price = 0, price_Ofer = -1, price_Liq = -1;
                        if (tblPrice != null && tblPrice.Rows != null && tblPrice.Rows.Count > 0)
                        {
                            foreach (DataRow row_price in tblPrice.Rows)
                            {
                                switch (row_price["PriceList"].ToString())
                                {
                                    case "1"://base
                                        Price = Convert.ToDouble(row_price["Price"].ToString());
                                        break;
                                    case "4": //ofertas
                                        price_Ofer = Convert.ToDouble(row_price["Price"].ToString());
                                        break;

                                    case "5"://liquidacion
                                        price_Liq = Convert.ToDouble(row_price["Price"].ToString());
                                        break;
                                }
                            }
                        }
                        #endregion



                        string queryCodeSat = $"SELECT TOP 1 {Utils.parseStringBD("NcmCode")} FROM {Utils.parseStringBD(DBConn.DBPrimaria)}.{Utils.parseStringBD("ONCM")} WHERE {Utils.parseStringBD("ONCM")}.{Utils.parseStringBD("AbsEntry")} = {NCMCode}";
                        DataTable tblCodeSat = DBConn.ExecQuery(queryCodeSat);

                        string CodeSAT = tblCodeSat != null && tblCodeSat.Rows != null && tblCodeSat.Rows.Count > 0 ? tblCodeSat.Rows[0]["NcmCode"] != null ? tblCodeSat.Rows[0]["NcmCode"].ToString() : "" : "";

                        string queryBrand = $"SELECT TOP 1 {Utils.parseStringBD("FirmName")} FROM {Utils.parseStringBD(DBConn.DBPrimaria)}.{Utils.parseStringBD("OMRC")} WHERE {Utils.parseStringBD("FirmCode")} = {FirmCode}";
                        DataTable tblBrand = DBConn.ExecQuery(queryBrand);

                        string Marca = tblBrand != null && tblBrand.Rows != null && tblBrand.Rows.Count > 0 ? tblBrand.Rows[0]["FirmName"] != null ? tblBrand.Rows[0]["FirmName"].ToString() : "" : "";

                        string Categorias = string.Empty;
                        if (!string.IsNullOrEmpty(nivel1)) Categorias += $"{nivel1}";
                        if (!string.IsNullOrEmpty(nivel2)) Categorias += string.IsNullOrEmpty(Categorias) ? nivel2 : $", {nivel2}";
                        if (!string.IsNullOrEmpty(nivel3)) Categorias += string.IsNullOrEmpty(Categorias) ? nivel3 : $", {nivel3}";
                        if (!string.IsNullOrEmpty(nivel4)) Categorias += string.IsNullOrEmpty(Categorias) ? nivel4 : $", {nivel4}";
                        if (!string.IsNullOrEmpty(nivel5)) Categorias += string.IsNullOrEmpty(Categorias) ? nivel5 : $", {nivel5}";
                        if (!string.IsNullOrEmpty(nivel6)) Categorias += string.IsNullOrEmpty(Categorias) ? nivel6 : $", {nivel6}";
                        if (!string.IsNullOrEmpty(nivel7)) Categorias += string.IsNullOrEmpty(Categorias) ? nivel7 : $", {nivel7}";
                        if (!string.IsNullOrEmpty(nivel8)) Categorias += string.IsNullOrEmpty(Categorias) ? nivel8 : $", {nivel8}";
                        if (!string.IsNullOrEmpty(nivel9)) Categorias += string.IsNullOrEmpty(Categorias) ? nivel9 : $", {nivel9}";
                        //if (!string.IsNullOrEmpty(nivel10)) Categorias += string.IsNullOrEmpty(Categorias) ? nivel10 : $", {nivel10}";


                        Marca = string.Join("", Marca.Split('\''));
                        Marca = Marca.Replace("'", "");
                        Marca = Marca.Trim(new char[] { '\\' });

                        Categorias = string.Join("", Categorias.Split('\''));
                        Categorias = Categorias.Replace("'", "");
                        Categorias = Categorias.Trim(new char[] { '\\' });

                        string query_dsq_wc_product_meta_lookup = $"SELECT product_id FROM dsq_wc_product_meta_lookup WHERE sku = '{itemCode}' LIMIT 1";
                        DataTable tbl_wc_product_meta_lookup = DBConnMysql.ExecQuery(query_dsq_wc_product_meta_lookup);
                        long id_product_WooCommerce = tbl_wc_product_meta_lookup != null && tbl_wc_product_meta_lookup.Rows != null && tbl_wc_product_meta_lookup.Rows.Count > 0 ? long.Parse(tbl_wc_product_meta_lookup.Rows[0]["product_id"].ToString()) : 0;

                        string insertQuery = $"INSERT INTO {Utils.parseStringBD(DBConn.zAdi_SyncItems)}";
                        if (id_product_WooCommerce > 0)
                        {
                            //Este bloque es para validar si un producto existe en el Woocommerce, pero en las bitácoras no existe.
                            #region obtener id de las 4 variantes

                            int idGEN = 0, idOFER = 0, idLIQ = 0;
                            string query_select_post = $"SELECT post_title FROM dsq_posts WHERE ID = {id_product_WooCommerce}";
                            DataTable dtProduct = DBConnMysql.ExecQuery(query_select_post);
                            if (dtProduct != null && dtProduct.Rows != null && dtProduct.Rows.Count > 0)
                            {
                                query_select_post = $"SELECT ID, post_excerpt FROM dsq_posts WHERE post_title LIKE '%{dtProduct.Rows[0]["post_title"].ToString()}%'";
                                //Utils.PrintLog("RegisterProductToLog_v2", "0", $"query_select_post: {query_select_post}");
                                dtProduct = DBConnMysql.ExecQuery(query_select_post);

                                if (dtProduct != null && dtProduct.Rows != null && dtProduct.Rows.Count > 0)
                                {
                                    foreach (DataRow row_product in dtProduct.Rows)
                                    {
                                        switch (row_product["post_excerpt"].ToString().Trim())
                                        {
                                            case "ALMACÉN: GENERAL":
                                                idGEN = int.Parse(row_product["ID"].ToString());
                                                break;
                                            case "ALMACÉN: OFERTAS":
                                                idOFER = int.Parse(row_product["ID"].ToString());
                                                break;
                                            case "ALMACÉN: LIQUIDACIONES":
                                                idLIQ = int.Parse(row_product["ID"].ToString());
                                                break;

                                            default:
                                                id_product_WooCommerce = int.Parse(row_product["ID"].ToString());
                                                break;
                                        }
                                    }
                                }
                            }

                            #endregion

                            insertQuery += $@" ({Utils.parseStringBD(zAdi_SyncItems.zAdi_ItemCode)}, 
                                                {Utils.parseStringBD(zAdi_SyncItems.zAdi_ItemName)}, 
                                                {Utils.parseStringBD(zAdi_SyncItems.zAdi_StockValue)}, 
                                                {Utils.parseStringBD(zAdi_SyncItems.zAdi_Price)},
                                                {Utils.parseStringBD(zAdi_SyncItems.zAdi_DateSend)}, 
                                                {Utils.parseStringBD(zAdi_SyncItems.zAdi_DesMessage)}, 
                                                {Utils.parseStringBD(zAdi_SyncItems.zAdi_DateRegister)}, 
                                                {Utils.parseStringBD(zAdi_SyncItems.zAdi_Action)},
                                                {Utils.parseStringBD("zAdi_Currency")},
                                                {Utils.parseStringBD("zAdi_Brand")},
                                                {Utils.parseStringBD("zAdi_CodeSAT")},
                                                {Utils.parseStringBD("zAdi_Description")},
                                                {Utils.parseStringBD("zAdi_Categories")},
                                                {Utils.parseStringBD("zAdi_UserText")},
                                                {Utils.parseStringBD("zAdi_IdCommerce")},
                                                {Utils.parseStringBD("zAdi_FlagSend")},
                                                {Utils.parseStringBD("zAdi_IdCommerceGEN")},
                                                {Utils.parseStringBD("zAdi_IdCommerceOFER")},
                                                {Utils.parseStringBD("zAdi_IdCommerceLIQ")},
                                                {Utils.parseStringBD("zAdi_PriceOFER")},
                                                {Utils.parseStringBD("zAdi_PriceLIQ")})";
                        insertQuery += $@" VALUES (
                                                '{itemCode}', 
                                                '{ItemName.Replace("'", "")}',
                                                {0},
                                                {Price},
                                                NOW(),
                                                ' ',
                                                NOW(),
                                                'INSERT',
                                                '{Currency}',
                                                '{Marca}',
                                                '{CodeSAT}',
                                                'campo obsoleto',
                                                '{Categorias}',
                                                'campo obsoleto',
                                                {id_product_WooCommerce},
                                                TRUE,
                                                {idGEN},
                                                {idOFER},
                                                {idLIQ},
                                                {price_Ofer},
                                                {price_Liq})";
                        }
                        else
                        {
                            insertQuery += $@" ({Utils.parseStringBD(zAdi_SyncItems.zAdi_ItemCode)}, 
                                               {Utils.parseStringBD(zAdi_SyncItems.zAdi_ItemName)}, 
                                               {Utils.parseStringBD(zAdi_SyncItems.zAdi_StockValue)}, 
                                               {Utils.parseStringBD(zAdi_SyncItems.zAdi_Price)}, 
                                               {Utils.parseStringBD(zAdi_SyncItems.zAdi_FlagSend)}, 
                                               {Utils.parseStringBD(zAdi_SyncItems.zAdi_DateSend)}, 
                                               {Utils.parseStringBD(zAdi_SyncItems.zAdi_DesMessage)}, 
                                               {Utils.parseStringBD(zAdi_SyncItems.zAdi_DateRegister)}, 
                                               {Utils.parseStringBD(zAdi_SyncItems.zAdi_Action)}, 
                                               {Utils.parseStringBD(zAdi_SyncItems.zAdi_IdCommerce)},
                                               {Utils.parseStringBD("zAdi_Currency")},
                                               {Utils.parseStringBD("zAdi_Brand")},
                                               {Utils.parseStringBD("zAdi_CodeSAT")},
                                               {Utils.parseStringBD("zAdi_Description")},
                                               {Utils.parseStringBD("zAdi_Categories")},
                                               {Utils.parseStringBD("zAdi_UserText")},
                                               {Utils.parseStringBD("zAdi_PriceOFER")},
                                               {Utils.parseStringBD("zAdi_PriceLIQ")})";
                            insertQuery += $@" VALUES (
                                               '{itemCode}',
                                               '{ItemName}',
                                                {0},
                                                {Price},
                                                {false},
                                                NULL,
                                                ' ',
                                                NOW(),
                                                'INSERT',
                                                NULL,
                                               '{Currency}',
                                               '{Marca}',
                                               '{CodeSAT}',
                                               'campo obsoleto',
                                               '{Categorias}',
                                               'campo obsoleto',
                                                {price_Ofer},
                                                {price_Liq})";
                        }

                        bool fgInset = DBConn.ExecQueryInsert(insertQuery, DBConn.ConectionDB.Bitacoras);
                        if (!fgInset) Utils.PrintLog("RegisterProductToLog_v2", "0", $"no fue posible registrar el producto {itemCode} en la bitácora. query: {insertQuery}");

                        continue;
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("RegisterProductToLog_v2", "1", ex.ToString());
            }
        }

        public void SyncProductsToWooCommerce_v2()
        {
            //string path = "C:\\SyncWooCommerce.txt";
            try
            {
                List<productoModel> lsProductos = new List<productoModel>();
                string querySelectSAP = $@"SELECT TOP {Utils.RangoRegistros_prod} 
                                        {Utils.parseStringBD(zAdi_SyncItems.zAdi_SyncItemsId)}, 
                                        {Utils.parseStringBD(zAdi_SyncItems.zAdi_ItemCode)}, 
                                        {Utils.parseStringBD(zAdi_SyncItems.zAdi_ItemName)}, 
                                        {Utils.parseStringBD(zAdi_SyncItems.zAdi_StockValue)}, 
                                        {Utils.parseStringBD(zAdi_SyncItems.zAdi_Price)}, 
                                        {Utils.parseStringBD("zAdi_Currency")}, 
                                        {Utils.parseStringBD("zAdi_Brand")}, 
                                        {Utils.parseStringBD("zAdi_CodeSAT")},
                                        {Utils.parseStringBD("zAdi_Description")},
                                        {Utils.parseStringBD("zAdi_Categories")},
                                        {Utils.parseStringBD("zAdi_UserText")},
                                        {Utils.parseStringBD("zAdi_PriceOFER")},
                                        {Utils.parseStringBD("zAdi_PriceLIQ")}";
                querySelectSAP += $" FROM {Utils.parseStringBD(DBConn.zAdi_SyncItems)}";
                querySelectSAP += $" WHERE {Utils.parseStringBD(DBConn.zAdi_SyncItems)}.{Utils.parseStringBD(zAdi_SyncItems.zAdi_FlagSend)} = FALSE AND {Utils.parseStringBD(DBConn.zAdi_SyncItems)}.{Utils.parseStringBD(zAdi_SyncItems.zAdi_Action)} = 'INSERT'";
                //Utils.PrintLog("SyncProductsToWooCommerce_v2", "0", $"querySelectSAP: {querySelectSAP}");
                DataTable tbl_zAdi_SyncItems = DBConn.ExecQuery(querySelectSAP, DBConn.ConectionDB.Bitacoras);
                if (tbl_zAdi_SyncItems != null && tbl_zAdi_SyncItems.Rows != null && tbl_zAdi_SyncItems.Rows.Count > 0)
                {
                    foreach (DataRow row_zAdi_SyncItems in tbl_zAdi_SyncItems.Rows)
                    {
                        productoModel producto = new productoModel();
                        string zAdi_SyncItemsId = row_zAdi_SyncItems["zAdi_SyncItemsId"].ToString();
                        string zAdi_ItemCode = row_zAdi_SyncItems["zAdi_ItemCode"].ToString();
                        string zAdi_ItemName = row_zAdi_SyncItems["zAdi_ItemName"].ToString();
                        zAdi_ItemName = zAdi_ItemName.Replace("'", "");
                        string zAdi_StockValue = row_zAdi_SyncItems["zAdi_StockValue"].ToString();
                        double zAdi_Price = Convert.ToDouble(row_zAdi_SyncItems["zAdi_Price"] != null && !string.IsNullOrEmpty(row_zAdi_SyncItems["zAdi_Price"].ToString()) ? row_zAdi_SyncItems["zAdi_Price"].ToString() : "0");
                        string zAdi_Currency = row_zAdi_SyncItems["zAdi_Currency"].ToString();
                        string zAdi_Brand = row_zAdi_SyncItems["zAdi_Brand"].ToString();
                        string zAdi_CodeSAT = row_zAdi_SyncItems["zAdi_CodeSAT"].ToString();
                        //string zAdi_Description = row_zAdi_SyncItems["zAdi_Description"].ToString();
                        string zAdi_Categories = row_zAdi_SyncItems["zAdi_Categories"].ToString();
                        string zAdi_UserText = row_zAdi_SyncItems["zAdi_UserText"].ToString();
                        double zAdi_PriceOFER = Convert.ToDouble(row_zAdi_SyncItems["zAdi_PriceOFER"] != null && !string.IsNullOrEmpty(row_zAdi_SyncItems["zAdi_PriceOFER"].ToString()) && row_zAdi_SyncItems["zAdi_PriceOFER"].ToString() != "?" ? row_zAdi_SyncItems["zAdi_PriceOFER"].ToString() : "0");
                        double zAdi_PriceLIQ = Convert.ToDouble(row_zAdi_SyncItems["zAdi_PriceLIQ"] != null && !string.IsNullOrEmpty(row_zAdi_SyncItems["zAdi_PriceLIQ"].ToString()) && row_zAdi_SyncItems["zAdi_PriceLIQ"].ToString() != "?" ? row_zAdi_SyncItems["zAdi_PriceLIQ"].ToString() : "0");

                        zAdi_ItemCode = string.Join("", zAdi_ItemCode.Split('\''));
                        zAdi_ItemCode = zAdi_ItemCode.Replace("'", "");
                        zAdi_ItemCode = zAdi_ItemCode.Trim(new char[] { '\\', ' ' });

                        zAdi_ItemName = string.Join("", zAdi_ItemName.Split('\''));
                        zAdi_ItemName = zAdi_ItemName.Replace("'", "");
                        zAdi_ItemName = zAdi_ItemName.Trim(new char[] { '\\' });

                        zAdi_Brand = string.Join("", zAdi_Brand.Split('\''));
                        zAdi_Brand = zAdi_Brand.Replace("'", "");
                        zAdi_Brand = zAdi_Brand.Trim(new char[] { '\\' });

                        zAdi_Categories = string.Join("", zAdi_Categories.Split('\''));
                        zAdi_Categories = zAdi_Categories.Replace("'", "");
                        zAdi_Categories = zAdi_Categories.Trim(new char[] { '\\' });


                        string queryPrice = $"SELECT {Utils.parseStringBD("PriceList")}, {Utils.parseStringBD("Price")}, {Utils.parseStringBD("Currency")} FROM {Utils.parseStringBD("ITM1")} WHERE TRIM(replace(replace({Utils.parseStringBD("ItemCode")}, '''',''),'\\', '')) = '{zAdi_ItemCode}' AND {Utils.parseStringBD("PriceList")} IN (1, 4, 5)";
                        //Utils.PrintLog("SyncProductsToWooCommerce_v2", "", queryPrice);
                        DataTable tblPrice = DBConn.ExecQuery(queryPrice);

                        //string Price = tblPrice != null && tblPrice.Rows != null && tblPrice.Rows.Count > 0 ? tblPrice.Rows[0]["Price"] != null ? tblPrice.Rows[0]["Price"].ToString() : "0": "0";
                        string Currency = tblPrice != null && tblPrice.Rows != null && tblPrice.Rows.Count > 0 ? tblPrice.Rows[0]["Currency"] != null ? tblPrice.Rows[0]["Currency"].ToString() : "USD" : "USD";

                        int dispGDL = 0, dispCDMX = 0, dispMTY = 0, dispLEON = 0, dispLIQ = 0, dispOFER = 0, unidadesCam = 0, dispGen = 0, dispMaster = 0;

                        string query = $@"SELECT {Utils.parseStringBD("WhsCode")}, {Utils.parseStringBD("OnHand")}, {Utils.parseStringBD("IsCommited")}, {Utils.parseStringBD("OnOrder")}";
                        query += $" FROM {Utils.parseStringBD("OITW")}";
                        query += $" WHERE TRIM(replace(replace({Utils.parseStringBD("ItemCode")}, '''',''),'\\', '')) = '{zAdi_ItemCode}'";
                        query += $" AND ( {returnWhsSelect(5)} )"; // suma total de pedido.

                        DataTable tbl_total_pedido = DBConn.ExecQuery(query);
                        if (tbl_total_pedido != null && tbl_total_pedido.Rows != null && tbl_total_pedido.Rows.Count > 0)
                        {
                            /*
                             * 01 - GDL
                             * 02 - CMDX
                             * 03 - MTY
                             * 04 - LEON
                             * 05 - LIQ
                             * 13 - OFER
                             * 
                             *  Disp = OnHand - IsCommited + OnOrder
                             */

                            foreach (DataRow row_inv in tbl_total_pedido.Rows)
                            {
                                int OnHand = row_inv["OnHand"] != null && !string.IsNullOrEmpty(row_inv["OnHand"].ToString()) ? Convert.ToInt32(double.Parse(row_inv["OnHand"].ToString())) : 0;
                                int IsCommited = row_inv["IsCommited"] != null && !string.IsNullOrEmpty(row_inv["IsCommited"].ToString()) ? Convert.ToInt32(double.Parse(row_inv["IsCommited"].ToString())) : 0;
                                int OnOrder = row_inv["OnOrder"] != null && !string.IsNullOrEmpty(row_inv["OnOrder"].ToString()) ? Convert.ToInt32(double.Parse(row_inv["OnOrder"].ToString())) : 0;
                                unidadesCam += OnOrder; //unidades en ccamino

                                switch (row_inv["WhsCode"].ToString())
                                {
                                    case "01":
                                        dispGDL = OnHand - IsCommited + OnOrder;
                                        break;
                                    case "02":
                                        dispCDMX = OnHand - IsCommited + OnOrder;
                                        break;
                                    case "03":
                                        dispMTY = OnHand - IsCommited + OnOrder;
                                        break;
                                    case "04":
                                        dispLEON = OnHand - IsCommited + OnOrder;
                                        break;
                                    case "05":
                                        dispLIQ = OnHand - IsCommited + OnOrder;
                                        break;
                                    case "13":
                                        dispOFER = OnHand - IsCommited + OnOrder;
                                        break;
                                }
                            }



                            if (dispCDMX < 0) dispCDMX = 0;
                            if (dispGDL < 0) dispGDL = 0;
                            if (dispLEON < 0) dispLEON = 0;
                            if (dispLIQ < 0) dispLIQ = 0;
                            if (dispMTY < 0) dispMTY = 0;
                            if (dispOFER < 0) dispOFER = 0;

                            dispGen = (dispCDMX + dispGDL + dispLEON + dispMTY);
                            dispMaster = (dispCDMX + dispGDL + dispLEON + dispMTY + dispLIQ + dispOFER);

                            if (dispGen < 0) dispGen = 0;
                            if (dispMaster < 0) dispMaster = 0;
                            //Utils.PrintLog("SyncProductsToWooCommerce_v2", "0", $"dispCDMX: {dispCDMX}, dispGDL:{dispGDL}, dispLEON: {dispLEON}, dispMTY: {dispMTY}, dispGen: {dispGen}, dispMaster: {dispMaster}");
                        }
                        /*
                        * Table dsq_posts Product MASTER
                        */
                        string post_name = Utils.RemoveReservedCharacters(zAdi_ItemCode);
                        if (post_name.All(char.IsNumber))
                            post_name += "prod";

                        string insert_dsq_posts = $"INSERT INTO dsq_posts (ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES";
                        insert_dsq_posts += $"(NULL"; //ID
                        insert_dsq_posts += $", 1";//post_author
                        insert_dsq_posts += $", '{Utils.ToLocalTimeMexico().ToString("yyyy-MM-dd hh:mm:ss")}'";//post_date
                        insert_dsq_posts += $", '{Utils.ToLocalTimeMexico().ToString("yyyy-MM-dd hh:mm:ss")}'";//post_date_gmt
                        insert_dsq_posts += $", ''";//post_content
                        insert_dsq_posts += $", '{zAdi_ItemName}'";//post_title
                        insert_dsq_posts += $", ''";//post_excerpt
                        insert_dsq_posts += $", 'publish'";//post_status
                        insert_dsq_posts += $", 'closed'";//comment_status
                        insert_dsq_posts += $", 'closed'";//ping_status
                        insert_dsq_posts += $", ''";//post_password
                        insert_dsq_posts += $", '{post_name}'";//post_name
                        insert_dsq_posts += $", ''";//to_ping
                        insert_dsq_posts += $", ''";//pinged
                        insert_dsq_posts += $", '{Utils.ToLocalTimeMexico().ToString("yyyy-MM-dd hh:mm:ss")}'";//post_modified
                        insert_dsq_posts += $", '{Utils.ToLocalTimeMexico().ToString("yyyy-MM-dd hh:mm:ss")}'";//post_modified_gmt
                        insert_dsq_posts += $", ''";//post_content_filtered
                        insert_dsq_posts += $", 0";//post_parent
                        insert_dsq_posts += $", 'url'";//guid
                        insert_dsq_posts += $", 0";//menu_order
                        insert_dsq_posts += $", 'product'";//post_type
                        insert_dsq_posts += $", ''";//post_mime_type
                        insert_dsq_posts += $", 0);";//comment_count
                        //Utils.PrintLog("", "0", $"insert_dsq_posts MASTER: {insert_dsq_posts}");
                        bool fgInsert = DBConnMysql.ExecQueryInsert(insert_dsq_posts);
                        if (fgInsert)
                        {

                            string select_dsq_posts = $"SELECT ID, post_title, post_name FROM dsq_posts WHERE post_title= '{zAdi_ItemName}' AND post_name = '{post_name}' LIMIT 1;";
                            //Utils.PrintLog("", "0", $"insert_dsq_posts select_dsq_posts: {select_dsq_posts}");
                            DataTable tbl_dqs_posts = DBConnMysql.ExecQuery(select_dsq_posts);
                            if (tbl_dqs_posts != null && tbl_dqs_posts.Rows != null && tbl_dqs_posts.Rows.Count > 0)
                            {
                                int ID = int.Parse(tbl_dqs_posts.Rows[0]["ID"].ToString());
                                producto.idMaster = ID;

                                #region Update FROM DB SAP HANA
                                string update_zAdi_SyncItems = $"UPDATE {Utils.parseStringBD(DBConn.zAdi_SyncItems)}";
                                update_zAdi_SyncItems += $" SET {Utils.parseStringBD(zAdi_SyncItems.zAdi_FlagSend)} = TRUE, {Utils.parseStringBD(zAdi_SyncItems.zAdi_DateSend)} = NOW(), {Utils.parseStringBD(zAdi_SyncItems.zAdi_IdCommerce)} = {ID}, {Utils.parseStringBD(zAdi_SyncItems.zAdi_DesMessage)} = 'El producto con código {row_zAdi_SyncItems.ItemArray[1].ToString()} se ha sincronizado con éxito.'";
                                update_zAdi_SyncItems += $" WHERE {Utils.parseStringBD(zAdi_SyncItems.zAdi_SyncItemsId)} = {zAdi_SyncItemsId}";
                                DBConn.ExecQueryUpdate(update_zAdi_SyncItems, DBConn.ConectionDB.Bitacoras);
                                #endregion

                                #region Update guid FROM DB Mysql
                                string update_dsq_posts = $"UPDATE dsq_posts";
                                update_dsq_posts += $" SET guid= '" + "https://adises.link/?post_type=product&#038;p=" + $"{ID}'";
                                update_dsq_posts += $" WHERE ID= {ID}";
                                DBConnMysql.ExecQueryUpdate(update_dsq_posts);
                                #endregion

                                double minPrice = zAdi_Price;
                                if (zAdi_PriceLIQ > 0 && zAdi_PriceOFER > 0)
                                    minPrice = zAdi_PriceLIQ < zAdi_PriceOFER ? zAdi_PriceLIQ : zAdi_PriceOFER;
                                else
                                {
                                    if (zAdi_PriceLIQ > 0)
                                        minPrice = zAdi_PriceLIQ;
                                    else if (zAdi_PriceOFER > 0)
                                        minPrice = zAdi_PriceOFER;
                                }
                                /*
                             * Table dsq_wc_product_meta_lookup PRODUCT MASTER
                             */
                                string insert_dsq_product_meta_lookup = $"INSERT INTO dsq_wc_product_meta_lookup (product_id, sku, virtual, downloadable, min_price, max_price, onsale, stock_quantity, stock_status, rating_count, average_rating, total_sales, tax_status, tax_class) VALUES ";
                                insert_dsq_product_meta_lookup += $"({ID} ";//product_id
                                insert_dsq_product_meta_lookup += $", '{zAdi_ItemCode}'";//sku
                                insert_dsq_product_meta_lookup += $", 0";//virtual
                                insert_dsq_product_meta_lookup += $", 0";//downloadable
                                //insert_dsq_product_meta_lookup += $", {(zAdi_PriceLIQ < zAdi_PriceOFER ? zAdi_PriceLIQ : zAdi_PriceOFER)}";//min_price
                                insert_dsq_product_meta_lookup += $", {(minPrice > 0 ? minPrice.ToString() : "NULL")}";//min_price
                                //insert_dsq_product_meta_lookup += $", {(price_Liq != -1 && price_Ofer != -1 ? price_Liq < price_Ofer ? price_Liq : price_Ofer : Price)}";//min_price
                                insert_dsq_product_meta_lookup += $", {(zAdi_Price > 0 ? zAdi_Price.ToString() : "NULL")}";//max_price
                                insert_dsq_product_meta_lookup += $", 0";//onsale
                                insert_dsq_product_meta_lookup += $", {dispGen}";//stock_quantity
                                insert_dsq_product_meta_lookup += $", 'instock'";//stock_status
                                insert_dsq_product_meta_lookup += $", 0";//rating_count
                                insert_dsq_product_meta_lookup += $", 0";//average_rating
                                insert_dsq_product_meta_lookup += $", 0";//total_sales
                                insert_dsq_product_meta_lookup += $", 'taxable'";//tax_status
                                insert_dsq_product_meta_lookup += $", '');";//tax_class
                                //Utils.PrintLog("", "0", $"insert_dsq_product_meta_lookup MASTER: {insert_dsq_product_meta_lookup}");
                                DBConnMysql.ExecQueryInsert(insert_dsq_product_meta_lookup);

                                /*
                                 * Table dsq_postmeta PRODUCT MASTER
                                 */
                                string insert_dsq_postmeta = string.Empty;
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'inline_featured_image', '0'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_edit_lock', '1615943826:1'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_edit_last', '4'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_sku', '{zAdi_ItemCode}'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'total_sales', '0'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_tax_status', 'taxable'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_tax_class', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_manage_stock', 'yes'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_backorders', 'no'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_sold_individually', 'no'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_virtual', 'no'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_downloadable', 'no'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_download_limit', '0'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_download_expiry', '7'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_stock', '{dispMaster}'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_stock_status', 'instock'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_wc_average_rating', '0'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_wc_review_count', '0'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_product_version', '4.9.1'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'modelo', '{zAdi_ItemCode}'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_modelo', 'field_5f9894478fecd'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'codigo_sat', '{zAdi_CodeSAT}'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_codigo_sat', 'field_5fa02ae4e8f9e'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'marca', '{zAdi_Brand}'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_marca', 'field_5fa0b28219d5c'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'unidades_camino', '{unidadesCam}'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_unidades_camino', 'field_5fd273a28ac85'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'contenido', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_contenido', 'field_5f987ebf8fecc'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'ficha_tecnica', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_ficha_tecnica', 'field_5f989cd68fece'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'video', '2y0Ky1IlJGw'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_video', 'field_5f98afd4b498e'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'logos_diferenciadores', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_logos_diferenciadores', 'field_5f989d918fed0'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'slide_template', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'rs_page_bg_color', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_jet_woo_template', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_template_type', 'default'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'unidades_gdl', '{dispGDL}'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_unidades_gdl', 'field_6047ff4aeb9d4'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'unidades_cdmx', '{dispCDMX}'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_unidades_cdmx', 'field_6047ff7beb9d5'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'unidades_mty', '{dispMTY}'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_unidades_mty', 'field_6047ff99eb9d6'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'unidades_leon', '{dispLEON}'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_unidades_leon', 'field_6047ffa5eb9d7'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_atum_attachments', '[]'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'wcmlim_stock_location_39', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'wcmlim_stock_location_38', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'descripcion', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_descripcion', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'so_wc_template_post_id', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'ocean_sidebar', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'ocean_second_sidebar', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'ocean_disable_margins', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'ocean_display_top_bar', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'ocean_display_header', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'ocean_center_header_left_menu', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'ocean_custom_header_template', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'ocean_header_custom_menu', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'ocean_menu_typo_font_family', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'ocean_disable_title', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'ocean_disable_heading', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'ocean_disable_breadcrumbs', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'ocean_display_footer_widgets', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'ocean_display_footer_bottom', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'ocean_custom_footer_template', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_primary_term_product_cat', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'wcmlim_stock_location_53', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'wcmlim_stock_location_54', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'wcmlim_stock_location_55', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'wcmlim_stock_location_56', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'wcmlim_stock_location_57', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_regular_price_wmcp', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_sale_price_wmcp', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, 'precio_base', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_precio_base', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_wp_old_date', ''); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_upsell_ids', 'a:2:" + "{i:0;i:5239;i:1;i:5238;}'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_default_attributes', 'a:1:" + "{s:7:\"almacen\";s:7:\"GENERAL\";}'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_product_attributes', 'a:1:" + "{s:7:\"almacen\";a:6:{s:4:\"name\";s:8:\"ALMACÉN\";s:5:\"value\";s:33:\"GENERAL | OFERTAS | LIQUIDACIONES\";s:8:\"position\";i:0;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:1;s:11:\"is_taxonomy\";i:0;}}'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_thumbnail_id', '5302'); \n";
                                insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID}, '_price', '{(zAdi_Price > 0 ? zAdi_Price.ToString() : "")}'); \n";

                                //Utils.PrintLog("", "0", $"insert_dsq_postmeta MASTER: {insert_dsq_postmeta}");
                                DBConnMysql.ExecQueryInsert(insert_dsq_postmeta);

                                /*
                                 * Table dsq_term_relationships PRODUCT MASTER
                                 */
                                string insert_dsq_term_relationships = $"INSERT INTO dsq_term_relationships(object_id, term_taxonomy_id, term_order) VALUES ({ID}, 24, {0});\n"; //product type simple
                                DBConnMysql.ExecQueryInsert(insert_dsq_term_relationships);

                                if (!string.IsNullOrEmpty(zAdi_Categories))
                                    SyncCategoriesToWooCommerce(zAdi_Categories, ID, Utils.MASTER, Utils.INSERT);


                                #region PRODUCT GENERAL

                                /*************************************************************************PRODUCT GENERAL**********************************************************************************/
                                insert_dsq_posts = $"INSERT INTO dsq_posts (ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES";
                                insert_dsq_posts += $"(NULL"; //ID
                                insert_dsq_posts += $", 1";//post_author
                                insert_dsq_posts += $", '{Utils.ToLocalTimeMexico().ToString("yyyy-MM-dd hh:mm:ss")}'";//post_date
                                insert_dsq_posts += $", '{Utils.ToLocalTimeMexico().ToString("yyyy-MM-dd hh:mm:ss")}'";//post_date_gmt
                                insert_dsq_posts += $", ''";//post_content
                                insert_dsq_posts += $", '{zAdi_ItemName}'";//post_title
                                insert_dsq_posts += $", 'ALMACÉN: GENERAL'";//post_excerpt
                                insert_dsq_posts += $", 'publish'";//post_status
                                insert_dsq_posts += $", 'closed'";//comment_status
                                insert_dsq_posts += $", 'closed'";//ping_status
                                insert_dsq_posts += $", ''";//post_password
                                insert_dsq_posts += $", '{post_name}'";//post_name
                                insert_dsq_posts += $", ''";//to_ping
                                insert_dsq_posts += $", ''";//pinged
                                insert_dsq_posts += $", '{Utils.ToLocalTimeMexico().ToString("yyyy-MM-dd hh:mm:ss")}'";//post_modified
                                insert_dsq_posts += $", '{Utils.ToLocalTimeMexico().ToString("yyyy-MM-dd hh:mm:ss")}'";//post_modified_gmt
                                insert_dsq_posts += $", ''";//post_content_filtered
                                insert_dsq_posts += $", {ID}";//post_parent
                                insert_dsq_posts += $", 'url'";//guid
                                insert_dsq_posts += $", 1";//menu_order
                                insert_dsq_posts += $", 'product_variation'";//post_type
                                insert_dsq_posts += $", ''";//post_mime_type
                                insert_dsq_posts += $", 0);";//comment_count
                                DBConnMysql.ExecQueryInsert(insert_dsq_posts);
                                select_dsq_posts = $"SELECT ID FROM dsq_posts WHERE post_title= '{zAdi_ItemName}' AND post_name = '{post_name}' AND post_excerpt = 'ALMACÉN: GENERAL' LIMIT 1;";
                                tbl_dqs_posts = DBConnMysql.ExecQuery(select_dsq_posts);
                                int ID_General = 0;
                                if (tbl_dqs_posts != null && tbl_dqs_posts.Rows != null && tbl_dqs_posts.Rows.Count > 0)
                                {
                                    ID_General = int.Parse(tbl_dqs_posts.Rows[0]["ID"].ToString());

                                    #region Update FROM DB SAP HANA
                                    update_zAdi_SyncItems = $"UPDATE {Utils.parseStringBD(DBConn.zAdi_SyncItems)}";
                                    update_zAdi_SyncItems += $" SET {Utils.parseStringBD("zAdi_IdCommerceGEN")} = {ID_General}";
                                    update_zAdi_SyncItems += $" WHERE {Utils.parseStringBD(zAdi_SyncItems.zAdi_SyncItemsId)} = {zAdi_SyncItemsId}";

                                    DBConn.ExecQueryUpdate(update_zAdi_SyncItems, DBConn.ConectionDB.Bitacoras);
                                    #endregion

                                    #region Update guid FROM DB Mysql
                                    update_dsq_posts = $"UPDATE dsq_posts";
                                    update_dsq_posts += $" SET guid= '" + "https://adises.link/producto/import-placeholder-for-" + $"{ID_General}/'";
                                    update_dsq_posts += $" WHERE ID= {ID_General}";
                                    DBConnMysql.ExecQueryUpdate(update_dsq_posts);
                                    #endregion


                                    insert_dsq_product_meta_lookup = $"INSERT INTO dsq_wc_product_meta_lookup (product_id, sku, virtual, downloadable, min_price, max_price, onsale, stock_quantity, stock_status, rating_count, average_rating, total_sales, tax_status, tax_class) VALUES ";
                                    insert_dsq_product_meta_lookup += $"({ID_General} ";//product_id
                                    insert_dsq_product_meta_lookup += $", ''";//sku
                                    insert_dsq_product_meta_lookup += $", 0";//virtual
                                    insert_dsq_product_meta_lookup += $", 0";//downloadable
                                    insert_dsq_product_meta_lookup += $", {(zAdi_Price > 0 ? zAdi_Price.ToString() : "NULL")}";//min_price
                                    insert_dsq_product_meta_lookup += $", {(zAdi_Price > 0 ? zAdi_Price.ToString() : "NULL")}";//max_price
                                    insert_dsq_product_meta_lookup += $", 0";//onsale
                                    insert_dsq_product_meta_lookup += $", {dispGen}";//stock_quantity
                                    insert_dsq_product_meta_lookup += $", 'instock'";//stock_status
                                    insert_dsq_product_meta_lookup += $", 0";//rating_count
                                    insert_dsq_product_meta_lookup += $", 0";//average_rating
                                    insert_dsq_product_meta_lookup += $", 0";//total_sales
                                    insert_dsq_product_meta_lookup += $", 'taxable'";//tax_status
                                    insert_dsq_product_meta_lookup += $", 'parent');";//tax_class
                                    //Utils.PrintLog("", "0", $"insert_dsq_product_meta_lookup GEN: {insert_dsq_product_meta_lookup}");
                                    DBConnMysql.ExecQueryInsert(insert_dsq_product_meta_lookup);

                                    /*
                                     * Table dsq_postmeta PRODUCT GENERAL
                                     */
                                    insert_dsq_postmeta = string.Empty;
                                    insert_dsq_postmeta = $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'inline_featured_image', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'total_sales', '0'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_tax_status', 'taxable'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_tax_class', 'parent'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_manage_stock', 'yes'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_backorders', 'no'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_sold_individually', 'no'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_virtual', 'no'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_downloadable', 'no'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_download_limit', '0'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_download_expiry', '7'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_stock', '{dispGen}'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_stock_status', 'instock'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_wc_average_rating', '0'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_wc_review_count', '0'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_product_version', '4.9.1'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'wcmlim_stock_location_39', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'wcmlim_stock_location_38', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'modelo', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_modelo', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'descripcion', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_descripcion', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'contenido', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_contenido', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'ficha_tecnica', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_ficha_tecnica', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'video', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_video', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'logos_diferenciadores', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_logos_diferenciadores', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'slide_template', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'rs_page_bg_color', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'so_wc_template_post_id', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'ocean_sidebar', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'ocean_second_sidebar', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'ocean_disable_margins', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'ocean_display_top_bar', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'ocean_display_header', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'ocean_center_header_left_menu', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'ocean_custom_header_template', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'ocean_header_custom_menu', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'ocean_menu_typo_font_family', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'ocean_disable_title', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'ocean_disable_heading', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'ocean_disable_breadcrumbs', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'ocean_display_footer_widgets', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'ocean_display_footer_bottom', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'ocean_custom_footer_template', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'codigo_sat', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_codigo_sat', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'marca', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_marca', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_primary_term_product_cat', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'wcmlim_stock_location_53', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'wcmlim_stock_location_54', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'wcmlim_stock_location_55', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'wcmlim_stock_location_56', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'wcmlim_stock_location_57', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_regular_price_wmcp', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_sale_price_wmcp', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'precio_base', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_precio_base', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_jet_woo_template', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_template_type', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'unidades_camino', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_unidades_camino', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_wp_old_date', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'unidades_gdl', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_unidades_gdl', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'unidades_cdmx', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_unidades_cdmx', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'unidades_mty', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_unidades_mty', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'unidades_leon', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_unidades_leon', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_atum_attachments', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_wp_old_slug', 'import-placeholder-for-5146'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_variation_description', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_regular_price', '{(zAdi_Price > 0 ? zAdi_Price.ToString() : "")}'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_thumbnail_id', '0'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, '_price', '{(zAdi_Price > 0 ? zAdi_Price.ToString() : "")}'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_General}, 'attribute_almacen', 'GENERAL'); \n";

                                    DBConnMysql.ExecQueryInsert(insert_dsq_postmeta);

                                    /*
                                 * Table dsq_term_relationships PRODUCT GENERAL
                                 */
                                    insert_dsq_term_relationships = $"INSERT INTO dsq_term_relationships(object_id, term_taxonomy_id, term_order) VALUES ({ID_General}, 35, {0});\n"; // 35: producto sin categorizar.

                                    DBConnMysql.ExecQueryInsert(insert_dsq_term_relationships);
                                }
                                else
                                {
                                    Utils.PrintLog("SyncProductsToWooCommerce_v2", "0", $"No fue posible realizar la sincronización del producto {zAdi_ItemCode} variante GENERAL");

                                }
                                #endregion

                                #region PRODUC OFERTA
                                /*************************************************************************PRODUCT OFERTA**********************************************************************************/
                                insert_dsq_posts = $"INSERT INTO dsq_posts (ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES";
                                insert_dsq_posts += $"(NULL"; //ID
                                insert_dsq_posts += $", 1";//post_author
                                insert_dsq_posts += $", '{Utils.ToLocalTimeMexico().ToString("yyyy-MM-dd hh:mm:ss")}'";//post_date
                                insert_dsq_posts += $", '{Utils.ToLocalTimeMexico().ToString("yyyy-MM-dd hh:mm:ss")}'";//post_date_gmt
                                insert_dsq_posts += $", ''";//post_content
                                insert_dsq_posts += $", '{zAdi_ItemName}'";//post_title
                                insert_dsq_posts += $", 'ALMACÉN: OFERTAS'";//post_excerpt
                                insert_dsq_posts += $", 'publish'";//post_status
                                insert_dsq_posts += $", 'closed'";//comment_status
                                insert_dsq_posts += $", 'closed'";//ping_status
                                insert_dsq_posts += $", ''";//post_password
                                insert_dsq_posts += $", '{post_name}'";//post_name
                                insert_dsq_posts += $", ''";//to_ping
                                insert_dsq_posts += $", ''";//pinged
                                insert_dsq_posts += $", '{Utils.ToLocalTimeMexico().ToString("yyyy-MM-dd hh:mm:ss")}'";//post_modified
                                insert_dsq_posts += $", '{Utils.ToLocalTimeMexico().ToString("yyyy-MM-dd hh:mm:ss")}'";//post_modified_gmt
                                insert_dsq_posts += $", ''";//post_content_filtered
                                insert_dsq_posts += $", {ID}";//post_parent
                                insert_dsq_posts += $", 'url'";//guid
                                insert_dsq_posts += $", {(ID_General > 0 ? 2 : 1)}";//menu_order
                                insert_dsq_posts += $", 'product_variation'";//post_type
                                insert_dsq_posts += $", ''";//post_mime_type
                                insert_dsq_posts += $", 0);";//comment_count
                                DBConnMysql.ExecQueryInsert(insert_dsq_posts);
                                select_dsq_posts = $"SELECT ID FROM dsq_posts WHERE post_title= '{zAdi_ItemName}' AND post_name = '{post_name}' AND post_excerpt = 'ALMACÉN: OFERTAS' LIMIT 1;";
                                tbl_dqs_posts = DBConnMysql.ExecQuery(select_dsq_posts);
                                int ID_Oferta = 0;
                                if (tbl_dqs_posts != null && tbl_dqs_posts.Rows != null && tbl_dqs_posts.Rows.Count > 0)
                                {
                                    ID_Oferta = int.Parse(tbl_dqs_posts.Rows[0]["ID"].ToString());

                                    #region Update FROM DB SAP HANA
                                    update_zAdi_SyncItems = $"UPDATE {Utils.parseStringBD(DBConn.zAdi_SyncItems)}";
                                    update_zAdi_SyncItems += $" SET {Utils.parseStringBD("zAdi_IdCommerceOFER")} = {ID_Oferta}";
                                    update_zAdi_SyncItems += $" WHERE {Utils.parseStringBD(zAdi_SyncItems.zAdi_SyncItemsId)} = {zAdi_SyncItemsId}";
                                    DBConn.ExecQueryUpdate(update_zAdi_SyncItems, DBConn.ConectionDB.Bitacoras);
                                    #endregion

                                    #region Update guid FROM DB Mysql
                                    update_dsq_posts = $"UPDATE dsq_posts";
                                    update_dsq_posts += $" SET guid= '" + "https://adises.link/producto/import-placeholder-for-" + $"{ID_Oferta}/'";
                                    update_dsq_posts += $" WHERE ID= {ID_Oferta}";
                                    DBConnMysql.ExecQueryUpdate(update_dsq_posts);
                                    #endregion

                                    SyncCategoriesToWooCommerce("", ID_Oferta, Utils.OFERTA, Utils.INSERT); //para categorizar al producto como OFERTA

                                    insert_dsq_product_meta_lookup = $"INSERT INTO dsq_wc_product_meta_lookup (product_id, sku, virtual, downloadable, min_price, max_price, onsale, stock_quantity, stock_status, rating_count, average_rating, total_sales, tax_status, tax_class) VALUES ";
                                    insert_dsq_product_meta_lookup += $"({ID_Oferta} ";//product_id
                                    insert_dsq_product_meta_lookup += $", ''";//sku
                                    insert_dsq_product_meta_lookup += $", 0";//virtual
                                    insert_dsq_product_meta_lookup += $", 0";//downloadable
                                    //insert_dsq_product_meta_lookup += $", {(zAdi_PriceOFER > 0 ? zAdi_PriceOFER.ToString() : "NULL")}";//min_price
                                    insert_dsq_product_meta_lookup += $", {(zAdi_PriceOFER > 0 ? zAdi_PriceOFER.ToString() : "0.1")}";//min_price
                                    //insert_dsq_product_meta_lookup += $", {(zAdi_PriceOFER > 0 ? zAdi_PriceOFER.ToString() : "NULL")}";//max_price
                                    insert_dsq_product_meta_lookup += $", {(zAdi_PriceOFER > 0 ? zAdi_PriceOFER.ToString() : "0.1")}";//max_price
                                    insert_dsq_product_meta_lookup += $", 0";//onsale
                                    insert_dsq_product_meta_lookup += $", {dispOFER}";//stock_quantity
                                    insert_dsq_product_meta_lookup += $", 'instock'";//stock_status
                                    insert_dsq_product_meta_lookup += $", 0";//rating_count
                                    insert_dsq_product_meta_lookup += $", 0";//average_rating
                                    insert_dsq_product_meta_lookup += $", 0";//total_sales
                                    insert_dsq_product_meta_lookup += $", 'taxable'";//tax_status
                                    insert_dsq_product_meta_lookup += $", 'parent');";//tax_class

                                    DBConnMysql.ExecQueryInsert(insert_dsq_product_meta_lookup);

                                    /*
                                     * Table dsq_postmeta PRODUCT OFERTA
                                     */
                                    insert_dsq_postmeta = string.Empty;
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'inline_featured_image', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'total_sales', '0'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_tax_status', 'taxable'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_tax_class', 'parent'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_manage_stock', 'yes'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_backorders', 'no'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_sold_individually', 'no'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_virtual', 'no'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_downloadable', 'no'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_download_limit', '0'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_download_expiry', '7'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_stock', '{dispOFER}'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_stock_status', 'instock'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_wc_average_rating', '0'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_wc_review_count', '0'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_product_version', '4.9.1'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'wcmlim_stock_location_39', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'wcmlim_stock_location_38', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'modelo', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_modelo', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'descripcion', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_descripcion', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'contenido', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_contenido', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'ficha_tecnica', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_ficha_tecnica', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'video', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_video', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'logos_diferenciadores', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_logos_diferenciadores', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'slide_template', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'rs_page_bg_color', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'so_wc_template_post_id', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'ocean_sidebar', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'ocean_second_sidebar', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'ocean_disable_margins', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'ocean_display_top_bar', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'ocean_display_header', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'ocean_center_header_left_menu', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'ocean_custom_header_template', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'ocean_header_custom_menu', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'ocean_menu_typo_font_family', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'ocean_disable_title', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'ocean_disable_heading', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'ocean_disable_breadcrumbs', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'ocean_display_footer_widgets', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'ocean_display_footer_bottom', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'ocean_custom_footer_template', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'codigo_sat', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_codigo_sat', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'marca', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_marca', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_primary_term_product_cat', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'wcmlim_stock_location_53', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'wcmlim_stock_location_54', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'wcmlim_stock_location_55', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'wcmlim_stock_location_56', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'wcmlim_stock_location_57', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_regular_price_wmcp', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_sale_price_wmcp', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'precio_base', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_precio_base', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_jet_woo_template', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_template_type', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'unidades_camino', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_unidades_camino', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_wp_old_date', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'unidades_gdl', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_unidades_gdl', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'unidades_cdmx', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_unidades_cdmx', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'unidades_mty', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_unidades_mty', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'unidades_leon', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_unidades_leon', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_atum_attachments', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_wp_old_slug', 'import-placeholder-for-5147'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_variation_description', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_regular_price', '{(zAdi_Price > 0 ? zAdi_Price.ToString() : "")}'); \n";
                                    //insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_sale_price', '{(zAdi_PriceOFER > 0 ? zAdi_PriceOFER.ToString() : "")}'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_sale_price', '{(zAdi_PriceOFER > 0 ? zAdi_PriceOFER.ToString() : "0.1")}'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_thumbnail_id', '0'); \n";
                                    //insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_price', '{(zAdi_PriceOFER > 0 ? zAdi_PriceOFER.ToString() : "")}'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, '_price', '{(zAdi_PriceOFER > 0 ? zAdi_PriceOFER.ToString() : "0.1")}'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Oferta}, 'attribute_almacen', 'OFERTAS'); \n";

                                    DBConnMysql.ExecQueryInsert(insert_dsq_postmeta);
                                }
                                else
                                {
                                    Utils.PrintLog("SyncProductsToWooCommerce_v2", "0", $"No fue posible realizar la sincronización del producto {zAdi_ItemCode} variante OFERTA");

                                }
                                #endregion

                                #region PRODUCT LIQUIDACION
                                /*************************************************************************PRODUCT LIQUIDACION**********************************************************************************/
                                insert_dsq_posts = $"INSERT INTO dsq_posts (ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES";
                                insert_dsq_posts += $"(NULL"; //ID
                                insert_dsq_posts += $", 1";//post_author
                                insert_dsq_posts += $", '{Utils.ToLocalTimeMexico().ToString("yyyy-MM-dd hh:mm:ss")}'";//post_date
                                insert_dsq_posts += $", '{Utils.ToLocalTimeMexico().ToString("yyyy-MM-dd hh:mm:ss")}'";//post_date_gmt
                                insert_dsq_posts += $", ''";//post_content
                                insert_dsq_posts += $", '{zAdi_ItemName}'";//post_title
                                insert_dsq_posts += $", 'ALMACÉN: LIQUIDACIONES'";//post_excerpt
                                insert_dsq_posts += $", 'publish'";//post_status
                                insert_dsq_posts += $", 'closed'";//comment_status
                                insert_dsq_posts += $", 'closed'";//ping_status
                                insert_dsq_posts += $", ''";//post_password
                                insert_dsq_posts += $", '{post_name}'";//post_name
                                insert_dsq_posts += $", ''";//to_ping
                                insert_dsq_posts += $", ''";//pinged
                                insert_dsq_posts += $", '{Utils.ToLocalTimeMexico().ToString("yyyy-MM-dd hh:mm:ss")}'";//post_modified
                                insert_dsq_posts += $", '{Utils.ToLocalTimeMexico().ToString("yyyy-MM-dd hh:mm:ss")}'";//post_modified_gmt
                                insert_dsq_posts += $", ''";//post_content_filtered
                                insert_dsq_posts += $", {ID}";//post_parent
                                insert_dsq_posts += $", 'url'";//guid
                                insert_dsq_posts += $", {(ID_General > 0 ? ID_Oferta > 0 ? 3 : 2 : 1)}";//menu_order
                                insert_dsq_posts += $", 'product_variation'";//post_type
                                insert_dsq_posts += $", ''";//post_mime_type
                                insert_dsq_posts += $", 0);";//comment_count
                                DBConnMysql.ExecQueryInsert(insert_dsq_posts);

                                select_dsq_posts = $"SELECT ID FROM dsq_posts WHERE post_title= '{zAdi_ItemName}' AND post_name = '{post_name}' AND post_excerpt = 'ALMACÉN: LIQUIDACIONES' LIMIT 1;";
                                tbl_dqs_posts = DBConnMysql.ExecQuery(select_dsq_posts);
                                int ID_Liq = 0;
                                if (tbl_dqs_posts != null && tbl_dqs_posts.Rows != null && tbl_dqs_posts.Rows.Count > 0)
                                {
                                    ID_Liq = int.Parse(tbl_dqs_posts.Rows[0]["ID"].ToString());

                                    #region Update FROM DB SAP HANA
                                    update_zAdi_SyncItems = $"UPDATE {Utils.parseStringBD(DBConn.zAdi_SyncItems)}";
                                    update_zAdi_SyncItems += $" SET {Utils.parseStringBD("zAdi_IdCommerceLIQ")} = {ID_Liq}";
                                    update_zAdi_SyncItems += $" WHERE {Utils.parseStringBD(zAdi_SyncItems.zAdi_SyncItemsId)} = {zAdi_SyncItemsId}";

                                    DBConn.ExecQueryUpdate(update_zAdi_SyncItems, DBConn.ConectionDB.Bitacoras);
                                    #endregion

                                    #region Update guid FROM DB Mysql
                                    update_dsq_posts = $"UPDATE dsq_posts";
                                    update_dsq_posts += $" SET guid= '" + "https://adises.link/producto/import-placeholder-for-" + $"{ID_Liq}/'";
                                    update_dsq_posts += $" WHERE ID= {ID_Liq}";

                                    //using (StreamWriter writer = new StreamWriter(path, true))
                                    //{
                                    //    writer.WriteLine("query mysql PRODUCT Utils.Utils.LIQUIDACION: " + update_dsq_posts);
                                    //    writer.Close();
                                    //}
                                    DBConnMysql.ExecQueryUpdate(update_dsq_posts);
                                    #endregion

                                    SyncCategoriesToWooCommerce("", ID_Liq, Utils.LIQUIDACION, Utils.INSERT); //Para categorizar al producto como LIQUIDACION

                                    insert_dsq_product_meta_lookup = $"INSERT INTO dsq_wc_product_meta_lookup (product_id, sku, virtual, downloadable, min_price, max_price, onsale, stock_quantity, stock_status, rating_count, average_rating, total_sales, tax_status, tax_class) VALUES ";
                                    insert_dsq_product_meta_lookup += $"({ID_Liq} ";//product_id
                                    insert_dsq_product_meta_lookup += $", ''";//sku
                                    insert_dsq_product_meta_lookup += $", 0";//virtual
                                    insert_dsq_product_meta_lookup += $", 0";//downloadable
                                    //insert_dsq_product_meta_lookup += $", {(zAdi_PriceLIQ > 0 ? zAdi_PriceLIQ.ToString() : "NULL")}";//min_price
                                    insert_dsq_product_meta_lookup += $", {(zAdi_PriceLIQ > 0 ? zAdi_PriceLIQ.ToString() : "0.1")}";//min_price
                                    //insert_dsq_product_meta_lookup += $", {(zAdi_PriceLIQ > 0 ? zAdi_PriceLIQ.ToString() : "NULL")}";//max_price
                                    insert_dsq_product_meta_lookup += $", {(zAdi_PriceLIQ > 0 ? zAdi_PriceLIQ.ToString() : "0.1")}";//max_price
                                    insert_dsq_product_meta_lookup += $", 0";//onsale
                                    insert_dsq_product_meta_lookup += $", {(dispLIQ) }";//stock_quantity
                                    insert_dsq_product_meta_lookup += $", 'instock'";//stock_status
                                    insert_dsq_product_meta_lookup += $", 0";//rating_count
                                    insert_dsq_product_meta_lookup += $", 0";//average_rating
                                    insert_dsq_product_meta_lookup += $", 0";//total_sales
                                    insert_dsq_product_meta_lookup += $", 'taxable'";//tax_status
                                    insert_dsq_product_meta_lookup += $", 'parent');";//tax_class
                                    DBConnMysql.ExecQueryInsert(insert_dsq_product_meta_lookup);

                                    /*
                                     * Table dsq_postmeta PRODUCT LIQ
                                     */
                                    insert_dsq_postmeta = string.Empty;
                                    insert_dsq_postmeta = $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'inline_featured_image', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'total_sales', '0'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_tax_status', 'taxable'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_tax_class', 'parent'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_manage_stock', 'yes'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_backorders', 'no'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_sold_individually', 'no'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_virtual', 'no'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_downloadable', 'no'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_download_limit', '0'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_download_expiry', '7'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_stock', '{dispLIQ}'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_stock_status', 'instock'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_wc_average_rating', '0'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_wc_review_count', '0'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_product_version', '4.9.1'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'wcmlim_stock_location_39', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'wcmlim_stock_location_38', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'modelo', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_modelo', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'descripcion', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_descripcion', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'contenido', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_contenido', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'ficha_tecnica', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_ficha_tecnica', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'video', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_video', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'logos_diferenciadores', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_logos_diferenciadores', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'slide_template', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'rs_page_bg_color', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'so_wc_template_post_id', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'ocean_sidebar', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'ocean_second_sidebar', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'ocean_disable_margins', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'ocean_display_top_bar', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'ocean_display_header', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'ocean_center_header_left_menu', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'ocean_custom_header_template', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'ocean_header_custom_menu', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'ocean_menu_typo_font_family', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'ocean_disable_title', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'ocean_disable_heading', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'ocean_disable_breadcrumbs', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'ocean_display_footer_widgets', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'ocean_display_footer_bottom', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'ocean_custom_footer_template', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'codigo_sat', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_codigo_sat', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'marca', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_marca', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_primary_term_product_cat', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'wcmlim_stock_location_53', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'wcmlim_stock_location_54', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'wcmlim_stock_location_55', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'wcmlim_stock_location_56', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'wcmlim_stock_location_57', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_regular_price_wmcp', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_sale_price_wmcp', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'precio_base', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_precio_base', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_jet_woo_template', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_template_type', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'unidades_camino', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_unidades_camino', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_wp_old_date', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'unidades_gdl', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_unidades_gdl', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'unidades_cdmx', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_unidades_cdmx', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'unidades_mty', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_unidades_mty', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'unidades_leon', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_unidades_leon', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_atum_attachments', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_wp_old_slug', 'import-placeholder-for-5148'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_variation_description', ''); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_regular_price', '{(zAdi_Price > 0 ? zAdi_Price.ToString() : "")}'); \n";
                                    //insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_sale_price', '{(zAdi_PriceLIQ > 0 ? zAdi_PriceLIQ.ToString() : "")}'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_sale_price', '{(zAdi_PriceLIQ > 0 ? zAdi_PriceLIQ.ToString() : "0.1")}'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_thumbnail_id', '0'); \n";
                                    //insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_price', '{(zAdi_PriceLIQ > 0 ? zAdi_PriceLIQ.ToString() : "")}'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, '_price', '{(zAdi_PriceLIQ > 0 ? zAdi_PriceLIQ.ToString() : "0.1")}'); \n";
                                    insert_dsq_postmeta += $"INSERT INTO dsq_postmeta(meta_id, post_id, meta_key, meta_value) VALUES (NULL, {ID_Liq}, 'attribute_almacen', 'LIQUIDACIONES'); \n";

                                    DBConnMysql.ExecQueryInsert(insert_dsq_postmeta);
                                }
                                else
                                {
                                    Utils.PrintLog("SyncProductsToWooCommerce_v2", "0", $"No fue posible realizar la sincronización del producto {zAdi_ItemCode} variante LIQUIDACIÓN");
                                }
                                #endregion

                                string metaValue = ID_Oferta > 0 && ID_Liq > 0 ? "a:2:{i:0;i:" + ID_Liq + ";i:1;i:" + ID_Oferta + ";}" : ID_Oferta > 0 || ID_Liq > 0 ? "a:1:{i:0;i:" + (ID_Oferta > 0 ? ID_Oferta : ID_Liq) + ";}" : "";
                                string update_dsq_postmeta = $"UPDATE dsq_postmeta SET meta_value = '{metaValue}' WHERE meta_key = '_upsell_ids' AND post_id = {ID};";
                                DBConnMysql.ExecQueryUpdate(update_dsq_postmeta);

                                string update_price = string.Empty;
                                if (zAdi_PriceOFER <= Convert.ToDouble(0))
                                {
                                    update_price += $"UPDATE dsq_wc_product_meta_lookup SET min_price= NULL, min_price = NULL WHERE product_id = {ID_Oferta}; \n";
                                    update_price += $"UPDATE dsq_postmeta SET meta_value = '' WHERE meta_key = '_sale_price' AND post_id = {ID_Oferta};\n";
                                    update_price += $"UPDATE dsq_postmeta SET meta_value = '' WHERE meta_key = '_price' AND post_id = {ID_Oferta};\n";


                                }
                                if (zAdi_PriceLIQ <= Convert.ToDouble(0))
                                {
                                    update_price += $"UPDATE dsq_wc_product_meta_lookup SET min_price = NULL, min_price = NULL WHERE product_id = {ID_Liq}; \n";
                                    update_price += $"UPDATE dsq_postmeta SET meta_value = '' WHERE meta_key = '_sale_price' AND post_id = {ID_Liq};\n";
                                    update_price += $"UPDATE dsq_postmeta SET meta_value = '' WHERE meta_key = '_price' AND post_id = {ID_Liq};\n";
                                }

                                if (!string.IsNullOrEmpty(update_price))
                                {
                                    //Utils.PrintLog("SyncProductsToWooCommerce_v2", "0", $"update_price: {update_price}");
                                    DBConnMysql.ExecQuery(update_price);
                                }
                                //--oferta--
                                /*APISYNC*/

                                //ApiWC.getInstance.UpdateAsyncPriceProductsVariationWCApi(ID.ToString(), ID_Oferta.ToString(), (zAdi_PriceOFER + 0.1).ToString());
                                //ApiWC.getInstance.UpdateAsyncPriceProductsVariationWCApi(ID.ToString(), ID_Oferta.ToString(), (zAdi_PriceOFER > 0 ? (zAdi_PriceOFER).ToString() : ""));

                                ApiWC.getInstance.runAsyncTask(API.UpdatePrice, ID, ID_Oferta, (Convert.ToDouble(zAdi_PriceOFER) + 0.1).ToString());
                                ApiWC.getInstance.runAsyncTask(API.UpdatePrice, ID, ID_Oferta, (zAdi_PriceOFER > 0 ? (zAdi_PriceOFER).ToString() : ""));
                                //--liquidacion--
                                /*APIASYNC*/
                                //ApiWC.getInstance.UpdateAsyncPriceProductsVariationWCApi(ID.ToString(), ID_Liq.ToString(), (zAdi_PriceLIQ + 0.1).ToString());
                                //ApiWC.getInstance.UpdateAsyncPriceProductsVariationWCApi(ID.ToString(), ID_Liq.ToString(), (zAdi_PriceLIQ > 0 ? (zAdi_PriceLIQ).ToString() : ""));

                                ApiWC.getInstance.runAsyncTask(API.UpdatePrice, ID, ID_Liq, (Convert.ToDouble(zAdi_PriceLIQ) + 0.1).ToString());
                                ApiWC.getInstance.runAsyncTask(API.UpdatePrice, ID, ID_Liq, (zAdi_PriceLIQ > 0 ? (zAdi_PriceLIQ).ToString() : ""));

                                //string status_OFER = zAdi_PriceOFER <= 0 ? "private" : "publish";
                                string status_OFER = "publish";
                                //string status_LIQ = zAdi_PriceLIQ <= 0 ? "private" : "publish";
                                string status_LIQ = "publish";

                                //if(status_OFER == "private")
                                //ApiWC.getInstance.UpdateAsyncStatusProductsVariationWCApi(ID.ToString(), ID_Oferta.ToString(), status_OFER);
                                ApiWC.getInstance.runAsyncTask(API.updateStatus, ID, ID_Oferta, status_OFER);

                                //UpdateStatusProductsVariationWCApi(ID.ToString(), ID_Oferta.ToString(), status_OFER);

                                //if(status_LIQ == "private")
                                //UpdateStatusProductsVariationWCApi(ID.ToString(), ID_Liq.ToString(), status_LIQ);
                                //ApiWC.getInstance.UpdateAsyncStatusProductsVariationWCApi(ID.ToString(), ID_Liq.ToString(), status_LIQ);
                                ApiWC.getInstance.runAsyncTask(API.updateStatus, ID, ID_Liq, status_LIQ);


                                string update_status = $"UPDATE dsq_posts SET post_status = 'publish' WHERE  ID IN ({ID}, {ID_General}, {ID_Oferta}, {ID_Liq})";
                                DBConnMysql.ExecQueryUpdate(update_status);
                            }

                        }
                        else
                        {
                            Utils.PrintLog("SyncProductsToWooCommerce_v2", "0", $"No fue posible realizar la sincronización del producto {zAdi_ItemCode}");
                        }

                        Thread.Sleep(1000);
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("RegisterProductToLog_v2", "1", ex.ToString());
            }

            //Utils.PrintLog("SyncProductsToWooCommerce_v2", "0", $"Fin------");
        }

        public void SyncUpdateProductsToWoocommerce_v2()
        {
            try
            {
                string querySelectSAP = $@"SELECT TOP {Utils.RangoRegistros_prod} 
                                        {Utils.parseStringBD(zAdi_SyncItems.zAdi_SyncItemsId)}, 
                                        {Utils.parseStringBD(zAdi_SyncItems.zAdi_ItemCode)}, 
                                        {Utils.parseStringBD(zAdi_SyncItems.zAdi_ItemName)}, 
                                        {Utils.parseStringBD(zAdi_SyncItems.zAdi_StockValue)}, 
                                        {Utils.parseStringBD(zAdi_SyncItems.zAdi_Price)}, 
                                        {Utils.parseStringBD("zAdi_Currency")}, 
                                        {Utils.parseStringBD("zAdi_Brand")}, 
                                        {Utils.parseStringBD("zAdi_CodeSAT")},
                                        {Utils.parseStringBD("zAdi_Description")},
                                        {Utils.parseStringBD("zAdi_Categories")},
                                        {Utils.parseStringBD("zAdi_UserText")},
                                        {Utils.parseStringBD("zAdi_IdCommerce")},
                                        {Utils.parseStringBD("zAdi_IdCommerceGEN")},
                                        {Utils.parseStringBD("zAdi_IdCommerceOFER")},
                                        {Utils.parseStringBD("zAdi_IdCommerceLIQ")},
                                        {Utils.parseStringBD("zAdi_PriceOFER")},
                                        {Utils.parseStringBD("zAdi_PriceLIQ")}";
                querySelectSAP += $" FROM {Utils.parseStringBD(DBConn.zAdi_SyncItems)}";
                querySelectSAP += $" WHERE {Utils.parseStringBD(zAdi_SyncItems.zAdi_Action)} = 'UPDATE' AND {Utils.parseStringBD(zAdi_SyncItems.zAdi_FlagSend)} = FALSE AND {Utils.parseStringBD("zAdi_FlagSendInventory")} IS NULL";
                //querySelectSAP += $" AND {Utils.parseStringBD(zAdi_SyncItems.zAdi_ItemCode)} IN ('0535-001', '0536-001')";
                //Utils.PrintLog("SyncUpdateProductsToWoocommerce_v2", "0", $"querySelectSAP update: {querySelectSAP}");
                DataTable tbl_zAdi_syncItems = DBConn.ExecQuery(querySelectSAP, DBConn.ConectionDB.Bitacoras);
                if (tbl_zAdi_syncItems != null && tbl_zAdi_syncItems.Rows != null && tbl_zAdi_syncItems.Rows.Count > 0)
                {
                    #region Delete caché on table dsq_options

                    int optionId = 0;

                    string query_dsq_option = $"SELECT option_id FROM dsq_options WHERE option_name LIKE '%_transient_atmmi_product_multi_prices%'; ";
                    //using (StreamWriter writer = new StreamWriter(path, true))
                    //{
                    //    writer.WriteLine(string.Format($"query_dsq_option cache: {query_dsq_option} \n"));
                    //    writer.Close();
                    //}
                    DataTable tbl_dsq_option = DBConnMysql.ExecQuery(query_dsq_option);

                    if (tbl_dsq_option != null && tbl_dsq_option.Rows != null && tbl_dsq_option.Rows.Count > 0)
                    {
                        string delete_dsq_option = $"DELETE FROM dsq_options WHERE option_id = {tbl_dsq_option.Rows[0].ItemArray[0]}";
                        //using (StreamWriter writer = new StreamWriter(path, true))
                        //{
                        //    writer.WriteLine(string.Format($"delete_dsq_option: {delete_dsq_option} \n"));
                        //    writer.Close();
                        //}
                        DBConnMysql.ExecQueryDelete(delete_dsq_option);
                    }


                    #endregion

                    foreach (DataRow rowSyncItem in tbl_zAdi_syncItems.Rows)
                    {
                        string zAdi_SyncItemsId = rowSyncItem["zAdi_SyncItemsId"] != null && !string.IsNullOrEmpty(rowSyncItem["zAdi_SyncItemsId"].ToString()) ? rowSyncItem["zAdi_SyncItemsId"].ToString() : "";
                        string zAdi_ItemCode = rowSyncItem["zAdi_ItemCode"] != null && !string.IsNullOrEmpty(rowSyncItem["zAdi_ItemCode"].ToString()) ? rowSyncItem["zAdi_ItemCode"].ToString() : "";
                        string zAdi_ItemName = rowSyncItem["zAdi_ItemName"] != null && !string.IsNullOrEmpty(rowSyncItem["zAdi_ItemName"].ToString()) ? rowSyncItem["zAdi_ItemName"].ToString() : "";
                        zAdi_ItemName = zAdi_ItemName.Replace("'", "");
                        double zAdi_Price = rowSyncItem["zAdi_Price"] != null && !string.IsNullOrEmpty(rowSyncItem["zAdi_Price"].ToString()) ? Convert.ToDouble(rowSyncItem["zAdi_Price"].ToString()) : 0;
                        string zAdi_Currency = rowSyncItem["zAdi_Currency"] != null && !string.IsNullOrEmpty(rowSyncItem["zAdi_Currency"].ToString()) ? rowSyncItem["zAdi_Currency"].ToString() : "";
                        string zAdi_Brand = rowSyncItem["zAdi_Brand"] != null && !string.IsNullOrEmpty(rowSyncItem["zAdi_Brand"].ToString()) ? rowSyncItem["zAdi_Brand"].ToString() : "";
                        string zAdi_CodeSAT = rowSyncItem["zAdi_CodeSAT"] != null && !string.IsNullOrEmpty(rowSyncItem["zAdi_CodeSAT"].ToString()) ? rowSyncItem["zAdi_CodeSAT"].ToString() : "";
                        string zAdi_Categories = rowSyncItem["zAdi_Categories"] != null && !string.IsNullOrEmpty(rowSyncItem["zAdi_Categories"].ToString()) ? rowSyncItem["zAdi_Categories"].ToString() : "";
                        string zAdi_IdCommerce = rowSyncItem["zAdi_IdCommerce"] != null && !string.IsNullOrEmpty(rowSyncItem["zAdi_IdCommerce"].ToString()) ? rowSyncItem["zAdi_IdCommerce"].ToString() : "0";
                        string zAdi_IdCommerceGEN = rowSyncItem["zAdi_IdCommerceGEN"] != null && !string.IsNullOrEmpty(rowSyncItem["zAdi_IdCommerceGEN"].ToString()) ? rowSyncItem["zAdi_IdCommerceGEN"].ToString() : "0";
                        string zAdi_IdCommerceOFER = rowSyncItem["zAdi_IdCommerceOFER"] != null && !string.IsNullOrEmpty(rowSyncItem["zAdi_IdCommerceOFER"].ToString()) ? rowSyncItem["zAdi_IdCommerceOFER"].ToString() : "0";
                        string zAdi_IdCommerceLIQ = rowSyncItem["zAdi_IdCommerceLIQ"] != null && !string.IsNullOrEmpty(rowSyncItem["zAdi_IdCommerceLIQ"].ToString()) ? rowSyncItem["zAdi_IdCommerceLIQ"].ToString() : "0";
                        double zAdi_PriceOFER = rowSyncItem["zAdi_PriceOFER"] != null && !string.IsNullOrEmpty(rowSyncItem["zAdi_PriceOFER"].ToString()) ? Convert.ToDouble(rowSyncItem["zAdi_PriceOFER"].ToString()) : -1;
                        double zAdi_PriceLIQ = rowSyncItem["zAdi_PriceLIQ"] != null && !string.IsNullOrEmpty(rowSyncItem["zAdi_PriceLIQ"].ToString()) ? Convert.ToDouble(rowSyncItem["zAdi_PriceLIQ"].ToString()) : -1;

                        zAdi_ItemCode = string.Join("", zAdi_ItemCode.Split('\''));
                        zAdi_ItemCode = zAdi_ItemCode.Replace("'", "");
                        zAdi_ItemCode = zAdi_ItemCode.Trim(new char[] { '\\', ' ' });

                        zAdi_ItemName = string.Join("", zAdi_ItemName.Split('\''));
                        zAdi_ItemName = zAdi_ItemName.Replace("'", "");
                        zAdi_ItemName = zAdi_ItemName.Trim(new char[] { '\\' });

                        zAdi_Brand = string.Join("", zAdi_Brand.Split('\''));
                        zAdi_Brand = zAdi_Brand.Replace("'", "");
                        zAdi_Brand = zAdi_Brand.Trim(new char[] { '\\' });

                        zAdi_Categories = string.Join("", zAdi_Categories.Split('\''));
                        zAdi_Categories = zAdi_Categories.Replace("'", "");
                        zAdi_Categories = zAdi_Categories.Trim(new char[] { '\\' });

                        //Utils.PrintLog("SyncUpdateProductsToWoocommerce_v2", "1", $"fin obtencion datos");

                        if (!string.IsNullOrEmpty(zAdi_IdCommerce) && zAdi_IdCommerce != "0")
                        {
                            if ((string.IsNullOrEmpty(zAdi_IdCommerceGEN) || zAdi_IdCommerceGEN == "0") || (string.IsNullOrEmpty(zAdi_IdCommerceOFER) || zAdi_IdCommerceOFER == "0") || (string.IsNullOrEmpty(zAdi_IdCommerceLIQ) || zAdi_IdCommerceLIQ == "0"))
                            {
                                string select_ids = $"SELECT TOP 1 {Utils.parseStringBD("zAdi_IdCommerceGEN")}, {Utils.parseStringBD("zAdi_IdCommerceOFER")}, {Utils.parseStringBD("zAdi_IdCommerceLIQ")}";
                                select_ids += $" FROM {Utils.parseStringBD("zAdi_SyncItems")} WHERE {Utils.parseStringBD("zAdi_ItemCode")} = '{zAdi_ItemCode}' AND {Utils.parseStringBD("zAdi_Action")} = 'INSERT' AND {Utils.parseStringBD("zAdi_FlagSend")} = TRUE";
                                DataTable tbl = DBConn.ExecQuery(select_ids, DBConn.ConectionDB.Bitacoras);
                                if (tbl != null && tbl.Rows != null && tbl.Rows.Count > 0)
                                {
                                    zAdi_IdCommerceGEN = tbl.Rows[0]["zAdi_IdCommerceGEN"] != null && !string.IsNullOrEmpty(tbl.Rows[0]["zAdi_IdCommerceGEN"].ToString()) ? tbl.Rows[0]["zAdi_IdCommerceGEN"].ToString() : "";
                                    zAdi_IdCommerceOFER = tbl.Rows[0]["zAdi_IdCommerceOFER"] != null && !string.IsNullOrEmpty(tbl.Rows[0]["zAdi_IdCommerceOFER"].ToString()) ? tbl.Rows[0]["zAdi_IdCommerceOFER"].ToString() : "";
                                    zAdi_IdCommerceLIQ = tbl.Rows[0]["zAdi_IdCommerceLIQ"] != null && !string.IsNullOrEmpty(tbl.Rows[0]["zAdi_IdCommerceLIQ"].ToString()) ? tbl.Rows[0]["zAdi_IdCommerceLIQ"].ToString() : "";

                                    #region Update FROM DB SAP HANA
                                    string update_zAdi_SyncItems = $"UPDATE {Utils.parseStringBD(DBConn.zAdi_SyncItems)}";
                                    update_zAdi_SyncItems += $" SET {Utils.parseStringBD("zAdi_IdCommerceGEN")} = {zAdi_IdCommerceGEN}, {Utils.parseStringBD("zAdi_IdCommerceOFER")} = {zAdi_IdCommerceOFER}, {Utils.parseStringBD("zAdi_IdCommerceLIQ")} = {zAdi_IdCommerceLIQ}";
                                    update_zAdi_SyncItems += $" WHERE {Utils.parseStringBD(zAdi_SyncItems.zAdi_SyncItemsId)} = {zAdi_SyncItemsId}";
                                    //Utils.PrintLog("SyncUpdateProductsToWoocommerce_v2", "0", $"update_zAdi_SyncItems: {update_zAdi_SyncItems}");
                                    //Utils.PrintLog("SyncUpdateProductsToWoocommerce_v2", "1", $" update 1 if: {update_zAdi_SyncItems}");
                                    DBConn.ExecQueryUpdate(update_zAdi_SyncItems, DBConn.ConectionDB.Bitacoras);
                                    #endregion
                                }
                                else
                                {
                                    #region Update FROM DB SAP HANA
                                    string update_zAdi_SyncItems = $"UPDATE {Utils.parseStringBD(DBConn.zAdi_SyncItems)}";
                                    update_zAdi_SyncItems += $" SET {Utils.parseStringBD(zAdi_SyncItems.zAdi_FlagSend)} = TRUE, {Utils.parseStringBD(zAdi_SyncItems.zAdi_DateSend)} = NOW(), {Utils.parseStringBD(zAdi_SyncItems.zAdi_DesMessage)} = 'El producto con código {rowSyncItem.ItemArray[1].ToString()} se ha sincronizado con éxito.'";
                                    update_zAdi_SyncItems += $" WHERE {Utils.parseStringBD(zAdi_SyncItems.zAdi_SyncItemsId)} = {zAdi_SyncItemsId}";
                                    //Utils.PrintLog("SyncUpdateProductsToWoocommerce_v2", "1", $" update 1 else: {update_zAdi_SyncItems}");
                                    DBConn.ExecQueryUpdate(update_zAdi_SyncItems, DBConn.ConectionDB.Bitacoras);
                                    #endregion
                                }
                                continue;
                            }


                            //implementar lo de quitar caracteres en esta consulta
                            #region inventarios
                            int dispGDL = 0, dispCDMX = 0, dispMTY = 0, dispLEON = 0, dispLIQ = 0, dispOFER = 0, unidadesCam = 0, dispGen = 0, dispMaster = 0;

                            string query = $@"SELECT {Utils.parseStringBD("WhsCode")}, {Utils.parseStringBD("OnHand")}, {Utils.parseStringBD("IsCommited")}, {Utils.parseStringBD("OnOrder")}";
                            query += $" FROM {Utils.parseStringBD("OITW")}";
                            query += $" WHERE TRIM(replace(replace({Utils.parseStringBD("ItemCode")}, '''',''),'\\', '')) = '{zAdi_ItemCode}'";
                            query += $" AND ( {returnWhsSelect(5)} )"; // suma total de pedido.

                            DataTable tbl_total_pedido = DBConn.ExecQuery(query);
                            if (tbl_total_pedido != null && tbl_total_pedido.Rows != null && tbl_total_pedido.Rows.Count > 0)
                            {
                                /*
                                 * 01 - GDL
                                 * 02 - CMDX
                                 * 03 - MTY
                                 * 04 - LEON
                                 * 05 - LIQ
                                 * 13 - OFER
                                 * 
                                 *  OnHand - IsCommited + OnOrder = Disp
                                 */
                                foreach (DataRow row_inv in tbl_total_pedido.Rows)
                                {
                                    int OnHand = row_inv["OnHand"] != null && !string.IsNullOrEmpty(row_inv["OnHand"].ToString()) ? Convert.ToInt32(double.Parse(row_inv["OnHand"].ToString())) : 0;
                                    int IsCommited = row_inv["IsCommited"] != null && !string.IsNullOrEmpty(row_inv["IsCommited"].ToString()) ? Convert.ToInt32(double.Parse(row_inv["IsCommited"].ToString())) : 0;
                                    int OnOrder = row_inv["OnOrder"] != null && !string.IsNullOrEmpty(row_inv["OnOrder"].ToString()) ? Convert.ToInt32(double.Parse(row_inv["OnOrder"].ToString())) : 0;
                                    unidadesCam += OnOrder; //unidades en ccamino

                                    switch (row_inv["WhsCode"].ToString())
                                    {
                                        case "01":
                                            dispGDL = OnHand - IsCommited + OnOrder;
                                            break;
                                        case "02":
                                            dispCDMX = OnHand - IsCommited + OnOrder;
                                            break;
                                        case "03":
                                            dispMTY = OnHand - IsCommited + OnOrder;
                                            break;
                                        case "04":
                                            dispLEON = OnHand - IsCommited + OnOrder;
                                            break;
                                        case "05":
                                            dispLIQ = OnHand - IsCommited + OnOrder;
                                            break;
                                        case "13":
                                            dispOFER = OnHand - IsCommited + OnOrder;
                                            break;
                                    }
                                }



                                if (dispCDMX < 0) dispCDMX = 0;
                                if (dispGDL < 0) dispGDL = 0;
                                if (dispLEON < 0) dispLEON = 0;
                                if (dispLIQ < 0) dispLIQ = 0;
                                if (dispMTY < 0) dispMTY = 0;
                                if (dispOFER < 0) dispOFER = 0;

                                dispGen = (dispCDMX + dispGDL + dispLEON + dispMTY);
                                dispMaster = (dispCDMX + dispGDL + dispLEON + dispMTY + dispLIQ + dispOFER);

                                if (dispGen < 0) dispGen = 0;
                                if (dispMaster < 0) dispMaster = 0;
                            }
                            #endregion

                            double minPrice = zAdi_Price;
                            if (zAdi_PriceLIQ > 0 && zAdi_PriceOFER > 0)
                                minPrice = zAdi_PriceLIQ < zAdi_PriceOFER ? zAdi_PriceLIQ : zAdi_PriceOFER;
                            else
                            {
                                if (zAdi_PriceLIQ > 0)
                                    minPrice = zAdi_PriceLIQ;
                                else if (zAdi_PriceOFER > 0)
                                    minPrice = zAdi_PriceOFER;
                            }
                            //Utils.PrintLog("SyncUpdateProductsToWoocommerce_v2", "1", $" update 1 fin obtencion inventarios");


                            string update = $"UPDATE dsq_posts SET post_title = '{zAdi_ItemName}' WHERE ID = {zAdi_IdCommerce}; \n"; //table dsq_post
                            update += $"UPDATE dsq_wc_product_meta_lookup SET sku = '{zAdi_ItemCode}', max_price = {(zAdi_Price > 0 ? zAdi_Price.ToString() : "NULL")}, min_price = {(minPrice > 0 ? minPrice.ToString() : "NULL")}, stock_quantity = {dispGen} WHERE product_id = {zAdi_IdCommerce}; \n"; //table dsq_wc_product_meta_lookup
                            update += $"UPDATE dsq_postmeta SET meta_value = '{zAdi_ItemCode}' WHERE post_id = {zAdi_IdCommerce} AND meta_key = '_sku'; \n"; //table dsq_postmeta
                            update += $"UPDATE dsq_postmeta SET meta_value = '{dispMaster}' WHERE post_id = {zAdi_IdCommerce} AND meta_key = '_stock'; \n"; //table dsq_postmeta
                            update += $"UPDATE dsq_postmeta SET meta_value = '{zAdi_ItemCode}' WHERE post_id = {zAdi_IdCommerce} AND meta_key = 'modelo'; \n"; //table dsq_postmeta
                            update += $"UPDATE dsq_postmeta SET meta_value = '{zAdi_CodeSAT}' WHERE post_id = {zAdi_IdCommerce} AND meta_key = 'codigo_sat'; \n"; //table dsq_postmeta
                            update += $"UPDATE dsq_postmeta SET meta_value = '{zAdi_Brand}' WHERE post_id = {zAdi_IdCommerce} AND meta_key = 'marca'; \n"; //table dsq_postmeta
                            update += $"UPDATE dsq_postmeta SET meta_value = '{unidadesCam}' WHERE post_id = {zAdi_IdCommerce} AND meta_key = 'unidades_camino'; \n"; //table dsq_postmeta
                            update += $"UPDATE dsq_postmeta SET meta_value = '{dispGDL}' WHERE post_id = {zAdi_IdCommerce} AND meta_key = 'unidades_gdl'; \n"; //table dsq_postmeta
                            update += $"UPDATE dsq_postmeta SET meta_value = '{dispCDMX}' WHERE post_id = {zAdi_IdCommerce} AND meta_key = 'unidades_cdmx'; \n"; //table dsq_postmeta
                            update += $"UPDATE dsq_postmeta SET meta_value = '{dispMTY}' WHERE post_id = {zAdi_IdCommerce} AND meta_key = 'unidades_mty'; \n"; //table dsq_postmeta
                            update += $"UPDATE dsq_postmeta SET meta_value = '{dispLEON}' WHERE post_id = {zAdi_IdCommerce} AND meta_key = 'unidades_leon'; \n"; //table dsq_postmeta
                            update += $"UPDATE dsq_postmeta SET meta_value = '{(zAdi_Price > 0 ? zAdi_Price.ToString() : "")}' WHERE post_id = {zAdi_IdCommerce} AND meta_key = '_price'; \n"; //table dsq_postmeta 

                            #region Categories
                            if (!String.IsNullOrEmpty(zAdi_Categories))
                                SyncCategoriesToWooCommerce(zAdi_Categories, Convert.ToInt32(zAdi_IdCommerce), Utils.MASTER, Utils.UPDATE);
                            #endregion
                            //Utils.PrintLog("SyncUpdateProductsToWoocommerce_v2", "0", $"update master: " + update);

                            DBConnMysql.ExecQueryUpdate(update);

                            //#region Tags
                            //SynctagsToWooCommerce(UserText, Convert.ToInt32(zAdi_IdCommerce));
                            //#endregion

                            #region VARIANTE GENERAL

                            if (!String.IsNullOrEmpty(zAdi_IdCommerceGEN) && zAdi_IdCommerceGEN != "0")
                            {
                                update = string.Empty;
                                update += $"UPDATE dsq_posts SET post_title = '{zAdi_ItemName}' WHERE ID = {zAdi_IdCommerceGEN}; \n"; //table dsq_post
                                update += $"UPDATE dsq_wc_product_meta_lookup SET sku = '{zAdi_ItemCode}', max_price = {(zAdi_Price > 0 ? zAdi_Price.ToString() : "NULL")}, min_price = {(zAdi_Price > 0 ? zAdi_Price.ToString() : "NULL")}, stock_quantity = {dispGen} WHERE product_id = {zAdi_IdCommerceGEN}; \n"; //table dsq_wc_product_meta_lookup
                                update += $"UPDATE dsq_postmeta SET meta_value = '{dispGen}' WHERE post_id = {zAdi_IdCommerceGEN} AND meta_key = '_stock'; \n"; //table dsq_postmeta
                                update += $"UPDATE dsq_postmeta SET meta_value = '{(zAdi_Price > 0 ? zAdi_Price.ToString() : "")}' WHERE post_id = {zAdi_IdCommerceGEN} AND meta_key = '_regular_price'; \n"; //table dsq_postmeta
                                update += $"UPDATE dsq_postmeta SET meta_value = '{(zAdi_Price > 0 ? zAdi_Price.ToString() : "")}' WHERE post_id = {zAdi_IdCommerceGEN} AND meta_key = '_price'; \n"; //table dsq_postmeta

                                //Utils.PrintLog("SyncUpdateProductsToWoocommerce_v2", "0", $"update gen: " + update);
                                DBConnMysql.ExecQueryUpdate(update);
                            }

                            #endregion

                            #region VARIANTE OFERTA

                            if (!String.IsNullOrEmpty(zAdi_IdCommerceOFER) && zAdi_IdCommerceOFER != "0")
                            {
                                //SyncCategoriesToWooCommerce("", Convert.ToInt32(zAdi_IdCommerceOFER), Utils.OFERTA, Utils.INSERT);

                                update = string.Empty;

                                //SyncCategoriesToWooCommerce(zAdi_Categories, Convert.ToInt32(zAdi_IdCommerceOFER), Utils.OFERTA, Utils.INSERT);
                                update += $"\n UPDATE dsq_posts SET post_title = '{zAdi_ItemName}' WHERE ID = {zAdi_IdCommerceOFER}; \n"; //table dsq_post
                                update += $"UPDATE dsq_postmeta SET meta_value = '{dispOFER}' WHERE post_id = {zAdi_IdCommerceOFER} AND meta_key = '_stock'; \n"; //table dsq_postmeta
                                update += $"UPDATE dsq_postmeta SET meta_value = '{(zAdi_Price > 0 ? zAdi_Price.ToString() : "")}' WHERE post_id = {zAdi_IdCommerceOFER} AND meta_key = '_regular_price'; \n"; //table dsq_postmeta
                                if (zAdi_PriceOFER > Convert.ToDouble( 0))
                                {
                                    update += $"UPDATE dsq_wc_product_meta_lookup SET sku = '{zAdi_ItemCode}', max_price = {zAdi_PriceOFER}, min_price = {zAdi_PriceOFER}, stock_quantity = {dispOFER} WHERE product_id = {zAdi_IdCommerceOFER}; \n"; //table dsq_wc_product_meta_lookup
                                    update += $"UPDATE dsq_postmeta SET meta_value = '{zAdi_PriceOFER}' WHERE post_id = {zAdi_IdCommerceOFER} AND meta_key = '_sale_price'; \n"; //table dsq_postmeta
                                    update += $"UPDATE dsq_postmeta SET meta_value = '{zAdi_PriceOFER}' WHERE post_id = {zAdi_IdCommerceOFER} AND meta_key = '_price'; \n"; //table dsq_postmeta

                                }
                                else
                                {
                                    update += $"UPDATE dsq_wc_product_meta_lookup SET sku = '{zAdi_ItemCode}', max_price = NULL, min_price = NULL, stock_quantity = {dispOFER} WHERE product_id = {zAdi_IdCommerceOFER}; \n"; //table dsq_wc_product_meta_lookup
                                    update += $"UPDATE dsq_postmeta SET meta_value = '' WHERE post_id = {zAdi_IdCommerceOFER} AND meta_key = '_sale_price'; \n"; //table dsq_postmeta
                                    update += $"UPDATE dsq_postmeta SET meta_value = '' WHERE post_id = {zAdi_IdCommerceOFER} AND meta_key = '_price'; \n"; //table dsq_postmeta
                                }

                                //Utils.PrintLog("SyncUpdateProductsToWoocommerce_v2", "0", $"update ofer: " + update);
                                DBConnMysql.ExecQueryUpdate(update);
                            }

                            #endregion

                            #region VARIANTE LIQUIDACION

                            if (!String.IsNullOrEmpty(zAdi_IdCommerceLIQ) && zAdi_IdCommerceLIQ != "0")
                            {
                                //SyncCategoriesToWooCommerce("", Convert.ToInt32(zAdi_IdCommerceLIQ), Utils.LIQUIDACION, Utils.INSERT);
                                //SyncCategoriesToWooCommerce(zAdi_Categories, Convert.ToInt32(zAdi_IdCommerceLIQ), Utils.LIQUIDACION, Utils.INSERT);

                                update = string.Empty;
                                update += $"\n UPDATE dsq_posts SET post_title = '{zAdi_ItemName}' WHERE ID = {zAdi_IdCommerceLIQ}; \n"; //table dsq_post
                                update += $"UPDATE dsq_postmeta SET meta_value = '{dispLIQ}' WHERE post_id = {zAdi_IdCommerceLIQ} AND meta_key = '_stock'; \n"; //table dsq_postmeta
                                update += $"UPDATE dsq_postmeta SET meta_value = '{(zAdi_Price > 0 ? zAdi_Price.ToString() : "")}' WHERE post_id = {zAdi_IdCommerceLIQ} AND meta_key = '_regular_price'; \n"; //table dsq_postmeta
                                if (zAdi_PriceLIQ > Convert.ToDouble(0))
                                {
                                    update += $"UPDATE dsq_wc_product_meta_lookup SET sku = '{zAdi_ItemCode}', max_price = {zAdi_PriceLIQ}, min_price = {zAdi_PriceLIQ}, stock_quantity = {dispLIQ} WHERE product_id = {zAdi_IdCommerceLIQ}; \n"; //table dsq_wc_product_meta_lookup
                                    update += $"UPDATE dsq_postmeta SET meta_value = '{zAdi_PriceLIQ}' WHERE post_id = {zAdi_IdCommerceLIQ} AND meta_key = '_sale_price'; \n"; //table dsq_postmeta
                                    update += $"UPDATE dsq_postmeta SET meta_value = '{zAdi_PriceLIQ}' WHERE post_id = {zAdi_IdCommerceLIQ} AND meta_key = '_price'; \n"; //table dsq_postmeta
                                }
                                else
                                {
                                    update += $"UPDATE dsq_wc_product_meta_lookup SET sku = '{zAdi_ItemCode}', max_price = NULL, min_price = NULL, stock_quantity = {dispLIQ} WHERE product_id = {zAdi_IdCommerceLIQ}; \n"; //table dsq_wc_product_meta_lookup
                                    update += $"UPDATE dsq_postmeta SET meta_value = '' WHERE post_id = {zAdi_IdCommerceLIQ} AND meta_key = '_sale_price'; \n"; //table dsq_postmeta
                                    update += $"UPDATE dsq_postmeta SET meta_value = '' WHERE post_id = {zAdi_IdCommerceLIQ} AND meta_key = '_price'; \n"; //table dsq_postmeta
                                }

                                //Utils.PrintLog("SyncUpdateProductsToWoocommerce_v2", "0", $"update liq: " + update);
                                DBConnMysql.ExecQueryUpdate(update);
                            }

                            #endregion

                            try
                            {
                                #region Update FROM DB SAP HANA
                                string update_zAdi_SyncItems = $"UPDATE {Utils.parseStringBD(DBConn.zAdi_SyncItems)}";
                                update_zAdi_SyncItems += $" SET {Utils.parseStringBD(zAdi_SyncItems.zAdi_FlagSend)} = TRUE, {Utils.parseStringBD(zAdi_SyncItems.zAdi_DateSend)} = NOW(), {Utils.parseStringBD(zAdi_SyncItems.zAdi_DesMessage)} = 'El producto con código {rowSyncItem.ItemArray[1].ToString()} se ha sincronizado con éxito.'";
                                update_zAdi_SyncItems += $" WHERE {Utils.parseStringBD(zAdi_SyncItems.zAdi_SyncItemsId)} = {zAdi_SyncItemsId}";

                                //Utils.PrintLog("SyncUpdateProductsToWoocommerce_v2", "1", $"update_zAdi_SyncItems: {update_zAdi_SyncItems}");

                                DBConn.ExecQueryUpdate(update_zAdi_SyncItems, DBConn.ConectionDB.Bitacoras);
                                #endregion

                                #region PricesAsync

                                ApiWC.getInstance.runAsyncTask(API.UpdatePrice, int.Parse(zAdi_IdCommerce), int.Parse(zAdi_IdCommerceOFER), (zAdi_PriceOFER + 0.1).ToString());
                                ApiWC.getInstance.runAsyncTask(API.UpdatePrice, int.Parse(zAdi_IdCommerce), int.Parse(zAdi_IdCommerceOFER), (zAdi_PriceOFER > 0 ? (zAdi_PriceOFER).ToString() : ""));

                                ApiWC.getInstance.runAsyncTask(API.UpdatePrice, int.Parse(zAdi_IdCommerce), int.Parse(zAdi_IdCommerceLIQ), (zAdi_PriceLIQ + 0.1).ToString());
                                ApiWC.getInstance.runAsyncTask(API.UpdatePrice, int.Parse(zAdi_IdCommerce), int.Parse(zAdi_IdCommerceLIQ), (zAdi_PriceLIQ > 0 ? (zAdi_PriceLIQ).ToString() : ""));
                                #endregion

                                string status_OFER = "publish";
                                string status_LIQ = "publish";

                                ApiWC.getInstance.runAsyncTask(API.updateStatus, int.Parse(zAdi_IdCommerce), int.Parse(zAdi_IdCommerceOFER), status_OFER);
                                ApiWC.getInstance.runAsyncTask(API.updateStatus, int.Parse(zAdi_IdCommerce), int.Parse(zAdi_IdCommerceLIQ), status_LIQ);

                                ApiWC.getInstance.runAsyncTask(API.UpdateDescription, int.Parse(zAdi_IdCommerce), int.Parse(zAdi_IdCommerce), ".");
                                ApiWC.getInstance.runAsyncTask(API.UpdateDescription, int.Parse(zAdi_IdCommerce), int.Parse(zAdi_IdCommerce), zAdi_ItemName);

                                string update_status = $"UPDATE dsq_posts SET post_status = 'publish' WHERE  ID IN ({zAdi_IdCommerce}, {zAdi_IdCommerceGEN}, {zAdi_IdCommerceOFER}, {zAdi_IdCommerceLIQ})";
                                DBConnMysql.ExecQueryUpdate(update_status);
                                //}

                            }
                            catch (Exception ex)
                            {
                                Utils.PrintLog("SyncUpdateProductsToWoocommerce_v2", "2", ex.ToString());
                            }
                        }
                        else
                        {
                            #region Update FROM DB SAP HANA
                            string update_zAdi_SyncItems = $"UPDATE {Utils.parseStringBD(DBConn.zAdi_SyncItems)}";
                            update_zAdi_SyncItems += $" SET {Utils.parseStringBD(zAdi_SyncItems.zAdi_FlagSend)} = TRUE, {Utils.parseStringBD(zAdi_SyncItems.zAdi_DateSend)} = NOW(), {Utils.parseStringBD(zAdi_SyncItems.zAdi_DesMessage)} = 'El producto con código {rowSyncItem.ItemArray[1].ToString()} se ha sincronizado con éxito.'";
                            update_zAdi_SyncItems += $" WHERE {Utils.parseStringBD(zAdi_SyncItems.zAdi_SyncItemsId)} = {zAdi_SyncItemsId}";

                            //Utils.PrintLog("SyncUpdateProductsToWoocommerce_v2", "1", $"update_zAdi_SyncItems ultimo: {update_zAdi_SyncItems}");

                            DBConn.ExecQueryUpdate(update_zAdi_SyncItems, DBConn.ConectionDB.Bitacoras);
                            #endregion
                        }

                        Thread.Sleep(1000);
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("SyncUpdateProductsToWoocommerce_v2", "1", ex.ToString());
            }

            //Utils.PrintLog("querySelectSAP", "0", $"Fin------");
        }

        private void SyncCategoriesToWooCommerce(string categories, int idObjectProduct, string type, string operation)
        {
            //return;
            //Utils.PrintLog("SyncCategoriesToWooCommerce", "", $"categories: {categories}, idObjectProduct: {idObjectProduct}, type:{type}, operation: {operation}");
            try
            {
                switch (type)
                {
                    case Utils.MASTER:
                        string clsCategories = ClearStringCategories(categories);
                        string PruebaCategories = ClearCategoriesToSync(categories);
                        if (operation == Utils.UPDATE)
                        {
                            /*Si es actualizacion de categorias se eliminan las categorias relacionadas con el producto, para volver a agregarlas*/
                            string deleteCateProd = $"DELETE dsq_term_relationships FROM dsq_term_relationships " +
                            $"INNER JOIN dsq_term_taxonomy ON dsq_term_relationships.term_taxonomy_id = dsq_term_taxonomy.term_taxonomy_id " +
                            $"WHERE dsq_term_taxonomy.taxonomy = 'product_cat' " +
                            $"AND dsq_term_relationships.object_id = {idObjectProduct}";
                            bool flagDelete = DBConnMysql.ExecQueryDelete(deleteCateProd);

                        }


                        string[] arrayCat = PruebaCategories.Split(','); // Call Split method
                        List<string> lsCategories = new List<string>(arrayCat); // Use List constructor

                        /*array de categorias limpias*/
                        string[] categSlug = clsCategories.Split(',');
                        List<string> listCategoriesClear = new List<string>(categSlug); // Use List constructor

                        int anteriorParent = 0;
                        string nameParent = "";
                        int contCateg = 0;
                        bool flagNewThree = false;

                        foreach (var categ in lsCategories)
                        {
                            string clearCategSlug = listCategoriesClear[contCateg].ToLower();
                            string existCategory = "";
                            string concatDescription = "";
                            concatDescription = concatDescription == "" ? clearCategSlug : "/" + clearCategSlug;
                            if (contCateg <= 2)
                            {
                                existCategory = $"SELECT * FROM dsq_terms WHERE name = '{categ}'" +
                                    $"AND slug = '{clearCategSlug + "-" + anteriorParent.ToString()}'";
                                flagNewThree = false;
                            }
                            else
                            {
                                if (flagNewThree == true)
                                {
                                    //validacion con padre
                                    existCategory = $"SELECT cat.term_id, cat.name, cat.slug ,tmtax.parent, tmtax.term_taxonomy_id FROM dsq_terms cat" +
                                    $" INNER JOIN dsq_term_taxonomy tmtax ON cat.term_id = tmtax.term_id" +
                                    $" WHERE tmtax.taxonomy = 'product_cat'" +
                                    $" AND tmtax.parent = {anteriorParent}" +
                                    $" AND cat.name = '{categ}'";

                                }
                                else
                                {
                                    existCategory = $"SELECT cat.term_id, cat.name, cat.slug ,tmtax.parent, tmtax.term_taxonomy_id FROM dsq_terms cat" +
                                    $" INNER JOIN dsq_term_taxonomy tmtax ON cat.term_id = tmtax.term_id" +
                                    $" WHERE tmtax.taxonomy = 'product_cat'" +
                                    $" AND tmtax.parent = {anteriorParent}" +
                                    $" AND cat.name = '{categ}'";
                                    flagNewThree = true;
                                }
                            }
                            DataTable dtExistCateg = DBConnMysql.ExecQuery(existCategory);

                            /*Si no existe la categoria se crea*/
                            if (!(dtExistCateg != null && dtExistCateg.Rows != null && dtExistCateg.Rows.Count > 0))
                            {
                                string insertCat = "";
                                //se debe hacer insert de cada categoria y recuperar su id, posteriormente se inserta en la tabla relacional del padre
                                if (contCateg >= 3)
                                {
                                    /*se debe validar si este producto tiene o existe en el mismo nivel pero con diferente padre cambio 03_04_2021*/
                                    insertCat = $"INSERT INTO dsq_terms VALUES (NULL, '{categ}', '{clearCategSlug + "-" + anteriorParent.ToString()}', 0, 0)";
                                    flagNewThree = true;
                                }
                                else
                                {
                                    //insertCat = $"INSERT INTO dsq_terms VALUES (NULL, '{categ}', '{clearCategSlug}', 0, 0)";
                                    insertCat = $"INSERT INTO dsq_terms VALUES (NULL, '{categ}', '{clearCategSlug + "-" + anteriorParent.ToString()}', 0, 0)";
                                    flagNewThree = false;
                                }
                                int insertedCat = DBConnMysql.ExecInsertReturnLastId(insertCat);
                                //SE OBTIENE EL ID DE LA CATEGORIA INSERTADA
                                if (insertedCat > 0)
                                {
                                    string getDataCategory = "";
                                    if (contCateg >= 3)
                                    {
                                        getDataCategory = $"SELECT term_id FROM dsq_terms WHERE slug = '{clearCategSlug + "-" + anteriorParent.ToString()}' and term_id = {insertedCat}";

                                    }
                                    else
                                    {
                                        //getDataCategory = $"SELECT term_id FROM dsq_terms WHERE name = '{categ}'";
                                        getDataCategory = $"SELECT term_id FROM dsq_terms WHERE slug = '{clearCategSlug + "-" + anteriorParent.ToString()}' and term_id = {insertedCat}";

                                    }
                                    DataTable tblCat = DBConnMysql.ExecQuery(getDataCategory);
                                    int TermIdCat = 0;

                                    if (tblCat != null && tblCat.Rows != null && tblCat.Rows.Count > 0)
                                    {
                                        TermIdCat = int.Parse(tblCat.Rows[0].ItemArray[0].ToString());
                                        if (contCateg == 0)
                                        {
                                            anteriorParent = 0;
                                            nameParent = "";

                                        }

                                        /*antes de esto se debe checar si existe*/
                                        string insertRelation = $"INSERT INTO dsq_term_taxonomy VALUES (NULL, {TermIdCat}, 'product_cat','{concatDescription}',{anteriorParent},1)";
                                        bool insertedRelation = DBConnMysql.ExecQueryInsert(insertRelation);

                                        if (insertedRelation)
                                        {
                                            anteriorParent = TermIdCat;
                                            nameParent = clearCategSlug;

                                        }
                                    }

                                    
                                    /*Ahora se va a hacer el INSERT hacia el ligue de producto con categorias*/
                                    string dtTaxonomyCat = $"SELECT term_taxonomy_id FROM dsq_term_taxonomy WHERE term_id = {TermIdCat}";
                                    DataTable resultTxonomy = DBConnMysql.ExecQuery(dtTaxonomyCat);
                                    if (resultTxonomy != null && resultTxonomy.Rows != null && resultTxonomy.Rows.Count > 0)
                                    {
                                        int termTaxonomyId = int.Parse(resultTxonomy.Rows[0].ItemArray[0].ToString());
                                        string insert_dsq_term_relationships = $"INSERT INTO dsq_term_relationships VALUES ({idObjectProduct}, {termTaxonomyId}, {0});\n";
                                        DBConnMysql.ExecQuery(insert_dsq_term_relationships);

                                        string select_terms = $"SELECT name FROM dsq_terms WHERE term_id = {TermIdCat}";
                                        DataTable tbl = DBConnMysql.ExecQuery(select_terms);
                                        if (tbl != null && tbl.Rows != null && tbl.Rows.Count > 0)
                                        {
                                            string name = tbl.Rows[0]["name"].ToString();

                                            //string update_term = $"UPDATE dsq_terms SET name = '{name}.' WHERE term_id = {TermIdCat};\n";
                                            //update_term += $"UPDATE dsq_terms SET name = '{name}' WHERE term_id = {TermIdCat};";


                                            //UpdateCategoriesWCApi(TermIdCat, name);
                                            //ApiWC.getInstance.UpdateAsyncCategoriesWCApi(TermIdCat, name);
                                            ApiWC.getInstance.runAsyncTask(API.UpdateCategorie, 0, TermIdCat, name);

                                            //DBConn.ExecQueryUpdate(update_term);
                                        }

                                    }
                                }
                            }
                            /*Si existe la categoria se procede a hacer validaciones*/
                            else
                            {
                                int categoryId = 0;
                                if (contCateg > 0 && contCateg <= 2)
                                {
                                    string validateParentLevelTwo = $"SELECT cat.term_id, cat.name, cat.slug ,tmtax.parent, tmtax.term_taxonomy_id FROM dsq_terms cat" +
                                    $" INNER JOIN dsq_term_taxonomy tmtax ON cat.term_id = tmtax.term_id" +
                                    $" WHERE tmtax.taxonomy = 'product_cat'" +
                                    $" AND tmtax.parent = {anteriorParent}" +
                                    $" AND cat.name = '{categ}'";
                                    //Utils.PrintLog("cat", "validateParentLevelTwo", validateParentLevelTwo);
                                    DataTable dtValidateParentLevelTwo = DBConnMysql.ExecQuery(validateParentLevelTwo);
                                    if (dtValidateParentLevelTwo.Rows.Count == 0 || dtValidateParentLevelTwo.Rows == null || dtValidateParentLevelTwo == null)
                                    {
                                        string addCategoryDiffParent = $"INSERT INTO dsq_terms VALUES (NULL, '{categ}', '{clearCategSlug + "-" + anteriorParent.ToString()}', 0, 0)";

                                        categoryId = DBConnMysql.ExecInsertReturnLastId(addCategoryDiffParent);
                                    }
                                    else
                                    {
                                        categoryId = int.Parse(dtValidateParentLevelTwo.Rows[0].ItemArray[0].ToString());
                                    }
                                }
                                else
                                {
                                    categoryId = int.Parse(dtExistCateg.Rows[0].ItemArray[0].ToString());
                                }
                                /*Se verifica que la categoria tenga relacion o exista en la tabla de relaciones
                                 ACT 31_03_2021 ----> Se debe validar qué nivel es,  en la tabla de relaciones padre e hijo., */
                                string existsRelationCat = $"SELECT dsq_term_taxonomy.term_taxonomy_id,dsq_terms.term_id,dsq_terms.slug FROM dsq_term_taxonomy" +
                                $" INNER JOIN dsq_terms on dsq_terms.term_id = dsq_term_taxonomy.term_id" +
                                $" WHERE dsq_term_taxonomy.term_id = {categoryId}" +
                                $" AND dsq_term_taxonomy.taxonomy = 'product_cat'";

                                //$"SELECT term_taxonomy_id,term_id,description FROM dsq_term_taxonomy WHERE term_id = {categoryId}";
                                DataTable existRelation = DBConnMysql.ExecQuery(existsRelationCat);

                                if (existRelation != null && existRelation.Rows != null && existRelation.Rows.Count > 0)
                                {
                                    /*La categoria existe en las tablas de relaciones por lo que se debe ahora checar si esta categoria tiene relacion con el producto 
                                     si no tiene relacion con el prodcuto pero ya existe en el sistema de wocommerce pues solo se debe hacer el insert hacia la tabla 
                                     de relaciones - producto*/
                                    int termTaxonomyId = int.Parse(existRelation.Rows[0].ItemArray[0].ToString());
                                    anteriorParent = int.Parse(existRelation.Rows[0].ItemArray[1].ToString());
                                    nameParent = contCateg > 0 ? listCategoriesClear[(contCateg - 1)] + "-" + clearCategSlug : "";

                                    string existRelationsProduct = $"SELECT * FROM dsq_term_relationships WHERE object_id = {idObjectProduct} AND term_taxonomy_id = {termTaxonomyId}";

                                    DataTable dtExistRelationProduct = DBConnMysql.ExecQuery(existRelationsProduct);
                                    if (!(dtExistRelationProduct != null && dtExistRelationProduct.Rows != null && dtExistRelationProduct.Rows.Count > 0))
                                    {
                                        string insert_dsq_term_relationships = $"INSERT INTO dsq_term_relationships VALUES ({idObjectProduct}, {termTaxonomyId}, {0});\n";

                                        bool insertdsq = DBConnMysql.ExecQueryInsert(insert_dsq_term_relationships);

                                        string select_terms = $"SELECT name FROM dsq_terms WHERE term_id = {categoryId}";

                                        DataTable tbl = DBConnMysql.ExecQuery(select_terms);
                                        if (tbl != null && tbl.Rows != null && tbl.Rows.Count > 0)
                                        {
                                            string name = tbl.Rows[0]["name"].ToString();

                                            //string update_term = $"UPDATE dsq_terms SET name = '{name}.' WHERE term_id = {categoryId};\n";
                                            //update_term += $"UPDATE dsq_terms SET name = '{name}' WHERE term_id = {categoryId};";
                                            //DBConn.ExecQueryUpdate(update_term);
                                            //ApiWC.getInstance.UpdateAsyncCategoriesWCApi(categoryId, name);
                                            ApiWC.getInstance.runAsyncTask(API.UpdateCategorie, 0, categoryId, name);
                                            //UpdateCategoriesWCApi(categoryId, name);
                                        }
                                    }

                                }
                                else
                                {
                                    /*quiere decir que la categoria existe en la tabla de catalogo pero no existe en la tabla de relaciones entre parents por lo que debe crearse 
                                     * el registro y posterior se recuperar el objectidtaxonomy para su proxima insercion*/

                                    if (contCateg == 0)
                                    {
                                        anteriorParent = 0;
                                        nameParent = "";

                                    }
                                    /*antes de esto se debe checar si existe*/
                                    string insertRelation = $"INSERT INTO dsq_term_taxonomy VALUES (NULL, {categoryId}, 'product_cat','{concatDescription}',{anteriorParent},1)";

                                    bool insertedRelation = DBConnMysql.ExecQueryInsert(insertRelation);

                                    if (insertedRelation)
                                    {
                                        anteriorParent = categoryId;
                                        nameParent = clearCategSlug;
                                    }
                                    /*Ahora se va a hacer el INSERT hacia el ligue de producto con categorias*/
                                    string dtTaxonomyCat = $"SELECT term_taxonomy_id FROM dsq_term_taxonomy WHERE term_id = {categoryId}";

                                    DataTable resultTxonomy = DBConnMysql.ExecQuery(dtTaxonomyCat);
                                    if (resultTxonomy != null && resultTxonomy.Rows != null && resultTxonomy.Rows.Count > 0)
                                    {
                                        int termTaxonomyId = int.Parse(resultTxonomy.Rows[0].ItemArray[0].ToString());
                                        string insert_dsq_term_relationships = $"INSERT INTO dsq_term_relationships VALUES ({idObjectProduct}, {termTaxonomyId}, {0});\n";

                                        DBConnMysql.ExecQuery(insert_dsq_term_relationships);


                                        string select_terms = $"SELECT name FROM dsq_terms WHERE term_id = {categoryId}";

                                        DataTable tbl = DBConnMysql.ExecQuery(select_terms);
                                        if (tbl != null && tbl.Rows != null && tbl.Rows.Count > 0)
                                        {
                                            string name = tbl.Rows[0]["name"].ToString();

                                            //string update_term = $"UPDATE dsq_terms SET name = '{name}.' WHERE term_id = {categoryId};\n";
                                            //update_term += $"UPDATE dsq_terms SET name = '{name}' WHERE term_id = {categoryId};";
                                            //DBConn.ExecQueryUpdate(update_term);
                                            //UpdateCategoriesWCApi(categoryId, name);
                                            //ApiWC.getInstance.UpdateAsyncCategoriesWCApi(categoryId, name);
                                            ApiWC.getInstance.runAsyncTask(API.UpdateCategorie, 0, categoryId, name);

                                        }
                                    }
                                }
                            }

                            contCateg++;
                        }
                        break;
                    case Utils.OFERTA:
                        switch (operation)
                        {
                            case Utils.INSERT:
                                string existCategoryOFER = $"SELECT term_id FROM dsq_terms WHERE name = '{Utils.OFERTA}' LIMIT 1";
                                DataTable dtExistCategOFER = DBConnMysql.ExecQuery(existCategoryOFER);
                                if (!(dtExistCategOFER != null && dtExistCategOFER.Rows != null && dtExistCategOFER.Rows.Count > 0))
                                {
                                    string insertCat = $"INSERT INTO dsq_terms VALUES (NULL, '{Utils.OFERTA}', '{Utils.OFERTA}-0', 0, 0)";
                                    bool insertedCat = DBConnMysql.ExecQueryInsert(insertCat);

                                    existCategoryOFER = $"SELECT term_id FROM dsq_terms WHERE name = '{Utils.OFERTA}' LIMIT 1";
                                    dtExistCategOFER = DBConnMysql.ExecQuery(existCategoryOFER);
                                }


                                if (dtExistCategOFER != null && dtExistCategOFER.Rows != null && dtExistCategOFER.Rows.Count > 0)
                                {
                                    int id_term = int.Parse(dtExistCategOFER.Rows[0]["term_id"].ToString());
                                    string existsRelationCatOFER = $"SELECT term_taxonomy_id FROM dsq_term_taxonomy WHERE term_id = {id_term} LIMIT 1";
                                    DataTable existRelation = DBConnMysql.ExecQuery(existsRelationCatOFER);
                                    if (!(existRelation != null && existRelation.Rows != null && existRelation.Rows.Count > 0))
                                    {
                                        string insertRelation = $"INSERT INTO dsq_term_taxonomy VALUES (NULL, {id_term}, 'product_cat', '{Utils.OFERTA}', 0, 0)";
                                        bool insertedRelation = DBConnMysql.ExecQueryInsert(insertRelation);

                                        existsRelationCatOFER = $"SELECT term_taxonomy_id FROM dsq_term_taxonomy WHERE term_id = {id_term} LIMIT 1";
                                        existRelation = DBConnMysql.ExecQuery(existsRelationCatOFER);
                                    }

                                    if (existRelation != null && existRelation.Rows != null && existRelation.Rows.Count > 0)
                                    {
                                        string insert_dsq_term_relationships = $"INSERT INTO dsq_term_relationships VALUES ({idObjectProduct}, {existRelation.Rows[0]["term_taxonomy_id"].ToString()}, {0});\n";
                                        DBConnMysql.ExecQuery(insert_dsq_term_relationships);
                                    }
                                }
                                break;
                        }

                        break;
                    case Utils.LIQUIDACION:

                        switch (operation)
                        {
                            case Utils.INSERT:
                                string existCategoryLIQ = $"SELECT term_id FROM dsq_terms WHERE name = '{Utils.LIQUIDACION}' LIMIT 1";
                                DataTable dtExistCategLIQ = DBConnMysql.ExecQuery(existCategoryLIQ);
                                if (!(dtExistCategLIQ != null && dtExistCategLIQ.Rows != null && dtExistCategLIQ.Rows.Count > 0))
                                {
                                    string insertCat = $"INSERT INTO dsq_terms VALUES (NULL, '{Utils.LIQUIDACION}', '{Utils.LIQUIDACION}-0', 0, 0)";
                                    bool insertedCat = DBConnMysql.ExecQueryInsert(insertCat);

                                    existCategoryLIQ = $"SELECT term_id FROM dsq_terms WHERE name = '{Utils.LIQUIDACION}' LIMIT 1";
                                    dtExistCategLIQ = DBConnMysql.ExecQuery(existCategoryLIQ);
                                }


                                if (dtExistCategLIQ != null && dtExistCategLIQ.Rows != null && dtExistCategLIQ.Rows.Count > 0)
                                {
                                    int id_term = int.Parse(dtExistCategLIQ.Rows[0]["term_id"].ToString());
                                    string existsRelationCatLIQ = $"SELECT term_taxonomy_id FROM dsq_term_taxonomy WHERE term_id = {id_term} LIMIT 1";
                                    DataTable existRelation = DBConnMysql.ExecQuery(existsRelationCatLIQ);
                                    if (!(existRelation != null && existRelation.Rows != null && existRelation.Rows.Count > 0))
                                    {
                                        string insertRelation = $"INSERT INTO dsq_term_taxonomy VALUES (NULL, {id_term}, 'product_cat', '{Utils.LIQUIDACION}', 0, 0)";
                                        bool insertedRelation = DBConnMysql.ExecQueryInsert(insertRelation);

                                        existsRelationCatLIQ = $"SELECT term_taxonomy_id FROM dsq_term_taxonomy WHERE term_id = {id_term} LIMIT 1";
                                        existRelation = DBConnMysql.ExecQuery(existsRelationCatLIQ);
                                    }

                                    if (existRelation != null && existRelation.Rows != null && existRelation.Rows.Count > 0)
                                    {
                                        string insert_dsq_term_relationships = $"INSERT INTO dsq_term_relationships VALUES ({idObjectProduct}, {existRelation.Rows[0]["term_taxonomy_id"].ToString()}, {0});\n";
                                        DBConnMysql.ExecQuery(insert_dsq_term_relationships);
                                    }
                                }
                                break;
                        }
                        break;
                }

                //Utils.PrintLog("SyncCategoriesToWooCommerce", "1", "Fin categorías-------------");

            }
            catch (Exception ex)
            {
                Utils.PrintLog("SyncCategoriesToWooCommerce", "1", ex.ToString());
            }
        }

        public string ClearCategoriesToSync(string categoriesList)
        {
            try
            {
                string[] arrayCat = categoriesList.Split(',');
                List<string> lsCategories = new List<string>(arrayCat);
                int contElement = 0;
                string clearCateg = "";
                foreach (string categ in lsCategories)
                {
                    int limit = categ.Length;
                    string validateCateg = categ;
                    validateCateg = categ.TrimStart().TrimEnd();
                    if (contElement == (lsCategories.Count - 1))
                    {
                        clearCateg += validateCateg;
                    }
                    else
                    {
                        clearCateg += validateCateg + ",";
                    }
                    contElement++;
                }
                return clearCateg;
            }
            catch (Exception ex)
            {
                Utils.PrintLog("ClearCategoriesToSync", "1", ex.ToString());
                return "";
            }

        }

        public string ClearStringCategories(string categories)
        {
            try
            {
                string[] arrayCat = categories.Split(',');
                List<string> lsCategories = new List<string>(arrayCat);
                int contElement = 0;
                string clearCateg = "";
                foreach (string categ in lsCategories)
                {
                    int cont = 0, limit = categ.Length;
                    string validateCateg = categ;
                    foreach (char letter in categ)
                    {
                        if (cont == 0 || cont == limit)
                        {
                            if (letter == 32)
                            {
                                validateCateg = categ.TrimStart().TrimEnd();
                            }
                        }
                        cont++;
                    }
                    string newstring = validateCateg.Replace("/", " ").Replace(" ", "-");

                    char previous = ' ';
                    int contGuion = 0, index = 0;
                    string stringLimpio = "";
                    foreach (char letter in newstring)
                    {
                        char[] arrayCateg = newstring.ToCharArray();
                        char actual = letter;
                        if (index > 0)
                        {
                            previous = arrayCateg[index - 1];
                        }

                        if (actual == previous)
                        {
                            contGuion++;
                        }
                        else
                        {
                            stringLimpio += actual.ToString();
                        }
                        index++;
                    }
                    //Console.WriteLine("el string" + stringLimpio);
                    //Console.WriteLine("cant guin" + contGuion);
                    if (contElement == (lsCategories.Count - 1))
                    {
                        clearCateg += stringLimpio;
                    }
                    else
                    {
                        clearCateg += stringLimpio + ",";
                    }
                    contElement++;
                }
                return clearCateg;
            }
            catch (Exception ex)
            {
                Utils.PrintLog("ClearStringCategories", "1", ex.ToString());
                return "";
            }

        }

        public string returnWhsSelect(int count)
        {
            try
            {
                string whsSelect = "";
                for (int index = 1; index <= count; index++)
                    whsSelect += string.IsNullOrEmpty(whsSelect) ? $"{Utils.parseStringBD("OITW")}.{Utils.parseStringBD("WhsCode")} = '0{index}'" : $" OR {Utils.parseStringBD("OITW")}.{Utils.parseStringBD("WhsCode")} = '{(index < 10 ? $"0{index}" : $"{index}")}'";

                whsSelect += $" OR {Utils.parseStringBD("OITW")}.{Utils.parseStringBD("WhsCode")} = '13'";
                return whsSelect;
            }
            catch (Exception ex)
            {
                Utils.PrintLog("returnWhsSelect", "1", ex.ToString());
                return "";
            }
        }

        public void SyncDeleteProducts()
        {
            try
            {
                string querySelectSAP = $@"SELECT TOP {Utils.RangoRegistros_prod} *";
                querySelectSAP += $" FROM {Utils.parseStringBD(DBConn.zAdi_SyncItems)}";
                querySelectSAP += $" WHERE {Utils.parseStringBD(zAdi_SyncItems.zAdi_FlagSend)} = FALSE AND {Utils.parseStringBD(zAdi_SyncItems.zAdi_Action)} = '{Utils.DELETE}'";
                //Utils.PrintLog("SyncDeleteProducts", "1", $"querySelectSAP:\n{querySelectSAP}");
                DataTable tbl_select = DBConn.ExecQuery(querySelectSAP, DBConn.ConectionDB.Bitacoras);
                if (tbl_select != null && tbl_select.Rows != null && tbl_select.Rows.Count > 0)
                {
                    foreach (DataRow row in tbl_select.Rows)
                    {
                        string zAdi_SyncitemsId = row["zAdi_SyncitemsId"].ToString();
                        string ID = row["zAdi_IdCommerce"] != null && !string.IsNullOrEmpty(row["zAdi_IdCommerce"].ToString()) ? row["zAdi_IdCommerce"].ToString() : "0";
                        string ID_Gen = row["zAdi_IdCommerceGEN"] != null && !string.IsNullOrEmpty(row["zAdi_IdCommerceGEN"].ToString()) ? row["zAdi_IdCommerceGEN"].ToString() : "0";
                        string ID_Ofer = row["zAdi_IdCommerceOFER"] != null && !string.IsNullOrEmpty(row["zAdi_IdCommerceOFER"].ToString()) ? row["zAdi_IdCommerceOFER"].ToString() : "0";
                        string ID_Liq = row["zAdi_IdCommerceLIQ"] != null && !string.IsNullOrEmpty(row["zAdi_IdCommerceLIQ"].ToString()) ? row["zAdi_IdCommerceLIQ"].ToString() : "0";

                        List<string> IDs = new List<string> { ID, ID_Gen, ID_Ofer, ID_Liq };

                        string select_post_name = $"SELECT post_name FROM dsq_posts WHERE ID = {ID}";
                        //Utils.PrintLog("SyncDeleteProducts", "1", $"select_post_name:\n{select_post_name}");
                        DataTable tbl_post_name = DBConnMysql.ExecQuery(select_post_name);
                        if (tbl_post_name != null && tbl_post_name.Rows != null && tbl_post_name.Rows.Count > 0)
                        {
                            string post_name = tbl_post_name.Rows[0][0].ToString();
                            string post_name_custom = post_name[post_name.Length - 1] == '-' ? (post_name.Remove(post_name.Length - 1)) : post_name;
                            post_name_custom = post_name_custom + "_";

                            string update = string.Empty;
                            update += $"UPDATE dsq_posts SET post_status = 'trash', post_name = '{post_name_custom}_trashed' WHERE ID = {ID};\n";
                            update += $"UPDATE dsq_posts SET post_status = 'trash', post_name = '{post_name_custom}_trashed3' WHERE ID = {ID_Gen};\n";
                            update += $"UPDATE dsq_posts SET post_status = 'trash', post_name = '{post_name_custom}_trashed2' WHERE ID = {ID_Ofer};\n";
                            update += $"UPDATE dsq_posts SET post_status = 'trash', post_name = '{post_name_custom}_trashed' WHERE ID = {ID_Liq};\n";


                            for (int index = 0; index < IDs.Count; index++)
                            {
                                update += $"INSERT INTO dsq_postmeta (meta_id, post_id, meta_key, meta_value) VALUES (NULL, {IDs[index]}, '_wp_trash_meta_status', 'publish');\n";
                                update += $"INSERT INTO dsq_postmeta (meta_id, post_id, meta_key, meta_value) VALUES (NULL, {IDs[index]}, '_wp_trash_meta_time', '1622480692');\n";
                                update += $"INSERT INTO dsq_postmeta (meta_id, post_id, meta_key, meta_value) VALUES (NULL, {IDs[index]}, '_wp_desired_post_slug', '{post_name}');\n";
                            }
                            //Utils.PrintLog("SyncDeleteProducts", "1", $"query:\n{update}");
                            DBConnMysql.ExecQueryUpdate(update);

                            #region Update FROM DB SAP HANA
                            string update_zAdi_SyncItems = $"UPDATE {Utils.parseStringBD(DBConn.zAdi_SyncItems)}";
                            update_zAdi_SyncItems += $" SET {Utils.parseStringBD(zAdi_SyncItems.zAdi_FlagSend)} = TRUE, {Utils.parseStringBD(zAdi_SyncItems.zAdi_DateSend)} = NOW()";
                            update_zAdi_SyncItems += $" WHERE {Utils.parseStringBD(zAdi_SyncItems.zAdi_SyncItemsId)} = {zAdi_SyncitemsId}";

                            DBConn.ExecQueryUpdate(update_zAdi_SyncItems, DBConn.ConectionDB.Bitacoras);

                            #endregion
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("SyncDeleteProducts", "1", ex.ToString());
            }
        }

        public void ReSyncProducts()
        {
            try
            {
                string select_Items = $"SELECT * FROM {Utils.parseStringBD(DBConn.zAdi_SyncItems)} WHERE {Utils.parseStringBD("zAdi_Action")} = 'INSERT' AND {Utils.parseStringBD("zAdi_FlagSend")} = TRUE AND ({Utils.parseStringBD("zAdi_IdCommerceGEN")} IS NULL OR {Utils.parseStringBD("zAdi_IdCommerceOFER")} IS NULL OR {Utils.parseStringBD("zAdi_IdCommerceLIQ")} IS NULL);";
                DataTable tbl_items = DBConn.ExecQuery(select_Items, DBConn.ConectionDB.Bitacoras);
                if (tbl_items != null && tbl_items.Rows != null && tbl_items.Rows.Count > 0)
                {
                    foreach (DataRow row in tbl_items.Rows)
                    {
                        string ItemCode = row["zAdi_ItemCode"] != null && !string.IsNullOrEmpty(row["zAdi_ItemCode"].ToString()) ? row["zAdi_ItemCode"].ToString() : "";
                        string idSyncItem = row["zAdi_SyncItemsId"] != null && !string.IsNullOrEmpty(row["zAdi_SyncItemsId"].ToString()) ? row["zAdi_SyncItemsId"].ToString() : "0";
                        string id_commerce = row["zAdi_IdCommerce"] != null && !string.IsNullOrEmpty(row["zAdi_IdCommerce"].ToString()) ? row["zAdi_IdCommerce"].ToString() : "0";
                        string id_commerceGEN = row["zAdi_IdCommerceGEN"] != null && !string.IsNullOrEmpty(row["zAdi_IdCommerceGEN"].ToString()) ? row["zAdi_IdCommerceGEN"].ToString() : "0";
                        string id_commerceOFER = row["zAdi_IdCommerceOFER"] != null && !string.IsNullOrEmpty(row["zAdi_IdCommerceOFER"].ToString()) ? row["zAdi_IdCommerceOFER"].ToString() : "0";
                        string id_commerceLIQ = row["zAdi_IdCommerceLIQ"] != null && !string.IsNullOrEmpty(row["zAdi_IdCommerceLIQ"].ToString()) ? row["zAdi_IdCommerceLIQ"].ToString() : "0";

                        if (id_commerce != "0")
                        {
                            string delete_ecommerce = string.Empty;
                            delete_ecommerce += $"DELETE FROM dsq_posts WHERE ID IN ({id_commerce}, {id_commerceGEN}, {id_commerceOFER}, {id_commerceLIQ});";
                            delete_ecommerce += $"DELETE FROM dsq_postmeta WHERE dsq_postmeta.post_id IN ({id_commerce}, {id_commerceGEN}, {id_commerceOFER}, {id_commerceLIQ});";
                            delete_ecommerce += $"DELETE FROM dsq_wc_product_meta_lookup WHERE dsq_wc_product_meta_lookup.product_id IN ({id_commerce}, {id_commerceGEN}, {id_commerceOFER}, {id_commerceLIQ});";
                            DBConnMysql.ExecQueryDelete(delete_ecommerce);

                            string select_count = $"SELECT COUNT(*) FROM {Utils.parseStringBD("zAdi_SyncItems")} WHERE {Utils.parseStringBD("zAdi_ItemCode")} = '{ItemCode}' AND {Utils.parseStringBD("zAdi_Action")} = 'UPDATE'";
                            DataTable tbl_count = DBConn.ExecQuery(select_count, DBConn.ConectionDB.Bitacoras);
                            if (tbl_count != null && tbl_count.Rows != null && tbl_count.Rows.Count > 0)
                            {
                                string count = tbl_count.Rows[0][0] != null && !string.IsNullOrEmpty(tbl_count.Rows[0][0].ToString()) ? tbl_count.Rows[0][0].ToString() : "0";
                                if (count != "0")
                                {
                                    string delete_sap = $"DELETE FROM {Utils.parseStringBD("zAdi_SyncItems")} WHERE {Utils.parseStringBD("zAdi_ItemCode")} = '{ItemCode}';";
                                    bool fgDelete = DBConn.ExecQueryDelete(delete_sap);
                                    if (!fgDelete)
                                    {
                                        Utils.PrintLog("ReSyncProducts", "0", $"No es posible eliminar el producto de la bitácora. query: {delete_sap}");
                                    }
                                }
                                else
                                {
                                    string updateSAP = $"UPDATE {Utils.parseStringBD("zAdi_SyncItems")} SET {Utils.parseStringBD("zAdi_FlagSend")} = FALSE, {Utils.parseStringBD("zAdi_IdCommerce")} = NULL WHERE {Utils.parseStringBD("zAdi_SyncItemsId")} = {idSyncItem}";

                                    bool fgUpdate = DBConn.ExecQueryUpdate(updateSAP, DBConn.ConectionDB.Bitacoras);
                                    if (!fgUpdate)
                                    {
                                        Utils.PrintLog("ReSyncProducts", "0", $"no es posible actualizar el registro. query : {updateSAP}");
                                    }
                                }
                            }
                            else
                            {
                                string updateSAP = $"UPDATE {Utils.parseStringBD("zAdi_SyncItems")} SET {Utils.parseStringBD("zAdi_FlagSend")} = FALSE, {Utils.parseStringBD("zAdi_IdCommerce")} = NULL WHERE {Utils.parseStringBD("zAdi_SyncItemsId")} = {idSyncItem}";

                                bool fgUpdate = DBConn.ExecQueryUpdate(updateSAP, DBConn.ConectionDB.Bitacoras);
                                if (!fgUpdate)
                                {
                                    Utils.PrintLog("ReSyncProducts", "0", $"no es posible actualizar el registro. query : {updateSAP}");
                                }
                            }

                        }
                        else
                        {
                            string delete = $"DELETE FROM {Utils.parseStringBD("zAdi_SyncItems")} WHERE {Utils.parseStringBD("zAdi_ItemCode")} = '{ItemCode}'";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("ReSyncProducts", "1", ex.ToString());
            }
        }

        public void reSyncCat()
        {
            try
            {
                //string select_items = $"SELECT TOP {Utils.RangoRegistros} * FROM {Utils.parseStringBD("zAdi_SyncItems")} WHERE {Utils.parseStringBD("zAdi_Action")} = 'INSERT'";
                string select_items = $"SELECT TOP {Utils.RangoRegistros_prod} * FROM {Utils.parseStringBD("zAdi_SyncItems")} WHERE {Utils.parseStringBD("zAdi_FlagSend")} = FALSE AND {Utils.parseStringBD("zAdi_Action")} = 'INSERT'";
                //select_items += $" AND {Utils.parseStringBD("zAdi_ItemCode")} IN ('EC-1LOOP', 'EC-1BRM4.5', 'EC-1BMIZ', 'RAIL-B02', 'EAUR-WEB', 'MC-1000', 'AC-LSP-8DR-MER-LCK', 'SC8132', 'IP04-06T-DT-E', 'IP08-78T-R4Z')";
                //Utils.PrintLog("reSyncCat", "1", $"select_items: {select_items}");
                DataTable tbl_items = DBConn.ExecQuery(select_items);
                if(tbl_items != null && tbl_items.Rows != null && tbl_items.Rows.Count > 0)
                {
                    foreach(DataRow item in tbl_items.Rows)
                    {
                        string zAdi_SyncItemsId = item["zAdi_SyncItemsId"] != null && !string.IsNullOrEmpty(item["zAdi_SyncItemsId"].ToString()) ? item["zAdi_SyncItemsId"].ToString() : "0";
                        string zAdi_IdCommerce = item["zAdi_IdCommerce"] != null && !string.IsNullOrEmpty(item["zAdi_IdCommerce"].ToString()) ? item["zAdi_IdCommerce"].ToString() : "0";
                        string zAdi_IdCommerceGEN = item["zAdi_IdCommerceGEN"] != null && !string.IsNullOrEmpty(item["zAdi_IdCommerceGEN"].ToString()) ? item["zAdi_IdCommerceGEN"].ToString() : "0";
                        string zAdi_IdCommerceOFER = item["zAdi_IdCommerceOFER"] != null && !string.IsNullOrEmpty(item["zAdi_IdCommerceOFER"].ToString()) ? item["zAdi_IdCommerceOFER"].ToString() : "0";
                        string zAdi_IdCommerceLIQ = item["zAdi_IdCommerceLIQ"] != null && !string.IsNullOrEmpty(item["zAdi_IdCommerceLIQ"].ToString()) ? item["zAdi_IdCommerceLIQ"].ToString() : "0";
                        string zAdi_Categories = item["zAdi_Categories"] != null && !string.IsNullOrEmpty(item["zAdi_Categories"].ToString()) ? item["zAdi_Categories"].ToString() : "";

                        //metodo alan

                        if(zAdi_IdCommerce != "0")
                        {
                            if(!string.IsNullOrEmpty(zAdi_Categories))
                                SyncCategoriesToWooCommerce(zAdi_Categories, Convert.ToInt32(zAdi_IdCommerce), Utils.MASTER, Utils.UPDATE);
                        }

                        if(zAdi_IdCommerceOFER != "0")
                        {
                            SyncCategoriesToWooCommerce(zAdi_Categories, Convert.ToInt32(zAdi_IdCommerceOFER), Utils.OFERTA, Utils.INSERT);
                        }

                        if(zAdi_IdCommerceLIQ != "0")
                        {
                            SyncCategoriesToWooCommerce(zAdi_Categories, Convert.ToInt32(zAdi_IdCommerceLIQ), Utils.LIQUIDACION, Utils.INSERT);
                        }

                        #region Update FROM DB SAP HANA
                        string update_zAdi_SyncItems = $"UPDATE {Utils.parseStringBD(DBConn.zAdi_SyncItems)}";
                        update_zAdi_SyncItems += $" SET {Utils.parseStringBD(zAdi_SyncItems.zAdi_FlagSend)} = TRUE";
                        update_zAdi_SyncItems += $" WHERE {Utils.parseStringBD(zAdi_SyncItems.zAdi_SyncItemsId)} = {zAdi_SyncItemsId}";
                        DBConn.ExecQueryUpdate(update_zAdi_SyncItems);
                        #endregion
                    }
                }
            }
            catch(Exception ex) {
                Utils.PrintLog("reSyncCat", "1", ex.ToString());
            }
        }

        public bool ValidateExistProdNoSync()
        {
            try
            {
                string querySelectSAP = $@"SELECT COUNT(*)";
                querySelectSAP += $" FROM {Utils.parseStringBD(DBConn.zAdi_SyncItems)}";
                querySelectSAP += $" WHERE {Utils.parseStringBD(zAdi_SyncItems.zAdi_FlagSend)} = FALSE AND {Utils.parseStringBD(zAdi_SyncItems.zAdi_Action)} = 'INSERT'";
                


                DataTable tbl_items = DBConn.ExecQuery(querySelectSAP, DBConn.ConectionDB.Bitacoras);
                if(tbl_items != null && tbl_items.Rows != null && tbl_items.Rows.Count > 0)
                {
                    if(tbl_items.Rows[0][0] != null && !string.IsNullOrEmpty(tbl_items.Rows[0][0].ToString()))
                    {
                        string count = tbl_items.Rows[0][0].ToString();
                        return (count == "0" || count == "?");
                    }
                    else
                        return true;
                }
                else
                    return true;
            }
            catch(Exception ex)
            {
                return true;
            }

            return true;
        }

        public void reSync_UpsellsId()
        {
            try
            {
                //string select_items = $"SELECT TOP {Utils.RangoRegistros} * FROM {Utils.parseStringBD("zAdi_SyncItems")} WHERE {Utils.parseStringBD("zAdi_Action")} = 'INSERT'";
                string select_items = $"SELECT TOP {Utils.RangoRegistros_prod} * FROM {Utils.parseStringBD("zAdi_SyncItems")} WHERE {Utils.parseStringBD("zAdi_FlagSend")} = FALSE AND {Utils.parseStringBD("zAdi_Action")} = 'INSERT'";
                //select_items += $" AND {Utils.parseStringBD("zAdi_ItemCode")} IN ('EC-1LOOP', 'EC-1BRM4.5', 'EC-1BMIZ', 'RAIL-B02', 'EAUR-WEB', 'MC-1000', 'AC-LSP-8DR-MER-LCK', 'SC8132', 'IP04-06T-DT-E', 'IP08-78T-R4Z')";
                //Utils.PrintLog("reSyncCat", "1", $"select_items: {select_items}");
                DataTable tbl_items = DBConn.ExecQuery(select_items);
                if (tbl_items != null && tbl_items.Rows != null && tbl_items.Rows.Count > 0)
                {
                    foreach (DataRow item in tbl_items.Rows)
                    {
                        string zAdi_SyncItemsId = item["zAdi_SyncItemsId"] != null && !string.IsNullOrEmpty(item["zAdi_SyncItemsId"].ToString()) ? item["zAdi_SyncItemsId"].ToString() : "0";
                        string zAdi_IdCommerce = item["zAdi_IdCommerce"] != null && !string.IsNullOrEmpty(item["zAdi_IdCommerce"].ToString()) ? item["zAdi_IdCommerce"].ToString() : "0";
                        string zAdi_IdCommerceGEN = item["zAdi_IdCommerceGEN"] != null && !string.IsNullOrEmpty(item["zAdi_IdCommerceGEN"].ToString()) ? item["zAdi_IdCommerceGEN"].ToString() : "0";
                        string zAdi_IdCommerceOFER = item["zAdi_IdCommerceOFER"] != null && !string.IsNullOrEmpty(item["zAdi_IdCommerceOFER"].ToString()) ? item["zAdi_IdCommerceOFER"].ToString() : "0";
                        string zAdi_IdCommerceLIQ = item["zAdi_IdCommerceLIQ"] != null && !string.IsNullOrEmpty(item["zAdi_IdCommerceLIQ"].ToString()) ? item["zAdi_IdCommerceLIQ"].ToString() : "0";
                        string zAdi_Categories = item["zAdi_Categories"] != null && !string.IsNullOrEmpty(item["zAdi_Categories"].ToString()) ? item["zAdi_Categories"].ToString() : "";

                        

                        if (zAdi_IdCommerce != "0")
                        {
                            string metaValue = zAdi_IdCommerceOFER != "0" && zAdi_IdCommerceLIQ != "0" ? "a:2:{i:0;i:" + zAdi_IdCommerceLIQ + ";i:1;i:" + zAdi_IdCommerceOFER + ";}" : zAdi_IdCommerceOFER != "0" || zAdi_IdCommerceLIQ != "0" ? "a:1:{i:0;i:" + (zAdi_IdCommerceOFER != "0" ? zAdi_IdCommerceOFER : zAdi_IdCommerceLIQ) + ";}" : "";
                            string update_dsq_postmeta = $"UPDATE dsq_postmeta SET meta_value = '{metaValue}' WHERE meta_key = '_upsell_ids' AND post_id = {zAdi_IdCommerce};";
                            //Utils.PrintLog("reSync_UpsellsId", "0", $"update_dsq_postmeta: {update_dsq_postmeta}");
                            DBConnMysql.ExecQueryUpdate(update_dsq_postmeta);
                        }

                        #region Update FROM DB SAP HANA
                        string update_zAdi_SyncItems = $"UPDATE {Utils.parseStringBD(DBConn.zAdi_SyncItems)}";
                        update_zAdi_SyncItems += $" SET {Utils.parseStringBD(zAdi_SyncItems.zAdi_FlagSend)} = TRUE";
                        update_zAdi_SyncItems += $" WHERE {Utils.parseStringBD(zAdi_SyncItems.zAdi_SyncItemsId)} = {zAdi_SyncItemsId}";
                        DBConn.ExecQueryUpdate(update_zAdi_SyncItems);
                        #endregion
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("reSyncCat", "1", ex.ToString());
            }
        }

        #endregion

        #region inventory

        #region v2

        public void RegisterLogInventory_v2()
        {
            try
            {
                /*
                * 01 - GDL
                * 02 - CMDX
                * 03 - MTY
                * 04 - LEON
                * 05 - LIQ
                * 13 - OFER
                * 
                * Disp = OnHand - IsCommited + OnOrder
                */

                string select_sync_items = $"SELECT TOP {Utils.RangoRegistros_prod} {Utils.parseStringBD("zAdi_SyncItemsId")}, {Utils.parseStringBD("zAdi_ItemCode")} FROM {Utils.parseStringBD(DBConn.DBBitacoras)}.{Utils.parseStringBD("zAdi_SyncItems")} WHERE {Utils.parseStringBD("zAdi_FlagSend")} = TRUE AND {Utils.parseStringBD("zAdi_Action")} = 'INSERT' AND {Utils.parseStringBD("zAdi_FlagSendInventory")} IS NULL";
                DataTable tbl_select_sync_item = DBConn.ExecQuery(select_sync_items, DBConn.ConectionDB.Bitacoras);
                if (tbl_select_sync_item != null && tbl_select_sync_item.Rows != null && tbl_select_sync_item.Rows.Count > 0)
                {
                    foreach (DataRow row_select_sync_item in tbl_select_sync_item.Rows)
                    {
                        int id = Convert.ToInt32(row_select_sync_item["zAdi_SyncItemsId"].ToString());
                        string zAdi_ItemCode = row_select_sync_item["zAdi_ItemCode"].ToString();

                        string select_OITW = $@"SELECT {Utils.parseStringBD("WhsCode")}, {Utils.parseStringBD("OnHand")}, {Utils.parseStringBD("Locked")}, {Utils.parseStringBD("IsCommited")}, {Utils.parseStringBD("OnOrder")}";
                        select_OITW += $" FROM {Utils.parseStringBD(DBConn.DBPrimaria)}.{Utils.parseStringBD("OITW")}";
                        select_OITW += $" WHERE TRIM(replace(replace({Utils.parseStringBD("ItemCode")}, '''',''),'\\', '')) = '{zAdi_ItemCode}' AND  ( {returnWhsSelect(5)} )";
                        DataTable tbl_OITW = DBConn.ExecQuery(select_OITW);
                        if (tbl_OITW != null && tbl_OITW.Rows != null && tbl_OITW.Rows.Count > 0)
                        {
                            foreach (DataRow row_inv in tbl_OITW.Rows)
                            {
                                string WhsCode = row_inv["WhsCode"].ToString();
                                int OnHand = row_inv["OnHand"] != null && !string.IsNullOrEmpty(row_inv["OnHand"].ToString()) ? Convert.ToInt32(double.Parse(row_inv["OnHand"].ToString())) : 0;
                                int IsCommited = row_inv["IsCommited"] != null && !string.IsNullOrEmpty(row_inv["IsCommited"].ToString()) ? Convert.ToInt32(double.Parse(row_inv["IsCommited"].ToString())) : 0;
                                int OnOrder = row_inv["OnOrder"] != null && !string.IsNullOrEmpty(row_inv["OnOrder"].ToString()) ? Convert.ToInt32(double.Parse(row_inv["OnOrder"].ToString())) : 0;
                                int Available = OnHand - IsCommited + OnOrder;

                                string select_nameWhs = $"SELECT TOP 1 {Utils.parseStringBD("WhsName")} FROM {Utils.parseStringBD("OWHS")} WHERE {Utils.parseStringBD("WhsCode")} = '{WhsCode}'";
                                DataTable tbl_OWHS = DBConn.ExecQuery(select_nameWhs);
                                string WhsName = string.Empty;
                                if (tbl_OWHS != null && tbl_OWHS.Rows != null && tbl_OWHS.Rows.Count > 0)
                                    WhsName = tbl_OWHS.Rows[0]["WhsName"].ToString();

                                string insert_zAdi_SyncInventory = $@"INSERT INTO {Utils.parseStringBD("zAdi_SyncInventory")} VALUES (";
                                insert_zAdi_SyncInventory += $"'{zAdi_ItemCode}'";//zAdi_ItemCode
                                insert_zAdi_SyncInventory += $", '{WhsCode}'";//zAdi_WhsCode
                                insert_zAdi_SyncInventory += $", {OnHand}";//zAdi_OnHand
                                insert_zAdi_SyncInventory += $", 'N'";//zAdi_Locked
                                insert_zAdi_SyncInventory += $", FALSE";//zAdi_FlagSend
                                insert_zAdi_SyncInventory += $", NULL";//zAdi_DateSend
                                insert_zAdi_SyncInventory += $", NOW()";//zAdi_DateRegister
                                insert_zAdi_SyncInventory += $", 'INSERT'";//zAdi_Action
                                insert_zAdi_SyncInventory += $", {id}";//zAdi_IdInventoryWoCommerce
                                insert_zAdi_SyncInventory += $", '{WhsName}'";//zAdi_WareHouse
                                insert_zAdi_SyncInventory += $", {IsCommited}";//zAdi_IsCommited
                                insert_zAdi_SyncInventory += $", {OnOrder}";//zAdi_OnOrder
                                insert_zAdi_SyncInventory += $", {Available}";//zAdi_Available
                                insert_zAdi_SyncInventory += $")";

                                bool Insert = DBConn.ExecQueryInsert(insert_zAdi_SyncInventory, DBConn.ConectionDB.Bitacoras);
                                if (!Insert)
                                {
                                    Utils.PrintLog("RegisterLogInventory_v2", "0", $"No fue posible realizar la sincronización de inventario del producto {zAdi_ItemCode}, sucursal {WhsName}");
                                }
                            }
                        }

                        #region Update FROM DB SAP HANA
                        string update_zAdi_SyncItems = $"UPDATE {Utils.parseStringBD(DBConn.zAdi_SyncItems)}";
                        update_zAdi_SyncItems += $" SET {Utils.parseStringBD("zAdi_FlagSendInventory")} = FALSE ";
                        update_zAdi_SyncItems += $" WHERE {Utils.parseStringBD(zAdi_SyncItems.zAdi_SyncItemsId)} = {id}";

                        DBConn.ExecQueryUpdate(update_zAdi_SyncItems, DBConn.ConectionDB.Bitacoras);
                        #endregion
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("RegisterLogInventory_v2", "1", ex.ToString());
            }
        }
        public void SyncInventoryToWooCommerce_v2()
        {
            try
            {
                /*
                * 01 - GDL
                * 02 - CMDX
                * 03 - MTY
                * 04 - LEON
                * 05 - LIQ
                * 13 - OFER
                * 
                *  OnHand - IsCommited + OnOrder = Disp
                */
                string select_Items = $"SELECT TOP {Utils.RangoRegistros_prod} {Utils.parseStringBD("zAdi_SyncItemsId")}, {Utils.parseStringBD("zAdi_ItemCode")}, {Utils.parseStringBD("zAdi_IdCommerce")}, {Utils.parseStringBD("zAdi_IdCommerceGEN")}, {Utils.parseStringBD("zAdi_IdCommerceOFER")}, {Utils.parseStringBD("zAdi_IdCommerceLIQ")} FROM {Utils.parseStringBD("zAdi_SyncItems")} WHERE {Utils.parseStringBD("zAdi_FlagSend")} = TRUE AND {Utils.parseStringBD("zAdi_Action")} = 'INSERT' AND {Utils.parseStringBD("zAdi_FlagSendInventory")} = FALSE";
                //Utils.PrintLog($"SyncInventoryToWooCommerce_v2", "0", $"select_Items: {select_Items}");
                DataTable tbl_Items = DBConn.ExecQuery(select_Items, DBConn.ConectionDB.Bitacoras);
                if (tbl_Items != null && tbl_Items.Rows != null && tbl_Items.Rows.Count > 0)
                {
                    foreach (DataRow item in tbl_Items.Rows)
                    {
                        int id = Convert.ToInt32(item["zAdi_SyncItemsId"].ToString());
                        string itemCode = item["zAdi_ItemCode"].ToString();
                        int IdCommerce = item["zAdi_IdCommerce"] != null && !string.IsNullOrEmpty(item["zAdi_IdCommerce"].ToString()) ? Convert.ToInt32(item["zAdi_IdCommerce"].ToString()) : 0;
                        int IdCommerceGEN = item["zAdi_IdCommerceGEN"] != null && !string.IsNullOrEmpty(item["zAdi_IdCommerceGEN"].ToString()) ? Convert.ToInt32(item["zAdi_IdCommerceGEN"].ToString()) : 0;
                        int IdCommerceOFER = item["zAdi_IdCommerceOFER"] != null && !string.IsNullOrEmpty(item["zAdi_IdCommerceOFER"].ToString()) ? Convert.ToInt32(item["zAdi_IdCommerceOFER"].ToString()) : 0;
                        int IdCommerceLIQ = item["zAdi_IdCommerceLIQ"] != null && !string.IsNullOrEmpty(item["zAdi_IdCommerceLIQ"].ToString()) ? Convert.ToInt32(item["zAdi_IdCommerceLIQ"].ToString()) : 0;

                        int dispGDL = 0, dispCDMX = 0, dispMTY = 0, dispLEON = 0, dispLIQ = 0, dispOFER = 0, unidadesCam = 0, dispGen = 0, dispMaster = 0;
                        string select_inventory = $"SELECT {Utils.parseStringBD("zAdi_WhsCode")}, {Utils.parseStringBD("zAdi_OnHand")}, {Utils.parseStringBD("zAdi_IsCommited")}, {Utils.parseStringBD("zAdi_OnOrder")}, {Utils.parseStringBD("zAdi_Available")} FROM {Utils.parseStringBD("zAdi_SyncInventory")} WHERE {Utils.parseStringBD("zAdi_IdInventoryWoCommerce")} = {id}";
                        //Utils.PrintLog($"SyncInventoryToWooCommerce_v2", "0", $"select_inventory: {select_inventory}");
                        DataTable tbl_inventory = DBConn.ExecQuery(select_inventory, DBConn.ConectionDB.Bitacoras);
                        if (tbl_inventory != null && tbl_inventory.Rows != null && tbl_inventory.Rows.Count > 0)
                        {
                            foreach (DataRow inventory in tbl_inventory.Rows)
                            {
                                string WhsCode = inventory["zAdi_WhsCode"] != null ? inventory["zAdi_WhsCode"].ToString() : "";
                                int OnHand = inventory["zAdi_OnHand"] != null ? Convert.ToInt32(double.Parse(inventory["zAdi_OnHand"].ToString().Trim())) : 0;
                                int IsCommited = inventory["zAdi_IsCommited"] != null ? Convert.ToInt32(double.Parse(inventory["zAdi_IsCommited"].ToString().Trim())) : 0;
                                int OnOrder = inventory["zAdi_OnOrder"] != null ? Convert.ToInt32(double.Parse(inventory["zAdi_OnOrder"].ToString().Trim())) : 0;
                                int Available = inventory["zAdi_Available"] != null ? Convert.ToInt32(double.Parse(inventory["zAdi_Available"].ToString().Trim())) : 0;
                                unidadesCam += OnOrder;


                                switch (inventory["zAdi_WhsCode"].ToString())
                                {
                                    case "01":
                                        dispGDL = OnHand - IsCommited + OnOrder;
                                        break;
                                    case "02":
                                        dispCDMX = OnHand - IsCommited + OnOrder;
                                        break;
                                    case "03":
                                        dispMTY = OnHand - IsCommited + OnOrder;
                                        break;
                                    case "04":
                                        dispLEON = OnHand - IsCommited + OnOrder;
                                        break;
                                    case "05":
                                        dispLIQ = OnHand - IsCommited + OnOrder;
                                        break;
                                    case "13":
                                        dispOFER = OnHand - IsCommited + OnOrder;
                                        break;
                                }

                                #region Update SAP HANA
                                string query_update_syncInventory = $"UPDATE {Utils.parseStringBD("zAdi_SyncInventory")}";
                                query_update_syncInventory += $" SET {Utils.parseStringBD("zAdi_FlagSend")} = TRUE, {Utils.parseStringBD("zAdi_DateSend")} = NOW()";
                                query_update_syncInventory += $" WHERE {Utils.parseStringBD("zAdi_IdInventoryWoCommerce")} = {id}";
                                DBConn.ExecQueryUpdate(query_update_syncInventory, DBConn.ConectionDB.Bitacoras);
                                #endregion
                            }


                            if (dispCDMX < 0) dispCDMX = 0;
                            if (dispGDL < 0) dispGDL = 0;
                            if (dispLEON < 0) dispLEON = 0;
                            if (dispLIQ < 0) dispLIQ = 0;
                            if (dispMTY < 0) dispMTY = 0;
                            if (dispOFER < 0) dispOFER = 0;

                            dispGen = (dispCDMX + dispGDL + dispLEON + dispMTY);
                            dispMaster = (dispCDMX + dispGDL + dispLEON + dispMTY + dispLIQ + dispOFER);

                            if (dispGen < 0) dispGen = 0;
                            if (dispMaster < 0) dispMaster = 0;

                            //Utils.PrintLog("SyncInventoryToWooCommerce_v2", "0", $"dispCDMX: {dispCDMX}, dispGDL:{dispGDL}, dispLEON: {dispLEON}, dispMTY: {dispMTY}, dispGen: {dispGen}, dispMaster: {dispMaster}");
                        }

                        if (IdCommerce > 0)
                        {
                            #region MASTER

                            string update = $"UPDATE dsq_postmeta SET meta_value = '{dispMaster}' WHERE post_id = {IdCommerce} AND meta_key = '_stock'; \n"; //table dsq_postmeta
                            update += $"UPDATE dsq_postmeta SET meta_value = '{dispGDL}' WHERE post_id = {IdCommerce} AND meta_key = 'unidades_gdl'; \n"; //table dsq_postmeta
                            update += $"UPDATE dsq_postmeta SET meta_value = '{dispCDMX}' WHERE post_id = {IdCommerce} AND meta_key = 'unidades_cdmx'; \n"; //table dsq_postmeta
                            update += $"UPDATE dsq_postmeta SET meta_value = '{dispMTY}' WHERE post_id = {IdCommerce} AND meta_key = 'unidades_mty'; \n"; //table dsq_postmeta
                            update += $"UPDATE dsq_postmeta SET meta_value = '{dispLEON}' WHERE post_id = {IdCommerce} AND meta_key = 'unidades_leon'; \n"; //table dsq_postmeta
                            update += $"UPDATE dsq_wc_product_meta_lookup SET stock_quantity = {dispGen} WHERE product_id = {IdCommerce}; \n"; //table dsq_wc_product_meta_lookup
                            #endregion
                            #region GEN
                            if (IdCommerceGEN > 0)
                            {
                                update += $"\n UPDATE dsq_wc_product_meta_lookup SET stock_quantity = {dispGen} WHERE product_id = {IdCommerceGEN}; \n"; //table dsq_wc_product_meta_lookup
                                update += $"UPDATE dsq_postmeta SET meta_value = '{dispGen}' WHERE post_id = {IdCommerceGEN} AND meta_key = '_stock'; \n"; //table dsq_postmeta
                            }
                            #endregion
                            #region OFER
                            if (IdCommerceOFER > 0)
                            {
                                update += $"\n UPDATE dsq_postmeta SET meta_value = '{dispOFER}' WHERE post_id = {IdCommerceOFER} AND meta_key = '_stock'; \n"; //table dsq_postmeta
                                update += $"UPDATE dsq_wc_product_meta_lookup SET stock_quantity = {dispOFER} WHERE product_id = {IdCommerceOFER}; \n"; //table dsq_wc_product_meta_lookup
                            }
                            #endregion
                            #region LIQ
                            if (IdCommerceLIQ > 0)
                            {
                                update += $"\n UPDATE dsq_postmeta SET meta_value = '{dispLIQ}' WHERE post_id = {IdCommerceLIQ} AND meta_key = '_stock'; \n"; //table dsq_postmeta
                                update += $"UPDATE dsq_wc_product_meta_lookup SET stock_quantity = {dispLIQ} WHERE product_id = {IdCommerceLIQ}; \n"; //table dsq_wc_product_meta_lookup
                            }
                            #endregion

                            try
                            {
                                string post_content_select = $"SELECT post_content FROM dsq_posts WHERE ID = {IdCommerce} LIMIT 1";
                                DataTable tbl = DBConnMysql.ExecQuery(post_content_select);
                                if (tbl != null && tbl.Rows != null && tbl.Rows.Count > 0)
                                {
                                    if (tbl.Rows[0]["post_content"] != null)
                                    {
                                        string post_content = tbl.Rows[0]["post_content"].ToString();
                                        update += $"UPDATE dsq_posts SET post_content = '{post_content} ' WHERE ID = {IdCommerce};\n";
                                        update += $"UPDATE dsq_posts SET post_content = '{post_content}' WHERE ID = {IdCommerce};\n";

                                        //Utils.PrintLog("SyncUpdateProductsToWoocommerce_v2", "0", $"UPDATE dsq_posts SET post_content = '{post_content} ' WHERE ID = {IdCommerce};");
                                    }
                                }
                                //Utils.PrintLog("SyncInventoryToWooCommerce_v2", "0", $"query update: \n{update}");

                                DBConnMysql.ExecQueryUpdate(update);

                                string select_price_ofer = $"select meta_value from dsq_postmeta where post_id = {IdCommerceOFER} AND meta_key = 'sale_price' LIMIT 1";
                                string select_price_Liq = $"select meta_value from dsq_postmeta where post_id = {IdCommerceLIQ} AND meta_key = 'sale_price' LIMIT 1";

                                string price_ofer = "0";
                                string price_liq = "0";

                                DataTable tbl_ofer = DBConnMysql.ExecQuery(select_price_ofer);
                                if (tbl_ofer != null && tbl_ofer.Rows != null && tbl_ofer.Rows.Count > 0)
                                {
                                    if (tbl_ofer.Rows[0]["meta_value"] != null && !string.IsNullOrEmpty(tbl_ofer.Rows[0]["meta_value"].ToString()))
                                        price_ofer = tbl_ofer.Rows[0]["meta_value"].ToString();
                                }

                                DataTable tbl_Liq = DBConnMysql.ExecQuery(select_price_Liq);
                                if (tbl_Liq != null && tbl_Liq.Rows != null && tbl_Liq.Rows.Count > 0)
                                {
                                    if (tbl_Liq.Rows[0]["meta_value"] != null && !string.IsNullOrEmpty(tbl_Liq.Rows[0]["meta_value"].ToString()))
                                        price_liq = tbl_Liq.Rows[0]["meta_value"].ToString();
                                }

                                //--oferta--
                                /*APIASYNC*/
                                //ApiWC.getInstance.UpdateAsyncPriceProductsVariationWCApi(IdCommerce.ToString(), IdCommerceOFER.ToString(), (Convert.ToDouble(price_ofer) + 0.1).ToString());
                                //ApiWC.getInstance.UpdateAsyncPriceProductsVariationWCApi(IdCommerce.ToString(), IdCommerceOFER.ToString(), (Convert.ToDouble(price_ofer) > 0.0 ? (Convert.ToDouble(price_ofer)).ToString() : ""));

                                ApiWC.getInstance.runAsyncTask(API.UpdatePrice, IdCommerce, IdCommerceOFER, (Convert.ToDouble(price_ofer) + 0.1).ToString());
                                ApiWC.getInstance.runAsyncTask(API.UpdatePrice, IdCommerce, IdCommerceOFER, (Convert.ToDouble(price_ofer) > 0.0 ? (Convert.ToDouble(price_ofer)).ToString() : ""));
                                //--liquidacion--
                                /*APIASYNC*/
                                //ApiWC.getInstance.UpdateAsyncPriceProductsVariationWCApi(IdCommerce.ToString(), IdCommerceLIQ.ToString(), (Convert.ToDouble(price_liq) + 0.1).ToString());
                                //ApiWC.getInstance.UpdateAsyncPriceProductsVariationWCApi(IdCommerce.ToString(), IdCommerceLIQ.ToString(), (Convert.ToDouble(price_liq) > 0.0 ? (Convert.ToDouble(price_liq)).ToString() : ""));

                                ApiWC.getInstance.runAsyncTask(API.UpdatePrice, IdCommerce, IdCommerceLIQ, (Convert.ToDouble(price_liq) + 0.1).ToString());
                                ApiWC.getInstance.runAsyncTask(API.UpdatePrice, IdCommerce, IdCommerceLIQ, (Convert.ToDouble(price_liq) > 0.0 ? (Convert.ToDouble(price_liq)).ToString() : ""));

                                #region Update FROM DB SAP HANA
                                string update_zAdi_SyncItems = $"UPDATE {Utils.parseStringBD(DBConn.zAdi_SyncItems)}";
                                update_zAdi_SyncItems += $" SET {Utils.parseStringBD("zAdi_FlagSendInventory")} = TRUE ";
                                update_zAdi_SyncItems += $" WHERE {Utils.parseStringBD(zAdi_SyncItems.zAdi_SyncItemsId)} = {id}";

                                DBConn.ExecQueryUpdate(update_zAdi_SyncItems, DBConn.ConectionDB.Bitacoras);
                                #endregion
                            }
                            catch (Exception ex)
                            {
                                Utils.PrintLog("SyncInventoryToWooCommerce_v2", "2", ex.ToString());
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("SyncInventoryToWooCommerce_v2", "1", ex.ToString());
            }
        }
        public void SyncUpdateInvToWooCommerce_v2()
        {
            try
            {
                /*
                * 01 - GDL
                * 02 - CMDX
                * 03 - MTY
                * 04 - LEON
                * 05 - LIQ
                * 13 - OFER
                * 
                *  Disp = OnHand - IsCommited + OnOrder
                */
                string select_Items = $"SELECT TOP {Utils.RangoRegistros_prod} {Utils.parseStringBD("zAdi_SyncItemsId")}, {Utils.parseStringBD("zAdi_ItemCode")}, {Utils.parseStringBD("zAdi_IdCommerce")}, {Utils.parseStringBD("zAdi_IdCommerceGEN")}, {Utils.parseStringBD("zAdi_IdCommerceOFER")}, {Utils.parseStringBD("zAdi_IdCommerceLIQ")} FROM {Utils.parseStringBD("zAdi_SyncItems")} WHERE {Utils.parseStringBD("zAdi_FlagSend")} = TRUE AND {Utils.parseStringBD("zAdi_Action")} = 'UPDATE' AND {Utils.parseStringBD("zAdi_FlagSendInventory")} = FALSE";
                //Utils.PrintLog($"SyncUpdateInvToWooCommerce_v2", "0", $"select_Items: {select_Items}");
                DataTable tbl_Items = DBConn.ExecQuery(select_Items, DBConn.ConectionDB.Bitacoras);
                if (tbl_Items != null && tbl_Items.Rows != null && tbl_Items.Rows.Count > 0)
                {
                    foreach (DataRow item in tbl_Items.Rows)
                    {
                        int id = Convert.ToInt32(item["zAdi_SyncItemsId"].ToString());
                        string itemCode = item["zAdi_ItemCode"].ToString();
                        int IdCommerce = item["zAdi_IdCommerce"] != null ? Convert.ToInt32(item["zAdi_IdCommerce"].ToString()) : 0;
                        int IdCommerceGEN = item["zAdi_IdCommerceGEN"] != null ? Convert.ToInt32(item["zAdi_IdCommerceGEN"].ToString()) : 0;
                        int IdCommerceOFER = item["zAdi_IdCommerceOFER"] != null ? Convert.ToInt32(item["zAdi_IdCommerceOFER"].ToString()) : 0;
                        int IdCommerceLIQ = item["zAdi_IdCommerceLIQ"] != null ? Convert.ToInt32(item["zAdi_IdCommerceLIQ"].ToString()) : 0;

                        int dispGDL = 0, dispCDMX = 0, dispMTY = 0, dispLEON = 0, dispLIQ = 0, dispOFER = 0, unidadesCam = 0, dispGen = 0, dispMaster = 0;

                        string select_inventory = $"SELECT {Utils.parseStringBD("zAdi_WhsCode")}, {Utils.parseStringBD("zAdi_OnHand")}, {Utils.parseStringBD("zAdi_IsCommited")}, {Utils.parseStringBD("zAdi_OnOrder")}, {Utils.parseStringBD("zAdi_Available")} FROM {Utils.parseStringBD("zAdi_SyncInventory")} WHERE {Utils.parseStringBD("zAdi_IdInventoryWoCommerce")} = {id}";
                        //Utils.PrintLog($"SyncUpdateInvToWooCommerce_v2", "0", $"select_inventory: {select_inventory}");
                        DataTable tbl_inventory = DBConn.ExecQuery(select_inventory, DBConn.ConectionDB.Bitacoras);
                        if (tbl_inventory != null && tbl_inventory.Rows != null && tbl_inventory.Rows.Count > 0)
                        {
                            foreach (DataRow inventory in tbl_inventory.Rows)
                            {
                                string WhsCode = inventory["zAdi_WhsCode"] != null ? inventory["zAdi_WhsCode"].ToString() : "";
                                int OnHand = inventory["zAdi_OnHand"] != null ? Convert.ToInt32(double.Parse(inventory["zAdi_OnHand"].ToString().Trim())) : 0;
                                int IsCommited = inventory["zAdi_IsCommited"] != null ? Convert.ToInt32(double.Parse(inventory["zAdi_IsCommited"].ToString().Trim())) : 0;
                                int OnOrder = inventory["zAdi_OnOrder"] != null ? Convert.ToInt32(double.Parse(inventory["zAdi_OnOrder"].ToString().Trim())) : 0;
                                int Available = inventory["zAdi_Available"] != null ? Convert.ToInt32(double.Parse(inventory["zAdi_Available"].ToString().Trim())) : 0;
                                unidadesCam += OnOrder;

                                switch (inventory["zAdi_WhsCode"].ToString())
                                {
                                    case "01":
                                        dispGDL = OnHand - IsCommited + OnOrder;
                                        break;
                                    case "02":
                                        dispCDMX = OnHand - IsCommited + OnOrder;
                                        break;
                                    case "03":
                                        dispMTY = OnHand - IsCommited + OnOrder;
                                        break;
                                    case "04":
                                        dispLEON = OnHand - IsCommited + OnOrder;
                                        break;
                                    case "05":
                                        dispLIQ = OnHand - IsCommited + OnOrder;
                                        break;
                                    case "13":
                                        dispOFER = OnHand - IsCommited + OnOrder;
                                        break;
                                }

                                #region Update SAP HANA
                                string query_update_syncInventory = $"UPDATE {Utils.parseStringBD("zAdi_SyncInventory")}";
                                query_update_syncInventory += $" SET {Utils.parseStringBD("zAdi_FlagSend")} = TRUE, {Utils.parseStringBD("zAdi_DateSend")} = NOW()";
                                query_update_syncInventory += $" WHERE {Utils.parseStringBD("zAdi_IdInventoryWoCommerce")} = {id}";
                                //Utils.PrintLog($"SyncUpdateInvToWooCommerce_v2", "0", $"query_update_syncInventory: {query_update_syncInventory}");
                                DBConn.ExecQueryUpdate(query_update_syncInventory, DBConn.ConectionDB.Bitacoras);
                                #endregion
                            }


                            if (dispCDMX < 0) dispCDMX = 0;
                            if (dispGDL < 0) dispGDL = 0;
                            if (dispLEON < 0) dispLEON = 0;
                            if (dispLIQ < 0) dispLIQ = 0;
                            if (dispMTY < 0) dispMTY = 0;
                            if (dispOFER < 0) dispOFER = 0;

                            dispGen = (dispCDMX + dispGDL + dispLEON + dispMTY);
                            dispMaster = (dispCDMX + dispGDL + dispLEON + dispMTY + dispLIQ + dispOFER);
                            //Utils.PrintLog("SyncUpdateInvToWooCommerce_v2", "0", $"dispGen: {dispGen}, dispMaster: {dispMaster}");


                            if (dispGen < 0) dispGen = 0;
                            if (dispMaster < 0) dispMaster = 0;

                            //Utils.PrintLog("SyncUpdateInvToWooCommerce_v2", "0", $"dispCDMX: {dispCDMX}, dispGDL:{dispGDL}, dispLEON: {dispLEON}, dispMTY: {dispMTY}, dispGen: {dispGen}, dispMaster: {dispMaster}");
                        }

                        if (IdCommerce > 0)
                        {
                            #region MASTER
                            string update = $"UPDATE dsq_postmeta SET meta_value = '{dispMaster}' WHERE post_id = {IdCommerce} AND meta_key = '_stock'; \n"; //table dsq_postmeta
                            update += $"UPDATE dsq_postmeta SET meta_value = '{dispGDL}' WHERE post_id = {IdCommerce} AND meta_key = 'unidades_gdl'; \n"; //table dsq_postmeta
                            update += $"UPDATE dsq_postmeta SET meta_value = '{dispCDMX}' WHERE post_id = {IdCommerce} AND meta_key = 'unidades_cdmx'; \n"; //table dsq_postmeta
                            update += $"UPDATE dsq_postmeta SET meta_value = '{dispMTY}' WHERE post_id = {IdCommerce} AND meta_key = 'unidades_mty'; \n"; //table dsq_postmeta
                            update += $"UPDATE dsq_postmeta SET meta_value = '{dispLEON}' WHERE post_id = {IdCommerce} AND meta_key = 'unidades_leon'; \n"; //table dsq_postmeta
                            #endregion
                            #region GEN
                            if (IdCommerceGEN > 0)
                            {
                                update += $"\n UPDATE dsq_wc_product_meta_lookup SET stock_quantity = {dispGen} WHERE product_id = {IdCommerceGEN}; \n"; //table dsq_wc_product_meta_lookup
                                update += $"UPDATE dsq_postmeta SET meta_value = '{dispGen}' WHERE post_id = {IdCommerceGEN} AND meta_key = '_stock'; \n"; //table dsq_postmeta
                            }
                            #endregion
                            #region OFER
                            if (IdCommerceOFER > 0)
                            {
                                update += $"\n UPDATE dsq_postmeta SET meta_value = '{dispOFER}' WHERE post_id = {IdCommerceOFER} AND meta_key = '_stock'; \n"; //table dsq_postmeta
                                update += $"UPDATE dsq_wc_product_meta_lookup SET stock_quantity = {dispOFER} WHERE product_id = {IdCommerceOFER}; \n"; //table dsq_wc_product_meta_lookup
                            }
                            #endregion
                            #region LIQ
                            if (IdCommerceLIQ > 0)
                            {
                                update += $"\n UPDATE dsq_postmeta SET meta_value = '{dispLIQ}' WHERE post_id = {IdCommerceLIQ} AND meta_key = '_stock'; \n"; //table dsq_postmeta
                                update += $"UPDATE dsq_wc_product_meta_lookup SET stock_quantity = {dispLIQ} WHERE product_id = {IdCommerceLIQ}; \n"; //table dsq_wc_product_meta_lookup
                            }
                            #endregion

                            try
                            {
                                string post_content_select = $"SELECT post_content FROM dsq_posts WHERE ID = {IdCommerce} LIMIT 1";
                                DataTable tbl = DBConnMysql.ExecQuery(post_content_select);
                                if (tbl != null && tbl.Rows != null && tbl.Rows.Count > 0)
                                {
                                    if (tbl.Rows[0]["post_content"] != null)
                                    {
                                        string post_content = tbl.Rows[0]["post_content"].ToString();
                                        update += $"UPDATE dsq_posts SET post_content = '{post_content} ' WHERE ID = {IdCommerce};\n";
                                        update += $"UPDATE dsq_posts SET post_content = '{post_content}' WHERE ID = {IdCommerce};\n";

                                        //Utils.PrintLog("SyncUpdateProductsToWoocommerce_v2", "0", $"UPDATE dsq_posts SET post_content = '{post_content} ' WHERE ID = {IdCommerce};");
                                    }
                                }
                                //Utils.PrintLog("SyncUpdateInvToWooCommerce_v2", "0", $"query update: \n{update}");
                                DBConnMysql.ExecQueryUpdate(update);

                                #region Update FROM DB SAP HANA
                                string update_zAdi_SyncItems = $"UPDATE {Utils.parseStringBD(DBConn.zAdi_SyncItems)}";
                                update_zAdi_SyncItems += $" SET {Utils.parseStringBD("zAdi_FlagSendInventory")} = TRUE ";
                                update_zAdi_SyncItems += $" WHERE {Utils.parseStringBD(zAdi_SyncItems.zAdi_SyncItemsId)} = {id}";
                                DBConn.ExecQueryUpdate(update_zAdi_SyncItems, DBConn.ConectionDB.Bitacoras);
                                #endregion
                            }
                            catch (Exception ex)
                            {
                                Utils.PrintLog("SyncUpdateInvToWooCommerce_v2", "2", ex.ToString());
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("SyncUpdateInvToWooCommerce_v2", "1", ex.ToString());
            }
        }
        #endregion

        #endregion

        #region API



        public void UpdateProductsWCApi(string idProduct, string description)
        {

            try
            {
                //var url = $"https://adises.link/wp-json/wc/v3/products/{idProduct}";
                var url = $"{Utils.UrlApi}/products/{idProduct}";
                var request = (HttpWebRequest)WebRequest.Create(url);

                var username = "ck_de22b3baa0f74c15bf619c4fefed1c014bf753fb";
                var password = "cs_46f1294b433891aaef2d0be72dbfe1cf3ce820b5";
                string encoded = System.Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1")
                                               .GetBytes(username + ":" + password));
                request.Headers.Add("Authorization", "Basic " + encoded);
                string json = $"{{\"description\":\"{description}\"}}";
                request.Method = "POST";
                request.ContentType = "application/json";
                request.Accept = "application/json";
                using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                {
                    streamWriter.Write(json);
                    streamWriter.Flush();
                    streamWriter.Close();
                }

                using (WebResponse response = request.GetResponse())
                {
                    using (Stream strReader = response.GetResponseStream())
                    {
                        if (strReader == null)
                        {
                            return;
                        }
                        using (StreamReader objReader = new StreamReader(strReader))
                        {
                            string responseBody = objReader.ReadToEnd();
                            JObject data = JObject.Parse(responseBody);
                            // Do something with responseBody
                            //Utils.PrintLog("UpdateCategoriesWCApi", "0", $"data: {data.Count}");
                            //Console.WriteLine(data);
                        }
                    }
                }
            }
            catch (WebException ex)
            {
                //Console.WriteLine(ex.Message.ToString());
                Utils.PrintLog("UpdateCategoriesWCApi", "1", ex.ToString());
            }
            //Utils.PrintLog("UpdateCategoriesWCApi", "0", $"fin UpdateCategoriesWCApi {DateTime.Now.ToString()}");

        }

        public void UpdateCategoriesWCApi(int idTerm, string Name)
        {

            //Utils.PrintLog("UpdateCategoriesWCApi", "0", $"inicio UpdateCategoriesWCApi {DateTime.Now.ToString()}");
            //Utils.PrintLog("UpdateCategoriesWCApi", "0", $"idCat: {idTerm}, name: {Name}");

            try
            {
                //var url = $"https://adises.link/wp-json/wc/v3/products/categories/{idTerm}";
                var url = $"{Utils.UrlApi}/products/categories/{idTerm}";
                var request = (HttpWebRequest)WebRequest.Create(url);

                var username = "ck_de22b3baa0f74c15bf619c4fefed1c014bf753fb";
                var password = "cs_46f1294b433891aaef2d0be72dbfe1cf3ce820b5";
                string encoded = System.Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1")
                                               .GetBytes(username + ":" + password));
                request.Headers.Add("Authorization", "Basic " + encoded);
                string json = $"{{\"name\":\"{Name}\"}}";
                request.Method = "POST";
                request.ContentType = "application/json";
                request.Accept = "application/json";
                using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                {
                    streamWriter.Write(json);
                    streamWriter.Flush();
                    streamWriter.Close();
                }

                using (WebResponse response = request.GetResponse())
                {
                    using (Stream strReader = response.GetResponseStream())
                    {
                        if (strReader == null)
                        {
                            return;
                        }
                        using (StreamReader objReader = new StreamReader(strReader))
                        {
                            string responseBody = objReader.ReadToEnd();
                            JObject data = JObject.Parse(responseBody);
                            // Do something with responseBody
                            //Utils.PrintLog("UpdateCategoriesWCApi", "0", $"data: {data.Count}");
                            //Console.WriteLine(data);
                        }
                    }
                }
            }
            catch (WebException ex)
            {
                //Console.WriteLine(ex.Message.ToString());
                Utils.PrintLog("UpdateCategoriesWCApi", "1", ex.ToString());
            }

            //Utils.PrintLog("UpdateCategoriesWCApi", "0", $"fin UpdateCategoriesWCApi {DateTime.Now.ToString()}");
        }

        public void UpdateStatusProductsVariationWCApi(string idProductMaster, string idVariation, string status)
        {
            //Utils.PrintLog("UpdateCategoriesWCApi", "0", $"inicio UpdateStatusProductsVariationWCApi {DateTime.Now.ToString()}");
            try
            {
                var url = $"{Utils.UrlApi}/products/{idProductMaster}/variations/{idVariation}";
                var request = (HttpWebRequest)WebRequest.Create(url);

                var username = "ck_de22b3baa0f74c15bf619c4fefed1c014bf753fb";
                var password = "cs_46f1294b433891aaef2d0be72dbfe1cf3ce820b5";
                string encoded = System.Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1")
                                               .GetBytes(username + ":" + password));
                request.Headers.Add("Authorization", "Basic " + encoded);
                string json = $"{{\"status\":\"{status}\"}}";
                request.Method = "POST";
                request.ContentType = "application/json";
                request.Accept = "application/json";
                using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                {
                    streamWriter.Write(json);
                    streamWriter.Flush();
                    streamWriter.Close();
                }

                using (WebResponse response = request.GetResponse())
                {
                    using (Stream strReader = response.GetResponseStream())
                    {
                        if (strReader == null)
                        {
                            return;
                        }
                        using (StreamReader objReader = new StreamReader(strReader))
                        {
                            string responseBody = objReader.ReadToEnd();
                            JObject data = JObject.Parse(responseBody);
                            // Do something with responseBody
                            //Utils.PrintLog("UpdateCategoriesWCApi", "0", $"data: {data.Count}");
                            //Console.WriteLine(data);
                        }
                    }
                }
            }
            catch (WebException ex)
            {
                //Console.WriteLine(ex.Message.ToString());
                Utils.PrintLog("UpdateCategoriesWCApi", "1", ex.ToString());
            }

            //Utils.PrintLog("UpdateCategoriesWCApi", "0", $"fin UpdateStatusProductsVariationWCApi {DateTime.Now.ToString()}");

        }

        public void UpdatePriceProductsVariationWCApi(string idProductMaster, string idVariation, string price)
        {
            //Utils.PrintLog("UpdateCategoriesWCApi", "0", $"inicio UpdatePriceProductsVariationWCApi {DateTime.Now.ToString()}");
            try
            {
                var url = $"{Utils.UrlApi}/products/{idProductMaster}/variations/{idVariation}";
                var request = (HttpWebRequest)WebRequest.Create(url);

                var username = "ck_de22b3baa0f74c15bf619c4fefed1c014bf753fb";
                var password = "cs_46f1294b433891aaef2d0be72dbfe1cf3ce820b5";
                string encoded = System.Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1")
                                               .GetBytes(username + ":" + password));
                request.Headers.Add("Authorization", "Basic " + encoded);
                string json = $"{{\"sale_price\":\"{price}\", \"price\":\"{price}\"}}";
                request.Method = "POST";
                request.ContentType = "application/json";
                request.Accept = "application/json";
                using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                {
                    streamWriter.Write(json);
                    streamWriter.Flush();
                    streamWriter.Close();
                }
                using (WebResponse response = request.GetResponse())
                {
                    using (Stream strReader = response.GetResponseStream())
                    {
                        if (strReader == null)
                        {
                            return;
                        }
                        using (StreamReader objReader = new StreamReader(strReader))
                        {
                            string responseBody = objReader.ReadToEnd();
                            JObject data = JObject.Parse(responseBody);
                            // Do something with responseBody
                            //Utils.PrintLog("UpdateCategoriesWCApi", "0", $"data: {data.Count}");
                            //Console.WriteLine(data);
                        }
                    }
                }
            }
            catch (WebException ex)
            {
                //Console.WriteLine(ex.Message.ToString());
                Utils.PrintLog("UpdateCategoriesWCApi", "1", ex.ToString());
            }

            //Utils.PrintLog("UpdateCategoriesWCApi", "0", $"inicio UpdatePriceProductsVariationWCApi {DateTime.Now.ToString()}");
        }

        #endregion
        public static Products getInstance => new Products();



        public void SyncUpdateCat()
        {
            try
            {
                string query = string.Empty;
                query += "SELECT";
                query += $" {Utils.parseStringBD("zAdi_SyncItemsId")},";
                query += $" {Utils.parseStringBD("zAdi_ItemCode")}";
                query += " FROM";
                query += $" {Utils.parseStringBD("zAdi_SyncItems")}";
                query += " WHERE";
                query += $" {Utils.parseStringBD("zAdi_FlagSend")} = FALSE";
                //query += $" AND {Utils.parseStringBD("zAdi_ItemCode")} IN ('POE-INJ2-95W-NA', 'SL-126Q/R')";

                DataTable tbl = DBConn.ExecQuery(query, DBConn.ConectionDB.Bitacoras);

                if(tbl != null && tbl.Rows!= null && tbl.Rows.Count  > 0)
                {
                    foreach(DataRow row in tbl.Rows)
                    {
                        string zAdi_SyncItemsId = row["zAdi_SyncItemsId"].ToString();
                        string zAdi_ItemCode = row["zAdi_ItemCode"].ToString();

                        query = string.Empty;
                        query += " SELECT TOP 1";
                        query += $" {Utils.parseStringBD("U_Nivel1")},";
                        query += $" {Utils.parseStringBD("U_Nivel2")},";
                        query += $" {Utils.parseStringBD("U_Nivel3")},";
                        query += $" {Utils.parseStringBD("U_Nivel4")},";
                        query += $" {Utils.parseStringBD("U_Nivel5")},";
                        query += $" {Utils.parseStringBD("U_Nivel6")},";
                        query += $" {Utils.parseStringBD("U_Nivel7")},";
                        query += $" {Utils.parseStringBD("U_Nivel8")},";
                        query += $" {Utils.parseStringBD("U_Nivel9")}";
                        query += " FROM";
                        query += $" {Utils.parseStringBD("@PROP_ECOM")}";
                        query += " WHERE";
                        query += $" TRIM(replace(replace({Utils.parseStringBD("Name")}, '''',''),'\\', '')) = '{zAdi_ItemCode}'";

                        string Categorias = string.Empty;
                        DataTable tbl_cat = DBConn.ExecQuery(query);
                        if(tbl_cat != null && tbl_cat.Rows != null && tbl_cat.Rows.Count > 0)
                        {
                            string nivel1 = tbl_cat.Rows[0]["U_Nivel1"] != null && !string.IsNullOrEmpty(tbl_cat.Rows[0]["U_Nivel1"].ToString())? tbl_cat.Rows[0]["U_Nivel1"].ToString() : "";
                            string nivel2 = tbl_cat.Rows[0]["U_Nivel2"] != null && !string.IsNullOrEmpty(tbl_cat.Rows[0]["U_Nivel2"].ToString())? tbl_cat.Rows[0]["U_Nivel2"].ToString() : "";
                            string nivel3 = tbl_cat.Rows[0]["U_Nivel3"] != null && !string.IsNullOrEmpty(tbl_cat.Rows[0]["U_Nivel3"].ToString())? tbl_cat.Rows[0]["U_Nivel3"].ToString() : "";
                            string nivel4 = tbl_cat.Rows[0]["U_Nivel4"] != null && !string.IsNullOrEmpty(tbl_cat.Rows[0]["U_Nivel4"].ToString())? tbl_cat.Rows[0]["U_Nivel4"].ToString() : "";
                            string nivel5 = tbl_cat.Rows[0]["U_Nivel5"] != null && !string.IsNullOrEmpty(tbl_cat.Rows[0]["U_Nivel5"].ToString())? tbl_cat.Rows[0]["U_Nivel5"].ToString() : "";
                            string nivel6 = tbl_cat.Rows[0]["U_Nivel6"] != null && !string.IsNullOrEmpty(tbl_cat.Rows[0]["U_Nivel6"].ToString())? tbl_cat.Rows[0]["U_Nivel6"].ToString() : "";
                            string nivel7 = tbl_cat.Rows[0]["U_Nivel7"] != null && !string.IsNullOrEmpty(tbl_cat.Rows[0]["U_Nivel7"].ToString())? tbl_cat.Rows[0]["U_Nivel7"].ToString() : "";
                            string nivel8 = tbl_cat.Rows[0]["U_Nivel8"] != null && !string.IsNullOrEmpty(tbl_cat.Rows[0]["U_Nivel8"].ToString())? tbl_cat.Rows[0]["U_Nivel8"].ToString() : "";
                            string nivel9 = tbl_cat.Rows[0]["U_Nivel9"] != null && !string.IsNullOrEmpty(tbl_cat.Rows[0]["U_Nivel9"].ToString())? tbl_cat.Rows[0]["U_Nivel9"].ToString() : "";

                            if (!string.IsNullOrEmpty(nivel1)) Categorias += $"{nivel1}";
                            if (!string.IsNullOrEmpty(nivel2)) Categorias += string.IsNullOrEmpty(Categorias) ? nivel2 : $", {nivel2}";
                            if (!string.IsNullOrEmpty(nivel3)) Categorias += string.IsNullOrEmpty(Categorias) ? nivel3 : $", {nivel3}";
                            if (!string.IsNullOrEmpty(nivel4)) Categorias += string.IsNullOrEmpty(Categorias) ? nivel4 : $", {nivel4}";
                            if (!string.IsNullOrEmpty(nivel5)) Categorias += string.IsNullOrEmpty(Categorias) ? nivel5 : $", {nivel5}";
                            if (!string.IsNullOrEmpty(nivel6)) Categorias += string.IsNullOrEmpty(Categorias) ? nivel6 : $", {nivel6}";
                            if (!string.IsNullOrEmpty(nivel7)) Categorias += string.IsNullOrEmpty(Categorias) ? nivel7 : $", {nivel7}";
                            if (!string.IsNullOrEmpty(nivel8)) Categorias += string.IsNullOrEmpty(Categorias) ? nivel8 : $", {nivel8}";
                            if (!string.IsNullOrEmpty(nivel9)) Categorias += string.IsNullOrEmpty(Categorias) ? nivel9 : $", {nivel9}";
                        }

                        string update = string.Empty;
                        update += $"UPDATE";
                        update += $" {Utils.parseStringBD("zAdi_SyncItems")}";
                        update += $" SET";
                        update += $" {Utils.parseStringBD("zAdi_Categories")} = '{Categorias}',";
                        update += $" {Utils.parseStringBD("zAdi_FlagSend")} = TRUE";
                        update += $" WHERE";
                        update += $"{Utils.parseStringBD("zAdi_ItemCode")} = '{zAdi_ItemCode}'";

                        DBConn.ExecQueryUpdate(update, DBConn.ConectionDB.Bitacoras);

                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("SyncUpdateCat", "", ex.ToString());
            }

            //Utils.PrintLog("querySelectSAP", "0", $"Fin------");
        }
    }

    public class productoModel
    {
        public int idMaster { get; set; }
        public int idGen { get; set; }
        public int idOfer { get; set; }
        public int idLiq { get; set; }
        public double priceMaster { get; set; }
        public double priceGen { get; set; }
        public double priceOfer { get; set; }
        public double priceLiq { get; set; }

        public string categoriasMaster { get; set; }
    }
}
