﻿using SAP_LIB.Controllers;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SapService.Modules
{
    public class Orders
    {
        #region Orders
        #region Bitacoras MYSQL
        //aqui ira la sincronizacion de las bitacoras
        public void RegisterFromMysqlBitacoraToSap()
        {
            //string path = "C:\\LogOrdersAlan.txt";

            try
            {
                string QueryMasterOrders = "SELECT * FROM zAdi_SyncOrder WHERE flagSend IS NOT NULL AND flagSend = 0";
                DataTable DtOrdersList = DBConnMysql.ExecQuery(QueryMasterOrders);

                if (DtOrdersList != null && DtOrdersList.Rows != null && DtOrdersList.Rows.Count > 0)
                {
                    foreach (DataRow rowOrderItemMysql in DtOrdersList.Rows)
                    {
                        #region Order Master Fields
                        int insert_idSyncOrder = int.Parse(rowOrderItemMysql.ItemArray[0].ToString());
                        string insert_order_id = (rowOrderItemMysql.ItemArray[1].ToString() != "" && rowOrderItemMysql.ItemArray[1].ToString() != null) ? rowOrderItemMysql.ItemArray[1].ToString() : null;
                        string insert_parent_id = (rowOrderItemMysql.ItemArray[2].ToString() != "" && rowOrderItemMysql.ItemArray[2].ToString() != null) ? rowOrderItemMysql.ItemArray[2].ToString() : "0";
                        string insert_date_created = (GetDateFormatToSap(rowOrderItemMysql.ItemArray[3].ToString()) != "" && GetDateFormatToSap(rowOrderItemMysql.ItemArray[3].ToString()) != null) ? GetDateFormatToSap(rowOrderItemMysql.ItemArray[3].ToString()) : null;
                        string insert_num_items_sold = (rowOrderItemMysql.ItemArray[4].ToString() != "" && rowOrderItemMysql.ItemArray[4].ToString() != null) ? rowOrderItemMysql.ItemArray[4].ToString() : null;
                        string insert_total_sales = (rowOrderItemMysql.ItemArray[5].ToString() != "" && rowOrderItemMysql.ItemArray[5].ToString() != null) ? rowOrderItemMysql.ItemArray[5].ToString() : null;
                        string insert_tax_total = (rowOrderItemMysql.ItemArray[6].ToString() != "" && rowOrderItemMysql.ItemArray[6].ToString() != null) ? rowOrderItemMysql.ItemArray[6].ToString() : null;
                        string insert_shipping_total = (rowOrderItemMysql.ItemArray[7].ToString() != "" && rowOrderItemMysql.ItemArray[7].ToString() != null) ? rowOrderItemMysql.ItemArray[7].ToString() : null;
                        string insert_net_total = (rowOrderItemMysql.ItemArray[8].ToString() != "" && rowOrderItemMysql.ItemArray[8].ToString() != null) ? rowOrderItemMysql.ItemArray[8].ToString() : null;
                        string insert_returning_customer = (rowOrderItemMysql.ItemArray[9].ToString() != "" && rowOrderItemMysql.ItemArray[9].ToString() != null) ? rowOrderItemMysql.ItemArray[9].ToString() : null;
                        string insert_status = (rowOrderItemMysql.ItemArray[10].ToString() != "" && rowOrderItemMysql.ItemArray[10].ToString() != null) ? rowOrderItemMysql.ItemArray[10].ToString() : null;
                        string insert_customer_id = (rowOrderItemMysql.ItemArray[11].ToString() != "" && rowOrderItemMysql.ItemArray[11].ToString() != null) ? rowOrderItemMysql.ItemArray[11].ToString() : null;
                        string insert_umeta_id = (rowOrderItemMysql.ItemArray[12].ToString() != "" && rowOrderItemMysql.ItemArray[12].ToString() != null) ? rowOrderItemMysql.ItemArray[12].ToString() : "0";
                        string insert_tsmShippingAddresses = (rowOrderItemMysql.ItemArray[13].ToString() != "" && rowOrderItemMysql.ItemArray[13].ToString() != null) ? rowOrderItemMysql.ItemArray[13].ToString() : null;
                        string insert__edit_lock = (rowOrderItemMysql.ItemArray[14].ToString() != "" && rowOrderItemMysql.ItemArray[14].ToString() != null) ? rowOrderItemMysql.ItemArray[14].ToString() : null;
                        string insert__order_stock_reduced = (rowOrderItemMysql.ItemArray[15].ToString() != "" && rowOrderItemMysql.ItemArray[15].ToString() != null) ? rowOrderItemMysql.ItemArray[15].ToString() : null;
                        string insert__recorded_coupon_usage_counts = (rowOrderItemMysql.ItemArray[16].ToString() != "" && rowOrderItemMysql.ItemArray[16].ToString() != null) ? rowOrderItemMysql.ItemArray[16].ToString() : null;
                        string insert__recorded_sales = (rowOrderItemMysql.ItemArray[17].ToString() != "" && rowOrderItemMysql.ItemArray[17].ToString() != null) ? rowOrderItemMysql.ItemArray[17].ToString() : null;
                        string insert_thwcfe_ship_to_billing = (rowOrderItemMysql.ItemArray[18].ToString() != "" && rowOrderItemMysql.ItemArray[18].ToString() != null) ? rowOrderItemMysql.ItemArray[18].ToString() : null;
                        string insert_is_vat_exempt = (rowOrderItemMysql.ItemArray[19].ToString() != "" && rowOrderItemMysql.ItemArray[19].ToString() != null) ? rowOrderItemMysql.ItemArray[19].ToString() : null;
                        string insert__shipping_address_index = (rowOrderItemMysql.ItemArray[20].ToString() != "" && rowOrderItemMysql.ItemArray[20].ToString() != null) ? rowOrderItemMysql.ItemArray[20].ToString() : null;
                        string insert__billing_address_index = (rowOrderItemMysql.ItemArray[21].ToString() != "" && rowOrderItemMysql.ItemArray[21].ToString() != null) ? rowOrderItemMysql.ItemArray[21].ToString() : null;

                        string insert__prices_include_tax = (rowOrderItemMysql.ItemArray[22].ToString() != "" && rowOrderItemMysql.ItemArray[22].ToString() != null) ? rowOrderItemMysql.ItemArray[22].ToString() : "";
                        string insert__order_version = (rowOrderItemMysql.ItemArray[23].ToString() != "" && rowOrderItemMysql.ItemArray[23].ToString() != null) ? rowOrderItemMysql.ItemArray[23].ToString() : "";
                        string insert__order_total = (rowOrderItemMysql.ItemArray[24].ToString() != "" && rowOrderItemMysql.ItemArray[24].ToString() != null) ? rowOrderItemMysql.ItemArray[24].ToString() : "";
                        string insert__order_tax = (rowOrderItemMysql.ItemArray[25].ToString() != "" && rowOrderItemMysql.ItemArray[25].ToString() != null) ? rowOrderItemMysql.ItemArray[25].ToString() : "";
                        string insert__order_shipping_tax = (rowOrderItemMysql.ItemArray[26].ToString() != "" && rowOrderItemMysql.ItemArray[26].ToString() != null) ? rowOrderItemMysql.ItemArray[26].ToString() : "";
                        string insert__order_shipping = (rowOrderItemMysql.ItemArray[27].ToString() != "" && rowOrderItemMysql.ItemArray[27].ToString() != null) ? rowOrderItemMysql.ItemArray[27].ToString() : "";
                        string insert__cart_discount_tax = (rowOrderItemMysql.ItemArray[28].ToString() != "" && rowOrderItemMysql.ItemArray[28].ToString() != null) ? rowOrderItemMysql.ItemArray[28].ToString() : "";
                        string insert__cart_discount = (rowOrderItemMysql.ItemArray[29].ToString() != "" && rowOrderItemMysql.ItemArray[29].ToString() != null) ? rowOrderItemMysql.ItemArray[29].ToString() : "";
                        string insert__order_currency = (rowOrderItemMysql.ItemArray[30].ToString() != "" && rowOrderItemMysql.ItemArray[30].ToString() != null) ? rowOrderItemMysql.ItemArray[30].ToString() : "";
                        string insert__shipping_country = (rowOrderItemMysql.ItemArray[31].ToString() != "" && rowOrderItemMysql.ItemArray[31].ToString() != null) ? rowOrderItemMysql.ItemArray[31].ToString() : "";
                        string insert__shipping_postcode = (rowOrderItemMysql.ItemArray[32].ToString() != "" && rowOrderItemMysql.ItemArray[32].ToString() != null) ? rowOrderItemMysql.ItemArray[32].ToString() : "";
                        string insert__shipping_state = (rowOrderItemMysql.ItemArray[33].ToString() != "" && rowOrderItemMysql.ItemArray[33].ToString() != null) ? rowOrderItemMysql.ItemArray[33].ToString() : "";
                        string insert__shipping_city = (rowOrderItemMysql.ItemArray[34].ToString() != "" && rowOrderItemMysql.ItemArray[34].ToString() != null) ? rowOrderItemMysql.ItemArray[34].ToString() : "";
                        string insert__shipping_address_2 = (rowOrderItemMysql.ItemArray[35].ToString() != "" && rowOrderItemMysql.ItemArray[35].ToString() != null) ? rowOrderItemMysql.ItemArray[35].ToString() : "";
                        string insert__shipping_address_1 = (rowOrderItemMysql.ItemArray[36].ToString() != "" && rowOrderItemMysql.ItemArray[36].ToString() != null) ? rowOrderItemMysql.ItemArray[36].ToString() : "";
                        string insert__shipping_company = (rowOrderItemMysql.ItemArray[37].ToString() != "" && rowOrderItemMysql.ItemArray[37].ToString() != null) ? rowOrderItemMysql.ItemArray[37].ToString() : "";
                        string insert__shipping_last_name = (rowOrderItemMysql.ItemArray[38].ToString() != "" && rowOrderItemMysql.ItemArray[38].ToString() != null) ? rowOrderItemMysql.ItemArray[38].ToString() : "";
                        string insert__shipping_first_name = (rowOrderItemMysql.ItemArray[39].ToString() != "" && rowOrderItemMysql.ItemArray[39].ToString() != null) ? rowOrderItemMysql.ItemArray[39].ToString() : "";
                        string insert__billing_phone = (rowOrderItemMysql.ItemArray[40].ToString() != "" && rowOrderItemMysql.ItemArray[40].ToString() != null) ? rowOrderItemMysql.ItemArray[40].ToString() : "";
                        string insert__billing_email = (rowOrderItemMysql.ItemArray[41].ToString() != "" && rowOrderItemMysql.ItemArray[41].ToString() != null) ? rowOrderItemMysql.ItemArray[41].ToString() : "";

                        string insert__billing_country = (rowOrderItemMysql.ItemArray[42].ToString() != "" && rowOrderItemMysql.ItemArray[42].ToString() != null) ? rowOrderItemMysql.ItemArray[42].ToString() : ""; rowOrderItemMysql.ItemArray[0].ToString();
                        string insert__billing_postcode = (rowOrderItemMysql.ItemArray[43].ToString() != "" && rowOrderItemMysql.ItemArray[43].ToString() != null) ? rowOrderItemMysql.ItemArray[43].ToString() : "";
                        string insert__billing_state = (rowOrderItemMysql.ItemArray[44].ToString() != "" && rowOrderItemMysql.ItemArray[44].ToString() != null) ? rowOrderItemMysql.ItemArray[44].ToString() : "";
                        string insert__billing_city = (rowOrderItemMysql.ItemArray[45].ToString() != "" && rowOrderItemMysql.ItemArray[45].ToString() != null) ? rowOrderItemMysql.ItemArray[45].ToString() : "";
                        string insert__billing_address_2 = (rowOrderItemMysql.ItemArray[46].ToString() != "" && rowOrderItemMysql.ItemArray[46].ToString() != null) ? rowOrderItemMysql.ItemArray[46].ToString() : "";
                        string insert__billing_address_1 = (rowOrderItemMysql.ItemArray[47].ToString() != "" && rowOrderItemMysql.ItemArray[47].ToString() != null) ? rowOrderItemMysql.ItemArray[47].ToString() : "";
                        string insert__billing_company = (rowOrderItemMysql.ItemArray[48].ToString() != "" && rowOrderItemMysql.ItemArray[48].ToString() != null) ? rowOrderItemMysql.ItemArray[48].ToString() : "";
                        string insert__billing_last_name = (rowOrderItemMysql.ItemArray[49].ToString() != "" && rowOrderItemMysql.ItemArray[49].ToString() != null) ? rowOrderItemMysql.ItemArray[49].ToString() : "";
                        string insert__billing_first_name = (rowOrderItemMysql.ItemArray[50].ToString() != "" && rowOrderItemMysql.ItemArray[50].ToString() != null) ? rowOrderItemMysql.ItemArray[50].ToString() : "";
                        string insert__cart_hash = (rowOrderItemMysql.ItemArray[51].ToString() != "" && rowOrderItemMysql.ItemArray[51].ToString() != null) ? rowOrderItemMysql.ItemArray[51].ToString() : "";
                        string insert__created_via = (rowOrderItemMysql.ItemArray[52].ToString() != "" && rowOrderItemMysql.ItemArray[52].ToString() != null) ? rowOrderItemMysql.ItemArray[52].ToString() : "";
                        string insert__customer_user_agent = (rowOrderItemMysql.ItemArray[53].ToString() != "" && rowOrderItemMysql.ItemArray[53].ToString() != null) ? rowOrderItemMysql.ItemArray[53].ToString() : "";
                        string insert__customer_ip_address = (rowOrderItemMysql.ItemArray[54].ToString() != "" && rowOrderItemMysql.ItemArray[54].ToString() != null) ? rowOrderItemMysql.ItemArray[54].ToString() : "";
                        string insert__payment_method_title = (rowOrderItemMysql.ItemArray[55].ToString() != "" && rowOrderItemMysql.ItemArray[55].ToString() != null) ? rowOrderItemMysql.ItemArray[55].ToString() : "";
                        string insert__payment_method = (rowOrderItemMysql.ItemArray[56].ToString() != "" && rowOrderItemMysql.ItemArray[56].ToString() != null) ? rowOrderItemMysql.ItemArray[56].ToString() : "";
                        string insert__customer_user = (rowOrderItemMysql.ItemArray[57].ToString() != "" && rowOrderItemMysql.ItemArray[57].ToString() != null) ? rowOrderItemMysql.ItemArray[57].ToString() : "";
                        string insert__order_key = (rowOrderItemMysql.ItemArray[58].ToString() != "" && rowOrderItemMysql.ItemArray[58].ToString() != null) ? rowOrderItemMysql.ItemArray[58].ToString() : "";
                        string insert_action = (rowOrderItemMysql.ItemArray[59].ToString() != "" && rowOrderItemMysql.ItemArray[59].ToString() != null) ? rowOrderItemMysql.ItemArray[59].ToString() : "";
                        string insert_flagSend = (rowOrderItemMysql.ItemArray[60].ToString() != "" && rowOrderItemMysql.ItemArray[60].ToString() != null) ? rowOrderItemMysql.ItemArray[60].ToString() : "";
                        string insert_dateSend = (GetDateFormatToSap(rowOrderItemMysql.ItemArray[61].ToString()) != "" && GetDateFormatToSap(rowOrderItemMysql.ItemArray[61].ToString()) != null) ? GetDateFormatToSap(rowOrderItemMysql.ItemArray[61].ToString()) : "";
                        string insert_dateRegister = (GetDateFormatToSap(rowOrderItemMysql.ItemArray[62].ToString()) != "" && GetDateFormatToSap(rowOrderItemMysql.ItemArray[62].ToString()) != null) ? GetDateFormatToSap(rowOrderItemMysql.ItemArray[62].ToString()) : "";
                        string insert_shipping_pickup_stores = (rowOrderItemMysql["_shipping_pickup_stores"] != null && rowOrderItemMysql["_shipping_pickup_stores"].ToString() != "") ? rowOrderItemMysql["_shipping_pickup_stores"].ToString() : "";

                        string add_BitacoraOrdersSap = $"INSERT INTO {Utils.parseStringBD("zAdi_SyncOrder")} (";
                        //add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_idSyncOrder")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_order_id")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_parent_id")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_date_created")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_num_items_sold")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_total_sales")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_tax_total")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_shipping_total")},";

                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_net_total")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_returning_customer")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_status")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_customer_id")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_umeta_id")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_tsmShippingAddresses")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_edit_lock")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_order_stock_reduced")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_recorded_coupon_usage_counts")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_recorded_sales")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_thwcfe_ship_to_billing")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_is_vat_exempt")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_shipping_address_index")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_billing_address_index")},";

                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_prices_include_tax")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_order_version")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_order_total")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_order_tax")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_order_shipping_tax")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_order_shipping")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_cart_discount_tax")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_cart_discount")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_order_currency")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_shipping_country")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_shipping_postcode")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_shipping_state")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_shipping_city")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_shipping_address_2")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_shipping_address_1")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_shipping_company")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_shipping_last_name")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_shipping_first_name")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_billing_phone")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_billing_email")},";

                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_billing_country")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_billing_postcode")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_billing_state")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_billing_city")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_billing_address_2")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_billing_address_1")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_billing_company")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_billing_last_name")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_billing_first_name")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_cart_hash")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_created_via")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_customer_user_agent")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_customer_ip_address")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_payment_method_title")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_payment_method")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_customer_user")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_order_key")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_action")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_flagSend")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_dateSend")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_dateRegister")},";
                        add_BitacoraOrdersSap += $"{Utils.parseStringBD("zAdi_Sucursal")})";

                        add_BitacoraOrdersSap += $"VALUES(";
                        //add_BitacoraOrdersSap += $" {insert_idSyncOrder.ToString()},";
                        add_BitacoraOrdersSap += $" {insert_order_id},";
                        add_BitacoraOrdersSap += $" {insert_parent_id},";
                        add_BitacoraOrdersSap += $" '{insert_date_created}',";
                        add_BitacoraOrdersSap += $" '{insert_num_items_sold}',";
                        add_BitacoraOrdersSap += $" {insert_total_sales},";
                        add_BitacoraOrdersSap += $" {insert_tax_total},";
                        add_BitacoraOrdersSap += $" {insert_shipping_total},";

                        add_BitacoraOrdersSap += $" {insert_net_total},";
                        add_BitacoraOrdersSap += $" {insert_returning_customer},";
                        add_BitacoraOrdersSap += $" '{insert_status}',";
                        add_BitacoraOrdersSap += $" {insert_customer_id},";
                        add_BitacoraOrdersSap += $" {insert_umeta_id},";
                        add_BitacoraOrdersSap += $" '{insert_tsmShippingAddresses}',";
                        add_BitacoraOrdersSap += $" '{insert__edit_lock}',";
                        add_BitacoraOrdersSap += $" '{insert__order_stock_reduced}',";
                        add_BitacoraOrdersSap += $" '{insert__recorded_coupon_usage_counts}',";
                        add_BitacoraOrdersSap += $" '{insert__recorded_sales}',";
                        add_BitacoraOrdersSap += $" '{insert_thwcfe_ship_to_billing}',";
                        add_BitacoraOrdersSap += $" '{insert_is_vat_exempt}',";
                        add_BitacoraOrdersSap += $" '{insert__shipping_address_index}',";
                        add_BitacoraOrdersSap += $" '{insert__billing_address_index}',";

                        add_BitacoraOrdersSap += $" '{insert__prices_include_tax}',";
                        add_BitacoraOrdersSap += $" '{insert__order_version}',";
                        add_BitacoraOrdersSap += $" '{insert__order_total}',";
                        add_BitacoraOrdersSap += $" '{insert__order_tax}',";
                        add_BitacoraOrdersSap += $" '{insert__order_shipping_tax}',";
                        add_BitacoraOrdersSap += $" '{insert__order_shipping}',";
                        add_BitacoraOrdersSap += $" '{insert__cart_discount_tax}',";
                        add_BitacoraOrdersSap += $" '{insert__cart_discount}',";
                        add_BitacoraOrdersSap += $" '{insert__order_currency}',";
                        add_BitacoraOrdersSap += $" '{insert__shipping_country}',";
                        add_BitacoraOrdersSap += $" '{insert__shipping_postcode}',";
                        add_BitacoraOrdersSap += $" '{insert__shipping_state}',";
                        add_BitacoraOrdersSap += $" '{insert__shipping_city}',";
                        add_BitacoraOrdersSap += $" '{insert__shipping_address_2}',";
                        add_BitacoraOrdersSap += $" '{insert__shipping_address_1}',";
                        add_BitacoraOrdersSap += $" '{insert__shipping_company}',";
                        add_BitacoraOrdersSap += $" '{insert__shipping_last_name}',";
                        add_BitacoraOrdersSap += $" '{insert__shipping_first_name}',";
                        add_BitacoraOrdersSap += $" '{insert__billing_phone}',";
                        add_BitacoraOrdersSap += $" '{insert__billing_email}',";

                        add_BitacoraOrdersSap += $" '{insert__billing_country}',";
                        add_BitacoraOrdersSap += $" '{insert__billing_postcode}',";
                        add_BitacoraOrdersSap += $" '{insert__billing_state}',";
                        add_BitacoraOrdersSap += $" '{insert__billing_city}',";
                        add_BitacoraOrdersSap += $" '{insert__billing_address_2}',";
                        add_BitacoraOrdersSap += $" '{insert__billing_address_1}',";
                        add_BitacoraOrdersSap += $" '{insert__billing_company}',";
                        add_BitacoraOrdersSap += $" '{insert__billing_last_name}',";
                        add_BitacoraOrdersSap += $" '{insert__billing_first_name}',";
                        add_BitacoraOrdersSap += $" '{insert__cart_hash}',";
                        add_BitacoraOrdersSap += $" '{insert__created_via}',";
                        add_BitacoraOrdersSap += $" '{insert__customer_user_agent}',";
                        add_BitacoraOrdersSap += $" '{insert__customer_ip_address}',";
                        add_BitacoraOrdersSap += $" '{insert__payment_method_title}',";
                        add_BitacoraOrdersSap += $" '{insert__payment_method}',";
                        add_BitacoraOrdersSap += $" '{insert__customer_user}',";
                        add_BitacoraOrdersSap += $" '{insert__order_key}',";
                        add_BitacoraOrdersSap += $" '{insert_action}',";
                        add_BitacoraOrdersSap += $" {insert_flagSend},";
                        add_BitacoraOrdersSap += $" '{insert_dateSend}',";
                        add_BitacoraOrdersSap += $" '{insert_dateRegister}',";
                        add_BitacoraOrdersSap += $" '{insert_shipping_pickup_stores}'";

                        add_BitacoraOrdersSap += $");";
                        bool flgInsert = DBConn.ExecQueryInsert(add_BitacoraOrdersSap, DBConn.ConectionDB.Bitacoras);
                        if (flgInsert)
                        {
                            string select_id = $"SELECT TOP 1 {Utils.parseStringBD("zAdi_idSyncOrder")} FROM {Utils.parseStringBD("zAdi_SyncOrder")} WHERE {Utils.parseStringBD("zAdi_order_id")} = {insert_order_id}";
                            DataTable tbl_id = DBConn.ExecQuery(select_id, DBConn.ConectionDB.Bitacoras);
                            string id = "0";
                            if (tbl_id != null && tbl_id.Rows != null && tbl_id.Rows.Count > 0)
                            {
                                if (tbl_id.Rows[0]["zAdi_idSyncOrder"] != null && !string.IsNullOrEmpty(tbl_id.Rows[0]["zAdi_idSyncOrder"].ToString()))
                                    id = tbl_id.Rows[0]["zAdi_idSyncOrder"].ToString();
                            }

                            RegisterDetailMysqlBitacoraToSap(int.Parse(insert_order_id), id);
                            string updateBitacoraOrders = $"UPDATE zAdi_SyncOrder SET flagSend = 1, dateSend = NOW() WHERE idSyncOrder = {insert_idSyncOrder.ToString()}";
                            DBConnMysql.ExecQueryUpdate(updateBitacoraOrders);
                        }
                        else
                        {
                            Utils.PrintLog("RegisterFromMysqlBitacoraToSap", "0", $"No fue posible realizar la sincronización del pedido {insert_order_id}. \n query: {add_BitacoraOrdersSap}");
                        }

                        //using (StreamWriter writer = new StreamWriter(path, true))
                        //{
                        //    writer.WriteLine(string.Format($"{flgInsert.ToString()}\n query {add_BitacoraOrdersSap}"));
                        //    writer.Close();
                        //}
                        #endregion
                    }
                }


            }
            catch (Exception ex)
            {
                Utils.PrintLog("RegisterFromMysqlBitacoraToSap", "1", ex.ToString());
            }
        }

        public void RegisterDetailMysqlBitacoraToSap(int OrderId, string idSyncOrder)
        {
            //string path = "C:\\LogDetailOrdersAlan.txt";
            try
            {
                string QueryGetDetailOrders = $"SELECT * FROM zAdi_SyncOrderItems WHERE order_id = {OrderId.ToString()}";
                DataTable dtDetailOrders = DBConnMysql.ExecQuery(QueryGetDetailOrders);
                string add_OrderDetailBitacora = "";
                //int insert_idSyncOrder = 0;
                string insert_order_item_id = "";
                string insert_order_id = "";
                string insert_isproduct = "";
                string insert_product_id = "";
                string insert_order_item_name = "";
                string insert_order_item_type = "";
                string insert_date_created = "";
                string insert_product_qty = "";
                string insert_product_net_revenue = "";
                string insert_product_gross_revenue = "";
                string insert_coupon_amount = "";
                string insert_tax_amount = "";
                string insert_shipping_amount = "";
                string insert_shiping_tax_amount = "";
                string insert_line_tax_data = "";
                string insert_line_tax = "";
                string insert_line_total = "";
                string insert_line_subtotal_tax = "";
                string insert_line_subtotal = "";
                string insert_tax_class = "";
                string insert_qty = "";
                string insert_variation_id = "";
                string insert_zproduct_id = "";
                string insert_articulos = "";
                string insert_taxes = "";
                string insert_total_tax = "";
                string insert_cost = "";
                string insert_instance_id = "";
                string insert_method_id = "";
                string insert_sku = "";
                string insert_post_id = "";
                string insert_meta_key = "";
                string insert_meta_value = "";
                if (dtDetailOrders != null && dtDetailOrders.Rows != null && dtDetailOrders.Rows.Count > 0)
                {
                    foreach (DataRow rowDetailOrder in dtDetailOrders.Rows)
                    {
                        //insert_idSyncOrder = int.Parse(rowDetailOrder.ItemArray[0].ToString());
                        insert_order_item_id = (rowDetailOrder.ItemArray[1].ToString() != null && rowDetailOrder.ItemArray[1].ToString() != "") ? rowDetailOrder.ItemArray[1].ToString() : "";
                        insert_order_id = (rowDetailOrder.ItemArray[2].ToString() != null && rowDetailOrder.ItemArray[2].ToString() != "") ? rowDetailOrder.ItemArray[2].ToString() : "";
                        insert_isproduct = (rowDetailOrder.ItemArray[3].ToString() != null && rowDetailOrder.ItemArray[3].ToString() != "") ? rowDetailOrder.ItemArray[3].ToString() : "";
                        insert_product_id = (rowDetailOrder.ItemArray[4].ToString() != null && rowDetailOrder.ItemArray[4].ToString() != "") ? rowDetailOrder.ItemArray[4].ToString() : "";
                        insert_order_item_name = (rowDetailOrder.ItemArray[5].ToString() != null && rowDetailOrder.ItemArray[5].ToString() != "") ? rowDetailOrder.ItemArray[5].ToString() : "";
                        insert_order_item_type = (rowDetailOrder.ItemArray[6].ToString() != null && rowDetailOrder.ItemArray[6].ToString() != "") ? rowDetailOrder.ItemArray[6].ToString() : "";
                        insert_date_created = (GetDateFormatToSap(rowDetailOrder.ItemArray[7].ToString()) != null && GetDateFormatToSap(rowDetailOrder.ItemArray[7].ToString()) != "") ? GetDateFormatToSap(rowDetailOrder.ItemArray[7].ToString()) : null;
                        insert_product_qty = (rowDetailOrder.ItemArray[8].ToString() != null && rowDetailOrder.ItemArray[8].ToString() != "") ? rowDetailOrder.ItemArray[8].ToString() : "";
                        insert_product_net_revenue = (rowDetailOrder.ItemArray[9].ToString() != null && rowDetailOrder.ItemArray[9].ToString() != "") ? rowDetailOrder.ItemArray[9].ToString() : "";
                        insert_product_gross_revenue = (rowDetailOrder.ItemArray[10].ToString() != null && rowDetailOrder.ItemArray[10].ToString() != "") ? rowDetailOrder.ItemArray[10].ToString() : "";
                        insert_coupon_amount = (rowDetailOrder.ItemArray[11].ToString() != null && rowDetailOrder.ItemArray[11].ToString() != "") ? rowDetailOrder.ItemArray[11].ToString() : "";
                        insert_tax_amount = (rowDetailOrder.ItemArray[12].ToString() != null && rowDetailOrder.ItemArray[12].ToString() != "") ? rowDetailOrder.ItemArray[12].ToString() : "";
                        insert_shipping_amount = (rowDetailOrder.ItemArray[13].ToString() != null && rowDetailOrder.ItemArray[13].ToString() != "") ? rowDetailOrder.ItemArray[13].ToString() : "";
                        insert_shiping_tax_amount = (rowDetailOrder.ItemArray[14].ToString() != null && rowDetailOrder.ItemArray[14].ToString() != "") ? rowDetailOrder.ItemArray[14].ToString() : "";
                        insert_line_tax_data = (rowDetailOrder.ItemArray[15].ToString() != null && rowDetailOrder.ItemArray[15].ToString() != "") ? rowDetailOrder.ItemArray[15].ToString() : "";

                        insert_line_tax = (rowDetailOrder.ItemArray[16].ToString() != null && rowDetailOrder.ItemArray[16].ToString() != "") ? rowDetailOrder.ItemArray[16].ToString() : "";
                        insert_line_total = (rowDetailOrder.ItemArray[17].ToString() != null && rowDetailOrder.ItemArray[17].ToString() != "") ? rowDetailOrder.ItemArray[17].ToString() : "";
                        insert_line_subtotal_tax = (rowDetailOrder.ItemArray[18].ToString() != null && rowDetailOrder.ItemArray[18].ToString() != "") ? rowDetailOrder.ItemArray[18].ToString() : "";
                        insert_line_subtotal = (rowDetailOrder.ItemArray[19].ToString() != null && rowDetailOrder.ItemArray[19].ToString() != "") ? rowDetailOrder.ItemArray[19].ToString() : "";
                        insert_tax_class = (rowDetailOrder.ItemArray[20].ToString() != null && rowDetailOrder.ItemArray[20].ToString() != "") ? rowDetailOrder.ItemArray[20].ToString() : "";
                        insert_qty = (rowDetailOrder.ItemArray[21].ToString() != null && rowDetailOrder.ItemArray[21].ToString() != "") ? rowDetailOrder.ItemArray[21].ToString() : "";
                        insert_variation_id = (rowDetailOrder.ItemArray[22].ToString() != null && rowDetailOrder.ItemArray[22].ToString() != "") ? rowDetailOrder.ItemArray[22].ToString() : "";
                        insert_zproduct_id = (rowDetailOrder.ItemArray[23].ToString() != null && rowDetailOrder.ItemArray[23].ToString() != "") ? rowDetailOrder.ItemArray[23].ToString() : "";
                        insert_articulos = (rowDetailOrder.ItemArray[24].ToString() != null && rowDetailOrder.ItemArray[24].ToString() != "") ? rowDetailOrder.ItemArray[24].ToString() : "";
                        insert_taxes = (rowDetailOrder.ItemArray[25].ToString() != null && rowDetailOrder.ItemArray[25].ToString() != "") ? rowDetailOrder.ItemArray[25].ToString() : "";
                        insert_total_tax = (rowDetailOrder.ItemArray[26].ToString() != null && rowDetailOrder.ItemArray[26].ToString() != "") ? rowDetailOrder.ItemArray[26].ToString() : "";
                        insert_cost = (rowDetailOrder.ItemArray[27].ToString() != null && rowDetailOrder.ItemArray[27].ToString() != "") ? rowDetailOrder.ItemArray[27].ToString() : "";
                        insert_instance_id = (rowDetailOrder.ItemArray[28].ToString() != null && rowDetailOrder.ItemArray[28].ToString() != "") ? rowDetailOrder.ItemArray[28].ToString() : "";
                        insert_method_id = (rowDetailOrder.ItemArray[29].ToString() != null && rowDetailOrder.ItemArray[29].ToString() != "") ? rowDetailOrder.ItemArray[29].ToString() : "";
                        insert_sku = (rowDetailOrder.ItemArray[30].ToString() != null && rowDetailOrder.ItemArray[30].ToString() != "") ? rowDetailOrder.ItemArray[30].ToString() : "";
                        insert_post_id = (rowDetailOrder.ItemArray[31].ToString() != null && rowDetailOrder.ItemArray[31].ToString() != "") ? rowDetailOrder.ItemArray[31].ToString() : "0";
                        insert_meta_key = (rowDetailOrder.ItemArray[32].ToString() != null && rowDetailOrder.ItemArray[32].ToString() != "") ? rowDetailOrder.ItemArray[32].ToString() : "";
                        insert_meta_value = (rowDetailOrder.ItemArray[33].ToString() != null && rowDetailOrder.ItemArray[33].ToString() != "") ? rowDetailOrder.ItemArray[33].ToString() : "";
                        add_OrderDetailBitacora = $"INSERT INTO {Utils.parseStringBD("zAdi_SyncOrderItems")}(";
                        add_OrderDetailBitacora += $"{Utils.parseStringBD("zAdi_idSyncOrder")},";
                        add_OrderDetailBitacora += $"{Utils.parseStringBD("zAdi_order_item_id")},";
                        add_OrderDetailBitacora += $"{Utils.parseStringBD("zAdi_order_id")},";
                        add_OrderDetailBitacora += $"{Utils.parseStringBD("zAdi_isproduct")},";
                        add_OrderDetailBitacora += $"{Utils.parseStringBD("zAdi_product_id")},";
                        add_OrderDetailBitacora += $"{Utils.parseStringBD("zAdi_order_item_name")},";
                        add_OrderDetailBitacora += $"{Utils.parseStringBD("zAdi_order_item_type")},";
                        add_OrderDetailBitacora += $"{Utils.parseStringBD("zAdi_date_created")},";
                        add_OrderDetailBitacora += $"{Utils.parseStringBD("zAdi_product_qty")},";
                        add_OrderDetailBitacora += $"{Utils.parseStringBD("zAdi_product_net_revenue")},";
                        add_OrderDetailBitacora += $"{Utils.parseStringBD("zAdi_product_gross_revenue")},";
                        add_OrderDetailBitacora += $"{Utils.parseStringBD("zAdi_coupon_amount")},";
                        add_OrderDetailBitacora += $"{Utils.parseStringBD("zAdi_tax_amount")},";
                        add_OrderDetailBitacora += $"{Utils.parseStringBD("zAdi_shipping_amount")},";
                        add_OrderDetailBitacora += $"{Utils.parseStringBD("zAdi_shiping_tax_amount")},";
                        add_OrderDetailBitacora += $"{Utils.parseStringBD("zAdi_line_tax_data")},";

                        add_OrderDetailBitacora += $"{Utils.parseStringBD("zAdi_line_tax")},";
                        add_OrderDetailBitacora += $"{Utils.parseStringBD("zAdi_line_total")},";
                        add_OrderDetailBitacora += $"{Utils.parseStringBD("zAdi_line_subtotal_tax")},";
                        add_OrderDetailBitacora += $"{Utils.parseStringBD("zAdi_line_subtotal")},";
                        add_OrderDetailBitacora += $"{Utils.parseStringBD("zAdi_tax_class")},";
                        add_OrderDetailBitacora += $"{Utils.parseStringBD("zAdi_qty")},";
                        add_OrderDetailBitacora += $"{Utils.parseStringBD("zAdi_variation_id")},";
                        add_OrderDetailBitacora += $"{Utils.parseStringBD("zAdi_zproduct_id")},";
                        add_OrderDetailBitacora += $"{Utils.parseStringBD("zAdi_articulos")},";
                        add_OrderDetailBitacora += $"{Utils.parseStringBD("zAdi_taxes")},";
                        add_OrderDetailBitacora += $"{Utils.parseStringBD("zAdi_total_tax")},";
                        add_OrderDetailBitacora += $"{Utils.parseStringBD("zAdi_cost")},";
                        add_OrderDetailBitacora += $"{Utils.parseStringBD("zAdi_instance_id")},";
                        add_OrderDetailBitacora += $"{Utils.parseStringBD("zAdi_method_id")},";
                        add_OrderDetailBitacora += $"{Utils.parseStringBD("zAdi_sku")},";
                        add_OrderDetailBitacora += $"{Utils.parseStringBD("zAdi_post_id")},";
                        add_OrderDetailBitacora += $"{Utils.parseStringBD("zAdi_meta_key")},";
                        add_OrderDetailBitacora += $"{Utils.parseStringBD("zAdi_meta_value")})";


                        add_OrderDetailBitacora += $"VALUES(";
                        add_OrderDetailBitacora += $" {idSyncOrder.ToString()},";
                        add_OrderDetailBitacora += $" {insert_order_item_id},";
                        add_OrderDetailBitacora += $" {OrderId},";
                        add_OrderDetailBitacora += $" {insert_isproduct.ToString()},";
                        add_OrderDetailBitacora += $" {insert_product_id},";
                        add_OrderDetailBitacora += $" '{insert_order_item_name}',";
                        add_OrderDetailBitacora += $" '{insert_order_item_type}',";
                        add_OrderDetailBitacora += $" '{insert_date_created}',";
                        add_OrderDetailBitacora += $" {insert_product_qty},";
                        add_OrderDetailBitacora += $" {insert_product_net_revenue},";
                        add_OrderDetailBitacora += $" {insert_product_gross_revenue},";
                        add_OrderDetailBitacora += $" {insert_coupon_amount},";
                        add_OrderDetailBitacora += $" {insert_tax_amount},";
                        add_OrderDetailBitacora += $" {insert_shipping_amount},";
                        add_OrderDetailBitacora += $" {insert_shiping_tax_amount},";
                        add_OrderDetailBitacora += $" '{insert_line_tax_data}',";


                        add_OrderDetailBitacora += $" '{insert_line_tax}',";
                        add_OrderDetailBitacora += $" '{insert_line_total}',";
                        add_OrderDetailBitacora += $" '{insert_line_subtotal_tax}',";
                        add_OrderDetailBitacora += $" '{insert_line_subtotal}',";
                        add_OrderDetailBitacora += $" '{insert_tax_class}',";
                        add_OrderDetailBitacora += $" '{insert_qty}',";
                        add_OrderDetailBitacora += $" '{insert_variation_id}',";
                        add_OrderDetailBitacora += $" '{insert_zproduct_id}',";
                        add_OrderDetailBitacora += $" '{insert_articulos}',";
                        add_OrderDetailBitacora += $" '{insert_taxes}',";
                        add_OrderDetailBitacora += $" '{insert_total_tax}',";
                        add_OrderDetailBitacora += $" '{insert_cost}',";
                        add_OrderDetailBitacora += $" '{insert_instance_id}',";
                        add_OrderDetailBitacora += $" '{insert_method_id}',";
                        add_OrderDetailBitacora += $" '{insert_sku}',";
                        add_OrderDetailBitacora += $" {insert_post_id},";
                        add_OrderDetailBitacora += $" '{insert_meta_key}',";
                        add_OrderDetailBitacora += $" '{insert_meta_value}'";
                        add_OrderDetailBitacora += $");";
                        bool flgInsert = DBConn.ExecQueryInsert(add_OrderDetailBitacora, DBConn.ConectionDB.Bitacoras);
                        if (!flgInsert)
                        {
                            Utils.PrintLog("RegisterDetailMysqlBitacoraToSap", "0", $"No fue posible realizar la sincronización del item {insert_order_item_id}");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("RegisterDetailMysqlBitacoraToSap", "1", ex.ToString());
            }
        }

        public string GetDateFormatToSap(string dateRow)
        {
            if (dateRow != "")
            {
                string newdate_created = dateRow.Replace("a. m.", "").Replace("p. m.", "");
                DateTime dtm_date = DateTime.Parse(newdate_created);
                string formatDate = dtm_date.ToString("yyyy-MM-dd HH:mm:ss");
                return formatDate;
            }
            return "";

        }
        #endregion

        public void CreateBOMQuotation(/*string cardcode, DataTable list_sales_items*/)
        {
            try
            {
                BOMQuotation.BOM bOM;
                bOM = new BOMQuotation.BOM();
                bOM.BO = new BOMQuotation.BOMBO[1];
                bOM.BO[0] = new BOMQuotation.BOMBO();

                //nodo admininfo
                bOM.BO[0].AdmInfo = new BOMQuotation.BOMBOAdmInfo { Object = WSIL.TipoObjeto.oQuotations.ToString() };
                bOM.BO[0].Documents = new BOMQuotation.BOMBORow[1];
                bOM.BO[0].Documents[0] = new BOMQuotation.BOMBORow
                {
                    DocDate = DateTime.Now.ToString("yyyyMMdd"),
                    DocDueDate = DateTime.Now.ToString("yyyyMMdd"),
                    CardCode = "GDL-00436"
                };
                bOM.BO[0].Document_Lines = new BOMQuotation.BOMBORow2[1];
                bOM.BO[0].Document_Lines[0] = new BOMQuotation.BOMBORow2
                {
                    ItemCode = "RM5-WKS-2MN-NA",
                    //(string)list_sales_items.Rows[0]["zAdi_sku"],
                    Quantity = 2,
                    //(double)list_sales_items.Rows[0]["zAdi_qty"],
                    QuantitySpecified = true
                };
                //bOM.BO[0].Document_Lines[1] = new BOMInvoice.BOMBORow2
                //{
                //    ItemCode = txtItem02Inv.Text,
                //    Quantity = Convert.ToDouble(txtQuantity02Inv.Text),
                //    QuantitySpecified = true
                //};

                string strXML;
                System.Xml.Serialization.XmlSerializerNamespaces ns;

                ns = new System.Xml.Serialization.XmlSerializerNamespaces();
                ns.Add("", "");
                strXML = DIServerApi.getInstance.ObjToStringXML<BOMQuotation.BOM>(bOM, ns, true);


                string bomQuotationXml = DIServerApi.getInstance.FormatXML(strXML);
                Utils.PrintLog("Orders", "LINE 500 print xml", strXML);
            }
            catch (Exception e)
            {

                Utils.PrintLog("Orders", "LINE 505 CATCH ERROR print xml", e.ToString());

            }


        }

        
        public void SyncLogsToOrders()
        {
            //string path = "C:\\SyncLogsToOrders.txt";
            try
            {
                //Anotaciones
                //pasar la persona de contacto correcta. (Hacer consulta)-> listo


                string query_selectLogs = $@"SELECT TOP {Utils.rangoRegistros_Pedidos}";
                #region columnsSelectLogs
                query_selectLogs += $"{Utils.parseStringBD("zAdi_idSyncOrder")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_order_id")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_parent_id")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_date_created")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_num_items_sold")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_total_sales")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_tax_total")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_shipping_total")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_net_total")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_returning_customer")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_status")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_customer_id")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_umeta_id")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_tsmShippingAddresses")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_edit_lock")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_order_stock_reduced")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_recorded_coupon_usage_counts")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_recorded_sales")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_thwcfe_ship_to_billing")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_is_vat_exempt")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_shipping_address_index")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_billing_address_index")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_prices_include_tax")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_order_version")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_order_total")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_order_tax")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_order_shipping_tax")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_order_shipping")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_cart_discount_tax")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_cart_discount")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_order_currency")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_shipping_country")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_shipping_postcode")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_shipping_state")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_shipping_city")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_shipping_address_2")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_shipping_address_1")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_shipping_company")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_shipping_last_name")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_shipping_first_name")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_billing_phone")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_billing_email")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_billing_country")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_billing_postcode")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_billing_state")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_billing_city")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_billing_address_2")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_billing_address_1")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_billing_company")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_billing_last_name")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_billing_first_name")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_cart_hash")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_created_via")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_customer_user_agent")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_customer_ip_address")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_payment_method_title")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_payment_method")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_customer_user")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_Sucursal")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_order_key")}";
                #endregion
                query_selectLogs += $" FROM {Utils.parseStringBD("zAdi_SyncOrder")}";
                query_selectLogs += $" WHERE {Utils.parseStringBD("zAdi_flagSend")} = FALSE AND {Utils.parseStringBD("zAdi_action")} = 'INSERT'";

                DataTable tbl_query_seleccLog = DBConn.ExecQuery(query_selectLogs, DBConn.ConectionDB.Bitacoras);
                if (tbl_query_seleccLog != null && tbl_query_seleccLog.Rows != null && tbl_query_seleccLog.Rows.Count > 0)
                {
                    string query_TC_Comercial = $"SELECT TOP 1 {Utils.parseStringBD("U_Fecha")}, {Utils.parseStringBD("U_TC_Comercial")} FROM {Utils.parseStringBD("@TC_COMERCIAL")} ORDER BY TO_DATE(REPLACE(REPLACE({Utils.parseStringBD("U_Fecha")}, '/', ''), '-', ''), 'DDMMYYYY') DESC";
                    DataTable tbl_tc_comercial = DBConn.ExecQuery(query_TC_Comercial);
                    string tc_Comercial = tbl_tc_comercial != null && tbl_tc_comercial.Rows != null && tbl_tc_comercial.Rows.Count > 0 ? tbl_tc_comercial.Rows[0]["U_TC_Comercial"].ToString() : "1";
                    string fe_tc_Comercial = tbl_tc_comercial != null && tbl_tc_comercial.Rows != null && tbl_tc_comercial.Rows.Count > 0 ? tbl_tc_comercial.Rows[0]["U_Fecha"].ToString() : "";
                    fe_tc_Comercial = fe_tc_Comercial.Replace("-", "/");

                    string FinncPriod = "0";
                    string Code = DateTime.Now.ToString("yyyy-MM");
                    string select_finnPriod = $"SELECT TOP 1 {Utils.parseStringBD("AbsEntry")} FROM {Utils.parseStringBD("OFPR")} WHERE {Utils.parseStringBD("Code")} = '{Code}'";
                    DataTable tbl_FinncPriod = DBConn.ExecQuery(select_finnPriod);
                    if (tbl_FinncPriod != null && tbl_FinncPriod.Rows != null && tbl_FinncPriod.Rows.Count > 0)
                    {
                        if (tbl_FinncPriod.Rows[0]["AbsEntry"] != null && !string.IsNullOrEmpty(tbl_FinncPriod.Rows[0]["AbsEntry"].ToString()))
                            FinncPriod = tbl_FinncPriod.Rows[0]["AbsEntry"].ToString();
                    }

                    foreach (DataRow row_query_selectLog in tbl_query_seleccLog.Rows)
                    {
                        #region tabla bitacoras cabecera

                        string idSyncOrder = row_query_selectLog["zAdi_idSyncOrder"] != null ? row_query_selectLog["zAdi_idSyncOrder"].ToString() : "0";
                        string order_id = row_query_selectLog["zAdi_order_id"] != null ? row_query_selectLog["zAdi_order_id"].ToString() : "";
                        string parent_id = row_query_selectLog["zAdi_parent_id"] != null ? row_query_selectLog["zAdi_parent_id"].ToString() : "";
                        string date_created = row_query_selectLog["zAdi_date_created"] != null ? row_query_selectLog["zAdi_date_created"].ToString() : "";
                        string num_items_sold = row_query_selectLog["zAdi_num_items_sold"] != null ? row_query_selectLog["zAdi_num_items_sold"].ToString() : "";
                        string total_sales = row_query_selectLog["zAdi_total_sales"] != null ? row_query_selectLog["zAdi_total_sales"].ToString() : "";
                        string tax_total = row_query_selectLog["zAdi_tax_total"] != null ? row_query_selectLog["zAdi_tax_total"].ToString() : "";
                        string shipping_total = row_query_selectLog["zAdi_shipping_total"] != null && !string.IsNullOrEmpty(row_query_selectLog["zAdi_shipping_total"].ToString()) ? row_query_selectLog["zAdi_shipping_total"].ToString() : "0";
                        string net_total = row_query_selectLog["zAdi_net_total"] != null ? row_query_selectLog["zAdi_net_total"].ToString() : "";
                        string returning_customer = row_query_selectLog["zAdi_returning_customer"] != null ? row_query_selectLog["zAdi_returning_customer"].ToString() : "";
                        string status = row_query_selectLog["zAdi_status"] != null ? row_query_selectLog["zAdi_status"].ToString() : "";
                        //string customer_id = row_query_selectLog["zAdi_customer_id"] != null ? row_query_selectLog["zAdi_customer_id"].ToString() : "0";
                        string umeta_id = row_query_selectLog["zAdi_umeta_id"] != null ? row_query_selectLog["zAdi_umeta_id"].ToString() : "";
                        string tsmShippingAddresses = row_query_selectLog["zAdi_tsmShippingAddresses"] != null ? row_query_selectLog["zAdi_tsmShippingAddresses"].ToString() : "";
                        string _edit_lock = row_query_selectLog["zAdi_edit_lock"] != null ? row_query_selectLog["zAdi_edit_lock"].ToString() : "";
                        string _order_stock_reduced = row_query_selectLog["zAdi_order_stock_reduced"] != null ? row_query_selectLog["zAdi_order_stock_reduced"].ToString() : "";
                        string _recorded_coupon_usage_counts = row_query_selectLog["zAdi_recorded_coupon_usage_counts"] != null ? row_query_selectLog["zAdi_recorded_coupon_usage_counts"].ToString() : "";
                        string _recorded_sales = row_query_selectLog["zAdi_recorded_sales"] != null ? row_query_selectLog["zAdi_recorded_sales"].ToString() : "";
                        string thwcfe_ship_to_billing = row_query_selectLog["zAdi_thwcfe_ship_to_billing"] != null ? row_query_selectLog["zAdi_thwcfe_ship_to_billing"].ToString() : "";
                        string is_vat_exempt = row_query_selectLog["zAdi_is_vat_exempt"] != null ? row_query_selectLog["zAdi_is_vat_exempt"].ToString() : "";
                        string _shipping_address_index = row_query_selectLog["zAdi_shipping_address_index"] != null ? row_query_selectLog["zAdi_shipping_address_index"].ToString() : "";
                        string _billing_address_index = row_query_selectLog["zAdi_billing_address_index"] != null ? row_query_selectLog["zAdi_billing_address_index"].ToString() : "";
                        string _prices_include_tax = row_query_selectLog["zAdi_prices_include_tax"] != null ? row_query_selectLog["zAdi_prices_include_tax"].ToString() : "";
                        string _order_version = row_query_selectLog["zAdi_order_version"] != null ? row_query_selectLog["zAdi_order_version"].ToString() : "";
                        string _order_total = row_query_selectLog["zAdi_order_total"] != null ? row_query_selectLog["zAdi_order_total"].ToString() : "";
                        string _order_tax = row_query_selectLog["zAdi_order_tax"] != null ? row_query_selectLog["zAdi_order_tax"].ToString() : "";
                        string _order_shipping_tax = row_query_selectLog["zAdi_order_shipping_tax"] != null ? row_query_selectLog["zAdi_order_shipping_tax"].ToString() : "";
                        string _order_shipping = row_query_selectLog["zAdi_order_shipping"] != null ? row_query_selectLog["zAdi_order_shipping"].ToString() : "";
                        string _cart_discount_tax = row_query_selectLog["zAdi_cart_discount_tax"] != null ? row_query_selectLog["zAdi_cart_discount_tax"].ToString() : "";
                        string _cart_discount = row_query_selectLog["zAdi_cart_discount"] != null ? row_query_selectLog["zAdi_cart_discount"].ToString() : "";
                        string _order_currency = row_query_selectLog["zAdi_order_currency"] != null ? row_query_selectLog["zAdi_order_currency"].ToString() : "";
                        string _shipping_country = row_query_selectLog["zAdi_shipping_country"] != null ? row_query_selectLog["zAdi_shipping_country"].ToString() : "";
                        string _shipping_postcode = row_query_selectLog["zAdi_shipping_postcode"] != null ? row_query_selectLog["zAdi_shipping_postcode"].ToString() : "";
                        string _shipping_state = row_query_selectLog["zAdi_shipping_state"] != null ? row_query_selectLog["zAdi_shipping_state"].ToString() : "";
                        string _shipping_city = row_query_selectLog["zAdi_shipping_city"] != null ? row_query_selectLog["zAdi_shipping_city"].ToString() : "";
                        string _shipping_address_2 = row_query_selectLog["zAdi_shipping_address_2"] != null ? row_query_selectLog["zAdi_shipping_address_2"].ToString() : "";
                        string _shipping_address_1 = row_query_selectLog["zAdi_shipping_address_1"] != null ? row_query_selectLog["zAdi_shipping_address_1"].ToString() : "";
                        string _shipping_company = row_query_selectLog["zAdi_shipping_company"] != null ? row_query_selectLog["zAdi_shipping_company"].ToString() : "";
                        string _shipping_last_name = row_query_selectLog["zAdi_shipping_last_name"] != null ? row_query_selectLog["zAdi_shipping_last_name"].ToString() : "";
                        string _shipping_first_name = row_query_selectLog["zAdi_shipping_first_name"] != null ? row_query_selectLog["zAdi_shipping_first_name"].ToString() : "";
                        string _billing_phone = row_query_selectLog["zAdi_billing_phone"] != null ? row_query_selectLog["zAdi_billing_phone"].ToString() : "";
                        string _billing_email = row_query_selectLog["zAdi_billing_email"] != null ? row_query_selectLog["zAdi_billing_email"].ToString() : "";
                        string _billing_country = row_query_selectLog["zAdi_billing_country"] != null ? row_query_selectLog["zAdi_billing_country"].ToString() : "";
                        string _billing_postcode = row_query_selectLog["zAdi_billing_postcode"] != null ? row_query_selectLog["zAdi_billing_postcode"].ToString() : "";
                        string _billing_state = row_query_selectLog["zAdi_billing_state"] != null ? row_query_selectLog["zAdi_billing_state"].ToString() : "";
                        string _billing_city = row_query_selectLog["zAdi_billing_city"] != null ? row_query_selectLog["zAdi_billing_city"].ToString() : "";
                        string _billing_address_2 = row_query_selectLog["zAdi_billing_address_2"] != null ? row_query_selectLog["zAdi_billing_address_2"].ToString() : "";
                        string _billing_address_1 = row_query_selectLog["zAdi_billing_address_1"] != null ? row_query_selectLog["zAdi_billing_address_1"].ToString() : "";
                        string _billing_company = row_query_selectLog["zAdi_billing_company"] != null ? row_query_selectLog["zAdi_billing_company"].ToString() : "";
                        string _billing_last_name = row_query_selectLog["zAdi_billing_last_name"] != null ? row_query_selectLog["zAdi_billing_last_name"].ToString() : "";
                        string _billing_first_name = row_query_selectLog["zAdi_billing_first_name"] != null ? row_query_selectLog["zAdi_billing_first_name"].ToString() : "";
                        string _cart_hash = row_query_selectLog["zAdi_cart_hash"] != null ? row_query_selectLog["zAdi_cart_hash"].ToString() : "";
                        string _created_via = row_query_selectLog["zAdi_created_via"] != null ? row_query_selectLog["zAdi_created_via"].ToString() : "";
                        string _customer_user_agent = row_query_selectLog["zAdi_customer_user_agent"] != null ? row_query_selectLog["zAdi_customer_user_agent"].ToString() : "";
                        string _customer_ip_address = row_query_selectLog["zAdi_customer_ip_address"] != null ? row_query_selectLog["zAdi_customer_ip_address"].ToString() : "";
                        string _payment_method_title = row_query_selectLog["zAdi_payment_method_title"] != null ? row_query_selectLog["zAdi_payment_method_title"].ToString() : "";
                        string _payment_method = row_query_selectLog["zAdi_payment_method"] != null ? row_query_selectLog["zAdi_payment_method"].ToString() : "";
                        string _customer_user = row_query_selectLog["zAdi_customer_user"] != null ? row_query_selectLog["zAdi_customer_user"].ToString() : "0";
                        string _order_key = row_query_selectLog["zAdi_order_key"] != null ? row_query_selectLog["zAdi_order_key"].ToString() : "";
                        string _shipping_pickup_stores = row_query_selectLog["zAdi_Sucursal"] != null ? row_query_selectLog["zAdi_Sucursal"].ToString() : "";
                        #endregion
                        string AddressCompleteBilling = $"calle {_billing_address_1} {_billing_address_2}\n {_billing_city}, {_billing_postcode}, {_billing_state}\n{_billing_country}";
                        string AddressCompleteShipping = $"calle {_shipping_address_1} {_shipping_address_2}\n {_shipping_city}, {_shipping_postcode}, {_shipping_state}\n{_shipping_country}";

                        string cardCode = string.Empty;
                        string cardName = string.Empty;
                        string LicTradNum = string.Empty;
                        string user_email = string.Empty;
                        string comments = string.Empty;
                        string TrnspCode = string.Empty;
                        string CntctCode = "0";

                        //Adises CDMX = 1
                        //Adises GDL  = 5
                        //Adises MTY  = 6
                        //Adises LEON  = 7
                        //PAQUETERIA  = 3
                        switch (_shipping_pickup_stores.ToUpper().Trim())
                        {
                            case "SUCURSAL CIUDAD DE MÉXICO":
                                TrnspCode = "1";
                                break;
                            case "SUCURSAL GUADALAJARA":
                                TrnspCode = "5";
                                break;
                            case "SUCURSAL MONTERREY":
                                TrnspCode = "6";
                                break;
                            case "SUCURSAL LEÓN":
                                TrnspCode = "7";
                                break;

                            default:
                                TrnspCode = "3";
                                break;
                        }
                        string select_user_meta = $"SELECT meta_value FROM dsq_usermeta WHERE user_id = {_customer_user} AND meta_key = 'nickname' LIMIT 1";

                        DataTable tbl_usermeta = DBConnMysql.ExecQuery(select_user_meta);
                        if (tbl_usermeta != null && tbl_usermeta.Rows != null && tbl_usermeta.Rows.Count > 0)
                        {
                            if (tbl_usermeta.Rows[0]["meta_value"] != null && !string.IsNullOrEmpty(tbl_usermeta.Rows[0]["meta_value"].ToString()))
                                cardCode = tbl_usermeta.Rows[0]["meta_value"].ToString();
                        }
                        tbl_usermeta = new DataTable();
                        select_user_meta = $"SELECT meta_value FROM dsq_usermeta WHERE user_id = {_customer_user} AND meta_key = '_billing_company' LIMIT 1";
                        tbl_usermeta = DBConnMysql.ExecQuery(select_user_meta);
                        if (tbl_usermeta != null && tbl_usermeta.Rows != null && tbl_usermeta.Rows.Count > 0)
                        {
                            if (tbl_usermeta.Rows[0]["meta_value"] != null && !string.IsNullOrEmpty(tbl_usermeta.Rows[0]["meta_value"].ToString()))
                                cardName = tbl_usermeta.Rows[0]["meta_value"].ToString();
                        }

                        if (string.IsNullOrEmpty(cardName))
                        {
                            tbl_usermeta = new DataTable();
                            select_user_meta = $"SELECT meta_value FROM dsq_usermeta WHERE user_id = {_customer_user} AND meta_key = 'billing_company' LIMIT 1";
                            tbl_usermeta = DBConnMysql.ExecQuery(select_user_meta);
                            if (tbl_usermeta != null && tbl_usermeta.Rows != null && tbl_usermeta.Rows.Count > 0)
                            {
                                if (tbl_usermeta.Rows[0]["meta_value"] != null && !string.IsNullOrEmpty(tbl_usermeta.Rows[0]["meta_value"].ToString()))
                                    cardName = tbl_usermeta.Rows[0]["meta_value"].ToString();
                            }
                        }

                        tbl_usermeta = new DataTable();
                        select_user_meta = $"SELECT user_login, user_email FROM dsq_users WHERE ID = {_customer_user} LIMIT 1";
                        tbl_usermeta = DBConnMysql.ExecQuery(select_user_meta);
                        if (tbl_usermeta != null && tbl_usermeta.Rows != null && tbl_usermeta.Rows.Count > 0)
                        {
                            if (tbl_usermeta.Rows[0]["user_login"] != null && !string.IsNullOrEmpty(tbl_usermeta.Rows[0]["user_login"].ToString()))
                                LicTradNum = tbl_usermeta.Rows[0]["user_login"].ToString();

                            if (tbl_usermeta.Rows[0]["user_email"] != null && !string.IsNullOrEmpty(tbl_usermeta.Rows[0]["user_email"].ToString()))
                                user_email = tbl_usermeta.Rows[0]["user_email"].ToString();
                        }
                        string select_comments = $"SELECT comment_content FROM dsq_comments WHERE comment_author = '{LicTradNum}' OR comment_author_email = '{user_email}'";
                        DataTable tbl_comments = DBConnMysql.ExecQuery(select_comments);
                        if (tbl_comments != null && tbl_comments.Rows != null && tbl_comments.Rows.Count > 0)
                            foreach (DataRow item in tbl_comments.Rows) comments += item["comment_content"] != null && !string.IsNullOrEmpty(item["comment_content"].ToString()) ? item["comment_content"].ToString() + "\n" : "";


                        string select_OCPR = $"SELECT TOP 1 {Utils.parseStringBD("CntctCode")} FROM {Utils.parseStringBD("OCPR")} WHERE {Utils.parseStringBD("CardCode")} = '{cardCode}'";
                        DataTable tbl_OCPR = DBConn.ExecQuery(select_OCPR);
                        if (tbl_OCPR != null && tbl_OCPR.Rows != null && tbl_OCPR.Rows.Count > 0)
                            if (tbl_OCPR.Rows[0]["CntctCode"] != null && !string.IsNullOrEmpty(tbl_OCPR.Rows[0]["CntctCode"].ToString()))
                                CntctCode = tbl_OCPR.Rows[0]["CntctCode"].ToString();



                        #region insert tabla nativa OQUT
                        DataTable tbl_DocEntryMax = DBConn.ExecQuery($"SELECT MAX({Utils.parseStringBD("DocEntry")}) FROM {Utils.parseStringBD("OQUT")}");
                        long docEntry = tbl_DocEntryMax != null && tbl_DocEntryMax.Rows != null ? long.Parse(tbl_DocEntryMax.Rows[0][0] != null ? tbl_DocEntryMax.Rows[0][0].ToString() : "0") : 0;
                        docEntry++;

                        DataTable tbl_NextNumberDocNum = DBConn.ExecQuery($"SELECT TOP 1 {Utils.parseStringBD("NextNumber")} FROM {Utils.parseStringBD("NNM1")} WHERE {Utils.parseStringBD("Series")} = 136 AND {Utils.parseStringBD("SeriesName")} = 'WEB'");//Obtener la serie(DocNum) perteneciente al pedido 
                        long DocNum = tbl_NextNumberDocNum != null && tbl_NextNumberDocNum.Rows != null ? long.Parse(tbl_NextNumberDocNum.Rows[0][0] != null ? tbl_NextNumberDocNum.Rows[0][0].ToString() : "0") : 0;

                        string query_insert_orders = $"INSERT INTO {Utils.parseStringBD("OQUT")} (";
                        #region columns
                        query_insert_orders += $" {Utils.parseStringBD("DocEntry")},"; // id de la tabla
                        query_insert_orders += $" {Utils.parseStringBD("DocNum")},"; //identificador a sincronizar
                        query_insert_orders += $" {Utils.parseStringBD("DocType")},"; //'I'
                        query_insert_orders += $" {Utils.parseStringBD("CANCELED")},";//'N'
                        query_insert_orders += $" {Utils.parseStringBD("Handwrtten")},";//'N'
                        query_insert_orders += $" {Utils.parseStringBD("Printed")},";//'N'
                        query_insert_orders += $" {Utils.parseStringBD("DocStatus")},";//'O'
                        query_insert_orders += $" {Utils.parseStringBD("InvntSttus")},";//'O'
                        query_insert_orders += $" {Utils.parseStringBD("Transfered")},";//'N'
                        query_insert_orders += $" {Utils.parseStringBD("ObjType")},";//23--
                        query_insert_orders += $" {Utils.parseStringBD("DocDate")},";//fecha de creación--
                        query_insert_orders += $" {Utils.parseStringBD("DocDueDate")},"; //fecha límite, un mes de diferencia a la creada--
                        query_insert_orders += $" {Utils.parseStringBD("CardCode")},";// 'GDL-00901'-- Cliente
                        query_insert_orders += $" {Utils.parseStringBD("CardName")},";//'MOSTRADOR'--
                        query_insert_orders += $" {Utils.parseStringBD("Address")},";//*************direccion de envio*****************--
                        query_insert_orders += $" {Utils.parseStringBD("VatPercent")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("VatSum")},";//2,211.55 -------> dato a sincronizar--
                        query_insert_orders += $" {Utils.parseStringBD("VatSumFC")},"; //110.58 ---------> dato a sincronizar--
                        query_insert_orders += $" {Utils.parseStringBD("DiscPrcnt")},"; //0--
                        query_insert_orders += $" {Utils.parseStringBD("DiscSum")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("DiscSumFC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("DocCur")},"; //'USD'--
                        query_insert_orders += $" {Utils.parseStringBD("DocRate")},";//20 ---------> tipo de cambio--
                        query_insert_orders += $" {Utils.parseStringBD("DocTotal")},"; //16033.75 ---------> total del pedido-- MXN
                        query_insert_orders += $" {Utils.parseStringBD("DocTotalFC")},"; //801.69 --------- > total del pedido / tipo de cambio--
                        query_insert_orders += $" {Utils.parseStringBD("PaidToDate")},"; //0--
                        query_insert_orders += $" {Utils.parseStringBD("PaidFC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("GrosProfit")},";//-224.9 ---------> buscar como salen estos valores
                        query_insert_orders += $" {Utils.parseStringBD("GrosProfFC")},";//-11.25 ---------> buscar como salen estos valores
                        query_insert_orders += $" {Utils.parseStringBD("Ref1")},";//-84472 ------> buscar como salen estos valores
                        query_insert_orders += $" {Utils.parseStringBD("Comments")},"; //duda... --> sincronizacion
                        query_insert_orders += $" {Utils.parseStringBD("JrnlMemo")},"; //'Ofertas de ventas - GDL-00901'
                        query_insert_orders += $" {Utils.parseStringBD("GroupNum")},"; //2
                        query_insert_orders += $" {Utils.parseStringBD("DocTime")},";//1555 -- buscar de donde salen estos valores
                        query_insert_orders += $" {Utils.parseStringBD("SlpCode")},";//2--
                        query_insert_orders += $" {Utils.parseStringBD("TrnspCode")},";//5--
                        query_insert_orders += $" {Utils.parseStringBD("PartSupply")},";//'Y'--
                        query_insert_orders += $" {Utils.parseStringBD("Confirmed")},";//'Y'--
                        query_insert_orders += $" {Utils.parseStringBD("GrossBase")},";//-5--
                        query_insert_orders += $" {Utils.parseStringBD("CreateTran")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("SummryType")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("UpdInvnt")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("UpdCardBal")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("Instance")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("Flags")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("InvntDirec")},";//'X'--
                        query_insert_orders += $" {Utils.parseStringBD("CntctCode")},";//5021 -----------buscar de donde salen estos valores--
                        query_insert_orders += $" {Utils.parseStringBD("ShowSCN")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("SysRate")},";//20 ---------buscar de donde salen estos valores--
                        query_insert_orders += $" {Utils.parseStringBD("CurSource")},";//'C'--
                        query_insert_orders += $" {Utils.parseStringBD("VatSumSy")},";//110.58 --------->buscar de donde salen estos valores--
                        query_insert_orders += $" {Utils.parseStringBD("DiscSumSy")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("DocTotalSy")},";//801.69 --> Buscar donde salen estos valores--
                        query_insert_orders += $" {Utils.parseStringBD("PaidSys")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("FatherType")},";//'P'--
                        query_insert_orders += $" {Utils.parseStringBD("GrosProfSy")},";//-11.25 ---------> Buscar de donde salen estos valores--
                        query_insert_orders += $" {Utils.parseStringBD("UpdateDate")},";  //Fecha de actualización--
                        query_insert_orders += $" {Utils.parseStringBD("IsICT")},"; // 'N'--
                        query_insert_orders += $" {Utils.parseStringBD("CreateDate")},";//Fecha de creación--
                        query_insert_orders += $" {Utils.parseStringBD("Volume")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("VolUnit")},";//4--
                        query_insert_orders += $" {Utils.parseStringBD("Weight")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("WeightUnit")},";//3--
                        query_insert_orders += $" {Utils.parseStringBD("Series")},";//16--
                        query_insert_orders += $" {Utils.parseStringBD("TaxDate")},";//Fecha del tipo de cambio--
                        query_insert_orders += $" {Utils.parseStringBD("DataSource")},";//'I'--
                        query_insert_orders += $" {Utils.parseStringBD("isCrin")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("FinncPriod")},";//55--
                        query_insert_orders += $" {Utils.parseStringBD("UserSign")},";//1--
                        query_insert_orders += $" {Utils.parseStringBD("selfInv")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("VatPaid")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("VatPaidFC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("VatPaidSys")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("UserSign2")},";//1--
                        query_insert_orders += $" {Utils.parseStringBD("WddStatus")},";//'-'--
                        query_insert_orders += $" {Utils.parseStringBD("TotalExpns")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("TotalExpFC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("TotalExpSC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("Address2")},";///////////////variable////////////////--
                        query_insert_orders += $" {Utils.parseStringBD("LogInstanc")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("Exported")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("StationID")},";//230--
                        query_insert_orders += $" {Utils.parseStringBD("NetProc")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("AqcsTax")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("CashDiscPr")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("CashDiscnt")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("CashDiscFC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("CashDiscSC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("LicTradNum")},";//'XAXX0010101000'--
                        query_insert_orders += $" {Utils.parseStringBD("WTSum")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("WTSumFC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("WTSumSC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("RoundDif")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("RoundDifFC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("RoundDifSy")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("submitted")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("PoPrss")},";//'Y'--
                        query_insert_orders += $" {Utils.parseStringBD("Rounding")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("RevisionPo")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("Segment")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("PickStatus")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("Pick")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("BlockDunn")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("PeyMethod")},";//99--
                        query_insert_orders += $" {Utils.parseStringBD("PayBlock")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("MaxDscn")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("Reserve")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("Max1099")},";//16,033.75 ****************variableeee*****************
                        query_insert_orders += $" {Utils.parseStringBD("ExpAppl")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("ExpApplFC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("ExpApplSC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("DeferrTax")},";//'Y'--
                        query_insert_orders += $" {Utils.parseStringBD("WTApplied")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("WTAppliedF")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("BoeReserev")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("WTAppliedS")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("EquVatSum")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("EquVatSumF")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("EquVatSumS")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("Installmnt")},";//1--
                        query_insert_orders += $" {Utils.parseStringBD("VATFirst")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("NnSbAmnt")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("NnSbAmntSC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("NbSbAmntFC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("ExepAmnt")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("ExepAmntSC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("ExepAmntFC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("CEECFlag")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("BaseAmnt")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("BaseAmntSC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("BaseAmntFC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("CtlAccount")},";//'100400001'--
                        query_insert_orders += $" {Utils.parseStringBD("SumAbsId")},";//-1--
                        query_insert_orders += $" {Utils.parseStringBD("PIndicator")},";//'Valor de p'---
                        query_insert_orders += $" {Utils.parseStringBD("UseShpdGd")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("BaseVtAt")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("BaseVtAtSC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("BaseVtAtFC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("NnSbVAt")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("NnSbVAtSC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("NbSbVAtFC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("ExptVAt")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("ExptVAtSC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("ExptVAtFC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("LYPmtAt")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("LYPmtAtSC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("LYPmtAtFC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("ExpAnSum")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("ExpAnSys")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("ExpAnFrgn")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("DocSubType")},";//'--'---------------------------------------Corte de asignacion de valor de campos
                        query_insert_orders += $" {Utils.parseStringBD("DpmStatus")},";//'O'--
                        query_insert_orders += $" {Utils.parseStringBD("DpmAmnt")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("DpmAmntSC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("DpmAmntFC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("DpmDrawn")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("DpmPrcnt")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("PaidSum")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("PaidSumFc")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("PaidSumSc")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("DpmAppl")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("DpmApplFc")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("DpmApplSc")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("Footer")},";//'AddCot'--
                        query_insert_orders += $" {Utils.parseStringBD("Posted")},";//'Y'--
                        query_insert_orders += $" {Utils.parseStringBD("OwnerCode")},";//63--
                        query_insert_orders += $" {Utils.parseStringBD("IsPaytoBnk")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("isIns")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("VersionNum")},";//'9.30.240.14'--
                        query_insert_orders += $" {Utils.parseStringBD("LangCode")},";//25--
                        query_insert_orders += $" {Utils.parseStringBD("BPNameOW")},";//'Y'--
                        query_insert_orders += $" {Utils.parseStringBD("BillToOW")},";//'Y'--
                        query_insert_orders += $" {Utils.parseStringBD("ShipToOW")},";//'Y'--
                        query_insert_orders += $" {Utils.parseStringBD("RetInvoice")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("Model")},";//'0' duda si es varchar o numeric--
                        query_insert_orders += $" {Utils.parseStringBD("TaxOnExp")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("TaxOnExpFc")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("TaxOnExpSc")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("TaxOnExAp")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("TaxOnExApF")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("TaxOnExApS")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("UseCorrVat")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("BlkCredMmo")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("OpenForLaC")},";//'Y'--
                        query_insert_orders += $" {Utils.parseStringBD("Excised")},";//'O'--
                        query_insert_orders += $" {Utils.parseStringBD("SrvGpPrcnt")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("DutyStatus")},";//'Y'--
                        query_insert_orders += $" {Utils.parseStringBD("AutoCrtFlw")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("VatJENum")},";//-1--
                        query_insert_orders += $" {Utils.parseStringBD("DpmVat")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("DpmVatFc")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("DpmVatSc")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("DpmAppVat")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("DpmAppVatF")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("DpmAppVatS")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("InsurOp347")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("IgnRelDoc")},";//'N'---
                        query_insert_orders += $" {Utils.parseStringBD("BuildDesc")},";//''--
                        query_insert_orders += $" {Utils.parseStringBD("ResidenNum")},";//1--
                        query_insert_orders += $" {Utils.parseStringBD("CopyNumber")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("PQTGrpHW")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("DocManClsd")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("ClosingOpt")},";//1--
                        query_insert_orders += $" {Utils.parseStringBD("Ordered")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("NTSApprov")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("PayDuMonth")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("ExtraMonth")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("ExtraDays")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("CdcOffset")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("EDocGenTyp")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("OnlineQuo")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("EDocStatus")},";//'C'--
                        query_insert_orders += $" {Utils.parseStringBD("EDocProces")},";//'C'--
                        query_insert_orders += $" {Utils.parseStringBD("EDocCancel")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("EDocTest")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("DpmAsDscnt")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("GTSRlvnt")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("BaseDisc")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("BaseDiscSc")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("BaseDiscFc")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("BaseDiscPr")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("CreateTS")},";//155503 ------>ver de donde sale este dato--
                        query_insert_orders += $" {Utils.parseStringBD("UpdateTS")},";//155949 -------> ver de donde sale este dato--
                        query_insert_orders += $" {Utils.parseStringBD("SrvTaxRule")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("ReqType")},";//12--
                        query_insert_orders += $" {Utils.parseStringBD("OriginType")},";//'M'--
                        query_insert_orders += $" {Utils.parseStringBD("IsReuseNum")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("IsReuseNFN")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("DocDlvry")},";//'0'--
                        query_insert_orders += $" {Utils.parseStringBD("PaidDpm")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("PaidDpmF")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("PaidDpmS")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("EnvTypeNFe")},";//-1--
                        query_insert_orders += $" {Utils.parseStringBD("IsAlt")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("AltBaseTyp")},";//-1--
                        query_insert_orders += $" {Utils.parseStringBD("PrintSEPA")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("FreeChrg")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("FreeChrgFC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("FreeChrgSC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("NfeValue")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("RelatedTyp")},";//0 --> duda si es numerico (no la apunte desde la bd)--
                        query_insert_orders += $" {Utils.parseStringBD("NfePrntFo")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("FoCTax")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("FoCTaxFC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("FoCTaxSC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("FoCFrght")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("FoCFrghtFC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("FoCFrghtSC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("InterimTyp")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("SplitTax")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("SplitTaxFC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("SplitTaxSC")},";//0--
                        query_insert_orders += $" {Utils.parseStringBD("PoDropPrss")},";//'Y'--
                        query_insert_orders += $" {Utils.parseStringBD("ExclTaxRep")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("Revision")},";//'N'--
                        query_insert_orders += $" {Utils.parseStringBD("BaseType")},";//-1--
                        query_insert_orders += $" {Utils.parseStringBD("ComTrade")},";//'E'---
                        query_insert_orders += $" {Utils.parseStringBD("UseBilAddr")},";//'N'--***********************corte******************
                        query_insert_orders += $" {Utils.parseStringBD("IssReason")},";//1
                        query_insert_orders += $" {Utils.parseStringBD("ComTradeRt")},";//'N'
                        query_insert_orders += $" {Utils.parseStringBD("SplitPmnt")},";//'U'
                        query_insert_orders += $" {Utils.parseStringBD("SelfPosted")},";//'U'
                        query_insert_orders += $" {Utils.parseStringBD("DPPStatus")},";//'N'
                        query_insert_orders += $" {Utils.parseStringBD("CtActTax")},";//0
                        query_insert_orders += $" {Utils.parseStringBD("CtActTaxFC")},";//0
                        query_insert_orders += $" {Utils.parseStringBD("CtActTaxSC")},";//0
                        query_insert_orders += $" {Utils.parseStringBD("EDocType")},";//'F'
                        query_insert_orders += $" {Utils.parseStringBD("U_B1SYS_MainUsage")},";//'G03'
                        query_insert_orders += $" {Utils.parseStringBD("U_TipoDeVenta")},";//'B' ********vARIABLE A SINCORNIZAR (TIPO DE VENTA)
                        query_insert_orders += $" {Utils.parseStringBD("U_SolicitarPrefactura")},";//'NO' *********VARIABLE A SINCRONIZAR
                        query_insert_orders += $" {Utils.parseStringBD("U_PorcentajeDeAnticipo")},";//0 ********VARIABLE A SINCORNIZAR
                        query_insert_orders += $" {Utils.parseStringBD("U_NotasDeEnvio")},"; //'NOTAS DE ENVIO'
                        query_insert_orders += $" {Utils.parseStringBD("U_DP_ComisionGerente")},";//0 ********
                        query_insert_orders += $" {Utils.parseStringBD("U_DP_ComVenMax")},";//0
                        query_insert_orders += $" {Utils.parseStringBD("U_DP_DescMax")},";//0
                        query_insert_orders += $" {Utils.parseStringBD("U_TC_Comercial")},";//20.5833 tIPO DE CAMBIO ACTUAL
                        query_insert_orders += $" {Utils.parseStringBD("U_Visto")},";//'NO'
                        query_insert_orders += $" {Utils.parseStringBD("U_TotalInf")},";//0
                        query_insert_orders += $" {Utils.parseStringBD("U_PAnticipoC")},";//0
                        query_insert_orders += $" {Utils.parseStringBD("U_PagoDeAnticipo")},";//'NO'
                        query_insert_orders += $" {Utils.parseStringBD("U_ValidarPago")},";//'NO'
                        query_insert_orders += $" {Utils.parseStringBD("U_AlertaAnt")},";//'NO'
                        query_insert_orders += $" {Utils.parseStringBD("U_E_NP")},";//0
                        query_insert_orders += $" {Utils.parseStringBD("U_E_DVM")},";//0
                        query_insert_orders += $" {Utils.parseStringBD("U_E_SDV")},";//0
                        query_insert_orders += $" {Utils.parseStringBD("U_E_CVM")},";//0
                        query_insert_orders += $" {Utils.parseStringBD("U_E_CGV")},";//0
                        query_insert_orders += $" {Utils.parseStringBD("U_E_CV")},";//0
                        query_insert_orders += $" {Utils.parseStringBD("U_E_CCV")},";//0
                        query_insert_orders += $" {Utils.parseStringBD("U_E_MGPDE")},";//0
                        query_insert_orders += $" {Utils.parseStringBD("U_E_PMGPDE")},";//0
                        query_insert_orders += $" {Utils.parseStringBD("U_E_MGPSDE")},";//0
                        query_insert_orders += $" {Utils.parseStringBD("U_E_PMGPSDE")},";//0
                        query_insert_orders += $" {Utils.parseStringBD("U_E_STCDM")},";//0
                        query_insert_orders += $" {Utils.parseStringBD("U_E_STPCD")},";//0
                        query_insert_orders += $" {Utils.parseStringBD("U_E_STCSDM")},";//0
                        query_insert_orders += $" {Utils.parseStringBD("U_E_STPSD")},";//0
                        query_insert_orders += $" {Utils.parseStringBD("U_E_OFA")},";//'I'
                        query_insert_orders += $" {Utils.parseStringBD("U_CETCUSD")},";//0
                        query_insert_orders += $" {Utils.parseStringBD("U_CETotalUSD")},";//0
                        query_insert_orders += $" {Utils.parseStringBD("Email")},";//Variable agregada
                        query_insert_orders += $" {Utils.parseStringBD("U_CorreoPC")},";
                        query_insert_orders += $" {Utils.parseStringBD("U_PEDIDO_WEB")}";
                        #endregion
                        query_insert_orders += ") VALUES (";
                        #region values
                        query_insert_orders += $" {docEntry},"; //DocEntry
                        query_insert_orders += $" {DocNum},"; //DocNum
                        query_insert_orders += $" 'I',"; //DocType
                        query_insert_orders += $" 'N',"; //CANCELED
                        query_insert_orders += $" 'N',"; //Handwrtten
                        query_insert_orders += $" 'N',"; //Printed
                        query_insert_orders += $" 'O',";//DocStatus --> posible actualizacion de estatus en diferentes procesos. //DocStatus
                        query_insert_orders += $" 'O',"; //InvntSttus
                        query_insert_orders += $" 'N',"; //Transfered
                        query_insert_orders += $" 23,"; //ObjType
                        query_insert_orders += $" NOW(),"; //Falta pasarle fecha del woocomeerce //DocDate
                        query_insert_orders += $" ADD_MONTHS (NOW(), 1),"; //DocDueDate
                        query_insert_orders += $" '{(!string.IsNullOrEmpty(cardCode) && !string.IsNullOrEmpty(cardName) ? cardCode : "GDL-00901")}',"; //CardCode
                        query_insert_orders += $" '{(!string.IsNullOrEmpty(cardCode) && !string.IsNullOrEmpty(cardName) ? cardName : "MOSTRADOR")}',"; //CardName
                        query_insert_orders += $" '{_shipping_address_index}',"; //Address
                        query_insert_orders += $" 0,"; //0 //VatPercent
                        query_insert_orders += $" 2211.55,"; //2,211.55 -------> dato a sincronizar //VatSum
                        query_insert_orders += $" 110.58,";//110.58 ---------> dato a sincronizar //VatSumFC
                        query_insert_orders += $" 0,"; //DiscPrcnt
                        query_insert_orders += $" {(!String.IsNullOrEmpty(_cart_discount) ? _cart_discount : "0")},"; //DiscSum
                        query_insert_orders += $" {(!String.IsNullOrEmpty(_cart_discount) ? _cart_discount : "0")},"; //DiscSumFC
                        query_insert_orders += $" '{_order_currency}',"; //DocCur
                        query_insert_orders += $" {tc_Comercial},"; //DocRate
                        query_insert_orders += $" {(double.Parse((!String.IsNullOrEmpty(_order_total) ? _order_total : "0")) * double.Parse(tc_Comercial.Trim()))},";//DocTotal //DocTotal
                        query_insert_orders += $" {(!String.IsNullOrEmpty(total_sales) ? total_sales : "0")},";//801.69 --------- > total del pedido / tipo de cambio //DocTotalFC
                        query_insert_orders += $" 0,"; //PaidToDate
                        query_insert_orders += $" 0,"; //PaidFC
                        query_insert_orders += $" -224.9,";//-224.9 ---------> buscar como salen estos valores //GrosProfit
                        query_insert_orders += $" -11.25,";//-11.25 ---------> buscar como salen estos valores //GrosProfFC
                        query_insert_orders += $" -84472,";//-84472 ------> buscar como salen estos valores //Ref1
                        query_insert_orders += $" '',";//duda... --> sincronizacion //Comments
                        query_insert_orders += $" 'Ofertas de ventas - {(!string.IsNullOrEmpty(cardCode) && !string.IsNullOrEmpty(cardName) ? cardCode : "GDL-00901")}',";//'Ofertas de ventas - GDL-00901' //JrnlMemo
                        query_insert_orders += $" 1,"; // condiciones de pago //GroupNum
                        query_insert_orders += $" 1555,";//1555 -- buscar de donde salen estos valores //DocTime
                        query_insert_orders += $" 2,"; //SlpCode
                        query_insert_orders += $" {TrnspCode},"; //TrnspCode
                        query_insert_orders += $" 'Y',"; //PartSupply
                        query_insert_orders += $" 'Y',"; //Confirmed
                        query_insert_orders += $" -5,"; //GrossBase
                        query_insert_orders += $" 'N',"; //CreateTran
                        query_insert_orders += $" 'N',"; //SummryType
                        query_insert_orders += $" 'N',"; //equivalente en WooCommerce *_order_stock_reduced* //UpdInvnt
                        query_insert_orders += $" 'N',"; //UpdCardBal
                        query_insert_orders += $" 0,"; //Instance
                        query_insert_orders += $" 0,"; //Flags
                        query_insert_orders += $" 'X',"; //InvntDirec
                        query_insert_orders += $" {CntctCode},";//5021 //CntctCode --> código de contacto
                        query_insert_orders += $" 'N',"; //ShowSCN
                        query_insert_orders += $" {tc_Comercial},";//20 //SysRate -> revisar bien este campo.................12/05/2021
                        query_insert_orders += $" 'C',"; //CurSource
                        query_insert_orders += $" 110.58,";//110.58 --------->buscar de donde salen estos valores //VatSumSy
                        query_insert_orders += $" 0,"; //DiscSumSy
                        query_insert_orders += $" {(!String.IsNullOrEmpty(total_sales) ? total_sales : "0")},";//DocTotalSy //DocTotalSy
                        query_insert_orders += $" 0,"; //PaidSys
                        query_insert_orders += $" 'P',"; //FatherType
                        query_insert_orders += $" -11.25,";//-11.25 ---------> Buscar de donde salen estos valores //GrosProfSy
                        query_insert_orders += $" NOW(),";//Fecha de actualización //UpdateDate
                        query_insert_orders += $" 'N',"; //IsICT
                        query_insert_orders += $" NOW(),"; //Fecha de creación //CreateDate
                        query_insert_orders += $" 0,"; //Volume
                        query_insert_orders += $" 4,"; //VolUnit
                        query_insert_orders += $" 0,"; //Weight
                        query_insert_orders += $" 3,"; //WeightUnit
                        query_insert_orders += $" 136,"; //Series
                        query_insert_orders += $" TO_DATE(REPLACE(REPLACE('{fe_tc_Comercial}', '/', ''), '-', ''), 'DDMMYYYY'),"; //Fecha del tipo de cambio //TaxDate
                        query_insert_orders += $" 'I',"; //DataSource
                        query_insert_orders += $" 'N',"; //isCrin
                        query_insert_orders += $" {FinncPriod},"; //FinncPriod - periodo contable
                        query_insert_orders += $" 1,"; //UserSign
                        query_insert_orders += $" 'N',"; //selfInv
                        query_insert_orders += $" 0,"; //VatPaid
                        query_insert_orders += $" 0,"; //VatPaidFC
                        query_insert_orders += $" 0,"; //VatPaidSys
                        query_insert_orders += $" 1,"; //UserSign2
                        query_insert_orders += $" '-',"; //WddStatus
                        query_insert_orders += $" 0,"; //TotalExpns
                        query_insert_orders += $" 0,"; //TotalExpFC
                        query_insert_orders += $" 0,"; //TotalExpSC
                        query_insert_orders += $" '{_billing_address_index}',";//Address2 //Address2
                        query_insert_orders += $" 0,"; //LogInstanc
                        query_insert_orders += $" 'N',"; //Exported
                        query_insert_orders += $" 230,"; //StationID
                        query_insert_orders += $" 'N',"; //NetProc
                        query_insert_orders += $" 0,"; //AqcsTax
                        query_insert_orders += $" 0,"; //CashDiscPr
                        query_insert_orders += $" 0,"; //CashDiscnt
                        query_insert_orders += $" 0,"; //CashDiscFC
                        query_insert_orders += $" 0,"; //CashDiscSC
                        query_insert_orders += $" '{(!string.IsNullOrEmpty(LicTradNum) ? LicTradNum : "XAXX0010101000")}',"; //LicTradNum
                        query_insert_orders += $" {(!String.IsNullOrEmpty(tax_total) ? tax_total : "0")},";//WTSum //WTSum
                        query_insert_orders += $" {(!String.IsNullOrEmpty(tax_total) ? tax_total : "0")},";//WTSumFC //WTSumFC
                        query_insert_orders += $" {(!String.IsNullOrEmpty(tax_total) ? tax_total : "0")},";//WTSumSC //WTSumSC
                        query_insert_orders += $" 0,"; //RoundDif
                        query_insert_orders += $" 0,"; //RoundDifFC
                        query_insert_orders += $" 0,"; //RoundDifSy
                        query_insert_orders += $" 'N',"; //submitted
                        query_insert_orders += $" 'N',"; //PoPrss
                        query_insert_orders += $" 'N',"; //Rounding
                        query_insert_orders += $" 'N',"; //RevisionPo
                        query_insert_orders += $" 0,"; //Segment
                        query_insert_orders += $" 'N',"; //PickStatus
                        query_insert_orders += $" 'N',"; //Pick
                        query_insert_orders += $" 'N',"; //BlockDunn
                        query_insert_orders += $" 99,"; //Pay method (método de pago) //99 por defecto por si llega a morir //PeyMethod
                        query_insert_orders += $" 'N',"; //PayBlock
                        query_insert_orders += $" 'N',"; //MaxDscn
                        query_insert_orders += $" 'N',"; //Reserve
                        query_insert_orders += $" 16033.75,";//16,033.75 ****************variableeee***************** falta poner valor correcto //Max1099
                        query_insert_orders += $" 0,"; //ExpAppl
                        query_insert_orders += $" 0,"; //ExpApplFC
                        query_insert_orders += $" 0,"; //ExpApplSC
                        query_insert_orders += $" 'Y',"; //DeferrTax
                        query_insert_orders += $" 0,"; //WTApplied
                        query_insert_orders += $" 0,"; //WTAppliedF
                        query_insert_orders += $" 'N',"; //BoeReserev
                        query_insert_orders += $" 0,"; //WTAppliedS
                        query_insert_orders += $" 0,"; //EquVatSum
                        query_insert_orders += $" 0,"; //EquVatSumF
                        query_insert_orders += $" 0,"; //EquVatSumS
                        query_insert_orders += $" 1,"; //Installmnt
                        query_insert_orders += $" '{(!string.IsNullOrEmpty(_prices_include_tax) ? (_prices_include_tax.ToUpper() == "SI" ? "Y" : "N") : "N")}',";//VATFirst por default 'N' //VATFirst
                        query_insert_orders += $" 0,"; //NnSbAmnt
                        query_insert_orders += $" 0,"; //NnSbAmntSC
                        query_insert_orders += $" 0,"; //NbSbAmntFC
                        query_insert_orders += $" 0,"; //ExepAmnt
                        query_insert_orders += $" 0,"; //ExepAmntSC
                        query_insert_orders += $" 0,"; //ExepAmntFC
                        query_insert_orders += $" 'N',"; //CEECFlag
                        query_insert_orders += $" 0,"; //BaseAmnt
                        query_insert_orders += $" 0,"; //BaseAmntSC
                        query_insert_orders += $" 0,"; //BaseAmntFC
                        query_insert_orders += $" '100400001',"; //CtlAccount
                        query_insert_orders += $" -1,"; //SumAbsId
                        query_insert_orders += $" 'Valor de p',"; //PIndicator
                        query_insert_orders += $" 'N',"; //UseShpdGd
                        query_insert_orders += $" 0,"; //BaseVtAt
                        query_insert_orders += $" 0,"; //BaseVtAtSC
                        query_insert_orders += $" 0,"; //BaseVtAtFC
                        query_insert_orders += $" 0,"; //NnSbVAt
                        query_insert_orders += $" 0,"; //NnSbVAtSC
                        query_insert_orders += $" 0,"; //NbSbVAtFC
                        query_insert_orders += $" 0,"; //ExptVAt
                        query_insert_orders += $" 0,"; //ExptVAtSC
                        query_insert_orders += $" 0,"; //ExptVAtFC
                        query_insert_orders += $" 0,"; //LYPmtAt
                        query_insert_orders += $" 0,"; //LYPmtAtSC
                        query_insert_orders += $" 0,"; //LYPmtAtFC
                        query_insert_orders += $" 0,"; //ExpAnSum
                        query_insert_orders += $" 0,"; //ExpAnSys
                        query_insert_orders += $" 0,"; //ExpAnFrgn
                        query_insert_orders += $" '--',"; //DocSubType
                        query_insert_orders += $" 'O',"; //DpmStatus
                        query_insert_orders += $" 0,"; //DpmAmnt
                        query_insert_orders += $" 0,"; //DpmAmntSC
                        query_insert_orders += $" 0,"; //DpmAmntFC
                        query_insert_orders += $" 'N',"; //DpmDrawn
                        query_insert_orders += $" 0,"; //DpmPrcnt
                        query_insert_orders += $" 0,"; //PaidSum
                        query_insert_orders += $" 0,"; //PaidSumFc
                        query_insert_orders += $" 0,"; //PaidSumSc
                        query_insert_orders += $" 0,"; //DpmAppl
                        query_insert_orders += $" 0,"; //DpmApplFc
                        query_insert_orders += $" 0,"; //DpmApplSc
                        query_insert_orders += $" 'AddCot',"; //Footer
                        query_insert_orders += $" 'Y',"; //Posted
                        query_insert_orders += $" 63,"; //OwnerCode
                        query_insert_orders += $" 'N',"; //IsPaytoBnk
                        query_insert_orders += $" 'N',"; //isIns
                        query_insert_orders += $" '9.30.240.14',"; //version no se mueve //VersionNum
                        query_insert_orders += $" 25,"; //LangCode
                        query_insert_orders += $" 'Y',"; //BPNameOW
                        query_insert_orders += $" 'Y',"; //BillToOW
                        query_insert_orders += $" 'Y',"; //ShipToOW
                        query_insert_orders += $" 'N',"; //RetInvoice
                        query_insert_orders += $" '0',";//Model
                        query_insert_orders += $" 0,"; //TaxOnExp
                        query_insert_orders += $" 0,"; //TaxOnExpFc
                        query_insert_orders += $" 0,"; //TaxOnExpSc
                        query_insert_orders += $" 0,"; //TaxOnExAp
                        query_insert_orders += $" 0,"; //TaxOnExApF
                        query_insert_orders += $" 0,"; //TaxOnExApS
                        query_insert_orders += $" 'N',"; //UseCorrVat
                        query_insert_orders += $" 'N',"; //BlkCredMmo
                        query_insert_orders += $" 'Y',"; //OpenForLaC
                        query_insert_orders += $" 'O',"; //Excised
                        query_insert_orders += $" 0,"; //SrvGpPrcnt
                        query_insert_orders += $" 'Y',"; //DutyStatus
                        query_insert_orders += $" 'N',"; //AutoCrtFlw
                        query_insert_orders += $" -1,"; //VatJENum
                        query_insert_orders += $" 0,"; //DpmVat
                        query_insert_orders += $" 0,"; //DpmVatFc
                        query_insert_orders += $" 0,"; //DpmVatSc
                        query_insert_orders += $" 0,"; //DpmAppVat
                        query_insert_orders += $" 0,"; //DpmAppVatF
                        query_insert_orders += $" 0,"; //DpmAppVatS
                        query_insert_orders += $" 'N',"; //InsurOp347
                        query_insert_orders += $" 'N',"; //IgnRelDoc
                        query_insert_orders += $" '',"; //BuildDesc
                        query_insert_orders += $" 1,"; //ResidenNum
                        query_insert_orders += $" 0,"; //CopyNumber
                        query_insert_orders += $" 'N',"; //PQTGrpHW
                        query_insert_orders += $" 'N',"; //DocManClsd
                        query_insert_orders += $" 1,"; //ClosingOpt
                        query_insert_orders += $" 'N',"; //Ordered
                        query_insert_orders += $" 'N',"; //NTSApprov
                        query_insert_orders += $" 'N',"; //PayDuMonth
                        query_insert_orders += $" 0,"; //ExtraMonth
                        query_insert_orders += $" 0,"; //ExtraDays
                        query_insert_orders += $" 0,"; //CdcOffset
                        query_insert_orders += $" 'N',"; //EDocGenTyp
                        query_insert_orders += $" 'N',"; //OnlineQuo
                        query_insert_orders += $" 'C',"; //EDocStatus
                        query_insert_orders += $" 'C',"; //EDocProces
                        query_insert_orders += $" 'N',"; //EDocCancel
                        query_insert_orders += $" 'N',"; //EDocTest
                        query_insert_orders += $" 'N',"; //DpmAsDscnt
                        query_insert_orders += $" 'N',"; //GTSRlvnt
                        query_insert_orders += $" 0,"; //BaseDisc
                        query_insert_orders += $" 0,"; //BaseDiscSc
                        query_insert_orders += $" 0,"; //BaseDiscFc
                        query_insert_orders += $" 0,"; //BaseDiscPr
                        query_insert_orders += $" 155503,";//155503 ------>ver de donde sale este dato //CreateTS
                        query_insert_orders += $" 155949,";//155949 -------> ver de donde sale este dato //UpdateTS
                        query_insert_orders += $" 'N',"; //SrvTaxRule
                        query_insert_orders += $" 12,"; //ReqType
                        query_insert_orders += $" 'M',"; //OriginType
                        query_insert_orders += $" 'N',"; //IsReuseNum
                        query_insert_orders += $" 'N',"; //IsReuseNFN
                        query_insert_orders += $" 0,"; //DocDlvry
                        query_insert_orders += $" 0,"; //PaidDpm
                        query_insert_orders += $" 0,"; //PaidDpmF
                        query_insert_orders += $" 0,"; //PaidDpmS
                        query_insert_orders += $" -1,"; //EnvTypeNFe
                        query_insert_orders += $" 'N',"; //IsAlt
                        query_insert_orders += $" -1,"; //AltBaseTyp
                        query_insert_orders += $" 'N',"; //PrintSEPA
                        query_insert_orders += $" 0,"; //FreeChrg
                        query_insert_orders += $" 0,"; //FreeChrgFC
                        query_insert_orders += $" 0,"; //FreeChrgSC
                        query_insert_orders += $" 0,"; //NfeValue
                        query_insert_orders += $" 0,"; //RelatedTyp
                        query_insert_orders += $" 0,"; //NfePrntFo
                        query_insert_orders += $" 0,"; //FoCTax
                        query_insert_orders += $" 0,"; //FoCTaxFC
                        query_insert_orders += $" 0,"; //FoCTaxSC
                        query_insert_orders += $" 0,"; //FoCFrght
                        query_insert_orders += $" 0,"; //FoCFrghtFC
                        query_insert_orders += $" 0,"; //FoCFrghtSC
                        query_insert_orders += $" 0,"; //InterimTyp
                        query_insert_orders += $" 0,"; //SplitTax
                        query_insert_orders += $" 0,"; //SplitTaxFC
                        query_insert_orders += $" 0,"; //SplitTaxSC
                        query_insert_orders += $" 'Y',"; //PoDropPrss
                        query_insert_orders += $" 'N',"; //ExclTaxRep
                        query_insert_orders += $" 'N',"; //Revision
                        query_insert_orders += $" -1,"; //BaseType
                        query_insert_orders += $" 'E',"; //ComTrade
                        query_insert_orders += $" 'N',"; //UseBilAddr
                        query_insert_orders += $" 1,"; //IssReason
                        query_insert_orders += $" 'N',"; //ComTradeRt
                        query_insert_orders += $" 'U',"; //SplitPmnt
                        query_insert_orders += $" 'U',"; //SelfPosted
                        query_insert_orders += $" 'N',"; //DPPStatus
                        query_insert_orders += $" 0,"; //CtActTax
                        query_insert_orders += $" 0,"; //CtActTaxFC
                        query_insert_orders += $" 0,"; //CtActTaxSC
                        query_insert_orders += $" 'F',"; //EDocType
                        query_insert_orders += $" 'G03',"; //U_B1SYS_MainUsage
                        query_insert_orders += $" 'B',";//(TIPO DE VENTA B) //U_TipoDeVenta
                        query_insert_orders += $" 'NO',";//U_SolicitarPrefactura
                        query_insert_orders += $" 0,"; //Porcentaje de anticipo //U_PorcentajeDeAnticipo
                        query_insert_orders += $" '',"; //notad de envio //U_NotasDeEnvio
                        query_insert_orders += $" 0,"; //U_DP_ComisionGerente
                        query_insert_orders += $" 0,"; //U_DP_ComVenMax
                        query_insert_orders += $" 0,"; //U_DP_DescMax
                        query_insert_orders += $" {tc_Comercial},"; //Tipo de cambio comercial //U_TC_Comercial
                        query_insert_orders += $" 'NO',"; //U_Visto
                        query_insert_orders += $" 0,"; //U_TotalInf
                        query_insert_orders += $" 0,"; //U_PAnticipoC
                        query_insert_orders += $" 'NO',"; //U_PagoDeAnticipo
                        query_insert_orders += $" 'NO',"; //U_ValidarPago
                        query_insert_orders += $" 'NO',"; //U_AlertaAnt
                        query_insert_orders += $" 0,"; //U_E_NP
                        query_insert_orders += $" 0,"; //U_E_DVM
                        query_insert_orders += $" 0,"; //U_E_SDV
                        query_insert_orders += $" 0,"; //U_E_CVM
                        query_insert_orders += $" 0,"; //U_E_CGV
                        query_insert_orders += $" 0,"; //U_E_CV
                        query_insert_orders += $" 0,"; //U_E_CCV
                        query_insert_orders += $" 0,"; //U_E_MGPDE
                        query_insert_orders += $" 0,"; //U_E_PMGPDE
                        query_insert_orders += $" 0,"; //U_E_MGPSDE
                        query_insert_orders += $" 0,"; //U_E_PMGPSDE
                        query_insert_orders += $" 0,"; //U_E_STCDM
                        query_insert_orders += $" 0,"; //U_E_STPCD
                        query_insert_orders += $" 0,"; //U_E_STCSDM
                        query_insert_orders += $" 0,"; //U_E_STPSD
                        query_insert_orders += $" 'I',"; //U_E_OFA
                        query_insert_orders += $" 0,"; //U_CETCUSD
                        query_insert_orders += $" 0,"; //U_CETotalUSD
                        query_insert_orders += $" '{_billing_email}',"; //Variable agregada. //Email
                        query_insert_orders += $" '{user_email}',"; //Variable agregada. //Email
                        query_insert_orders += $" '{order_id}'"; //Email U_PEDIDO_WEB
                        #endregion
                        query_insert_orders += ")";
                        #endregion
                        bool fgInsert = false;
                            //DBConn.ExecQueryInsert(query_insert_orders);
                        if (fgInsert)
                        {
                            string update_logOrder = $"UPDATE {Utils.parseStringBD("zAdi_SyncOrder")} SET";
                            update_logOrder += $" {Utils.parseStringBD("zAdi_flagSend")} = TRUE,";
                            update_logOrder += $" {Utils.parseStringBD("zAdi_dateSend")} = NOW(),";
                            update_logOrder += $" {Utils.parseStringBD("zAdi_DocEntry")} = {docEntry},";
                            update_logOrder += $" {Utils.parseStringBD("zAdi_DocNum")} = {DocNum},";
                            update_logOrder += $" {Utils.parseStringBD("zAdi_Serie")} = 'WEB'";
                            update_logOrder += $" WHERE {Utils.parseStringBD("zAdi_idSyncOrder")} =  {idSyncOrder}";
                            DBConn.ExecQueryUpdate(update_logOrder);
                            DBConn.ExecQueryUpdate($"UPDATE {Utils.parseStringBD("NNM1")} SET {Utils.parseStringBD("NextNumber")} = {DocNum + 1} WHERE {Utils.parseStringBD("Series")} = 136 AND {Utils.parseStringBD("SeriesName")} = 'WEB'"); //Actualizar la serie (Aumentar 1)

                            #region direcciones

                            string query_direcciones = $"INSERT INTO {Utils.parseStringBD("QUT12")} (";
                            query_direcciones += $" {Utils.parseStringBD("DocEntry")},"; //'84472'
                            query_direcciones += $" {Utils.parseStringBD("NetWeight")},"; //'0'
                            query_direcciones += $" {Utils.parseStringBD("GrsWeight")},"; //'0'
                            query_direcciones += $" {Utils.parseStringBD("LogInstanc")},"; //'0'
                            query_direcciones += $" {Utils.parseStringBD("ObjectType")},"; //'23'
                            query_direcciones += $" {Utils.parseStringBD("StreetS")},"; //'calle fac'
                            query_direcciones += $" {Utils.parseStringBD("BlockS")},"; //'col fac'
                            query_direcciones += $" {Utils.parseStringBD("BuildingS")},"; //' '
                            query_direcciones += $" {Utils.parseStringBD("CityS")},"; //'ciudad fac'
                            query_direcciones += $" {Utils.parseStringBD("ZipCodeS")},"; //'97910'
                            query_direcciones += $" {Utils.parseStringBD("StateS")},"; //'YUC'
                            query_direcciones += $" {Utils.parseStringBD("CountryS")},"; //'MX'
                            query_direcciones += $" {Utils.parseStringBD("AddrTypeS")},"; //' '
                            query_direcciones += $" {Utils.parseStringBD("StreetNoS")},"; //'nu fac'
                            query_direcciones += $" {Utils.parseStringBD("StreetB")},"; //'calle env'
                            query_direcciones += $" {Utils.parseStringBD("BlockB")},"; //'col env'
                            query_direcciones += $" {Utils.parseStringBD("CityB")},"; //'ciudad env'
                            query_direcciones += $" {Utils.parseStringBD("ZipCodeB")},"; //'97910'
                            query_direcciones += $" {Utils.parseStringBD("StateB")},"; //'YUC'
                            query_direcciones += $" {Utils.parseStringBD("CountryB")},"; //'MX'
                            query_direcciones += $" {Utils.parseStringBD("StreetNoB")},"; //'nu env'
                            query_direcciones += $" {Utils.parseStringBD("Vat")},"; //'N'
                            query_direcciones += $" {Utils.parseStringBD("Address2S")},"; //' '
                            query_direcciones += $" {Utils.parseStringBD("Address3S")},"; //' '
                            query_direcciones += $" {Utils.parseStringBD("GlbLocNumS")},"; //' '
                            query_direcciones += $" {Utils.parseStringBD("ExportType")},"; //'E'
                            query_direcciones += $" {Utils.parseStringBD("BoEValue")}"; //'0'
                            query_direcciones += ") VALUES (";
                            query_direcciones += $" {(docEntry)},";
                            query_direcciones += $" 0,";
                            query_direcciones += $" 0,";
                            query_direcciones += $" 0,";
                            query_direcciones += $" 23,";
                            query_direcciones += $" '{_billing_address_1} {_billing_address_2}',";
                            query_direcciones += $" 'col fac',"; //pendiente de obtener colonia fac
                            query_direcciones += $" ' ',";
                            query_direcciones += $" '{_billing_city}',";
                            query_direcciones += $" '{_billing_postcode}',";
                            query_direcciones += $" '{_billing_state}',";
                            query_direcciones += $" '{_billing_country}',";
                            query_direcciones += $" ' ',";
                            query_direcciones += $" 'S/N fac',";
                            query_direcciones += $" '{_shipping_address_1} {_shipping_address_2}',";
                            query_direcciones += $" 'col env',";//pendiente obtener colonia env
                            query_direcciones += $" '{_shipping_city}',";
                            query_direcciones += $" '{_shipping_postcode}',";
                            query_direcciones += $" '{_shipping_state}',";
                            query_direcciones += $" '{_shipping_country}',";
                            query_direcciones += $" 'S/N env',";
                            query_direcciones += $" 'N',";
                            query_direcciones += $" ' ',";
                            query_direcciones += $" ' ',";
                            query_direcciones += $" ' ',";
                            query_direcciones += $" 'E',";
                            query_direcciones += $" 0";
                            query_direcciones += ")";

                            DBConn.ExecQueryInsert(query_direcciones);
                            #endregion

                            int lineNum = 0;
                            #region Items
                            string query_select_items = $"SELECT";
                            #region select columns zAdi_SyncOrderItems
                            query_select_items += $" {Utils.parseStringBD("zAdi_order_item_id")},";
                            query_select_items += $" {Utils.parseStringBD("zAdi_order_id")},";
                            query_select_items += $" {Utils.parseStringBD("zAdi_isproduct")},";
                            query_select_items += $" {Utils.parseStringBD("zAdi_product_id")},";
                            query_select_items += $" {Utils.parseStringBD("zAdi_order_item_name")},";
                            query_select_items += $" {Utils.parseStringBD("zAdi_order_item_type")},";
                            query_select_items += $" {Utils.parseStringBD("zAdi_date_created")},";
                            query_select_items += $" {Utils.parseStringBD("zAdi_product_qty")},";
                            query_select_items += $" {Utils.parseStringBD("zAdi_product_net_revenue")},";
                            query_select_items += $" {Utils.parseStringBD("zAdi_product_gross_revenue")},";
                            query_select_items += $" {Utils.parseStringBD("zAdi_coupon_amount")},";
                            query_select_items += $" {Utils.parseStringBD("zAdi_tax_amount")},";
                            query_select_items += $" {Utils.parseStringBD("zAdi_shipping_amount")},";
                            query_select_items += $" {Utils.parseStringBD("zAdi_shiping_tax_amount")},";
                            query_select_items += $" {Utils.parseStringBD("zAdi_line_tax_data")},";
                            query_select_items += $" {Utils.parseStringBD("zAdi_line_tax")},";
                            query_select_items += $" {Utils.parseStringBD("zAdi_line_total")},";
                            query_select_items += $" {Utils.parseStringBD("zAdi_line_subtotal_tax")},";
                            query_select_items += $" {Utils.parseStringBD("zAdi_line_subtotal")},";
                            query_select_items += $" {Utils.parseStringBD("zAdi_tax_class")},";
                            query_select_items += $" {Utils.parseStringBD("zAdi_qty")},";
                            query_select_items += $" {Utils.parseStringBD("zAdi_variation_id")},";
                            query_select_items += $" {Utils.parseStringBD("zAdi_zproduct_id")},";
                            query_select_items += $" {Utils.parseStringBD("zAdi_articulos")},";
                            query_select_items += $" {Utils.parseStringBD("zAdi_taxes")},";
                            query_select_items += $" {Utils.parseStringBD("zAdi_total_tax")},";
                            query_select_items += $" {Utils.parseStringBD("zAdi_cost")},";
                            query_select_items += $" {Utils.parseStringBD("zAdi_instance_id")},";
                            query_select_items += $" {Utils.parseStringBD("zAdi_method_id")},";
                            query_select_items += $" {Utils.parseStringBD("zAdi_sku")},";
                            query_select_items += $" {Utils.parseStringBD("zAdi_post_id")},";
                            query_select_items += $" {Utils.parseStringBD("zAdi_meta_key")},";
                            //query_select_items +=  $"{Utils.parseStringBD("zAdi_")},";
                            query_select_items += $" {Utils.parseStringBD("zAdi_meta_value")}";
                            #endregion
                            query_select_items += $" FROM {Utils.parseStringBD("zAdi_SyncOrderItems")} WHERE {Utils.parseStringBD("zAdi_idSyncOrder")} = {idSyncOrder}";

                            DataTable tbl_query_selectItems = DBConn.ExecQuery(query_select_items);
                            if (tbl_query_selectItems != null && tbl_query_selectItems.Rows != null && tbl_query_selectItems.Rows.Count > 0)
                            {
                                foreach (DataRow row in tbl_query_selectItems.Rows)
                                {
                                    #region columns logs parse
                                    string order_item_id = row["zAdi_order_item_id"] != null ? row["zAdi_order_item_id"].ToString() : "";
                                    //string order_id = row["zAdi_"] != null ? row["zAdi_"].ToString() : "";
                                    string item_isproduct = row["zAdi_isproduct"] != null ? row["zAdi_isproduct"].ToString() : "";
                                    string item_product_id = row["zAdi_product_id"] != null ? row["zAdi_product_id"].ToString() : "";
                                    string item_order_item_name = row["zAdi_order_item_name"] != null ? row["zAdi_order_item_name"].ToString() : "";
                                    string item_order_item_type = row["zAdi_order_item_type"] != null ? row["zAdi_order_item_type"].ToString() : "";
                                    string item_date_created = row["zAdi_date_created"] != null ? row["zAdi_date_created"].ToString() : "";
                                    string item_product_qty = row["zAdi_product_qty"] != null ? row["zAdi_product_qty"].ToString() : "";
                                    string item_product_net_revenue = row["zAdi_product_net_revenue"] != null ? row["zAdi_product_net_revenue"].ToString() : "";
                                    string item_product_gross_revenue = row["zAdi_product_gross_revenue"] != null ? row["zAdi_product_gross_revenue"].ToString() : "";
                                    string item_coupon_amount = row["zAdi_coupon_amount"] != null ? row["zAdi_coupon_amount"].ToString() : "";
                                    string item_tax_amount = row["zAdi_tax_amount"] != null ? row["zAdi_tax_amount"].ToString() : "0";
                                    string item_shipping_amount = row["zAdi_shipping_amount"] != null ? row["zAdi_shipping_amount"].ToString() : "";
                                    string item_shiping_tax_amount = row["zAdi_shiping_tax_amount"] != null ? row["zAdi_shiping_tax_amount"].ToString() : "";
                                    string item__line_tax_data = row["zAdi_line_tax_data"] != null ? row["zAdi_line_tax_data"].ToString() : "";
                                    string item__line_tax = row["zAdi_line_tax"] != null ? row["zAdi_line_tax"].ToString() : "";
                                    string item__line_total = row["zAdi_line_total"] != null ? row["zAdi_line_total"].ToString() : "";
                                    string item__line_subtotal_tax = row["zAdi_line_subtotal_tax"] != null ? row["zAdi_line_subtotal_tax"].ToString() : "";
                                    string item__line_subtotal = row["zAdi_line_subtotal"] != null ? row["zAdi_line_subtotal"].ToString() : "";
                                    string item__tax_class = row["zAdi_tax_class"] != null ? row["zAdi_tax_class"].ToString() : "";
                                    string item__qty = row["zAdi_qty"] != null ? row["zAdi_qty"].ToString() : "";
                                    string item__variation_id = row["zAdi_variation_id"] != null ? row["zAdi_variation_id"].ToString() : "";
                                    string item__product_id = row["zAdi_zproduct_id"] != null ? row["zAdi_zproduct_id"].ToString() : "";
                                    string item_Artículos = row["zAdi_articulos"] != null ? row["zAdi_articulos"].ToString() : "";
                                    string item_taxes = row["zAdi_taxes"] != null ? row["zAdi_taxes"].ToString() : "";
                                    string item_total_tax = row["zAdi_total_tax"] != null ? row["zAdi_total_tax"].ToString() : "";
                                    string item_cost = row["zAdi_cost"] != null ? row["zAdi_cost"].ToString() : "";
                                    string item_instance_id = row["zAdi_instance_id"] != null ? row["zAdi_instance_id"].ToString() : "";
                                    string item_method_id = row["zAdi_method_id"] != null ? row["zAdi_method_id"].ToString() : "";
                                    string item_sku = row["zAdi_sku"] != null ? row["zAdi_sku"].ToString() : "";
                                    string item_post_id = row["zAdi_post_id"] != null ? row["zAdi_post_id"].ToString() : "";
                                    string item_meta_key = row["zAdi_meta_key"] != null ? row["zAdi_meta_key"].ToString() : "";
                                    string item_meta_value = row["zAdi_meta_value"] != null ? row["zAdi_meta_value"].ToString() : "";
                                    #endregion


                                    //item_product_net_revenue = price * qty
                                    //product_gross_revenue = item_product_net_revenue + tax_amount + shipping amount
                                    //tax_amount = item_product_net_revenue * 0.16 (IVA)
                                    //shipping_amount = envío prorrateado

                                    string query_insert_items = $"INSERT INTO {Utils.parseStringBD("QUT1")} (";
                                    #region Columns
                                    query_insert_items += $" {Utils.parseStringBD("DocEntry")},";//123
                                    query_insert_items += $" {Utils.parseStringBD("LineNum")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("TargetType")},";//-1
                                    query_insert_items += $" {Utils.parseStringBD("BaseRef")},";//' '
                                    query_insert_items += $" {Utils.parseStringBD("BaseType")},";//-1
                                    query_insert_items += $" {Utils.parseStringBD("LineStatus")},";//'O'
                                    query_insert_items += $" {Utils.parseStringBD("ItemCode")},";//'otemCode'
                                    query_insert_items += $" {Utils.parseStringBD("Dscription")},"; //'Description'
                                    query_insert_items += $" {Utils.parseStringBD("Quantity")},";//1
                                    query_insert_items += $" {Utils.parseStringBD("OpenQty")},";//1
                                    query_insert_items += $" {Utils.parseStringBD("Price")},";//690.11
                                    query_insert_items += $" {Utils.parseStringBD("Currency")},";//'USD'
                                    query_insert_items += $" {Utils.parseStringBD("Rate")},";//20
                                    query_insert_items += $" {Utils.parseStringBD("DiscPrcnt")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("LineTotal")},";//13802.2
                                    query_insert_items += $" {Utils.parseStringBD("TotalFrgn")},";//690.11
                                    query_insert_items += $" {Utils.parseStringBD("OpenSum")},";//13802.2
                                    query_insert_items += $" {Utils.parseStringBD("OpenSumFC")},";//690.11
                                    query_insert_items += $" {Utils.parseStringBD("VendorNum")},";//'TS-251+-8G-US'
                                    query_insert_items += $" {Utils.parseStringBD("WhsCode")},";//1
                                    query_insert_items += $" {Utils.parseStringBD("SlpCode")},";//2
                                    query_insert_items += $" {Utils.parseStringBD("Commission")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("TreeType")},";//'N'
                                    query_insert_items += $" {Utils.parseStringBD("AcctCode")},";//'400000002'
                                    query_insert_items += $" {Utils.parseStringBD("TaxStatus")},";//'Y'
                                    query_insert_items += $" {Utils.parseStringBD("GrossBuyPr")},";//14047.1
                                    query_insert_items += $" {Utils.parseStringBD("PriceBefDi")},";//690.11
                                    query_insert_items += $" {Utils.parseStringBD("DocDate")},";//NOW()
                                    query_insert_items += $" {Utils.parseStringBD("Flags")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("OpenCreQty")},";//1
                                    query_insert_items += $" {Utils.parseStringBD("UseBaseUn")},";//'N'
                                    query_insert_items += $" {Utils.parseStringBD("SubCatNum")},";//' '
                                    query_insert_items += $" {Utils.parseStringBD("BaseCard")},";//'GDL-00901'
                                    query_insert_items += $" {Utils.parseStringBD("TotalSumSy")},";//690.11
                                    query_insert_items += $" {Utils.parseStringBD("OpenSumSys")},";//690.11
                                    query_insert_items += $" {Utils.parseStringBD("InvntSttus")},";//'O'
                                    query_insert_items += $" {Utils.parseStringBD("Project")},";//' '
                                    query_insert_items += $" {Utils.parseStringBD("VatPrcnt")},";//16
                                    query_insert_items += $" {Utils.parseStringBD("VatGroup")},";//' '
                                    query_insert_items += $" {Utils.parseStringBD("PriceAfVAT")},";//800.53
                                    query_insert_items += $" {Utils.parseStringBD("Height1")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("Height2")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("Width1")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("Width2")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("Length1")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("length2")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("Volume")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("VolUnit")},";//4
                                    query_insert_items += $" {Utils.parseStringBD("Weight1")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("Weight2")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("Factor1")},";//1
                                    query_insert_items += $" {Utils.parseStringBD("Factor2")},";//1
                                    query_insert_items += $" {Utils.parseStringBD("Factor3")},";//1
                                    query_insert_items += $" {Utils.parseStringBD("Factor4")},";//1
                                    query_insert_items += $" {Utils.parseStringBD("PackQty")},";//1
                                    query_insert_items += $" {Utils.parseStringBD("UpdInvntry")},";//'Y'
                                    query_insert_items += $" {Utils.parseStringBD("SWW")},";//' '
                                    query_insert_items += $" {Utils.parseStringBD("VatSum")},";//2208.35
                                    query_insert_items += $" {Utils.parseStringBD("VatSumFrgn")},";//110.42
                                    query_insert_items += $" {Utils.parseStringBD("VatSumSy")},";//110.42
                                    query_insert_items += $" {Utils.parseStringBD("FinncPriod")},";//55
                                    query_insert_items += $" {Utils.parseStringBD("ObjType")},";//23
                                    query_insert_items += $" {Utils.parseStringBD("LogInstanc")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("DedVatSum")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("DedVatSumF")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("DedVatSumS")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("IsAqcuistn")},";//'N'
                                    query_insert_items += $" {Utils.parseStringBD("DistribSum")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("DstrbSumFC")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("DstrbSumSC")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("GrssProfit")},";//-244.9
                                    query_insert_items += $" {Utils.parseStringBD("GrssProfSC")},";//-12.25
                                    query_insert_items += $" {Utils.parseStringBD("GrssProfFC")},";//-12.25
                                    query_insert_items += $" {Utils.parseStringBD("VisOrder")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("INMPrice")},";//690.11
                                    query_insert_items += $" {Utils.parseStringBD("PoTrgEntry")},";//' '
                                    query_insert_items += $" {Utils.parseStringBD("DropShip")},";//'N'
                                    query_insert_items += $" {Utils.parseStringBD("Address")},";//' '
                                    query_insert_items += $" {Utils.parseStringBD("TaxCode")},";//'IVAV16'
                                    query_insert_items += $" {Utils.parseStringBD("TaxType")},";//'Y'
                                    query_insert_items += $" {Utils.parseStringBD("FreeTxt")},";//' '
                                    query_insert_items += $" {Utils.parseStringBD("PickStatus")},";//'N'
                                    query_insert_items += $" {Utils.parseStringBD("PickOty")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("TrnsCode")},";//5
                                    query_insert_items += $" {Utils.parseStringBD("VatAppld")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("VatAppldFC")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("VatAppldSC")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("BaseQty")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("BaseOpnQty")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("VatDscntPr")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("WtLiable")},";//'N'
                                    query_insert_items += $" {Utils.parseStringBD("DeferrTax")},";//'Y'
                                    query_insert_items += $" {Utils.parseStringBD("EquVatPer")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("EquVatSum")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("EquVatSumF")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("EquVatSumS")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("LineVat")},";//2208.35
                                    query_insert_items += $" {Utils.parseStringBD("LineVatlF")},";//110.42
                                    query_insert_items += $" {Utils.parseStringBD("LineVatS")},";//110.42
                                    query_insert_items += $" {Utils.parseStringBD("unitMsr")},";//'H87'
                                    query_insert_items += $" {Utils.parseStringBD("NumPerMsr")},";//1
                                    query_insert_items += $" {Utils.parseStringBD("CEECFlag")},";//'S'
                                    query_insert_items += $" {Utils.parseStringBD("ToStock")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("ToDiff")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("ExciseAmt")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("TaxPerUnit")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("TotInclTax")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("StckDstSum")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("ReleasQtty")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("LineType")},";//'R'
                                    query_insert_items += $" {Utils.parseStringBD("Text")},";//'Servidores, NAS'
                                    query_insert_items += $" {Utils.parseStringBD("OwnerCode")},";//63
                                    query_insert_items += $" {Utils.parseStringBD("StockPrice")},";//14047.1
                                    query_insert_items += $" {Utils.parseStringBD("ConsumeFCT")},";//'Y'
                                    query_insert_items += $" {Utils.parseStringBD("LstByDsSum")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("StckINMPr")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("LstBINMPr")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("StckDstFc")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("StckDstSc")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("LstByDsFc")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("LstByDsSc")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("StockSum")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("StockSumFc")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("StockSumSc")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("StckSumApp")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("StckAppFc")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("StckAppSc")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("ShipToDesc")},";//'calle fac   col fac\r\rciudad fac,97910, YUC\rMX'
                                    query_insert_items += $" {Utils.parseStringBD("StckAppD")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("StckAppDFC")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("StckAppDSC")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("BasePrice")},";//'E'
                                    query_insert_items += $" {Utils.parseStringBD("GTotal")},";//16010.6
                                    query_insert_items += $" {Utils.parseStringBD("GTotalFC")},";//800.53
                                    query_insert_items += $" {Utils.parseStringBD("GTotalSC")},";//800.53
                                    query_insert_items += $" {Utils.parseStringBD("DistribExp")},";//'Y'
                                    query_insert_items += $" {Utils.parseStringBD("DescOW")},";//'N'
                                    query_insert_items += $" {Utils.parseStringBD("DetailsOW")},";//'N'
                                    query_insert_items += $" {Utils.parseStringBD("GrossBase")},";//-5
                                    query_insert_items += $" {Utils.parseStringBD("VatWoDpm")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("VatWoDpmFc")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("VatWoDpmSc")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("TaxOnly")},";//'N'
                                    query_insert_items += $" {Utils.parseStringBD("WtCalced")},";//'N'
                                    query_insert_items += $" {Utils.parseStringBD("QtyToShip")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("DelivrdQty")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("OrderedQty")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("CiOppLineN")},";//-1
                                    query_insert_items += $" {Utils.parseStringBD("CogsAcct")},";//501000002
                                    query_insert_items += $" {Utils.parseStringBD("ChgAsmBoMW")},";//'N'
                                    query_insert_items += $" {Utils.parseStringBD("TaxDistSum")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("TaxDistSFC")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("TaxDistSSC")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("PostTax")},";//'Y'
                                    query_insert_items += $" {Utils.parseStringBD("AssblValue")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("StockValue")},";//14047.1
                                    query_insert_items += $" {Utils.parseStringBD("GPTtlBasPr")},";//14047.1
                                    query_insert_items += $" {Utils.parseStringBD("unitMsr2")},";//'H87'
                                    query_insert_items += $" {Utils.parseStringBD("NumPerMsr2")},";//1
                                    query_insert_items += $" {Utils.parseStringBD("SpecPrice")},";//'R'
                                    query_insert_items += $" {Utils.parseStringBD("isSrvCall")},";//'N'
                                    query_insert_items += $" {Utils.parseStringBD("PQTReqQty")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("PcDocType")},";//-1
                                    query_insert_items += $" {Utils.parseStringBD("PcQuantity")},";//1
                                    query_insert_items += $" {Utils.parseStringBD("LinManClsd")},";//'N'
                                    query_insert_items += $" {Utils.parseStringBD("VatGrpSrc")},";//'D'
                                    query_insert_items += $" {Utils.parseStringBD("NoInvtryMv")},";//'N'
                                    query_insert_items += $" {Utils.parseStringBD("OpenRtnQty")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("Surpluses")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("DefBreak")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("Shortages")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("UomEntry")},";//-1
                                    query_insert_items += $" {Utils.parseStringBD("UomEntry2")},";//-1
                                    query_insert_items += $" {Utils.parseStringBD("UomCode")},";//'Manual'
                                    query_insert_items += $" {Utils.parseStringBD("UomCode2")},";//'Manual'
                                    query_insert_items += $" {Utils.parseStringBD("NeedQty")},";//'N'
                                    query_insert_items += $" {Utils.parseStringBD("PartRetire")},";//'N'
                                    query_insert_items += $" {Utils.parseStringBD("RetireQty")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("RetireAPC")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("RetirAPCFC")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("RetirAPCSC")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("InvQty")},";//1
                                    query_insert_items += $" {Utils.parseStringBD("OpenInvQty")},";//1
                                    query_insert_items += $" {Utils.parseStringBD("EnSetCost")},";//'N'
                                    query_insert_items += $" {Utils.parseStringBD("RetCost")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("Incoterms")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("TransMod")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("LineVendor")},";//' '
                                    query_insert_items += $" {Utils.parseStringBD("DistribIS")},";//'N'
                                    query_insert_items += $" {Utils.parseStringBD("ISDistrb")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("ISDistrbFC")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("ISDistrbSC")},";//0
                                    query_insert_items += $" {Utils.parseStringBD("IsByPrdct")},";//N'
                                    query_insert_items += $" {Utils.parseStringBD("ItemType")},";//' '
                                    query_insert_items += $" {Utils.parseStringBD("PriceEdit")},";//'N'
                                    query_insert_items += $" {Utils.parseStringBD("LinePoPrss")},";//'N'
                                    query_insert_items += $" {Utils.parseStringBD("FreeChrgBP")},";//'N'
                                    query_insert_items += $" {Utils.parseStringBD("TaxRelev")},";//'Y'
                                    query_insert_items += $" {Utils.parseStringBD("ThirdParty")},";//'N'
                                    query_insert_items += $" {Utils.parseStringBD("InvQtyOnly")},";//'N'
                                    query_insert_items += $" {Utils.parseStringBD("GPBefDisc")},";//800.53
                                    query_insert_items += $" {Utils.parseStringBD("ReturnRsn")},";//-1
                                    query_insert_items += $" {Utils.parseStringBD("ReturnAct")},";//1
                                    query_insert_items += $" {Utils.parseStringBD("NCMCode")},";//25480
                                    query_insert_items += $" {Utils.parseStringBD("IsPrscGood")},";//'N'
                                    query_insert_items += $" {Utils.parseStringBD("IsCstmAct")},";//'N'
                                    query_insert_items += $" {Utils.parseStringBD("U_PorcentajeComision")},";//1
                                    query_insert_items += $" {Utils.parseStringBD("U_Comision")},";//138.02
                                    query_insert_items += $" {Utils.parseStringBD("U_DP_Stock")},";//1
                                    query_insert_items += $" {Utils.parseStringBD("U_DP_DescExtra")},";//'N'
                                    query_insert_items += $" {Utils.parseStringBD("U_DispAd")},";//1
                                    query_insert_items += $" {Utils.parseStringBD("U_E_Pedido")}";//0
                                    #endregion
                                    query_insert_items += ") VALUES (";
                                    #region Values
                                    int qty = (!string.IsNullOrEmpty(item_product_qty) ? int.Parse(item_product_qty.Trim()) : 1);
                                    double totalItemUSD = (!string.IsNullOrEmpty(item_product_net_revenue) ? double.Parse(item_product_net_revenue) : 0);
                                    double PriceUnit = (totalItemUSD / qty);
                                    double tpCambio = double.Parse(tc_Comercial);
                                    double LineTotal = (totalItemUSD * tpCambio);
                                    double tax_amountUSD = double.Parse(item_tax_amount);
                                    double tax_amount = double.Parse(item_tax_amount) * tpCambio;
                                    double GTotal = Math.Round((LineTotal + tax_amount), 2);
                                    double GTotalFC = Math.Round((GTotal / tpCambio), 2);
                                    double PriceAfVAT = totalItemUSD + tax_amountUSD;
                                    query_insert_items += $" {docEntry},";//DocEntry
                                    query_insert_items += $" {lineNum},";//LineNum
                                    query_insert_items += $" -1,";//TargetType
                                    query_insert_items += $" '',";//BaseRef
                                    query_insert_items += $" -1,";//BaseType
                                    query_insert_items += $" 'O',";//LineStatus
                                    query_insert_items += $" '{item_sku}',";//ItemCode
                                    query_insert_items += $" '{item_order_item_name}',";//Dscription
                                    query_insert_items += $" {qty},";//Quantity
                                    query_insert_items += $" {qty},";//OpenQty
                                    query_insert_items += $" {PriceUnit},";//Price
                                    query_insert_items += $" 'USD',";//Currency
                                    query_insert_items += $" {tc_Comercial},";//Rate
                                    query_insert_items += $" 0,";//DiscPrcnt
                                    query_insert_items += $" {LineTotal},";//LineTotal
                                    query_insert_items += $" {totalItemUSD},";//TotalFrgn
                                    query_insert_items += $" {LineTotal},";//OpenSum 
                                    query_insert_items += $" {totalItemUSD},";//OpenSumFC
                                    query_insert_items += $" '{item_sku}',";//VendorNum
                                    query_insert_items += $" '01',";//WhsCode
                                    query_insert_items += $" 2,";//SlpCode
                                    query_insert_items += $" 0,";//Commission
                                    query_insert_items += $" 'N',";//TreeType
                                    query_insert_items += $" '400000002',";//AcctCode
                                    query_insert_items += $" 'Y',";//TaxStatus
                                    query_insert_items += $" 14047.1,";//GrossBuyPr --> falta encontrar de donde viene este valor
                                    query_insert_items += $" {PriceUnit},";//PriceBefDi
                                    query_insert_items += $" NOW(),";//DocDate -->
                                    query_insert_items += $" 0,";//Flags
                                    query_insert_items += $" {qty},";//OpenCreQty
                                    query_insert_items += $" 'N',";//UseBaseUn
                                    query_insert_items += $" ' ',";//SubCatNum
                                    query_insert_items += $" '{cardCode}',";//BaseCard
                                    query_insert_items += $" {totalItemUSD},";//TotalSumSy
                                    query_insert_items += $" {totalItemUSD},";//OpenSumSys
                                    query_insert_items += $" 'O',";//InvntSttus
                                    query_insert_items += $" '',";//Project
                                    query_insert_items += $" 16,";//VatPrcnt
                                    query_insert_items += $" '',";//VatGroup
                                    query_insert_items += $" {PriceAfVAT},";//PriceAfVAT
                                    query_insert_items += $" 0,";//Height1
                                    query_insert_items += $" 0,";//Height2
                                    query_insert_items += $" 0,";//Width1
                                    query_insert_items += $" 0,";//Width2
                                    query_insert_items += $" 0,";//Length1
                                    query_insert_items += $" 0,";//length2
                                    query_insert_items += $" 0,";//Volume
                                    query_insert_items += $" 4,";//VolUnit
                                    query_insert_items += $" 0,";//Weight1
                                    query_insert_items += $" 0,";//Weight2
                                    query_insert_items += $" 1,";//Factor1
                                    query_insert_items += $" 1,";//Factor2
                                    query_insert_items += $" 1,";//Factor3
                                    query_insert_items += $" 1,";//Factor4
                                    query_insert_items += $" {qty},";//PackQty
                                    query_insert_items += $" 'Y',";//UpdInvntry
                                    query_insert_items += $" ' ',";//SWW
                                    query_insert_items += $" 2208.35,";//VatSum
                                    query_insert_items += $" 110.42,";//VatSumFrgn --> falta encontrar de donde viene este valor
                                    query_insert_items += $" 110.42,";//VatSumSy --> falta encontrar de donde viene este valor
                                    query_insert_items += $" {FinncPriod},";//FinncPriod
                                    query_insert_items += $" '23',";//ObjType
                                    query_insert_items += $" 0,";//LogInstanc
                                    query_insert_items += $" 0,";//DedVatSum
                                    query_insert_items += $" 0,";//DedVatSumF
                                    query_insert_items += $" 0,";//DedVatSumS
                                    query_insert_items += $" 'N',";//IsAqcuistn
                                    query_insert_items += $" 0,";//DistribSum
                                    query_insert_items += $" 0,";//DstrbSumFC
                                    query_insert_items += $" 0,";//DstrbSumSC
                                    query_insert_items += $" -244.9,";//GrssProfit
                                    query_insert_items += $" -12.25,";//GrssProfSC
                                    query_insert_items += $" -12.25,";//GrssProfFC
                                    query_insert_items += $" 0,";//VisOrder
                                    query_insert_items += $" {PriceUnit},";//INMPrice
                                    query_insert_items += $" ' ',";//PoTrgEntry
                                    query_insert_items += $" 'N',";//DropShip
                                    query_insert_items += $" ' ',";//Address
                                    query_insert_items += $" 'IVAV16',";//TaxCode
                                    query_insert_items += $" 'Y',";//TaxType
                                    query_insert_items += $" ' ',";//FreeTxt
                                    query_insert_items += $" 'N',";//PickStatus
                                    query_insert_items += $" 0,";//PickOty
                                    query_insert_items += $" 5,";//TrnsCode
                                    query_insert_items += $" 0,";//VatAppld
                                    query_insert_items += $" 0,";//VatAppldFC
                                    query_insert_items += $" 0,";//VatAppldSC
                                    query_insert_items += $" 0,";//BaseQty
                                    query_insert_items += $" 0,";//BaseOpnQty
                                    query_insert_items += $" 0,";//VatDscntPr
                                    query_insert_items += $" 'N',";//WtLiable
                                    query_insert_items += $" 'Y',";//DeferrTax
                                    query_insert_items += $" 0,";//EquVatPer
                                    query_insert_items += $" 0,";//EquVatSum
                                    query_insert_items += $" 0,";//EquVatSumF
                                    query_insert_items += $" 0,";//EquVatSumS
                                    query_insert_items += $" {tax_amount},";//LineVat
                                    query_insert_items += $" {tax_amountUSD},";//LineVatlF --> falta encontrar de donde viene este valor
                                    query_insert_items += $" {tax_amountUSD},";//LineVatS --> falta encontrar de donde viene este valor
                                    query_insert_items += $" 'H87',";//unitMsr
                                    query_insert_items += $" 1,";//NumPerMsr
                                    query_insert_items += $" 'S',";//CEECFlag
                                    query_insert_items += $" 0,";//ToStock
                                    query_insert_items += $" 0,";//ToDiff
                                    query_insert_items += $" 0,";//ExciseAmt
                                    query_insert_items += $" 0,";//TaxPerUnit
                                    query_insert_items += $" 0,";//TotInclTax
                                    query_insert_items += $" 0,";//StckDstSum
                                    query_insert_items += $" 0,";//ReleasQtty
                                    query_insert_items += $" 'R',";//LineType
                                    query_insert_items += $" 'Servidores, NAS',";//Text   --> falta encontrar como se obtiene este valor
                                    query_insert_items += $" 63,";//OwnerCode
                                    query_insert_items += $" 14047.1,";//StockPrice --> falta encontrar de donde viene este valor
                                    query_insert_items += $" 'Y',";//ConsumeFCT
                                    query_insert_items += $" 0,";//LstByDsSum
                                    query_insert_items += $" 0,";//StckINMPr
                                    query_insert_items += $" 0,";//LstBINMPr
                                    query_insert_items += $" 0,";//StckDstFc
                                    query_insert_items += $" 0,";//StckDstSc
                                    query_insert_items += $" 0,";//LstByDsFc
                                    query_insert_items += $" 0,";//LstByDsSc
                                    query_insert_items += $" 0,";//StockSum
                                    query_insert_items += $" 0,";//StockSumFc
                                    query_insert_items += $" 0,";//StockSumSc
                                    query_insert_items += $" 0,";//StckSumApp
                                    query_insert_items += $" 0,";//StckAppFc
                                    query_insert_items += $" 0,";//StckAppSc
                                    query_insert_items += $" '{AddressCompleteBilling}',";//ShipToDesc
                                    query_insert_items += $" 0,";//StckAppD
                                    query_insert_items += $" 0,";//StckAppDFC
                                    query_insert_items += $" 0,";//StckAppDSC
                                    query_insert_items += $" 'E',";//BasePrice
                                    query_insert_items += $" {GTotal},";//GTotal -> LineTotal + LineVat
                                    query_insert_items += $" {GTotalFC},";//GTotalFC   --> LineTotal / tpCambio
                                    query_insert_items += $" {GTotalFC},";//GTotalSC   --> LineTotal / tpCambio
                                    query_insert_items += $" 'Y',";//DistribExp
                                    query_insert_items += $" 'N',";//DescOW
                                    query_insert_items += $" 'N',";//DetailsOW
                                    query_insert_items += $" -5,";//GrossBase
                                    query_insert_items += $" 0,";//VatWoDpm
                                    query_insert_items += $" 0,";//VatWoDpmFc
                                    query_insert_items += $" 0,";//VatWoDpmSc
                                    query_insert_items += $" 'N',";//TaxOnly
                                    query_insert_items += $" 'N',";//WtCalced
                                    query_insert_items += $" 0,";//QtyToShip
                                    query_insert_items += $" 0,";//DelivrdQty
                                    query_insert_items += $" 0,";//OrderedQty
                                    query_insert_items += $" -1,";//CiOppLineN
                                    query_insert_items += $" '501000002',";//CogsAcct
                                    query_insert_items += $" 'N',";//ChgAsmBoMW
                                    query_insert_items += $" 0,";//TaxDistSum
                                    query_insert_items += $" 0,";//TaxDistSFC
                                    query_insert_items += $" 0,";//TaxDistSSC
                                    query_insert_items += $" 'Y',";//PostTax
                                    query_insert_items += $" 0,";//AssblValue
                                    query_insert_items += $" 14047.1,";//StockValue --> falta encontrar de donde viene este valor
                                    query_insert_items += $" 14047.1,";//GPTtlBasPr --> falta encontrar de donde viene este valor
                                    query_insert_items += $" 'H87',";//unitMsr2
                                    query_insert_items += $" 1,";//NumPerMsr2
                                    query_insert_items += $" 'N',";//SpecPrice
                                    query_insert_items += $" 'N',";//isSrvCall
                                    query_insert_items += $" 0,";//PQTReqQty
                                    query_insert_items += $" -1,";//PcDocType
                                    query_insert_items += $" {qty},";//PcQuantity
                                    query_insert_items += $" 'N',";//LinManClsd
                                    query_insert_items += $" 'D',";//VatGrpSrc
                                    query_insert_items += $" 'N',";//NoInvtryMv
                                    query_insert_items += $" 0,";//OpenRtnQty
                                    query_insert_items += $" 0,";//Surpluses
                                    query_insert_items += $" 0,";//DefBreak
                                    query_insert_items += $" 0,";//Shortages
                                    query_insert_items += $" -1,";//UomEntry
                                    query_insert_items += $" -1,";//UomEntry2
                                    query_insert_items += $" 'Manual',";//UomCode
                                    query_insert_items += $" 'Manual',";//UomCode2
                                    query_insert_items += $" 'N',";//NeedQty
                                    query_insert_items += $" 'N',";//PartRetire
                                    query_insert_items += $" 0,";//RetireQty
                                    query_insert_items += $" 0,";//RetireAPC
                                    query_insert_items += $" 0,";//RetirAPCFC
                                    query_insert_items += $" 0,";//RetirAPCSC
                                    query_insert_items += $" {qty},";//InvQty
                                    query_insert_items += $" {qty},";//OpenInvQty
                                    query_insert_items += $" 'N',";//EnSetCost
                                    query_insert_items += $" 0,";//RetCost
                                    query_insert_items += $" 0,";//Incoterms
                                    query_insert_items += $" 0,";//TransMod
                                    query_insert_items += $" ' ',";//LineVendor
                                    query_insert_items += $" 'N',";//DistribIS
                                    query_insert_items += $" 0,";//ISDistrb
                                    query_insert_items += $" 0,";//ISDistrbFC
                                    query_insert_items += $" 0,";//ISDistrbSC
                                    query_insert_items += $" 'N',";//IsByPrdct
                                    query_insert_items += $" 4,";//ItemType
                                    query_insert_items += $" 'N',";//PriceEdit
                                    query_insert_items += $" 'N',";//LinePoPrss
                                    query_insert_items += $" 'N',";//FreeChrgBP
                                    query_insert_items += $" 'Y',";//TaxRelev
                                    query_insert_items += $" 'N',";//ThirdParty
                                    query_insert_items += $" 'N',";//InvQtyOnly
                                    query_insert_items += $" 800.53,";//GPBefDisc   --> falta encontrar como se obtiene este valor
                                    query_insert_items += $" -1,";//ReturnRsn
                                    query_insert_items += $" 1,";//ReturnAct
                                    query_insert_items += $" 25480,";//NCMCode
                                    query_insert_items += $" 'N',";//IsPrscGood
                                    query_insert_items += $" 'N',";//IsCstmAct
                                    query_insert_items += $" 1,";//U_PorcentajeComision
                                    query_insert_items += $" 0,";//U_Comision   --> falta encontrar como se obtiene este valor
                                    query_insert_items += $" 1,";//U_DP_Stock
                                    query_insert_items += $" 'N',";//U_DP_DescExtra
                                    query_insert_items += $" 1,";//U_DispAd
                                    query_insert_items += $" 0";//U_E_Pedido
                                    #endregion
                                    query_insert_items += ")";

                                    bool fgInsertItem = DBConn.ExecQueryInsert(query_insert_items);
                                    if (!fgInsertItem)
                                    {
                                        Utils.PrintLog("SyncLogsToOrders", "0", $"No fue posible realizar la sincronización el item {item_sku} del pedido. \nquery: {query_insert_items}");
                                    }
                                    else
                                        lineNum++;
                                }
                                #endregion
                            }
                            #region item envio

                            if (string.IsNullOrEmpty(shipping_total)) continue; //Por si viene nulo el monto de envío

                            if (Convert.ToDouble(shipping_total.Trim()) == 0)
                                continue;
                            else
                            {
                                //DataTable tbl_lineNumEnvio = DBConn.ExecQuery($"SELECT MAX({Utils.parseStringBD("LineNum")}) FROM {Utils.parseStringBD("QUT1")} WHERE {Utils.parseStringBD("DocEntry")} = {(docEntry)}");
                                //long lineNumEnvio = tbl_lineNumEnvio != null && tbl_lineNumEnvio.Rows != null && tbl_lineNumEnvio.Rows.Count > 0 ? tbl_lineNumEnvio.Rows[0][0] != null && !string.IsNullOrEmpty(tbl_lineNumEnvio.Rows[0][0].ToString()) && tbl_lineNumEnvio.Rows[0][0].ToString() != "?" ? long.Parse(tbl_lineNumEnvio.Rows[0][0].ToString()) : 0 : 0;
                                //lineNumEnvio++;

                                string query_insert_envio = $"INSERT INTO {Utils.parseStringBD("QUT1")} (";
                                #region columnsInsert
                                query_insert_envio += $" {Utils.parseStringBD("DocEntry")},";//123
                                query_insert_envio += $" {Utils.parseStringBD("LineNum")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("TargetType")},";//-1
                                query_insert_envio += $" {Utils.parseStringBD("BaseRef")},";//' '
                                query_insert_envio += $" {Utils.parseStringBD("BaseType")},";//-1
                                query_insert_envio += $" {Utils.parseStringBD("LineStatus")},";//'O'
                                query_insert_envio += $" {Utils.parseStringBD("ItemCode")},";//'otemCode'
                                query_insert_envio += $" {Utils.parseStringBD("Dscription")},"; //'Description'
                                query_insert_envio += $" {Utils.parseStringBD("Quantity")},";//1
                                query_insert_envio += $" {Utils.parseStringBD("OpenQty")},";//1
                                query_insert_envio += $" {Utils.parseStringBD("Price")},";//690.11
                                query_insert_envio += $" {Utils.parseStringBD("Currency")},";//'USD'
                                query_insert_envio += $" {Utils.parseStringBD("Rate")},";//20
                                query_insert_envio += $" {Utils.parseStringBD("DiscPrcnt")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("LineTotal")},";//13802.2
                                query_insert_envio += $" {Utils.parseStringBD("TotalFrgn")},";//690.11
                                query_insert_envio += $" {Utils.parseStringBD("OpenSum")},";//13802.2
                                query_insert_envio += $" {Utils.parseStringBD("OpenSumFC")},";//690.11
                                query_insert_envio += $" {Utils.parseStringBD("VendorNum")},";//'TS-251+-8G-US'
                                query_insert_envio += $" {Utils.parseStringBD("WhsCode")},";//1
                                query_insert_envio += $" {Utils.parseStringBD("SlpCode")},";//2
                                query_insert_envio += $" {Utils.parseStringBD("Commission")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("TreeType")},";//'N'
                                query_insert_envio += $" {Utils.parseStringBD("AcctCode")},";//'400000002'
                                query_insert_envio += $" {Utils.parseStringBD("TaxStatus")},";//'Y'
                                query_insert_envio += $" {Utils.parseStringBD("GrossBuyPr")},";//14047.1
                                query_insert_envio += $" {Utils.parseStringBD("PriceBefDi")},";//690.11
                                query_insert_envio += $" {Utils.parseStringBD("DocDate")},";//NOW()
                                query_insert_envio += $" {Utils.parseStringBD("Flags")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("OpenCreQty")},";//1
                                query_insert_envio += $" {Utils.parseStringBD("UseBaseUn")},";//'N'
                                query_insert_envio += $" {Utils.parseStringBD("SubCatNum")},";//' '
                                query_insert_envio += $" {Utils.parseStringBD("BaseCard")},";//'GDL-00901'
                                query_insert_envio += $" {Utils.parseStringBD("TotalSumSy")},";//690.11
                                query_insert_envio += $" {Utils.parseStringBD("OpenSumSys")},";//690.11
                                query_insert_envio += $" {Utils.parseStringBD("InvntSttus")},";//'O'
                                query_insert_envio += $" {Utils.parseStringBD("Project")},";//' '
                                query_insert_envio += $" {Utils.parseStringBD("VatPrcnt")},";//16
                                query_insert_envio += $" {Utils.parseStringBD("VatGroup")},";//' '
                                query_insert_envio += $" {Utils.parseStringBD("PriceAfVAT")},";//800.53
                                query_insert_envio += $" {Utils.parseStringBD("Height1")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("Height2")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("Width1")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("Width2")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("Length1")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("length2")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("Volume")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("VolUnit")},";//4
                                query_insert_envio += $" {Utils.parseStringBD("Weight1")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("Weight2")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("Factor1")},";//1
                                query_insert_envio += $" {Utils.parseStringBD("Factor2")},";//1
                                query_insert_envio += $" {Utils.parseStringBD("Factor3")},";//1
                                query_insert_envio += $" {Utils.parseStringBD("Factor4")},";//1
                                query_insert_envio += $" {Utils.parseStringBD("PackQty")},";//1
                                query_insert_envio += $" {Utils.parseStringBD("UpdInvntry")},";//'Y'
                                query_insert_envio += $" {Utils.parseStringBD("SWW")},";//' '
                                query_insert_envio += $" {Utils.parseStringBD("VatSum")},";//2208.35
                                query_insert_envio += $" {Utils.parseStringBD("VatSumFrgn")},";//110.42
                                query_insert_envio += $" {Utils.parseStringBD("VatSumSy")},";//110.42
                                query_insert_envio += $" {Utils.parseStringBD("FinncPriod")},";//55
                                query_insert_envio += $" {Utils.parseStringBD("ObjType")},";//23
                                query_insert_envio += $" {Utils.parseStringBD("LogInstanc")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("DedVatSum")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("DedVatSumF")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("DedVatSumS")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("IsAqcuistn")},";//'N'
                                query_insert_envio += $" {Utils.parseStringBD("DistribSum")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("DstrbSumFC")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("DstrbSumSC")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("GrssProfit")},";//-244.9
                                query_insert_envio += $" {Utils.parseStringBD("GrssProfSC")},";//-12.25
                                query_insert_envio += $" {Utils.parseStringBD("GrssProfFC")},";//-12.25
                                query_insert_envio += $" {Utils.parseStringBD("VisOrder")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("INMPrice")},";//690.11
                                query_insert_envio += $" {Utils.parseStringBD("PoTrgEntry")},";//' '
                                query_insert_envio += $" {Utils.parseStringBD("DropShip")},";//'N'
                                query_insert_envio += $" {Utils.parseStringBD("Address")},";//' '
                                query_insert_envio += $" {Utils.parseStringBD("TaxCode")},";//'IVAV16'
                                query_insert_envio += $" {Utils.parseStringBD("TaxType")},";//'Y'
                                query_insert_envio += $" {Utils.parseStringBD("FreeTxt")},";//' '
                                query_insert_envio += $" {Utils.parseStringBD("PickStatus")},";//'N'
                                query_insert_envio += $" {Utils.parseStringBD("PickOty")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("TrnsCode")},";//5
                                query_insert_envio += $" {Utils.parseStringBD("VatAppld")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("VatAppldFC")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("VatAppldSC")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("BaseQty")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("BaseOpnQty")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("VatDscntPr")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("WtLiable")},";//'N'
                                query_insert_envio += $" {Utils.parseStringBD("DeferrTax")},";//'Y'
                                query_insert_envio += $" {Utils.parseStringBD("EquVatPer")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("EquVatSum")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("EquVatSumF")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("EquVatSumS")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("LineVat")},";//2208.35
                                query_insert_envio += $" {Utils.parseStringBD("LineVatlF")},";//110.42
                                query_insert_envio += $" {Utils.parseStringBD("LineVatS")},";//110.42
                                query_insert_envio += $" {Utils.parseStringBD("unitMsr")},";//'H87'
                                query_insert_envio += $" {Utils.parseStringBD("NumPerMsr")},";//1
                                query_insert_envio += $" {Utils.parseStringBD("CEECFlag")},";//'S'
                                query_insert_envio += $" {Utils.parseStringBD("ToStock")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("ToDiff")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("ExciseAmt")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("TaxPerUnit")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("TotInclTax")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("StckDstSum")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("ReleasQtty")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("LineType")},";//'R'
                                query_insert_envio += $" {Utils.parseStringBD("Text")},";//'Servidores, NAS'
                                query_insert_envio += $" {Utils.parseStringBD("OwnerCode")},";//63
                                query_insert_envio += $" {Utils.parseStringBD("StockPrice")},";//14047.1
                                query_insert_envio += $" {Utils.parseStringBD("ConsumeFCT")},";//'Y'
                                query_insert_envio += $" {Utils.parseStringBD("LstByDsSum")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("StckINMPr")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("LstBINMPr")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("StckDstFc")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("StckDstSc")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("LstByDsFc")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("LstByDsSc")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("StockSum")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("StockSumFc")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("StockSumSc")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("StckSumApp")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("StckAppFc")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("StckAppSc")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("ShipToDesc")},";//'calle fac   col fac\r\rciudad fac,97910, YUC\rMX'
                                query_insert_envio += $" {Utils.parseStringBD("StckAppD")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("StckAppDFC")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("StckAppDSC")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("BasePrice")},";//'E'
                                query_insert_envio += $" {Utils.parseStringBD("GTotal")},";//16010.6
                                query_insert_envio += $" {Utils.parseStringBD("GTotalFC")},";//800.53
                                query_insert_envio += $" {Utils.parseStringBD("GTotalSC")},";//800.53
                                query_insert_envio += $" {Utils.parseStringBD("DistribExp")},";//'Y'
                                query_insert_envio += $" {Utils.parseStringBD("DescOW")},";//'N'
                                query_insert_envio += $" {Utils.parseStringBD("DetailsOW")},";//'N'
                                query_insert_envio += $" {Utils.parseStringBD("GrossBase")},";//-5
                                query_insert_envio += $" {Utils.parseStringBD("VatWoDpm")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("VatWoDpmFc")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("VatWoDpmSc")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("TaxOnly")},";//'N'
                                query_insert_envio += $" {Utils.parseStringBD("WtCalced")},";//'N'
                                query_insert_envio += $" {Utils.parseStringBD("QtyToShip")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("DelivrdQty")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("OrderedQty")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("CiOppLineN")},";//-1
                                query_insert_envio += $" {Utils.parseStringBD("CogsAcct")},";//501000002
                                query_insert_envio += $" {Utils.parseStringBD("ChgAsmBoMW")},";//'N'
                                query_insert_envio += $" {Utils.parseStringBD("TaxDistSum")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("TaxDistSFC")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("TaxDistSSC")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("PostTax")},";//'Y'
                                query_insert_envio += $" {Utils.parseStringBD("AssblValue")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("StockValue")},";//14047.1
                                query_insert_envio += $" {Utils.parseStringBD("GPTtlBasPr")},";//14047.1
                                query_insert_envio += $" {Utils.parseStringBD("unitMsr2")},";//'H87'
                                query_insert_envio += $" {Utils.parseStringBD("NumPerMsr2")},";//1
                                query_insert_envio += $" {Utils.parseStringBD("SpecPrice")},";//'R'
                                query_insert_envio += $" {Utils.parseStringBD("isSrvCall")},";//'N'
                                query_insert_envio += $" {Utils.parseStringBD("PQTReqQty")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("PcDocType")},";//-1
                                query_insert_envio += $" {Utils.parseStringBD("PcQuantity")},";//1
                                query_insert_envio += $" {Utils.parseStringBD("LinManClsd")},";//'N'
                                query_insert_envio += $" {Utils.parseStringBD("VatGrpSrc")},";//'D'
                                query_insert_envio += $" {Utils.parseStringBD("NoInvtryMv")},";//'N'
                                query_insert_envio += $" {Utils.parseStringBD("OpenRtnQty")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("Surpluses")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("DefBreak")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("Shortages")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("UomEntry")},";//-1
                                query_insert_envio += $" {Utils.parseStringBD("UomEntry2")},";//-1
                                query_insert_envio += $" {Utils.parseStringBD("UomCode")},";//'Manual'
                                query_insert_envio += $" {Utils.parseStringBD("UomCode2")},";//'Manual'
                                query_insert_envio += $" {Utils.parseStringBD("NeedQty")},";//'N'
                                query_insert_envio += $" {Utils.parseStringBD("PartRetire")},";//'N'
                                query_insert_envio += $" {Utils.parseStringBD("RetireQty")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("RetireAPC")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("RetirAPCFC")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("RetirAPCSC")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("InvQty")},";//1
                                query_insert_envio += $" {Utils.parseStringBD("OpenInvQty")},";//1
                                query_insert_envio += $" {Utils.parseStringBD("EnSetCost")},";//'N'
                                query_insert_envio += $" {Utils.parseStringBD("RetCost")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("Incoterms")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("TransMod")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("LineVendor")},";//' '
                                query_insert_envio += $" {Utils.parseStringBD("DistribIS")},";//'N'
                                query_insert_envio += $" {Utils.parseStringBD("ISDistrb")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("ISDistrbFC")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("ISDistrbSC")},";//0
                                query_insert_envio += $" {Utils.parseStringBD("IsByPrdct")},";//N'
                                query_insert_envio += $" {Utils.parseStringBD("ItemType")},";//' '
                                query_insert_envio += $" {Utils.parseStringBD("PriceEdit")},";//'N'
                                query_insert_envio += $" {Utils.parseStringBD("LinePoPrss")},";//'N'
                                query_insert_envio += $" {Utils.parseStringBD("FreeChrgBP")},";//'N'
                                query_insert_envio += $" {Utils.parseStringBD("TaxRelev")},";//'Y'
                                query_insert_envio += $" {Utils.parseStringBD("ThirdParty")},";//'N'
                                query_insert_envio += $" {Utils.parseStringBD("InvQtyOnly")},";//'N'
                                query_insert_envio += $" {Utils.parseStringBD("GPBefDisc")},";//800.53
                                query_insert_envio += $" {Utils.parseStringBD("ReturnRsn")},";//-1
                                query_insert_envio += $" {Utils.parseStringBD("ReturnAct")},";//1
                                query_insert_envio += $" {Utils.parseStringBD("NCMCode")},";//25480
                                query_insert_envio += $" {Utils.parseStringBD("IsPrscGood")},";//'N'
                                query_insert_envio += $" {Utils.parseStringBD("IsCstmAct")},";//'N'
                                query_insert_envio += $" {Utils.parseStringBD("U_PorcentajeComision")},";//1
                                query_insert_envio += $" {Utils.parseStringBD("U_Comision")},";//138.02
                                query_insert_envio += $" {Utils.parseStringBD("U_DP_Stock")},";//1
                                query_insert_envio += $" {Utils.parseStringBD("U_DP_DescExtra")},";//'N'
                                query_insert_envio += $" {Utils.parseStringBD("U_DispAd")},";//1
                                query_insert_envio += $" {Utils.parseStringBD("U_E_Pedido")}";//0
                                #endregion
                                query_insert_envio += ") VALUES (";
                                #region valuesColumnsInsert
                                double tpCambio = double.Parse(tc_Comercial);
                                double priceUSD = double.Parse(shipping_total.Trim());
                                double LineTotal = double.Parse(shipping_total.Trim()) * tpCambio;
                                double taxUSD = double.Parse(tax_total);
                                double tax = taxUSD * tpCambio;
                                double GTotal = Math.Round((LineTotal + tax), 2);
                                double GTotalFC = Math.Round((GTotal / tpCambio), 2);
                                double PriceAfVAT = priceUSD + taxUSD;

                                query_insert_envio += $" {docEntry},";//DocEntry
                                query_insert_envio += $" {lineNum},";//LineNum
                                query_insert_envio += $" -1,";//TargetType
                                query_insert_envio += $" ' ',";//BaseRef
                                query_insert_envio += $" -1,";//BaseType
                                query_insert_envio += $" 'O',";//LineStatus
                                query_insert_envio += $" 'SERV001',";//ItemCode
                                query_insert_envio += $" 'SERVICIO DE ENVÍO',";//Dscription
                                query_insert_envio += $" 1,";//Quantity
                                query_insert_envio += $" 1,";//OpenQty
                                query_insert_envio += $" {priceUSD},";//Price
                                query_insert_envio += $" 'USD',";//Currency
                                query_insert_envio += $" {tc_Comercial},";//Rate
                                query_insert_envio += $" 0,";//DiscPrcnt
                                query_insert_envio += $" {LineTotal},";//LineTotal
                                query_insert_envio += $" {priceUSD},";//TotalFrgn
                                query_insert_envio += $" {LineTotal},";//OpenSum
                                query_insert_envio += $" {priceUSD},";//OpenSumFC
                                query_insert_envio += $" '',";//VendorNum
                                query_insert_envio += $" '01',";//WhsCode
                                query_insert_envio += $" 2,";//SlpCode
                                query_insert_envio += $" 0,";//Commission
                                query_insert_envio += $" 'N',";//TreeType
                                query_insert_envio += $" '400000002',";//AcctCode
                                query_insert_envio += $" 'Y',";//TaxStatus
                                query_insert_envio += $" 0,";//GrossBuyPr --> falta encontrar de donde viene este valor
                                query_insert_envio += $" {priceUSD},";//PriceBefDi
                                query_insert_envio += $" NOW(),";//DocDate
                                query_insert_envio += $" 0,";//Flags
                                query_insert_envio += $" 1,";//OpenCreQty
                                query_insert_envio += $" 'N',";//UseBaseUn
                                query_insert_envio += $" ' ',";//SubCatNum
                                query_insert_envio += $" '{cardCode}',";//BaseCard
                                query_insert_envio += $" {priceUSD},";//TotalSumSy
                                query_insert_envio += $" {priceUSD},";//OpenSumSys
                                query_insert_envio += $" 'O',";//InvntSttus
                                query_insert_envio += $" ' ',";//Project
                                query_insert_envio += $" 16,";//VatPrcnt
                                query_insert_envio += $" ' ',";//VatGroup
                                query_insert_envio += $" {PriceAfVAT},";//PriceAfVAT  --> falta encontrar como se obtiene este valor
                                query_insert_envio += $" 0,";//Height1
                                query_insert_envio += $" 0,";//Height2
                                query_insert_envio += $" 0,";//Width1
                                query_insert_envio += $" 0,";//Width2
                                query_insert_envio += $" 0,";//Length1
                                query_insert_envio += $" 0,";//length2
                                query_insert_envio += $" 0,";//Volume
                                query_insert_envio += $" 4,";//VolUnit
                                query_insert_envio += $" 0,";//Weight1
                                query_insert_envio += $" 0,";//Weight2
                                query_insert_envio += $" 1,";//Factor1
                                query_insert_envio += $" 1,";//Factor2
                                query_insert_envio += $" 1,";//Factor3
                                query_insert_envio += $" 1,";//Factor4
                                query_insert_envio += $" 1,";//PackQty
                                query_insert_envio += $" 'Y',";//UpdInvntry
                                query_insert_envio += $" ' ',";//SWW
                                query_insert_envio += $" 3.2,";//VatSum --> falta encontrar de donde viene este valor
                                query_insert_envio += $" 0.16,";//VatSumFrgn --> falta encontrar de donde viene este valor
                                query_insert_envio += $" 0.16,";//VatSumSy --> falta encontrar de donde viene este valor
                                query_insert_envio += $" {FinncPriod},";//FinncPriod
                                query_insert_envio += $" '23',";//ObjType
                                query_insert_envio += $" 0,";//LogInstanc
                                query_insert_envio += $" 0,";//DedVatSum
                                query_insert_envio += $" 0,";//DedVatSumF
                                query_insert_envio += $" 0,";//DedVatSumS
                                query_insert_envio += $" 'N',";//IsAqcuistn
                                query_insert_envio += $" 0,";//DistribSum
                                query_insert_envio += $" 0,";//DstrbSumFC
                                query_insert_envio += $" 0,";//DstrbSumSC
                                query_insert_envio += $" 20,";//GrssProfit --> falta encontrar de donde viene este valor
                                query_insert_envio += $" 1,";//GrssProfSC
                                query_insert_envio += $" 1,";//GrssProfFC
                                query_insert_envio += $" 0,";//VisOrder
                                query_insert_envio += $" {priceUSD},";//INMPrice
                                query_insert_envio += $" ' ',";//PoTrgEntry
                                query_insert_envio += $" 'N',";//DropShip
                                query_insert_envio += $" ' ',";//Address
                                query_insert_envio += $" 'IVAV16',";//TaxCode
                                query_insert_envio += $" 'Y',";//TaxType
                                query_insert_envio += $" ' ',";//FreeTxt
                                query_insert_envio += $" 'N',";//PickStatus
                                query_insert_envio += $" 0,";//PickOty
                                query_insert_envio += $" 5,";//TrnsCode
                                query_insert_envio += $" 0,";//VatAppld
                                query_insert_envio += $" 0,";//VatAppldFC
                                query_insert_envio += $" 0,";//VatAppldSC
                                query_insert_envio += $" 0,";//BaseQty
                                query_insert_envio += $" 0,";//BaseOpnQty
                                query_insert_envio += $" 0,";//VatDscntPr
                                query_insert_envio += $" 'N',";//WtLiable
                                query_insert_envio += $" 'Y',";//DeferrTax
                                query_insert_envio += $" 0,";//EquVatPer
                                query_insert_envio += $" 0,";//EquVatSum
                                query_insert_envio += $" 0,";//EquVatSumF
                                query_insert_envio += $" 0,";//EquVatSumS
                                query_insert_envio += $" {tax},";//LineVat --> falta encontrar de donde viene este valor
                                query_insert_envio += $" {taxUSD},";//LineVatlF --> falta encontrar de donde viene este valor
                                query_insert_envio += $" {taxUSD},";//LineVatS --> falta encontrar de donde viene este valor
                                query_insert_envio += $" 'E48',";//unitMsr
                                query_insert_envio += $" 1,";//NumPerMsr
                                query_insert_envio += $" 'S',";//CEECFlag
                                query_insert_envio += $" 0,";//ToStock
                                query_insert_envio += $" 0,";//ToDiff
                                query_insert_envio += $" 0,";//ExciseAmt
                                query_insert_envio += $" 0,";//TaxPerUnit
                                query_insert_envio += $" 0,";//TotInclTax
                                query_insert_envio += $" 0,";//StckDstSum
                                query_insert_envio += $" 0,";//ReleasQtty
                                query_insert_envio += $" 'R',";//LineType
                                query_insert_envio += $" 'Servidores, NAS',";//Text   --> falta encontrar como se obtiene este valor
                                query_insert_envio += $" 63,";//OwnerCode
                                query_insert_envio += $" 0,";//StockPrice --> falta encontrar de donde viene este valor
                                query_insert_envio += $" 'Y',";//ConsumeFCT
                                query_insert_envio += $" 0,";//LstByDsSum
                                query_insert_envio += $" 0,";//StckINMPr
                                query_insert_envio += $" 0,";//LstBINMPr
                                query_insert_envio += $" 0,";//StckDstFc
                                query_insert_envio += $" 0,";//StckDstSc
                                query_insert_envio += $" 0,";//LstByDsFc
                                query_insert_envio += $" 0,";//LstByDsSc
                                query_insert_envio += $" 0,";//StockSum
                                query_insert_envio += $" 0,";//StockSumFc
                                query_insert_envio += $" 0,";//StockSumSc
                                query_insert_envio += $" 0,";//StckSumApp
                                query_insert_envio += $" 0,";//StckAppFc
                                query_insert_envio += $" 0,";//StckAppSc
                                query_insert_envio += $" '{AddressCompleteBilling}',";//ShipToDesc
                                query_insert_envio += $" 0,";//StckAppD
                                query_insert_envio += $" 0,";//StckAppDFC
                                query_insert_envio += $" 0,";//StckAppDSC
                                query_insert_envio += $" 'E',";//BasePrice
                                query_insert_envio += $" {GTotal},";//GTotal
                                query_insert_envio += $" {GTotalFC},";//GTotalFC
                                query_insert_envio += $" {GTotalFC},";//GTotalSC
                                query_insert_envio += $" 'Y',";//DistribExp
                                query_insert_envio += $" 'N',";//DescOW
                                query_insert_envio += $" 'N',";//DetailsOW
                                query_insert_envio += $" -5,";//GrossBase
                                query_insert_envio += $" 0,";//VatWoDpm
                                query_insert_envio += $" 0,";//VatWoDpmFc
                                query_insert_envio += $" 0,";//VatWoDpmSc
                                query_insert_envio += $" 'N',";//TaxOnly
                                query_insert_envio += $" 'N',";//WtCalced
                                query_insert_envio += $" 0,";//QtyToShip
                                query_insert_envio += $" 0,";//DelivrdQty
                                query_insert_envio += $" 0,";//OrderedQty
                                query_insert_envio += $" -1,";//CiOppLineN
                                query_insert_envio += $" '501000002',";//CogsAcct
                                query_insert_envio += $" 'N',";//ChgAsmBoMW
                                query_insert_envio += $" 0,";//TaxDistSum
                                query_insert_envio += $" 0,";//TaxDistSFC
                                query_insert_envio += $" 0,";//TaxDistSSC
                                query_insert_envio += $" 'Y',";//PostTax
                                query_insert_envio += $" 0,";//AssblValue
                                query_insert_envio += $" 0,";//StockValue
                                query_insert_envio += $" 0,";//GPTtlBasPr
                                query_insert_envio += $" 'E48',";//unitMsr2
                                query_insert_envio += $" 1,";//NumPerMsr2
                                query_insert_envio += $" 'N',";//SpecPrice
                                query_insert_envio += $" 'N',";//isSrvCall
                                query_insert_envio += $" 0,";//PQTReqQty
                                query_insert_envio += $" -1,";//PcDocType
                                query_insert_envio += $" 1,";//PcQuantity
                                query_insert_envio += $" 'N',";//LinManClsd
                                query_insert_envio += $" 'D',";//VatGrpSrc
                                query_insert_envio += $" 'N',";//NoInvtryMv
                                query_insert_envio += $" 0,";//OpenRtnQty
                                query_insert_envio += $" 0,";//Surpluses
                                query_insert_envio += $" 0,";//DefBreak
                                query_insert_envio += $" 0,";//Shortages
                                query_insert_envio += $" -1,";//UomEntry
                                query_insert_envio += $" -1,";//UomEntry2
                                query_insert_envio += $" 'Manual',";//UomCode
                                query_insert_envio += $" 'Manual',";//UomCode2
                                query_insert_envio += $" 'N',";//NeedQty
                                query_insert_envio += $" 'N',";//PartRetire
                                query_insert_envio += $" 0,";//RetireQty
                                query_insert_envio += $" 0,";//RetireAPC
                                query_insert_envio += $" 0,";//RetirAPCFC
                                query_insert_envio += $" 0,";//RetirAPCSC
                                query_insert_envio += $" 1,";//InvQty
                                query_insert_envio += $" 1,";//OpenInvQty
                                query_insert_envio += $" 'N',";//EnSetCost
                                query_insert_envio += $" 0,";//RetCost
                                query_insert_envio += $" 0,";//Incoterms
                                query_insert_envio += $" 0,";//TransMod
                                query_insert_envio += $" ' ',";//LineVendor
                                query_insert_envio += $" 'N',";//DistribIS
                                query_insert_envio += $" 0,";//ISDistrb
                                query_insert_envio += $" 0,";//ISDistrbFC
                                query_insert_envio += $" 0,";//ISDistrbSC
                                query_insert_envio += $" 'N',";//IsByPrdct
                                query_insert_envio += $" 4,";//ItemType
                                query_insert_envio += $" 'N',";//PriceEdit
                                query_insert_envio += $" 'N',";//LinePoPrss
                                query_insert_envio += $" 'N',";//FreeChrgBP
                                query_insert_envio += $" 'Y',";//TaxRelev
                                query_insert_envio += $" 'N',";//ThirdParty
                                query_insert_envio += $" 'N',";//InvQtyOnly
                                query_insert_envio += $" 1.16,";//GPBefDisc   --> falta encontrar como se obtiene este valor
                                query_insert_envio += $" -1,";//ReturnRsn
                                query_insert_envio += $" 1,";//ReturnAct
                                query_insert_envio += $" 1,";//NCMCode
                                query_insert_envio += $" 'N',";//IsPrscGood
                                query_insert_envio += $" 'N',";//IsCstmAct
                                query_insert_envio += $" 0,";//U_PorcentajeComision
                                query_insert_envio += $" 0,";//U_Comision
                                query_insert_envio += $" 0,";//U_DP_Stock
                                query_insert_envio += $" 'N',";//U_DP_DescExtra
                                query_insert_envio += $" 0,";//U_DispAd
                                query_insert_envio += $" 0";//U_E_Pedido
                                #endregion
                                query_insert_envio += ")";

                                bool fgInsertEnv = DBConn.ExecQueryInsert(query_insert_envio);
                                if (!fgInsertEnv)
                                {
                                    Utils.PrintLog("SyncLogsToOrders", "0", $"No fue posible realizar la sincronización del envio del pedido. \nquery: {query_insert_envio}");
                                }
                            }
                            #endregion
                        }
                        else
                        {
                            Utils.PrintLog("SyncLogsToOrders", "0", $"No fue posible realizar la sincronización el pedido {order_id}");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("SyncLogsToOrders", "1", ex.ToString());
            }
        }

        public void SyncLogsToOrdersWDIAPI(DIServerApi obapi)
        {
            //string path = "C:\\SyncLogsToOrders.txt";
            try
            {
                //Anotaciones
                //pasar la persona de contacto correcta. (Hacer consulta)-> listo

                //Utils.PrintLog("OrderClass", "LINE 2484 ", $"SyncLogsToOrdersWDIAPI");

                string query_selectLogs = $@"SELECT TOP {Utils.rangoRegistros_Pedidos}";
                #region columnsSelectLogs
                query_selectLogs += $"{Utils.parseStringBD("zAdi_idSyncOrder")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_order_id")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_parent_id")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_date_created")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_num_items_sold")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_total_sales")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_tax_total")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_shipping_total")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_net_total")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_returning_customer")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_status")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_customer_id")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_umeta_id")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_tsmShippingAddresses")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_edit_lock")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_order_stock_reduced")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_recorded_coupon_usage_counts")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_recorded_sales")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_thwcfe_ship_to_billing")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_is_vat_exempt")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_shipping_address_index")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_billing_address_index")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_prices_include_tax")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_order_version")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_order_total")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_order_tax")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_order_shipping_tax")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_order_shipping")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_cart_discount_tax")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_cart_discount")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_order_currency")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_shipping_country")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_shipping_postcode")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_shipping_state")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_shipping_city")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_shipping_address_2")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_shipping_address_1")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_shipping_company")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_shipping_last_name")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_shipping_first_name")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_billing_phone")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_billing_email")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_billing_country")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_billing_postcode")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_billing_state")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_billing_city")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_billing_address_2")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_billing_address_1")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_billing_company")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_billing_last_name")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_billing_first_name")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_cart_hash")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_created_via")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_customer_user_agent")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_customer_ip_address")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_payment_method_title")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_payment_method")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_customer_user")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_Sucursal")},";
                query_selectLogs += $"{Utils.parseStringBD("zAdi_order_key")}";
                #endregion
                query_selectLogs += $" FROM {Utils.parseStringBD("zAdi_SyncOrder")}";
                query_selectLogs += $" WHERE {Utils.parseStringBD("zAdi_flagSend")} = FALSE AND {Utils.parseStringBD("zAdi_action")} = 'INSERT'";

                DataTable tbl_query_seleccLog = DBConn.ExecQuery(query_selectLogs, DBConn.ConectionDB.Bitacoras);
                if (tbl_query_seleccLog != null && tbl_query_seleccLog.Rows != null && tbl_query_seleccLog.Rows.Count > 0)
                {
                    //Utils.PrintLog("OrderClass", "SyncLogsToOrdersWDIAPI -> 2555 ", $"validacion de bitacora");
                    string query_TC_Comercial = $"SELECT TOP 1 {Utils.parseStringBD("U_Fecha")}, {Utils.parseStringBD("U_TC_Comercial")} FROM {Utils.parseStringBD("@TC_COMERCIAL")} ORDER BY TO_DATE(REPLACE(REPLACE({Utils.parseStringBD("U_Fecha")}, '/', ''), '-', ''), 'DDMMYYYY') DESC";
                    DataTable tbl_tc_comercial = DBConn.ExecQuery(query_TC_Comercial);
                    string tc_Comercial = tbl_tc_comercial != null && tbl_tc_comercial.Rows != null && tbl_tc_comercial.Rows.Count > 0 ? tbl_tc_comercial.Rows[0]["U_TC_Comercial"].ToString() : "1";
                    string fe_tc_Comercial = tbl_tc_comercial != null && tbl_tc_comercial.Rows != null && tbl_tc_comercial.Rows.Count > 0 ? tbl_tc_comercial.Rows[0]["U_Fecha"].ToString() : "";
                    fe_tc_Comercial = fe_tc_Comercial.Replace("-", "/");

                    string FinncPriod = "0";
                    string Code = DateTime.Now.ToString("yyyy-MM");
                    string select_finnPriod = $"SELECT TOP 1 {Utils.parseStringBD("AbsEntry")} FROM {Utils.parseStringBD("OFPR")} WHERE {Utils.parseStringBD("Code")} = '{Code}'";
                    DataTable tbl_FinncPriod = DBConn.ExecQuery(select_finnPriod);
                    if (tbl_FinncPriod != null && tbl_FinncPriod.Rows != null && tbl_FinncPriod.Rows.Count > 0)
                    {
                        if (tbl_FinncPriod.Rows[0]["AbsEntry"] != null && !string.IsNullOrEmpty(tbl_FinncPriod.Rows[0]["AbsEntry"].ToString()))
                            FinncPriod = tbl_FinncPriod.Rows[0]["AbsEntry"].ToString();
                    }
                    int rowSale = 0;
                    foreach (DataRow row_query_selectLog in tbl_query_seleccLog.Rows)
                    {
                        #region tabla bitacoras cabecera

                        string idSyncOrder = row_query_selectLog["zAdi_idSyncOrder"] != null ? row_query_selectLog["zAdi_idSyncOrder"].ToString() : "0";
                        string order_id = row_query_selectLog["zAdi_order_id"] != null ? row_query_selectLog["zAdi_order_id"].ToString() : "";
                        string parent_id = row_query_selectLog["zAdi_parent_id"] != null ? row_query_selectLog["zAdi_parent_id"].ToString() : "";
                        string date_created = row_query_selectLog["zAdi_date_created"] != null ? row_query_selectLog["zAdi_date_created"].ToString() : "";
                        string num_items_sold = row_query_selectLog["zAdi_num_items_sold"] != null ? row_query_selectLog["zAdi_num_items_sold"].ToString() : "";
                        string total_sales = row_query_selectLog["zAdi_total_sales"] != null ? row_query_selectLog["zAdi_total_sales"].ToString() : "";
                        string tax_total = row_query_selectLog["zAdi_tax_total"] != null ? row_query_selectLog["zAdi_tax_total"].ToString() : "";
                        string shipping_total = row_query_selectLog["zAdi_shipping_total"] != null && !string.IsNullOrEmpty(row_query_selectLog["zAdi_shipping_total"].ToString()) ? row_query_selectLog["zAdi_shipping_total"].ToString() : "0";
                        string net_total = row_query_selectLog["zAdi_net_total"] != null ? row_query_selectLog["zAdi_net_total"].ToString() : "";
                        string returning_customer = row_query_selectLog["zAdi_returning_customer"] != null ? row_query_selectLog["zAdi_returning_customer"].ToString() : "";
                        string status = row_query_selectLog["zAdi_status"] != null ? row_query_selectLog["zAdi_status"].ToString() : "";
                        //string customer_id = row_query_selectLog["zAdi_customer_id"] != null ? row_query_selectLog["zAdi_customer_id"].ToString() : "0";
                        string umeta_id = row_query_selectLog["zAdi_umeta_id"] != null ? row_query_selectLog["zAdi_umeta_id"].ToString() : "";
                        string tsmShippingAddresses = row_query_selectLog["zAdi_tsmShippingAddresses"] != null ? row_query_selectLog["zAdi_tsmShippingAddresses"].ToString() : "";
                        string _edit_lock = row_query_selectLog["zAdi_edit_lock"] != null ? row_query_selectLog["zAdi_edit_lock"].ToString() : "";
                        string _order_stock_reduced = row_query_selectLog["zAdi_order_stock_reduced"] != null ? row_query_selectLog["zAdi_order_stock_reduced"].ToString() : "";
                        string _recorded_coupon_usage_counts = row_query_selectLog["zAdi_recorded_coupon_usage_counts"] != null ? row_query_selectLog["zAdi_recorded_coupon_usage_counts"].ToString() : "";
                        string _recorded_sales = row_query_selectLog["zAdi_recorded_sales"] != null ? row_query_selectLog["zAdi_recorded_sales"].ToString() : "";
                        string thwcfe_ship_to_billing = row_query_selectLog["zAdi_thwcfe_ship_to_billing"] != null ? row_query_selectLog["zAdi_thwcfe_ship_to_billing"].ToString() : "";
                        string is_vat_exempt = row_query_selectLog["zAdi_is_vat_exempt"] != null ? row_query_selectLog["zAdi_is_vat_exempt"].ToString() : "";
                        string _shipping_address_index = row_query_selectLog["zAdi_shipping_address_index"] != null ? row_query_selectLog["zAdi_shipping_address_index"].ToString() : "";
                        string _billing_address_index = row_query_selectLog["zAdi_billing_address_index"] != null ? row_query_selectLog["zAdi_billing_address_index"].ToString() : "";
                        string _prices_include_tax = row_query_selectLog["zAdi_prices_include_tax"] != null ? row_query_selectLog["zAdi_prices_include_tax"].ToString() : "";
                        string _order_version = row_query_selectLog["zAdi_order_version"] != null ? row_query_selectLog["zAdi_order_version"].ToString() : "";
                        string _order_total = row_query_selectLog["zAdi_order_total"] != null ? row_query_selectLog["zAdi_order_total"].ToString() : "";
                        string _order_tax = row_query_selectLog["zAdi_order_tax"] != null ? row_query_selectLog["zAdi_order_tax"].ToString() : "";
                        string _order_shipping_tax = row_query_selectLog["zAdi_order_shipping_tax"] != null ? row_query_selectLog["zAdi_order_shipping_tax"].ToString() : "";
                        string _order_shipping = row_query_selectLog["zAdi_order_shipping"] != null ? row_query_selectLog["zAdi_order_shipping"].ToString() : "";
                        string _cart_discount_tax = row_query_selectLog["zAdi_cart_discount_tax"] != null ? row_query_selectLog["zAdi_cart_discount_tax"].ToString() : "";
                        string _cart_discount = row_query_selectLog["zAdi_cart_discount"] != null ? row_query_selectLog["zAdi_cart_discount"].ToString() : "";
                        string _order_currency = row_query_selectLog["zAdi_order_currency"] != null ? row_query_selectLog["zAdi_order_currency"].ToString() : "";
                        string _shipping_country = row_query_selectLog["zAdi_shipping_country"] != null ? row_query_selectLog["zAdi_shipping_country"].ToString() : "";
                        string _shipping_postcode = row_query_selectLog["zAdi_shipping_postcode"] != null ? row_query_selectLog["zAdi_shipping_postcode"].ToString() : "";
                        string _shipping_state = row_query_selectLog["zAdi_shipping_state"] != null ? row_query_selectLog["zAdi_shipping_state"].ToString() : "";
                        string _shipping_city = row_query_selectLog["zAdi_shipping_city"] != null ? row_query_selectLog["zAdi_shipping_city"].ToString() : "";
                        string _shipping_address_2 = row_query_selectLog["zAdi_shipping_address_2"] != null ? row_query_selectLog["zAdi_shipping_address_2"].ToString() : "";
                        string _shipping_address_1 = row_query_selectLog["zAdi_shipping_address_1"] != null ? row_query_selectLog["zAdi_shipping_address_1"].ToString() : "";
                        string _shipping_company = row_query_selectLog["zAdi_shipping_company"] != null ? row_query_selectLog["zAdi_shipping_company"].ToString() : "";
                        string _shipping_last_name = row_query_selectLog["zAdi_shipping_last_name"] != null ? row_query_selectLog["zAdi_shipping_last_name"].ToString() : "";
                        string _shipping_first_name = row_query_selectLog["zAdi_shipping_first_name"] != null ? row_query_selectLog["zAdi_shipping_first_name"].ToString() : "";
                        string _billing_phone = row_query_selectLog["zAdi_billing_phone"] != null ? row_query_selectLog["zAdi_billing_phone"].ToString() : "";
                        string _billing_email = row_query_selectLog["zAdi_billing_email"] != null ? row_query_selectLog["zAdi_billing_email"].ToString() : "";
                        string _billing_country = row_query_selectLog["zAdi_billing_country"] != null ? row_query_selectLog["zAdi_billing_country"].ToString() : "";
                        string _billing_postcode = row_query_selectLog["zAdi_billing_postcode"] != null ? row_query_selectLog["zAdi_billing_postcode"].ToString() : "";
                        string _billing_state = row_query_selectLog["zAdi_billing_state"] != null ? row_query_selectLog["zAdi_billing_state"].ToString() : "";
                        string _billing_city = row_query_selectLog["zAdi_billing_city"] != null ? row_query_selectLog["zAdi_billing_city"].ToString() : "";
                        string _billing_address_2 = row_query_selectLog["zAdi_billing_address_2"] != null ? row_query_selectLog["zAdi_billing_address_2"].ToString() : "";
                        string _billing_address_1 = row_query_selectLog["zAdi_billing_address_1"] != null ? row_query_selectLog["zAdi_billing_address_1"].ToString() : "";
                        string _billing_company = row_query_selectLog["zAdi_billing_company"] != null ? row_query_selectLog["zAdi_billing_company"].ToString() : "";
                        string _billing_last_name = row_query_selectLog["zAdi_billing_last_name"] != null ? row_query_selectLog["zAdi_billing_last_name"].ToString() : "";
                        string _billing_first_name = row_query_selectLog["zAdi_billing_first_name"] != null ? row_query_selectLog["zAdi_billing_first_name"].ToString() : "";
                        string _cart_hash = row_query_selectLog["zAdi_cart_hash"] != null ? row_query_selectLog["zAdi_cart_hash"].ToString() : "";
                        string _created_via = row_query_selectLog["zAdi_created_via"] != null ? row_query_selectLog["zAdi_created_via"].ToString() : "";
                        string _customer_user_agent = row_query_selectLog["zAdi_customer_user_agent"] != null ? row_query_selectLog["zAdi_customer_user_agent"].ToString() : "";
                        string _customer_ip_address = row_query_selectLog["zAdi_customer_ip_address"] != null ? row_query_selectLog["zAdi_customer_ip_address"].ToString() : "";
                        string _payment_method_title = row_query_selectLog["zAdi_payment_method_title"] != null ? row_query_selectLog["zAdi_payment_method_title"].ToString() : "";
                        string _payment_method = row_query_selectLog["zAdi_payment_method"] != null ? row_query_selectLog["zAdi_payment_method"].ToString() : "";
                        string _customer_user = row_query_selectLog["zAdi_customer_user"] != null ? row_query_selectLog["zAdi_customer_user"].ToString() : "0";
                        string _order_key = row_query_selectLog["zAdi_order_key"] != null ? row_query_selectLog["zAdi_order_key"].ToString() : "";
                        string _shipping_pickup_stores = row_query_selectLog["zAdi_Sucursal"] != null ? row_query_selectLog["zAdi_Sucursal"].ToString() : "";
                        #endregion
                        string AddressCompleteBilling = $"calle {_billing_address_1} {_billing_address_2}\n {_billing_city}, {_billing_postcode}, {_billing_state}\n{_billing_country}";
                        string AddressCompleteShipping = $"calle {_shipping_address_1} {_shipping_address_2}\n {_shipping_city}, {_shipping_postcode}, {_shipping_state}\n{_shipping_country}";
                        DataTable tbl_NextNumberDocNum = DBConn.ExecQuery($"SELECT TOP 1 {Utils.parseStringBD("NextNumber")} FROM {Utils.parseStringBD("NNM1")} WHERE {Utils.parseStringBD("Series")} = 136 AND {Utils.parseStringBD("SeriesName")} = 'WEB'");//Obtener la serie(DocNum) perteneciente al pedido 
                        long DocNum = tbl_NextNumberDocNum != null && tbl_NextNumberDocNum.Rows != null ? long.Parse(tbl_NextNumberDocNum.Rows[0][0] != null ? tbl_NextNumberDocNum.Rows[0][0].ToString() : "0") : 0;



                        string cardCode = string.Empty;
                        string cardName = string.Empty;
                        string LicTradNum = string.Empty;
                        string user_email = string.Empty;
                        string comments = string.Empty;
                        string TrnspCode = string.Empty;
                        string CntctCode = "0";

                        //Adises CDMX = 1
                        //Adises GDL  = 5
                        //Adises MTY  = 6
                        //Adises LEON  = 7
                        //PAQUETERIA  = 3
                        switch (_shipping_pickup_stores.ToUpper().Trim())
                        {
                            case "SUCURSAL CIUDAD DE MÉXICO":
                                TrnspCode = "1";
                                break;
                            case "SUCURSAL GUADALAJARA":
                                TrnspCode = "5";
                                break;
                            case "SUCURSAL MONTERREY":
                                TrnspCode = "6";
                                break;
                            case "SUCURSAL LEÓN":
                                TrnspCode = "7";
                                break;

                            default:
                                TrnspCode = "3";
                                break;
                        }
                        string select_user_meta = $"SELECT meta_value FROM dsq_usermeta WHERE user_id = {_customer_user} AND meta_key = 'nickname' LIMIT 1";

                        DataTable tbl_usermeta = DBConnMysql.ExecQuery(select_user_meta);
                        if (tbl_usermeta != null && tbl_usermeta.Rows != null && tbl_usermeta.Rows.Count > 0)
                        {
                            if (tbl_usermeta.Rows[0]["meta_value"] != null && !string.IsNullOrEmpty(tbl_usermeta.Rows[0]["meta_value"].ToString()))
                                cardCode = tbl_usermeta.Rows[0]["meta_value"].ToString();
                        }
                        tbl_usermeta = new DataTable();
                        select_user_meta = $"SELECT meta_value FROM dsq_usermeta WHERE user_id = {_customer_user} AND meta_key = '_billing_company' LIMIT 1";
                        tbl_usermeta = DBConnMysql.ExecQuery(select_user_meta);
                        if (tbl_usermeta != null && tbl_usermeta.Rows != null && tbl_usermeta.Rows.Count > 0)
                        {
                            if (tbl_usermeta.Rows[0]["meta_value"] != null && !string.IsNullOrEmpty(tbl_usermeta.Rows[0]["meta_value"].ToString()))
                                cardName = tbl_usermeta.Rows[0]["meta_value"].ToString();
                        }

                        if (string.IsNullOrEmpty(cardName))
                        {
                            tbl_usermeta = new DataTable();
                            select_user_meta = $"SELECT meta_value FROM dsq_usermeta WHERE user_id = {_customer_user} AND meta_key = 'billing_company' LIMIT 1";
                            tbl_usermeta = DBConnMysql.ExecQuery(select_user_meta);
                            if (tbl_usermeta != null && tbl_usermeta.Rows != null && tbl_usermeta.Rows.Count > 0)
                            {
                                if (tbl_usermeta.Rows[0]["meta_value"] != null && !string.IsNullOrEmpty(tbl_usermeta.Rows[0]["meta_value"].ToString()))
                                    cardName = tbl_usermeta.Rows[0]["meta_value"].ToString();
                            }
                        }

                        tbl_usermeta = new DataTable();
                        select_user_meta = $"SELECT user_login, user_email FROM dsq_users WHERE ID = {_customer_user} LIMIT 1";
                        tbl_usermeta = DBConnMysql.ExecQuery(select_user_meta);
                        if (tbl_usermeta != null && tbl_usermeta.Rows != null && tbl_usermeta.Rows.Count > 0)
                        {
                            if (tbl_usermeta.Rows[0]["user_login"] != null && !string.IsNullOrEmpty(tbl_usermeta.Rows[0]["user_login"].ToString()))
                                LicTradNum = tbl_usermeta.Rows[0]["user_login"].ToString();

                            if (tbl_usermeta.Rows[0]["user_email"] != null && !string.IsNullOrEmpty(tbl_usermeta.Rows[0]["user_email"].ToString()))
                                user_email = tbl_usermeta.Rows[0]["user_email"].ToString();
                        }
                        string select_comments = $"SELECT comment_content FROM dsq_comments WHERE comment_author = '{LicTradNum}' OR comment_author_email = '{user_email}'";
                        DataTable tbl_comments = DBConnMysql.ExecQuery(select_comments);
                        if (tbl_comments != null && tbl_comments.Rows != null && tbl_comments.Rows.Count > 0)
                            foreach (DataRow item in tbl_comments.Rows) comments += item["comment_content"] != null && !string.IsNullOrEmpty(item["comment_content"].ToString()) ? item["comment_content"].ToString() + "\n" : "";


                        string select_OCPR = $"SELECT TOP 1 {Utils.parseStringBD("CntctCode")} FROM {Utils.parseStringBD("OCPR")} WHERE {Utils.parseStringBD("CardCode")} = '{cardCode}'";
                        DataTable tbl_OCPR = DBConn.ExecQuery(select_OCPR);
                        if (tbl_OCPR != null && tbl_OCPR.Rows != null && tbl_OCPR.Rows.Count > 0)
                            if (tbl_OCPR.Rows[0]["CntctCode"] != null && !string.IsNullOrEmpty(tbl_OCPR.Rows[0]["CntctCode"].ToString()))
                                CntctCode = tbl_OCPR.Rows[0]["CntctCode"].ToString();


                        string query_select_items = $"SELECT";
                        #region select columns zAdi_SyncOrderItems
                        query_select_items += $" {Utils.parseStringBD("zAdi_order_item_id")},";
                        query_select_items += $" {Utils.parseStringBD("zAdi_order_id")},";
                        query_select_items += $" {Utils.parseStringBD("zAdi_isproduct")},";
                        query_select_items += $" {Utils.parseStringBD("zAdi_product_id")},";
                        query_select_items += $" {Utils.parseStringBD("zAdi_order_item_name")},";
                        query_select_items += $" {Utils.parseStringBD("zAdi_order_item_type")},";
                        query_select_items += $" {Utils.parseStringBD("zAdi_date_created")},";
                        query_select_items += $" {Utils.parseStringBD("zAdi_product_qty")},";
                        query_select_items += $" {Utils.parseStringBD("zAdi_product_net_revenue")},";
                        query_select_items += $" {Utils.parseStringBD("zAdi_product_gross_revenue")},";
                        query_select_items += $" {Utils.parseStringBD("zAdi_coupon_amount")},";
                        query_select_items += $" {Utils.parseStringBD("zAdi_tax_amount")},";
                        query_select_items += $" {Utils.parseStringBD("zAdi_shipping_amount")},";
                        query_select_items += $" {Utils.parseStringBD("zAdi_shiping_tax_amount")},";
                        query_select_items += $" {Utils.parseStringBD("zAdi_line_tax_data")},";
                        query_select_items += $" {Utils.parseStringBD("zAdi_line_tax")},";
                        query_select_items += $" {Utils.parseStringBD("zAdi_line_total")},";
                        query_select_items += $" {Utils.parseStringBD("zAdi_line_subtotal_tax")},";
                        query_select_items += $" {Utils.parseStringBD("zAdi_line_subtotal")},";
                        query_select_items += $" {Utils.parseStringBD("zAdi_tax_class")},";
                        query_select_items += $" {Utils.parseStringBD("zAdi_qty")},";
                        query_select_items += $" {Utils.parseStringBD("zAdi_variation_id")},";
                        query_select_items += $" {Utils.parseStringBD("zAdi_zproduct_id")},";
                        query_select_items += $" {Utils.parseStringBD("zAdi_articulos")},";
                        query_select_items += $" {Utils.parseStringBD("zAdi_taxes")},";
                        query_select_items += $" {Utils.parseStringBD("zAdi_total_tax")},";
                        query_select_items += $" {Utils.parseStringBD("zAdi_cost")},";
                        query_select_items += $" {Utils.parseStringBD("zAdi_instance_id")},";
                        query_select_items += $" {Utils.parseStringBD("zAdi_method_id")},";
                        query_select_items += $" {Utils.parseStringBD("zAdi_sku")},";
                        query_select_items += $" {Utils.parseStringBD("zAdi_post_id")},";
                        query_select_items += $" {Utils.parseStringBD("zAdi_meta_key")},";
                        //query_select_items +=  $"{Utils.parseStringBD("zAdi_")},";
                        query_select_items += $" {Utils.parseStringBD("zAdi_meta_value")}";
                        #endregion
                        query_select_items += $" FROM {Utils.parseStringBD("zAdi_SyncOrderItems")} WHERE {Utils.parseStringBD("zAdi_idSyncOrder")} = {idSyncOrder}";

                        DataTable tbl_query_selectItems = DBConn.ExecQuery(query_select_items, DBConn.ConectionDB.Bitacoras);

                        if (tbl_query_selectItems != null && tbl_query_selectItems.Rows.Count > 0)
                        {
                            //llamar di api
                            //CreateBOMQuotation(cardCode, tbl_query_selectItems);
                            //Utils.PrintLog("OrderClass", "SyncLogsToOrdersWDIAPI -> 2775 ", $"total de items: {tbl_query_selectItems.Rows.Count.ToString()}");

                            try
                            {
                                BOMQuotation.BOM bOM;
                                bOM = new BOMQuotation.BOM();
                                bOM.BO = new BOMQuotation.BOMBO[1];
                                bOM.BO[0] = new BOMQuotation.BOMBO();

                                //nodo admininfo
                                bOM.BO[0].AdmInfo = new BOMQuotation.BOMBOAdmInfo { Object = WSIL.TipoObjeto.oQuotations.ToString() };
                                bOM.BO[0].Documents = new BOMQuotation.BOMBORow[1];
                                bOM.BO[0].Documents[0] = new BOMQuotation.BOMBORow
                                {
                                    DocDate = DateTime.Now.ToString("yyyyMMdd"),
                                    DocDueDate = DateTime.Now.ToString("yyyyMMdd"),
                                    CardCode = cardCode,
                                    //CardName = cardName,
                                    //Address = _shipping_address_index,
                                    DiscountPercent = Convert.ToDouble(_cart_discount),
                                    DocTotal = (Convert.ToDouble(_order_total) * Convert.ToDouble(tc_Comercial)),
                                    DocTotalFc = Convert.ToDouble(total_sales),
                                    //JournalMemo = cardCode,
                                    TransportationCode = Convert.ToInt32(TrnspCode),
                                    TransportationCodeSpecified = true,
                                    //ContactPersonCode = Convert.ToInt32(CntctCode),
                                    //DocRate = 20.5,
                                    DocCurrency = "USD",
                                    
                                    Series = 136,
                                    //DocNum = DocNum,
                                    SeriesSpecified = true,
                                    //DocNumSpecified = true,
                                    //sysrate
                                    //DocTotalSy = total_sales
                                    TaxDate = Convert.ToDateTime(fe_tc_Comercial).ToString("yyyyMMdd"),
                                    //FinncPriod
                                    //Address2 = _billing_address_index,
                                    //LicTradNum
                                    //VatPercent = "",
                                    U_TC_Comercial = Convert.ToDouble(tc_Comercial),
                                    U_TC_ComercialSpecified = true,
                                    U_PEDIDO_WEB = order_id,
                                    U_CorreoPC = user_email,
                                    U_TipoDeVenta = "B",
                                    U_SolicitarPrefactura = "NO",
                                    U_B1SYS_MainUsage = "G03",
                                    U_NotasDeEnvio = _shipping_address_index,
                                    U_TotalInf = (Convert.ToDouble(total_sales) * Convert.ToDouble(tc_Comercial)),
                                    U_TotalInfSpecified = true
                                    //
                                };
                                //Utils.PrintLog("OrderClass", "SyncLogsToOrdersWDIAPI -> 2822 ", $"variable que valida el envio: {shipping_total.ToString()}");

                                //int sizeProd = 0;
                                //if (string.IsNullOrEmpty(shipping_total) && (Convert.ToDouble(shipping_total.Trim()) == 0))
                                //    sizeProd = tbl_query_selectItems.Rows.Count;
                                //else
                                //    sizeProd = tbl_query_selectItems.Rows.Count + 1;


                                int sizeProd = tbl_query_selectItems.Rows.Count;
                                if (!(string.IsNullOrEmpty(shipping_total)) && (Convert.ToDouble(shipping_total.Trim()) > 0))
                                {
                                    //Utils.PrintLog("OrderClass", "SyncLogsToOrdersWDIAPI -> 2834 ", $"into if : {(sizeProd + 1)}");
                                    bOM.BO[0].Document_Lines = new BOMQuotation.BOMBORow2[(sizeProd + 1)];
                                }
                                else
                                    bOM.BO[0].Document_Lines = new BOMQuotation.BOMBORow2[sizeProd];

                                //Utils.PrintLog("OrderClass", "SyncLogsToOrdersWDIAPI -> 2828 ", $"validacion array productos: {sizeProd}");
                                //bOM.BO[0].Document_Lines = new BOMQuotation.BOMBORow2[sizeProd];
                                for (int i = 0; i < sizeProd; i++)
                                {

                                    int qty = (!string.IsNullOrEmpty(tbl_query_selectItems.Rows[i]["zAdi_qty"].ToString()) ? int.Parse(tbl_query_selectItems.Rows[i]["zAdi_qty"].ToString().Trim()) : 1);
                                    double totalItemUSD = (!string.IsNullOrEmpty(tbl_query_selectItems.Rows[i]["zAdi_product_net_revenue"].ToString()) ? double.Parse(tbl_query_selectItems.Rows[i]["zAdi_product_net_revenue"].ToString()) : 0);
                                    double PriceUnit = (totalItemUSD / (qty > 0 ? qty : 1));

                                    //if (string.IsNullOrEmpty(shipping_total) && (Convert.ToDouble(shipping_total.Trim()) == 0))
                                    //{
                                    bOM.BO[0].Document_Lines[i] = new BOMQuotation.BOMBORow2
                                    {
                                        ItemCode = tbl_query_selectItems.Rows[i]["zAdi_sku"].ToString(),
                                        Quantity = Convert.ToDouble(qty),
                                        //MeasureUnit = "H87",
                                        Price = PriceUnit,
                                        QuantitySpecified = true,
                                        PriceSpecified = true,
                                        UnitPrice = PriceUnit,
                                        UnitPriceSpecified = true
                                        //,ShipToCode = "Facturacion"
                                    };
                                    //}
                                }
                                if ((Convert.ToDouble(shipping_total.Trim()) > 0))
                                {
                                    //Utils.PrintLog("Orders", $"LINE 25837 -> shipping_total:", Math.Round(Convert.ToDouble(shipping_total), 2).ToString());

                                    bOM.BO[0].Document_Lines[sizeProd] = new BOMQuotation.BOMBORow2
                                    {
                                        ItemCode = "SERV001",
                                        ItemDescription = "SERVICIO DE ENVÍO",
                                        Price = Math.Round(Convert.ToDouble(shipping_total), 2),
                                        //UnitPrice = Convert.ToDouble(shipping_total),
                                        PriceSpecified = true,
                                        //MeasureUnit = "E48",
                                        //"RM5-WKS-2MN-NA",
                                        //(string)list_sales_items.Rows[0]["zAdi_sku"],
                                        Quantity = 1,
                                        //(double)list_sales_items.Rows[0]["zAdi_qty"],
                                        QuantitySpecified = true
                                    };
                                }

                                #region NODOS Addresses
                                //Datos para direccion de facturacion
                                //bOM.BO[0].TaxExtension = new BOMQuotation.BOMBORow11[1];
                                //bOM.BO[0].TaxExtension[0] = new BOMQuotation.BOMBORow11
                                //{
                                //    StreetS = $"{_billing_address_1} {_billing_address_2}",
                                //    CityS = _billing_city,
                                //    ZipCodeS = _billing_postcode,
                                //    CountryS = _billing_country,
                                //    StateS = _billing_state,
                                //    CountyS = _billing_country,
                                //    BoEValueSpecified = true,

                                //    StreetB = $"{_billing_address_1} {_billing_address_2}",
                                //    CityB = _shipping_city,
                                //    ZipCodeB = _shipping_postcode,
                                //    CountryB = _shipping_country,
                                //    StateB = _shipping_state,
                                //    CountyB = _shipping_country,
                                //    ShipUnitNoSpecified = false,
                                //};

                                //bloque de code para los datos de direccion
                                //bOM.BO[0].AddressExtension = new BOMQuotation.BOMBORow12[1];
                                //bOM.BO[0].AddressExtension[0] = new BOMQuotation.BOMBORow12
                                //{
                                //    ShipToStreet = _shipping_address_1,
                                //    ShipToStreetNo = _shipping_address_2,
                                //    ShipToBlock = "",//colonia
                                //    ShipToCity = _shipping_city,
                                //    ShipToZipCode = _shipping_postcode,
                                //    ShipToCounty = _shipping_country,
                                //    ShipToState = _shipping_state,
                                //    ShipToCountry = _shipping_country,
                                //    BillToStreet = _billing_address_1,
                                //    BillToStreetNo = _billing_address_2,
                                //    //BillToBlock = ""//---
                                //    //BillToBuilding = 
                                //    BillToCity      = _billing_city,
                                //    BillToZipCode   = _billing_postcode,
                                //    BillToCounty    = _shipping_country,
                                //    BillToState     = _billing_state,
                                //    BillToCountry   = _billing_country,


                                //    //_billing_address_1,
                                //    //_billing_address_2,
                                //    //_billing_city,
                                //    //_billing_postcode,
                                //    //_billing_state,
                                //    //_billing_country
                                //};
                                #endregion

                                string strXML;
                                System.Xml.Serialization.XmlSerializerNamespaces ns;

                                ns = new System.Xml.Serialization.XmlSerializerNamespaces();
                                ns.Add("", "");
                                strXML = DIServerApi.getInstance.ObjToStringXML<BOMQuotation.BOM>(bOM, ns, true);


                                string bomCreateQuot = DIServerApi.getInstance.FormatXML(strXML);
                                //Utils.PrintLog("Orders", $"LINE 2580 print xml -> respuesta:", bomCreateQuot);
                                string cmd = "";
                                string response = obapi.WSAddObject(bomCreateQuot, cmd);
                                //DIServerApi.getInstance.WSAddObject(bomCreateQuot, cmd);

                                Utils.PrintLog("Orders", $"LINE 2580 print xml resp-> respuesta:", response);
                                int IdQuout = obapi.GetIdResponse(response);
                                if(IdQuout > 0)
                                {
                                    string DocNumUp = "0";
                                    string select_DocNum = $"SELECT {Utils.parseStringBD("DocNum")} FROM {Utils.parseStringBD("OQUT")} WHERE {Utils.parseStringBD("DocEntry")} = {IdQuout}";
                                    DataTable tbl_DocNum = DBConn.ExecQuery(select_DocNum);
                                    if (tbl_DocNum != null && tbl_DocNum.Rows != null && tbl_DocNum.Rows.Count > 0)
                                    {
                                        DocNumUp = tbl_DocNum.Rows[0]["DocNum"].ToString();

                                        #region UpManualDirecciones
                                        //string select_dir = $"SELECT * FROM {Utils.parseStringBD("QUT12")} WHERE {Utils.parseStringBD("DocEntry")} = {IdQuout}";
                                        //DataTable tbl_dir = DBConn.ExecQuery(select_dir);
                                        //if (tbl_dir != null && tbl_dir.Rows != null && tbl_dir.Rows.Count > 0)
                                        //{
                                        //    string update_dir = $"UPDATE {Utils.parseStringBD("QUT12")} SET";
                                        //    update_dir += $" {Utils.parseStringBD("ObjectType")} = 23,";
                                        //    update_dir += $" {Utils.parseStringBD("StreetS")} = '{_billing_address_1} {_billing_address_2}',";
                                        //    update_dir += $" {Utils.parseStringBD("CityS")} = '{_billing_city}',";
                                        //    update_dir += $" {Utils.parseStringBD("ZipCodeS")} = '{_billing_postcode}',";
                                        //    update_dir += $" {Utils.parseStringBD("StateS")} = '{_billing_state}',";
                                        //    update_dir += $" {Utils.parseStringBD("CountryS")} = '{_billing_country}',";
                                        //    update_dir += $" {Utils.parseStringBD("StreetB")} = '{_shipping_address_1} {_shipping_address_2}',";
                                        //    update_dir += $" {Utils.parseStringBD("CityB")} = '{_shipping_city}',";
                                        //    update_dir += $" {Utils.parseStringBD("ZipCodeB")} = '{_shipping_postcode}',";
                                        //    update_dir += $" {Utils.parseStringBD("StateB")} = '{_shipping_state}',";
                                        //    update_dir += $" {Utils.parseStringBD("CountryB")} = '{_shipping_country}'";
                                        //    update_dir += $" WHERE {Utils.parseStringBD("DocEntry")} = {IdQuout}";

                                        //    DBConn.ExecQueryUpdate(update_dir);
                                        //}
                                        //else
                                        //{
                                        //    string query_direcciones = $"INSERT INTO {Utils.parseStringBD("QUT12")} (";
                                        //    query_direcciones += $" {Utils.parseStringBD("DocEntry")},"; //'84472'
                                        //    query_direcciones += $" {Utils.parseStringBD("NetWeight")},"; //'0'
                                        //    query_direcciones += $" {Utils.parseStringBD("GrsWeight")},"; //'0'
                                        //    query_direcciones += $" {Utils.parseStringBD("LogInstanc")},"; //'0'
                                        //    query_direcciones += $" {Utils.parseStringBD("ObjectType")},"; //'23'
                                        //    query_direcciones += $" {Utils.parseStringBD("StreetS")},"; //'calle fac'
                                        //    query_direcciones += $" {Utils.parseStringBD("BlockS")},"; //'col fac'
                                        //    query_direcciones += $" {Utils.parseStringBD("BuildingS")},"; //' '
                                        //    query_direcciones += $" {Utils.parseStringBD("CityS")},"; //'ciudad fac'
                                        //    query_direcciones += $" {Utils.parseStringBD("ZipCodeS")},"; //'97910'
                                        //    query_direcciones += $" {Utils.parseStringBD("StateS")},"; //'YUC'
                                        //    query_direcciones += $" {Utils.parseStringBD("CountryS")},"; //'MX'
                                        //    query_direcciones += $" {Utils.parseStringBD("AddrTypeS")},"; //' '
                                        //    query_direcciones += $" {Utils.parseStringBD("StreetNoS")},"; //'nu fac'
                                        //    query_direcciones += $" {Utils.parseStringBD("StreetB")},"; //'calle env'
                                        //    query_direcciones += $" {Utils.parseStringBD("BlockB")},"; //'col env'
                                        //    query_direcciones += $" {Utils.parseStringBD("CityB")},"; //'ciudad env'
                                        //    query_direcciones += $" {Utils.parseStringBD("ZipCodeB")},"; //'97910'
                                        //    query_direcciones += $" {Utils.parseStringBD("StateB")},"; //'YUC'
                                        //    query_direcciones += $" {Utils.parseStringBD("CountryB")},"; //'MX'
                                        //    query_direcciones += $" {Utils.parseStringBD("StreetNoB")},"; //'nu env'
                                        //    query_direcciones += $" {Utils.parseStringBD("Vat")},"; //'N'
                                        //    query_direcciones += $" {Utils.parseStringBD("Address2S")},"; //' '
                                        //    query_direcciones += $" {Utils.parseStringBD("Address3S")},"; //' '
                                        //    query_direcciones += $" {Utils.parseStringBD("GlbLocNumS")},"; //' '
                                        //    query_direcciones += $" {Utils.parseStringBD("ExportType")},"; //'E'
                                        //    query_direcciones += $" {Utils.parseStringBD("BoEValue")}"; //'0'
                                        //    query_direcciones += ") VALUES (";
                                        //    query_direcciones += $" {(IdQuout)},";
                                        //    query_direcciones += $" 0,"; //NetWeight
                                        //    query_direcciones += $" 0,";//GrsWeight
                                        //    query_direcciones += $" 0,";//LogInstanc
                                        //    query_direcciones += $" 23,";//ObjectType
                                        //    query_direcciones += $" '{_billing_address_1} {_billing_address_2}',";//StreetS
                                        //    query_direcciones += $" 'col fac',"; //pendiente de obtener colonia fac //BlockS
                                        //    query_direcciones += $" ' ',";//BuildingS
                                        //    query_direcciones += $" '{_billing_city}',";//CityS
                                        //    query_direcciones += $" '{_billing_postcode}',";//ZipCodeS
                                        //    query_direcciones += $" '{_billing_state}',";//StateS
                                        //    query_direcciones += $" '{_billing_country}',";//CountryS
                                        //    query_direcciones += $" ' ',";//AddrTypeS
                                        //    query_direcciones += $" 'S/N fac',";//StreetNoS
                                        //    query_direcciones += $" '{_shipping_address_1} {_shipping_address_2}',";//StreetB
                                        //    query_direcciones += $" 'col env',";//pendiente obtener colonia env //BlockB
                                        //    query_direcciones += $" '{_shipping_city}',";//CityB
                                        //    query_direcciones += $" '{_shipping_postcode}',";//ZipCodeB
                                        //    query_direcciones += $" '{_shipping_state}',";//StateB
                                        //    query_direcciones += $" '{_shipping_country}',";//CountryB
                                        //    query_direcciones += $" 'S/N env',";//StreetNoB
                                        //    query_direcciones += $" 'N',";//Vat
                                        //    query_direcciones += $" ' ',";//Address2S
                                        //    query_direcciones += $" ' ',";//Address3S
                                        //    query_direcciones += $" ' ',";//GlbLocNumS
                                        //    query_direcciones += $" 'E',";//ExportType
                                        //    query_direcciones += $" 0";//BoEValue
                                        //    query_direcciones += ")";

                                        //    //DBConn.ExecQueryInsert(query_direcciones);
                                        //}
                                        #endregion


                                        string update_logOrder = $"UPDATE {Utils.parseStringBD("zAdi_SyncOrder")} SET";
                                        update_logOrder += $" {Utils.parseStringBD("zAdi_flagSend")} = TRUE,";
                                        update_logOrder += $" {Utils.parseStringBD("zAdi_dateSend")} = NOW(),";
                                        update_logOrder += $" {Utils.parseStringBD("zAdi_DocEntry")} = {IdQuout},";
                                        update_logOrder += $" {Utils.parseStringBD("zAdi_DocNum")} = {DocNumUp},";
                                        update_logOrder += $" {Utils.parseStringBD("zAdi_Serie")} = 'WEB'";
                                        update_logOrder += $" WHERE {Utils.parseStringBD("zAdi_idSyncOrder")} =  {idSyncOrder}";
                                        DBConn.ExecQueryUpdate(update_logOrder, DBConn.ConectionDB.Bitacoras);
                                    }
                                }
                            }
                            catch (Exception e)
                            {

                                Utils.PrintLog("Orders", "LINE 2892 CATCH ERROR al crear pedido", e.Message);

                            }

                            rowSale++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("SyncLogsToOrders", "1", ex.ToString());
            }
            obapi.WSLogout();
        }

        public void SynUpdateOrdersToWooCommerce()
        {
            //string path = "C:\\SynUpdateOrdersToWooCommerce.txt";

            try
            {
                string select_UpdatedOrders = $"SELECT TOP {Utils.rangoRegistros_Pedidos} * FROM {Utils.parseStringBD("zAdi_UpdatedOrders")} WHERE {Utils.parseStringBD("zAdi_FlagSend")} = FALSE ORDER BY {Utils.parseStringBD("zAdi_idUpdatedOrder")} ASC";

                DataTable tbl_update = DBConn.ExecQuery(select_UpdatedOrders, DBConn.ConectionDB.Bitacoras);
                if (tbl_update != null && tbl_update.Rows != null && tbl_update.Rows.Count > 0)
                {
                    foreach (DataRow item in tbl_update.Rows)
                    {
                        string zAdi_idUpdatedOrder = item["zAdi_idUpdatedOrder"] != null && !string.IsNullOrEmpty(item["zAdi_idUpdatedOrder"].ToString()) ? item["zAdi_idUpdatedOrder"].ToString() : "0";
                        string zAdi_OrderId = item["zAdi_OrderId"] != null && !string.IsNullOrEmpty(item["zAdi_OrderId"].ToString()) ? item["zAdi_OrderId"].ToString() : "0";
                        string zAdi_DocNum = item["zAdi_DocNum"] != null && !string.IsNullOrEmpty(item["zAdi_DocNum"].ToString()) ? item["zAdi_DocNum"].ToString() : "";
                        string zAdi_U_Status = item["zAdi_U_Status"] != null && !string.IsNullOrEmpty(item["zAdi_U_Status"].ToString()) ? item["zAdi_U_Status"].ToString() : "";
                        string zAdi_U_Paqueteria = item["zAdi_U_Paqueteria"] != null && !string.IsNullOrEmpty(item["zAdi_U_Paqueteria"].ToString()) ? item["zAdi_U_Paqueteria"].ToString() : "";
                        string zAdi_U_NoGuia = item["zAdi_U_NoGuia"] != null && !string.IsNullOrEmpty(item["zAdi_U_NoGuia"].ToString()) ? item["zAdi_U_NoGuia"].ToString() : "";
                        string zAdi_DesMessage = item["zAdi_DesMessage"] != null && !string.IsNullOrEmpty(item["zAdi_DesMessage"].ToString()) ? item["zAdi_DesMessage"].ToString() : "";
                        //string zAdi_IdCommerce = item["zAdi_IdCommerce"] != null && !string.IsNullOrEmpty(item["zAdi_IdCommerce"].ToString()) ? item["zAdi_IdCommerce"].ToString() : "0";

                        string _customer_user = "0";
                        string user_login = string.Empty;
                        string user_email = string.Empty;
                        //string _customer_user = row_query_selectLog["zAdi_customer_user"] != null ? row_query_selectLog["zAdi_customer_user"].ToString() : "0";

                        string select_SyncOrder = $"SELECT _customer_user FROM zAdi_SyncOrder WHERE order_id = {zAdi_OrderId} LIMIT 1";

                        DataTable tbl_SyncOrder = DBConnMysql.ExecQuery(select_SyncOrder);
                        if (tbl_SyncOrder != null && tbl_SyncOrder.Rows != null && tbl_SyncOrder.Rows.Count > 0)
                        {
                            if (tbl_SyncOrder.Rows[0]["_customer_user"] != null && !string.IsNullOrEmpty(tbl_SyncOrder.Rows[0]["_customer_user"].ToString()))
                                _customer_user = tbl_SyncOrder.Rows[0]["_customer_user"].ToString();
                        }

                        string select_user_meta = $"SELECT user_login, user_email FROM dsq_users WHERE ID = {_customer_user} LIMIT 1";

                        DataTable tbl_usermeta = DBConnMysql.ExecQuery(select_user_meta);
                        if (tbl_usermeta != null && tbl_usermeta.Rows != null && tbl_usermeta.Rows.Count > 0)
                        {
                            if (tbl_usermeta.Rows[0]["user_login"] != null && !string.IsNullOrEmpty(tbl_usermeta.Rows[0]["user_login"].ToString()))
                                user_login = tbl_usermeta.Rows[0]["user_login"].ToString();

                            if (tbl_usermeta.Rows[0]["user_email"] != null && !string.IsNullOrEmpty(tbl_usermeta.Rows[0]["user_email"].ToString()))
                                user_email = tbl_usermeta.Rows[0]["user_email"].ToString();
                        }

                        if (!string.IsNullOrEmpty(user_email) || !string.IsNullOrEmpty(user_login))
                        {

                            string update_status = $"UPDATE dsq_wc_order_stats SET status = '{zAdi_U_Status}' WHERE order_id = {zAdi_OrderId};";
                            update_status += $"UPDATE dsq_posts SET post_status = '{zAdi_U_Status}' WHERE ID = {zAdi_OrderId};";

                            DBConnMysql.ExecQueryUpdate(update_status);
                            string message = $"Su pedido ha sido {zAdi_DesMessage}.";
                            //string message = $"Su pedido ha sido {zAdi_DesMessage} el día {DateTime.Now.ToLocalTime().ToString("dd-MM-yyyy hh:mm:ss tt")}";


                            if (!string.IsNullOrEmpty(zAdi_DesMessage))
                            {
                                switch (zAdi_DesMessage.ToUpper())
                                {
                                    case "PREPARADO":
                                        message = "Tu pedido está siendo preparado.";
                                        break;
                                    case "ENVIADO":
                                        if (!string.IsNullOrEmpty(zAdi_U_NoGuia) && !string.IsNullOrEmpty(zAdi_U_Paqueteria))
                                            message = $"Tu pedido ha sido enviado.\nNúmero de guía: {zAdi_U_NoGuia}.\npaquetería: {zAdi_U_Paqueteria}.";
                                        else if (!string.IsNullOrEmpty(zAdi_U_NoGuia))
                                            message = $"Tu pedido ha sido enviado. Número de guía {zAdi_U_NoGuia}.";
                                        else if (!string.IsNullOrEmpty(zAdi_U_Paqueteria))
                                            message = $"Tu pedido ha sido enviado. Paquetería {zAdi_U_Paqueteria}.";
                                        else
                                            message = "Tu pedido ha sido enviado.";
                                        break;
                                    case "ENTREGADO":
                                        message = "Tu pedido ha sido entregado.";
                                        break;
                                }
                                string validate_message = $"SELECT * FROM dsq_comments WHERE comment_post_ID = {zAdi_OrderId} AND comment_content = '{message}'";
                                DataTable tbl_validate = DBConnMysql.ExecQuery(validate_message);
                                if (!(tbl_validate != null && tbl_validate.Rows != null && tbl_validate.Rows.Count > 0))
                                {
                                    string insert_comment = $"INSERT INTO dsq_comments (";
                                    insert_comment += " comment_ID,";
                                    insert_comment += " comment_post_ID,";
                                    insert_comment += " comment_author,";
                                    insert_comment += " comment_author_email,";
                                    insert_comment += " comment_author_url,";
                                    insert_comment += " comment_author_IP,";
                                    insert_comment += " comment_date,";
                                    insert_comment += " comment_date_gmt,";
                                    insert_comment += " comment_content,";
                                    insert_comment += " comment_karma,";
                                    insert_comment += " comment_approved,";
                                    insert_comment += " comment_agent,";
                                    insert_comment += " comment_type,";
                                    insert_comment += " comment_parent,";
                                    insert_comment += " user_id) VALUES (";
                                    insert_comment += " NULL,";//comment_ID
                                    insert_comment += $" {zAdi_OrderId},";//comment_post_ID
                                    insert_comment += $" '{user_login}',";//comment_author
                                    insert_comment += $" '{user_email}',";//comment_author_email
                                    insert_comment += " '',";//comment_author_url
                                    insert_comment += " '',";//comment_author_IP
                                    insert_comment += " CURRENT_TIMESTAMP,";//comment_date
                                    insert_comment += " CURRENT_TIMESTAMP,";//comment_date_gmt
                                    insert_comment += $" '{message}',";//comment_content
                                    insert_comment += " 0,";//comment_karma
                                    insert_comment += " '1',";//comment_approved
                                    insert_comment += " 'WooCommerce',";//comment_agent
                                    insert_comment += " 'order_note',";//comment_type
                                    insert_comment += " 0,";//comment_parent
                                    insert_comment += " 0";//user_id
                                    insert_comment += ");";

                                    bool fgInsert = DBConnMysql.ExecQueryInsert(insert_comment);
                                    if (!fgInsert)
                                    {
                                        Utils.PrintLog("SynUpdateOrdersToWooCommerce", "0", $"No fue posible realizar la sincronización del estatus {zAdi_idUpdatedOrder}");
                                    }
                                }
                            }

                            string update_sap = $"UPDATE {Utils.parseStringBD("zAdi_UpdatedOrders")} SET ";
                            update_sap += $" {Utils.parseStringBD("zAdi_FlagSend")} = TRUE,";
                            update_sap += $" {Utils.parseStringBD("zAdi_DateSend")} = NOW()";
                            update_sap += $" WHERE {Utils.parseStringBD("zAdi_idUpdatedOrder")} = {zAdi_idUpdatedOrder} ";

                            DBConn.ExecQueryUpdate(update_sap, DBConn.ConectionDB.Bitacoras);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("SynUpdateOrdersToWooCommerce", "1", ex.ToString());
            }
        }
        #endregion

        public static Orders getInstance => new Orders();
    }
}
