﻿using SAP_LIB.Controllers;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SapService.Modules
{
    class Leads
    {
        #region Leads
        public void RegisterLeadsBitacoraToSap()
        {
            //string pathL = "C:\\LogLeadsRchan.txt";
            try
            {
                string QueryMasterLeads = $"SELECT * FROM zAdi_SyncLead WHERE flagSend IS NOT NULL AND flagSend = 0 AND (CardName != 'X' OR CardName != '---') LIMIT {Utils.rangoRegistros_Leads}";
                //Utils.PrintLog("RegisterLeadsBitacoraToSap", "0", $"QueryMasterLeads: {QueryMasterLeads}");
                DataTable DtLeadList = DBConnMysql.ExecQuery(QueryMasterLeads);
                #region GET/INSERT LEADS Fields
                if (DtLeadList != null && DtLeadList.Rows != null && DtLeadList.Rows.Count > 0)
                {
                    foreach (DataRow rowLeads in DtLeadList.Rows)
                    {

                        //int insert_idSyncLead = int.Parse(rowLeads.ItemArray[0].ToString());
                        string insert_idSyncLead = string.Empty;
                        int insert_idClient = int.Parse(rowLeads.ItemArray[1].ToString());
                        string insert_CardCode = (rowLeads.ItemArray[2].ToString() != "" && rowLeads.ItemArray[2].ToString() != null) ? rowLeads.ItemArray[2].ToString() : "";
                        string insert_CardName = (rowLeads.ItemArray[3].ToString() != "" && rowLeads.ItemArray[3].ToString() != null) ? rowLeads.ItemArray[3].ToString() : "";
                        string insert_CardType = (rowLeads.ItemArray[4].ToString() != "" && rowLeads.ItemArray[4].ToString() != null) ? rowLeads.ItemArray[4].ToString() : "";
                        string insert_Address = (rowLeads.ItemArray[5].ToString() != "" && rowLeads.ItemArray[5].ToString() != null) ? rowLeads.ItemArray[5].ToString() : "";
                        string insert_ZipCode = (rowLeads.ItemArray[6].ToString() != "" && rowLeads.ItemArray[6].ToString() != null) ? rowLeads.ItemArray[6].ToString() : "";
                        string insert_MailAddress = (rowLeads.ItemArray[7].ToString() != "" && rowLeads.ItemArray[7].ToString() != null) ? rowLeads.ItemArray[7].ToString() : "";
                        string insert_Phone1 = (rowLeads.ItemArray[8].ToString() != "" && rowLeads.ItemArray[8].ToString() != null) ? rowLeads.ItemArray[8].ToString() : "";
                        string insert_Contact = (rowLeads.ItemArray[9].ToString() != "" && rowLeads.ItemArray[9].ToString() != null) ? rowLeads.ItemArray[9].ToString() : "";
                        string insert_CURP = (rowLeads.ItemArray[10].ToString() != "" && rowLeads.ItemArray[10].ToString() != null) ? rowLeads.ItemArray[10].ToString() : "";
                        string insert_City = (rowLeads.ItemArray[11].ToString() != "" && rowLeads.ItemArray[11].ToString() != null) ? rowLeads.ItemArray[11].ToString() : "";
                        string insert_Country = (rowLeads.ItemArray[12].ToString() != "" && rowLeads.ItemArray[12].ToString() != null) ? rowLeads.ItemArray[12].ToString() : "";
                        string insert_CreateDate = (Utils.GetDateFormatToSap(rowLeads.ItemArray[13].ToString()) != "" && Utils.GetDateFormatToSap(rowLeads.ItemArray[13].ToString()) != null) ? Utils.GetDateFormatToSap(rowLeads.ItemArray[13].ToString()) : "";
                        string insert_UpdateDate = (Utils.GetDateFormatToSap(rowLeads.ItemArray[14].ToString()) != "" && Utils.GetDateFormatToSap(rowLeads.ItemArray[14].ToString()) != null) ? Utils.GetDateFormatToSap(rowLeads.ItemArray[14].ToString()) : "";
                        string insert_Block = (rowLeads["Block"].ToString() != "" && rowLeads["Block"].ToString() != null) ? rowLeads["Block"].ToString() : "";
                        string insert_sucursalk = (rowLeads["sucursal"].ToString() != "" && rowLeads["sucursal"].ToString() != null) ? rowLeads["sucursal"].ToString() : "";
                        string insert_cfdi = (rowLeads["cfdi"].ToString() != "" && rowLeads["cfdi"].ToString() != null) ? rowLeads["cfdi"].ToString() : "";
                        string asesor = (rowLeads["asesor"].ToString() != "" && rowLeads["asesor"].ToString() != null) ? rowLeads["asesor"].ToString() : "";
                        string asesor2 = (rowLeads["asesor2"].ToString() != "" && rowLeads["asesor2"].ToString() != null) ? rowLeads["asesor2"].ToString() : "";
                        string asesor3 = (rowLeads["asesor3"].ToString() != "" && rowLeads["asesor3"].ToString() != null) ? rowLeads["asesor3"].ToString() : "";
                        string asesor4 = (rowLeads["asesor4"].ToString() != "" && rowLeads["asesor4"].ToString() != null) ? rowLeads["asesor4"].ToString() : "";
                        string asesor5 = (rowLeads["asesor5"].ToString() != "" && rowLeads["asesor5"].ToString() != null) ? rowLeads["asesor5"].ToString() : "";
                        string asesor6 = (rowLeads["asesor6"].ToString() != "" && rowLeads["asesor6"].ToString() != null) ? rowLeads["asesor6"].ToString() : "";
                        string user_email = (rowLeads["user_email"].ToString() != "" && rowLeads["user_email"].ToString() != null) ? rowLeads["user_email"].ToString() : "";

                        string final_asesor = string.Empty;
                        if (!string.IsNullOrEmpty(asesor))
                            final_asesor = asesor;
                        else if (!string.IsNullOrEmpty(asesor2))
                            final_asesor = asesor2;
                        else if (!string.IsNullOrEmpty(asesor3))
                            final_asesor = asesor3;
                        else if (!string.IsNullOrEmpty(asesor4))
                            final_asesor = asesor4;
                        else if (!string.IsNullOrEmpty(asesor5))
                            final_asesor = asesor5;
                        else if (!string.IsNullOrEmpty(asesor6))
                            final_asesor = asesor6;
                        else
                            final_asesor = "";

                        if (!string.IsNullOrEmpty(insert_CardCode))
                            insert_CardCode = string.Join("", insert_CardCode.Split('\''));
                        insert_CardCode = insert_CardCode.Replace("'", "");

                        if (!string.IsNullOrEmpty(insert_CardName))
                            insert_CardName = string.Join("", insert_CardName.Split('\''));
                        insert_CardName = insert_CardName.Replace("'", "");

                        if (!string.IsNullOrEmpty(insert_Address))
                            insert_Address = string.Join("", insert_Address.Split('\''));
                        insert_Address = insert_Address.Replace("'", "");

                        if (!string.IsNullOrEmpty(insert_MailAddress))
                            insert_MailAddress = string.Join("", insert_MailAddress.Split('\''));
                        insert_MailAddress = insert_MailAddress.Replace("'", "");

                        if (!string.IsNullOrEmpty(insert_Phone1))
                            insert_Phone1 = string.Join("", insert_Phone1.Split('\''));
                        insert_Phone1 = insert_Phone1.Replace("'", "");

                        if (!string.IsNullOrEmpty(insert_Contact))
                            insert_Contact = string.Join("", insert_Contact.Split('\''));
                        insert_Contact = insert_Contact.Replace("'", "");

                        if (!string.IsNullOrEmpty(insert_CURP))
                            insert_CURP = string.Join("", insert_CURP.Split('\''));
                        insert_CURP = insert_CURP.Replace("'", "");

                        if (!string.IsNullOrEmpty(insert_City))
                            insert_City = string.Join("", insert_City.Split('\''));
                        insert_City = insert_City.Replace("'", "");

                        if (!string.IsNullOrEmpty(insert_Country))
                            insert_Country = string.Join("", insert_Country.Split('\''));
                        insert_Country = insert_Country.Replace("'", "");
                        //////
                        //string insert_State1 = (Utils.RemoveAccents(rowLeads.ItemArray[15].ToString()) != "" && Utils.RemoveAccents(rowLeads.ItemArray[15].ToString()) != null) ? Utils.RemoveAccents(rowLeads.ItemArray[15].ToString()) : null;
                        string insert_State1 = (rowLeads.ItemArray[15] != null && rowLeads.ItemArray[15].ToString() != "") ? rowLeads.ItemArray[15].ToString().Trim() : "";
                        /////

                        string insert_action = (rowLeads.ItemArray[16].ToString() != "" && rowLeads.ItemArray[16].ToString() != null) ? rowLeads.ItemArray[16].ToString() : null;
                        string insert_flagSend = (rowLeads.ItemArray[17].ToString() != "" && rowLeads.ItemArray[17].ToString() != null) ? rowLeads.ItemArray[17].ToString() : null;
                        string insert_dateSend = (Utils.GetDateFormatToSap(rowLeads.ItemArray[18].ToString()) != "" && Utils.GetDateFormatToSap(rowLeads.ItemArray[18].ToString()) != null) ? Utils.GetDateFormatToSap(rowLeads.ItemArray[18].ToString()) : "";
                        string insert_dateRegister = (Utils.GetDateFormatToSap(rowLeads.ItemArray[19].ToString()) != "" && Utils.GetDateFormatToSap(rowLeads.ItemArray[19].ToString()) != null) ? Utils.GetDateFormatToSap(rowLeads.ItemArray[19].ToString()) : "";

                        string add_SyncLeads = $"INSERT INTO {Utils.parseStringBD("zAdi_SyncLeadSAP")} (";
                        //add_SyncLeads += $"{Utils.parseStringBD("idSyncLead")},";
                        add_SyncLeads += $"{Utils.parseStringBD("idClient")},";
                        add_SyncLeads += $"{Utils.parseStringBD("CardCode")},";
                        add_SyncLeads += $"{Utils.parseStringBD("CardName")},";
                        add_SyncLeads += $"{Utils.parseStringBD("CardType")},";
                        add_SyncLeads += $"{Utils.parseStringBD("Address")},";
                        add_SyncLeads += $"{Utils.parseStringBD("ZipCode")},";
                        add_SyncLeads += $"{Utils.parseStringBD("MailAddress")},";
                        add_SyncLeads += $"{Utils.parseStringBD("Phone1")},";
                        add_SyncLeads += $"{Utils.parseStringBD("Contact")},";
                        add_SyncLeads += $"{Utils.parseStringBD("CURP")},";
                        add_SyncLeads += $"{Utils.parseStringBD("City")},";
                        add_SyncLeads += $"{Utils.parseStringBD("Country")},";
                        add_SyncLeads += $"{Utils.parseStringBD("CreateDate")},";
                        add_SyncLeads += $"{Utils.parseStringBD("UpdateDate")},";
                        add_SyncLeads += $"{Utils.parseStringBD("State1")},";
                        add_SyncLeads += $"{Utils.parseStringBD("action")},";
                        add_SyncLeads += $"{Utils.parseStringBD("flagSend")},";
                        add_SyncLeads += $"{Utils.parseStringBD("dateSend")},";
                        add_SyncLeads += $"{Utils.parseStringBD("dateRegister")},";
                        add_SyncLeads += $"{Utils.parseStringBD("FlagLead")},";
                        add_SyncLeads += $"{Utils.parseStringBD("Address_2")},";
                        add_SyncLeads += $"{Utils.parseStringBD("sucursal")},";
                        add_SyncLeads += $"{Utils.parseStringBD("asesor")},";
                        add_SyncLeads += $"{Utils.parseStringBD("cfdi")},";
                        add_SyncLeads += $"{Utils.parseStringBD("user_email")})";

                        add_SyncLeads += $"VALUES(";
                        //add_SyncLeads += $" '{insert_idSyncLead.ToString()}',";
                        add_SyncLeads += $" '{insert_idClient.ToString()}',";
                        add_SyncLeads += $" '{insert_CardCode}',";
                        add_SyncLeads += $" '{insert_CardName}',";
                        add_SyncLeads += $" '{insert_CardType}',";
                        add_SyncLeads += $" '{insert_Address}',";
                        add_SyncLeads += $" '{insert_ZipCode}',";
                        add_SyncLeads += $" '{insert_MailAddress}',";

                        add_SyncLeads += $" '{insert_Phone1}',";
                        add_SyncLeads += $" '{insert_Contact}',";
                        add_SyncLeads += $" '{insert_CURP}',";
                        add_SyncLeads += $" '{insert_City}',";
                        add_SyncLeads += $" '{insert_Country}',";
                        add_SyncLeads += $" '{insert_CreateDate}',";
                        add_SyncLeads += $" '{insert_UpdateDate}',";

                        add_SyncLeads += $" '{insert_State1}',";
                        add_SyncLeads += $" '{insert_action}',";
                        add_SyncLeads += $" FALSE,";
                        add_SyncLeads += $" '{insert_dateSend}',";
                        add_SyncLeads += $" '{insert_dateRegister}',";
                        add_SyncLeads += $" TRUE,";
                        add_SyncLeads += $" '{insert_Block}',";
                        add_SyncLeads += $" '{insert_sucursalk}',";
                        add_SyncLeads += $" '{final_asesor}',";
                        add_SyncLeads += $" '{insert_cfdi}',";
                        add_SyncLeads += $" '{user_email}'";
                        add_SyncLeads += $");";

                        bool LeadInsert = DBConn.ExecQueryInsert(add_SyncLeads, DBConn.ConectionDB.Bitacoras);
                        if (!LeadInsert)
                        {
                            Utils.PrintLog("RegisterLeadsBitacoraToSap", "0", $"No fue posible realizar la sincronización del lead {insert_CardCode}");
                        }
                        #endregion

                        #region Actualizar Consecutivo, Estado
                        if (LeadInsert)
                        {
                            string select_id = $"SELECT TOP 1 {Utils.parseStringBD("idSyncLead")} FROM {Utils.parseStringBD("zAdi_SyncLeadSAP")} WHERE {Utils.parseStringBD("CardName")} = '{insert_CardName}'";
                            DataTable tbl_id = DBConn.ExecQuery(select_id, DBConn.ConectionDB.Bitacoras);
                            insert_idSyncLead = (tbl_id != null && tbl_id.Rows != null && tbl_id.Rows.Count > 0) ? tbl_id.Rows[0]["idSyncLead"].ToString() : "0";


                            ///Metodo para actualizar el consecutivo en SAP y Ecommerce
                            //UpdateCardCode(int.Parse(insert_idSyncLead), insert_idClient);


                            //Metodo para cambiar el nombre del estado a Siglas en SAP
                            UpdateState(int.Parse(insert_idSyncLead), insert_State1);
                            //Metodo para insertar en la tabla nativa
                            //InsertNativeLead(insert_idSyncLead);

                            /////Actualizar el estado del FLAG en Ecommerce
                            string updateBitacoraLeads = $"UPDATE zAdi_SyncLead SET flagSend = 1, dateSend = NOW() WHERE idClient = {insert_idClient}";
                            DBConnMysql.ExecQuery(updateBitacoraLeads);

                        }
                        #endregion
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("RegisterLeadsBitacoraToSap", "1", ex.ToString());
            }


        }
        public void InsertNativeLead(int insert_idSyncLead)
        {

            #region ToNative
            //string pathNATIVE = "C:\\LogLeadsRchanINSERTNATIVE.txt";
            //string pathNATIVECONTACT = "C:\\LogLeadsRchanINSERTNATIVECONTACT.txt";
            //string pathNATIVEdirr = "C:\\LogLeadsRchanINSERTNATIVEdirr.txt";
            //string pathQUERY = "C:\\LogLeadsRchanINSERTquery.txt";

            try
            {


                //string query_GetBitSAP = $@"SELECT *";
                //query_GetBitSAP += $" FROM {Utils.parseStringBD("zAdi_SyncLeadSAP")}";
                //query_GetBitSAP += $" WHERE {Utils.parseStringBD("idSyncLead")} = '{insert_idSyncLead}'";

                string query_GetBitSAP = $@"SELECT TOP {Utils.rangoRegistros_Leads} *";
                query_GetBitSAP += $" FROM {Utils.parseStringBD("zAdi_SyncLeadSAP")}";
                query_GetBitSAP += $" WHERE {Utils.parseStringBD("flagSend")} = FALSE AND {Utils.parseStringBD("FlagLead")} = TRUE AND ({Utils.parseStringBD("CardCode")} != 'x' OR {Utils.parseStringBD("CardCode")} != 'X' OR {Utils.parseStringBD("CardCode")} != '---')";

                //using (StreamWriter writer = new StreamWriter(pathQUERY, true))
                //{
                //    writer.WriteLine(string.Format($"query_insert_envio: \n{query_GetBitSAP}\n\n"));
                //    writer.Close();
                //}

                DataTable DtLeadBit = DBConn.ExecQuery(query_GetBitSAP, DBConn.ConectionDB.Bitacoras);
                foreach (DataRow rowLeads in DtLeadBit.Rows)
                {
                    ////Recuperar la información reciente agregada a la Bitacora SAP
                    string query_GetNextDocEntry = $@"SELECT TOP 1 {Utils.parseStringBD("DocEntry")}";
                    query_GetNextDocEntry += $" FROM {Utils.parseStringBD("OCRD")}";
                    query_GetNextDocEntry += $" ORDER BY {Utils.parseStringBD("DocEntry")} DESC";

                    DataTable DtNextDocE = DBConn.ExecQuery(query_GetNextDocEntry);
                    //Se recupera el valor más alto para este campo y se le suma 1, el campo es de valor unico.
                    int NextDocEntry = (int.Parse(DtNextDocE.Rows[0]["DocEntry"].ToString()) + 1);

                    string idSyncLead = rowLeads["idSyncLead"].ToString() != "" && rowLeads["idSyncLead"].ToString() != null ? rowLeads["idSyncLead"].ToString() : "0"; ;
                    string idCliente = (rowLeads["idClient"].ToString() != "" && rowLeads["idClient"].ToString() != null) ? rowLeads["idClient"].ToString() : "0";
                    string insert_CardCode = (rowLeads.ItemArray[2].ToString() != "" && rowLeads.ItemArray[2].ToString() != null) ? rowLeads.ItemArray[2].ToString() : null;
                    string insert_CardName = (rowLeads.ItemArray[3].ToString() != "" && rowLeads.ItemArray[3].ToString() != null) ? rowLeads.ItemArray[3].ToString() : null;
                    string insert_CardType = (rowLeads.ItemArray[4].ToString() != "" && rowLeads.ItemArray[4].ToString() != null) ? rowLeads.ItemArray[4].ToString() : null;
                    string insert_Address = (rowLeads.ItemArray[5].ToString() != "" && rowLeads.ItemArray[5].ToString() != null) ? rowLeads.ItemArray[5].ToString() : null;
                    string insert_ZipCode = (rowLeads.ItemArray[6].ToString() != "" && rowLeads.ItemArray[6].ToString() != null) ? rowLeads.ItemArray[6].ToString() : null;
                    string insert_MailAddress = (rowLeads.ItemArray[7].ToString() != "" && rowLeads.ItemArray[7].ToString() != null) ? rowLeads.ItemArray[7].ToString() : null;
                    string insert_Phone1 = (rowLeads.ItemArray[8].ToString() != "" && rowLeads.ItemArray[8].ToString() != null) ? rowLeads.ItemArray[8].ToString() : null;
                    string insert_Contact = (rowLeads.ItemArray[9].ToString() != "" && rowLeads.ItemArray[9].ToString() != null) ? rowLeads.ItemArray[9].ToString() : null;
                    string insert_CURP = (rowLeads.ItemArray[10].ToString() != "" && rowLeads.ItemArray[10].ToString() != null) ? rowLeads.ItemArray[10].ToString() : null;
                    string insert_City = (rowLeads.ItemArray[11].ToString() != "" && rowLeads.ItemArray[11].ToString() != null) ? rowLeads.ItemArray[11].ToString() : null;
                    string insert_Country = (rowLeads.ItemArray[12].ToString() != "" && rowLeads.ItemArray[12].ToString() != null) ? rowLeads.ItemArray[12].ToString() : null;
                    string insert_CreateDate = (Utils.GetDateFormatToSap(rowLeads.ItemArray[13].ToString()) != "" && Utils.GetDateFormatToSap(rowLeads.ItemArray[13].ToString()) != null) ? Utils.GetDateFormatToSap(rowLeads.ItemArray[13].ToString()) : "";
                    string insert_UpdateDate = (Utils.GetDateFormatToSap(rowLeads.ItemArray[14].ToString()) != "" && Utils.GetDateFormatToSap(rowLeads.ItemArray[14].ToString()) != null) ? Utils.GetDateFormatToSap(rowLeads.ItemArray[14].ToString()) : "";
                    //////
                    string insert_State1WAccent = (Utils.RemoveAccents(rowLeads.ItemArray[15].ToString()) != null && Utils.RemoveAccents(rowLeads.ItemArray[15].ToString()) != "") ? Utils.RemoveAccents(rowLeads.ItemArray[15].ToString()) : null;
                    string insert_State1 = (Utils.RemoveAccents(rowLeads.ItemArray[15].ToString()) != "" && Utils.RemoveAccents(rowLeads.ItemArray[15].ToString()) != null) ? Utils.RemoveAccents(rowLeads.ItemArray[15].ToString()) : null;
                    /////

                    string insert_action = (rowLeads.ItemArray[16].ToString() != "" && rowLeads.ItemArray[16].ToString() != null) ? rowLeads.ItemArray[16].ToString() : null;
                    string insert_flagSend = (rowLeads.ItemArray[17].ToString() != "" && rowLeads.ItemArray[17].ToString() != null) ? rowLeads.ItemArray[17].ToString() : null;
                    string insert_dateSend = (Utils.GetDateFormatToSap(rowLeads.ItemArray[18].ToString()) != "" && Utils.GetDateFormatToSap(rowLeads.ItemArray[18].ToString()) != null) ? Utils.GetDateFormatToSap(rowLeads.ItemArray[18].ToString()) : "";
                    string insert_dateRegister = (Utils.GetDateFormatToSap(rowLeads.ItemArray[19].ToString()) != "" && Utils.GetDateFormatToSap(rowLeads.ItemArray[19].ToString()) != null) ? Utils.GetDateFormatToSap(rowLeads.ItemArray[19].ToString()) : "";

                    /////Proceso de INSERT
                    #region columns
                    string query_insert_LeadsDef = $"INSERT INTO {Utils.parseStringBD("OCRD")} (\n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("CardCode")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("CardName")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("CardType")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("GroupCode")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("CmpPrivate")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("Address")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("ZipCode")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("Phone1")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("Phone2")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("Fax")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("CntctPrsn")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("Balance")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("ChecksBal")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("DNotesBal")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("OrdersBal")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("GroupNum")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("CreditLine")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("DebtLine")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("Discount")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("VatStatus")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("LicTradNum")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("DdctStatus")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("DdctPrcnt")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("ListNum")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("DNoteBalFC")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("OrderBalFC")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("DNoteBalSy")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("OrderBalSy")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("Transfered")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("BalTrnsfrd")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("IntrstRate")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("Commission")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("CommGrCode")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("SlpCode")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("PrevYearAc")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("Currency")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("BalanceSys")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("BalanceFC")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("Protected")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("Cellular")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("City")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("County")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("Country")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("E_Mail")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("BankCode")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("AddID")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("CardFName")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("FatherType")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup1")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup2")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup3")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup4")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup5")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup6")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup7")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup8")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup9")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup10")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup11")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup12")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup13")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup14")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup15")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup16")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup17")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup18")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup19")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup20")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup21")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup22")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup23")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup24")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup25")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup26")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup27")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup28")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup29")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup30")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup31")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup32")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup33")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup34")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup35")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup36")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup37")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup38")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup39")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup40")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup41")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup42")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup43")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup44")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup45")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup46")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup47")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup48")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup49")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup50")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup51")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup52")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup53")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup54")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup55")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup56")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup57")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup58")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup59")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup60")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup61")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup62")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup63")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("QryGroup64")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("CreateDate")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("UpdateDate")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("DscntObjct")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("DscntRel")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("SPGCounter")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("SPPCounter")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("MinIntrst")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("DataSource")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("OprCount")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("Priority")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("CreditCard")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("CrCardNum")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("UserSign")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("LocMth")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("validFor")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("frozenFor")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("sEmployed")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("DdgKey")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("DdtKey")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("chainStore")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("DiscInRet")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("State1")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("LogInstanc")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("ObjType")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("DebPayAcct")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("Block")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("Deleted")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("DocEntry")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("PymCode")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("BackOrder")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("PartDelivr")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("BlockDunn")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("CollecAuth")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("SinglePaym")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("PaymBlock")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("PyBlckDesc")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("HousBnkCry")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("SysMatchNo")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("DeferrTax")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("MaxAmount")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("WTLiable")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("AccCritria")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("Equ")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("TypWTReprt")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("IsDomestic")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("IsResident")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("AutoCalBCG")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("Building")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("BillToDef")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("IntrntSite")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("LangCode")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("HousActKey")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("UseShpdGd")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("HousCtlKey")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("InsurOp347")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("TaxRndRule")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("ThreshOver")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("SurOver")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("OpCode347")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("ResidenNum")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("UserSign2")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("Affiliate")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("MivzExpSts")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("HierchDdct")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("CertWHT")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("CertBKeep")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("WHShaamGrp")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("DatevFirst")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("HsBnkSwift")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("HsBnkIBAN")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("Series")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("Number")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("TaxIdIdent")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("DiscRel")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("NoDiscount")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("SCAdjust")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("SefazCheck")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("TpCusPres")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("BlockComm")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("ExpnPrfFnd")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("EdrsFromBP")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("EdrsToBP")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("CreateTS")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("UpdateTS")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("EffecPrice")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("TxExMxVdTp")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("UseBilAddr")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("NaturalPer")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("DPPStatus")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("EnERD4In")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("EnERD4Out")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("DflCustomr")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("FCERelevnt")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("FCEVldte")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("U_BOY_TB_0")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("U_CETipoOperacion")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("U_CEClavePedimento")}, \n";
                    query_insert_LeadsDef += $"{Utils.parseStringBD("U_CENumExportador")} \n";
                    #endregion
                    #region values
                    ////Valores:
                    query_insert_LeadsDef += ")\n VALUES (";
                    query_insert_LeadsDef += $" '{insert_CardCode}' \n"; //CardCode
                    query_insert_LeadsDef += $", '{insert_CardName}' \n"; //CardName
                    query_insert_LeadsDef += $", '{insert_CardType}'\n"; //CardType
                    query_insert_LeadsDef += $", '132'\n"; //GroupCode
                    query_insert_LeadsDef += $", 'C'\n"; //CmpPrivate
                    query_insert_LeadsDef += $", '{insert_Address}'\n"; //Address Variable SYnc
                    query_insert_LeadsDef += $", '{insert_ZipCode}'\n"; //ZipCode Variable Sync
                    query_insert_LeadsDef += $", '{insert_Phone1}'\n"; //Phone1 Variable Syc
                    query_insert_LeadsDef += $", ''\n"; //Phone2
                    query_insert_LeadsDef += $", ''\n"; //Fax
                    query_insert_LeadsDef += $", '{insert_Contact}'\n"; //CntctPrsn Vairbale Sync
                    query_insert_LeadsDef += $", 0\n"; //Balance
                    query_insert_LeadsDef += $", 0\n"; //ChecksBal
                    query_insert_LeadsDef += $", 0\n"; //DNotesBal
                    query_insert_LeadsDef += $", 0\n"; //OrdersBal
                    query_insert_LeadsDef += $", 2\n"; //GroupNum
                    query_insert_LeadsDef += $", 0\n"; //CreditLine
                    query_insert_LeadsDef += $", 0\n"; //DebtLine
                    query_insert_LeadsDef += $", 0\n"; //Discount
                    query_insert_LeadsDef += $", 'Y'\n"; //VatStatus
                    query_insert_LeadsDef += $", '{insert_CURP}'\n"; //LicTradNum
                    query_insert_LeadsDef += $", 'N'\n"; //DdctStatus
                    query_insert_LeadsDef += $", 0\n"; //DdctPrcnt
                    query_insert_LeadsDef += $", 3\n"; //ListNum
                    query_insert_LeadsDef += $", 0\n"; //DNoteBalFC
                    query_insert_LeadsDef += $", 0\n"; //OrderBalFC
                    query_insert_LeadsDef += $", 0\n"; //DNoteBalSy
                    query_insert_LeadsDef += $", 0\n"; //OrderBalSy
                    query_insert_LeadsDef += $", 'N'\n"; //Transfered
                    query_insert_LeadsDef += $", 'N'\n"; //BalTrnsfrd
                    query_insert_LeadsDef += $", 0\n"; //IntrstRate
                    query_insert_LeadsDef += $", 0\n"; //Commission
                    query_insert_LeadsDef += $", 0\n"; //CommGrCode
                    query_insert_LeadsDef += $", -1\n"; //SlpCode
                    query_insert_LeadsDef += $", 'N'\n"; //PrevYearAc
                    query_insert_LeadsDef += $", 'USD'\n"; //Currency
                    query_insert_LeadsDef += $", 0\n"; //BalanceSys
                    query_insert_LeadsDef += $", 0\n"; //BalanceFC
                    query_insert_LeadsDef += $", 'N'\n"; //Protected
                    query_insert_LeadsDef += $", ''\n"; //Cellular
                    query_insert_LeadsDef += $", '{insert_City}'\n"; //City
                    query_insert_LeadsDef += $", ''\n"; //County
                    query_insert_LeadsDef += $", '{insert_Country}'\n"; //Country
                    query_insert_LeadsDef += $", '{insert_MailAddress}'\n"; //E_Mail
                    query_insert_LeadsDef += $", '-1'\n"; //BankCode
                    query_insert_LeadsDef += $", ''\n"; //AddID
                    query_insert_LeadsDef += $", ''\n"; //CardFName
                    query_insert_LeadsDef += $", 'p'\n"; //FatherType
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup1
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup2
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup3
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup4
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup5
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup6
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup7
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup8
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup9
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup10
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup11
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup12
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup13
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup14
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup15
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup16
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup17
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup18
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup19
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup20
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup21
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup22
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup23
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup24
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup25
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup26
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup27
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup28
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup29
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup30
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup31
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup32
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup33
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup34
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup35
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup36
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup37
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup38
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup39
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup40
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup41
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup42
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup43
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup44
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup45
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup46
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup47
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup48
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup49
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup50
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup51
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup52
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup53
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup54
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup55
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup56
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup57
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup58
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup59
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup60
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup61
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup62
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup63
                    query_insert_LeadsDef += $", 'N'\n"; //QryGroup64
                    query_insert_LeadsDef += $", '{insert_CreateDate}'\n"; //CreateDate Variable Sync
                    query_insert_LeadsDef += $", NOW()\n"; //UpdateDate Variable Sync
                    query_insert_LeadsDef += $", -1\n"; //DscntObjct
                    query_insert_LeadsDef += $", 'L'\n"; //DscntRel
                    query_insert_LeadsDef += $", 0\n"; //SPGCounter
                    query_insert_LeadsDef += $", 0\n"; //SPPCounter
                    query_insert_LeadsDef += $", 0\n"; //MinIntrst
                    query_insert_LeadsDef += $", 'O'\n"; //DataSource
                    query_insert_LeadsDef += $", 1\n"; //OprCount
                    query_insert_LeadsDef += $", -1\n"; //Priority
                    query_insert_LeadsDef += $", -1\n"; //CreditCard
                    query_insert_LeadsDef += $", '/aJkEu9+xYoUrzxQe1zMCw=='\n"; //CrCardNum
                    query_insert_LeadsDef += $", 1\n"; //UserSign
                    query_insert_LeadsDef += $", 'Y'\n"; //LocMth
                    query_insert_LeadsDef += $", 'Y'\n"; //validFor
                    query_insert_LeadsDef += $", 'N'\n"; //frozenFor
                    query_insert_LeadsDef += $", 'N'\n"; //sEmployed
                    query_insert_LeadsDef += $", -1\n"; //DdgKey
                    query_insert_LeadsDef += $", -1\n"; //DdtKey
                    query_insert_LeadsDef += $", 'N'\n"; //chainStore
                    query_insert_LeadsDef += $", 'N'\n"; //DiscInRet
                    query_insert_LeadsDef += $", '{insert_State1}'\n"; //State1 Variable Sync
                    query_insert_LeadsDef += $", 0\n"; //LogInstanc
                    query_insert_LeadsDef += $", '2'\n"; //ObjType
                    query_insert_LeadsDef += $", '100400001'\n"; //DebPayAcct  Variable Sync
                    query_insert_LeadsDef += $", ''\n"; //Block
                    query_insert_LeadsDef += $", 'N'\n"; //Deleted
                    query_insert_LeadsDef += $", '{NextDocEntry}'\n"; //21527//DocEntry DE DONDE SALE ESTE DATO, ES NUMERICO ?(Debe ir vacio, es autoincremental al parecer.)
                    query_insert_LeadsDef += $", '99'\n"; //PymCode ES NUMÉRICO ?
                    query_insert_LeadsDef += $", 'Y'\n"; //BackOrder
                    query_insert_LeadsDef += $", 'Y'\n"; //PartDelivr
                    query_insert_LeadsDef += $",'N'\n"; //BlockDunn
                    query_insert_LeadsDef += $",'N'\n"; //CollecAuth
                    query_insert_LeadsDef += $", 'N'\n"; //SinglePaym
                    query_insert_LeadsDef += $", 'N'\n"; //PaymBlock
                    query_insert_LeadsDef += $", -1\n"; //PyBlckDesc
                    query_insert_LeadsDef += $", 'MX'\n"; //HousBnkCry Variable Sync
                    query_insert_LeadsDef += $", -1\n"; //SysMatchNo
                    query_insert_LeadsDef += $", 'Y'\n"; //DeferrTax
                    query_insert_LeadsDef += $", 0\n"; //MaxAmount
                    query_insert_LeadsDef += $", 'N'\n"; //WTLiable
                    query_insert_LeadsDef += $", 'N'\n"; //AccCritria
                    query_insert_LeadsDef += $", 'N'\n"; //Equ
                    query_insert_LeadsDef += $", 'C'\n"; //TypWTReprt
                    query_insert_LeadsDef += $", 'Y'\n"; //IsDomestic
                    query_insert_LeadsDef += $", 'Y'\n"; //IsResident
                    query_insert_LeadsDef += $", 'N'\n"; //AutoCalBCG
                    query_insert_LeadsDef += $", ''\n"; //Building
                    query_insert_LeadsDef += $", 'CliTest'\n"; //BillToDef Variable Sync
                    query_insert_LeadsDef += $", ''\n"; //IntrntSite
                    query_insert_LeadsDef += $", 23\n"; //LangCode
                    query_insert_LeadsDef += $", 0\n"; //HousActKey
                    query_insert_LeadsDef += $", 'N'\n"; //UseShpdGd
                    query_insert_LeadsDef += $", ''\n"; //HousCtlKey
                    query_insert_LeadsDef += $", 'N'\n"; //InsurOp347
                    query_insert_LeadsDef += $", 'D'\n"; //TaxRndRule
                    query_insert_LeadsDef += $", 'N'\n"; //ThreshOver
                    query_insert_LeadsDef += $", 'N'\n"; //SurOver
                    query_insert_LeadsDef += $", 'B'\n"; //OpCode347
                    query_insert_LeadsDef += $", '1'\n"; //ResidenNum
                    query_insert_LeadsDef += $", 1\n"; //UserSign2
                    query_insert_LeadsDef += $", 'N'\n"; //Affiliate
                    query_insert_LeadsDef += $", 'B'\n"; //MivzExpSts
                    query_insert_LeadsDef += $", 'N'\n"; //HierchDdct
                    query_insert_LeadsDef += $", 'N'\n"; //CertWHT
                    query_insert_LeadsDef += $", 'N'\n"; //CertBKeep
                    query_insert_LeadsDef += $", '1'\n"; //WHShaamGrp
                    query_insert_LeadsDef += $", 'Y'\n"; //DatevFirst
                    query_insert_LeadsDef += $", ''\n"; //HsBnkSwift
                    query_insert_LeadsDef += $", ''\n"; //HsBnkIBAN
                    query_insert_LeadsDef += $", 94\n"; //Series DE DONDE SALE ESTE VALOR
                    query_insert_LeadsDef += $", 1250\n"; //Number DE DONDE SALE ESTE VALOR
                    query_insert_LeadsDef += $", '3'\n"; //TaxIdIdent
                    query_insert_LeadsDef += $", 'L'\n"; //DiscRel
                    query_insert_LeadsDef += $", 'N'\n"; //NoDiscount
                    query_insert_LeadsDef += $", 'N'\n"; //SCAdjust
                    query_insert_LeadsDef += $", 'N'\n"; //SefazCheck
                    query_insert_LeadsDef += $", 9\n"; //TpCusPres DE DONDE SALE ESTE VALOR
                    query_insert_LeadsDef += $", 'N'\n"; //BlockComm
                    query_insert_LeadsDef += $", 0\n"; //ExpnPrfFnd
                    query_insert_LeadsDef += $", 'Y'\n"; //EdrsFromBP
                    query_insert_LeadsDef += $", 'N'\n"; //EdrsToBP
                    query_insert_LeadsDef += $", 184449\n"; //CreateTS DE DONDE SALE ESTE VALOR
                    query_insert_LeadsDef += $", 165618\n"; //UpdateTS DE DONDE SALE ESTE VALOR
                    query_insert_LeadsDef += $", 'D'\n"; //EffecPrice
                    query_insert_LeadsDef += $", 'I'\n"; //TxExMxVdTp
                    query_insert_LeadsDef += $", 'N'\n"; //UseBilAddr
                    query_insert_LeadsDef += $", 'N'\n"; //NaturalPer
                    query_insert_LeadsDef += $", 'N'\n"; //DPPStatus
                    query_insert_LeadsDef += $", 'Y'\n"; //EnERD4In
                    query_insert_LeadsDef += $", 'Y'\n"; //EnERD4Out
                    query_insert_LeadsDef += $", 'N'\n"; //DflCustomr
                    query_insert_LeadsDef += $", 'N'\n"; //FCERelevnt
                    query_insert_LeadsDef += $", 'N'\n"; //FCEVldte
                    query_insert_LeadsDef += $", 'N'\n"; //U_BOY_TB_0
                    query_insert_LeadsDef += $", '2'\n"; //U_CETipoOperacion
                    query_insert_LeadsDef += $", 'A1'\n"; //U_CEClavePedimento
                    query_insert_LeadsDef += $", ''\n"; //U_CENumExportador
                    query_insert_LeadsDef += ")";
                    #endregion


                    //using (StreamWriter writer = new StreamWriter(pathNATIVE, true))
                    //{
                    //    writer.WriteLine(string.Format($"query_insert_envio: \n{query_insert_LeadsDef}\n\n"));
                    //    writer.Close();
                    //}
                    bool fginsert = DBConn.ExecQueryInsert(query_insert_LeadsDef);

                    if (fginsert)
                    {
                        string update_log = $"UPDATE {Utils.parseStringBD("zAdi_SyncLeadSAP")} SET  {Utils.parseStringBD("flagSend")} = TRUE WHERE {Utils.parseStringBD("idSyncLead")} = {idSyncLead}";
                        DBConn.ExecQueryUpdate(update_log, DBConn.ConectionDB.Bitacoras);

                        //using (StreamWriter writer = new StreamWriter(pathNATIVE, true))
                        //{
                        //    writer.WriteLine(string.Format($"update_log: \n{update_log}\n\n"));
                        //    writer.Close();
                        //}

                        #region DatosContacto
                        ////Recuperar el ultimo consecutivo para los contactos
                        string query_GetNextContactC = $@"SELECT TOP 1 {Utils.parseStringBD("CntctCode")}";
                        query_GetNextContactC += $" FROM {Utils.parseStringBD("OCPR")}";
                        query_GetNextContactC += $" ORDER BY {Utils.parseStringBD("CntctCode")} DESC";

                        DataTable DtNextContactC = DBConn.ExecQuery(query_GetNextContactC);
                        //Se recupera el valor más alto para este campo y se le suma 1, el campo es de valor unico.
                        int NextContactC = (int.Parse(DtNextContactC.Rows[0]["CntctCode"].ToString()) + 1);

                        //Se deben guardar los datos de la persona de contacto en otra tabla. Se usarán los mismos registros yá recuperados

                        string query_insert_LeadContact = $"INSERT INTO {Utils.parseStringBD("OCPR")} (\n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("CntctCode")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("CardCode")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("Name")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("Position")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("Address")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("Tel1")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("Tel2")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("Cellolar")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("Fax")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("E_MailL")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("Pager")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("Notes1")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("Notes2")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("DataSource")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("UserSign")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("Password")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("LogInstanc")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("ObjType")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("BirthPlace")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("BirthDate")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("Gender")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("Profession")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("updateDate")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("updateTime")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("Title")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("BirthCity")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("Active")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("FirstName")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("MiddleName")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("LastName")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("BirthState")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("ResidCity")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("ResidCntry")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("ResidState")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("NFeRcpn")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("EmlGrpCode")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("BlockComm")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("FiscalCode")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("CtyPrvsYr")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("SttPrvsYr")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("CtyCdPrvsY")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("CtyCurYr")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("SttCurYr")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("CtyCdCurYr")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("NotResdSch")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("CtyFsnCode")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("NaturalPer")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("DPPStatus")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("CreateDate")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("CreateTS")}, \n";
                        query_insert_LeadContact += $"{Utils.parseStringBD("EncryptIV")} \n";
                        ////Valores:
                        query_insert_LeadContact += ")\n VALUES (";
                        query_insert_LeadContact += $" '{NextContactC}' \n";//CntctCode
                        query_insert_LeadContact += $", '{insert_CardCode}'\n";//CardCode
                        query_insert_LeadContact += $", '{insert_Contact}'\n";//Name
                        query_insert_LeadContact += $", ''\n";//Position
                        query_insert_LeadContact += $", ''\n";//Address
                        query_insert_LeadContact += $", '{insert_Phone1}'\n";//Tel1
                        query_insert_LeadContact += $", ''\n";//Tel2
                        query_insert_LeadContact += $", ''\n";//Cellolar
                        query_insert_LeadContact += $", ''\n";//Fax
                        query_insert_LeadContact += $", '{insert_MailAddress}'\n";//E_MailL
                        query_insert_LeadContact += $", ''\n";//Pager
                        query_insert_LeadContact += $", ''\n";//Notes1
                        query_insert_LeadContact += $", ''\n";//Notes2
                        query_insert_LeadContact += $", 'N'\n";//DataSource
                        query_insert_LeadContact += $", 1\n";//UserSign
                        query_insert_LeadContact += $", ''\n";//Password
                        query_insert_LeadContact += $", 0\n";//LogInstanc
                        query_insert_LeadContact += $", 11\n";//ObjType
                        query_insert_LeadContact += $", ''\n";//BirthPlace
                        query_insert_LeadContact += $", ''\n";//BirthDate
                        query_insert_LeadContact += $", 'E'\n";//Gender
                        query_insert_LeadContact += $", ''\n";//Profession
                        query_insert_LeadContact += $", '{insert_CreateDate}'\n";//updateDate
                        query_insert_LeadContact += $", 1844\n";//updateTime
                        query_insert_LeadContact += $", ''\n";//Title
                        query_insert_LeadContact += $", ''\n";//BirthCity
                        query_insert_LeadContact += $", 'Y'\n";//Active
                        query_insert_LeadContact += $", ''\n";//FirstName
                        query_insert_LeadContact += $", ''\n";//MiddleName
                        query_insert_LeadContact += $", ''\n";//LastName
                        query_insert_LeadContact += $", ''\n";//BirthState
                        query_insert_LeadContact += $", ''\n";//ResidCity
                        query_insert_LeadContact += $", ''\n";//ResidCntry
                        query_insert_LeadContact += $", ''\n";//ResidState
                        query_insert_LeadContact += $", 'N'\n";//NFeRcpn
                        query_insert_LeadContact += $", ''\n";//EmlGrpCode
                        query_insert_LeadContact += $", 'N'\n";//BlockComm
                        query_insert_LeadContact += $", ''\n";//FiscalCode
                        query_insert_LeadContact += $", ''\n";//CtyPrvsYr
                        query_insert_LeadContact += $", ''\n";//SttPrvsYr
                        query_insert_LeadContact += $", ''\n";//CtyCdPrvsY
                        query_insert_LeadContact += $", ''\n";//CtyCurYr
                        query_insert_LeadContact += $", ''\n";//SttCurYr
                        query_insert_LeadContact += $", ''\n";//CtyCdCurYr
                        query_insert_LeadContact += $", ''\n";//NotResdSch
                        query_insert_LeadContact += $", ''\n";//CtyFsnCode
                        query_insert_LeadContact += $", 'N'\n";//NaturalPer
                        query_insert_LeadContact += $", 'N'\n";//DPPStatus
                        query_insert_LeadContact += $", '{insert_CreateDate}'\n";//CreateDate
                        query_insert_LeadContact += $", '184499'\n";//CreateTS
                        query_insert_LeadContact += $", ''\n";//EncryptIV
                        query_insert_LeadContact += ")";

                        //using (StreamWriter writer = new StreamWriter(pathNATIVECONTACT, true))
                        //{
                        //    writer.WriteLine(string.Format($"query_insert_envio: \n{query_insert_LeadContact}\n\n"));
                        //    writer.Close();
                        //}
                        bool fgInsert = DBConn.ExecQueryInsert(query_insert_LeadContact);
                        if (!fgInsert)
                        {
                            Utils.PrintLog("InsertNativeLead", "0", $"No fue posible realizar la sincronización del contacto {insert_Contact}");
                        }
                        #endregion

                        #region Dirección

                        //Se deben guardar los datos de la persona de contacto en otra tabla. Se usarán los mismos registros yá recuperados

                        string query_insert_LeadDir = $"INSERT INTO {Utils.parseStringBD("CRD1")} (\n";
                        query_insert_LeadDir += $"{Utils.parseStringBD("Address")}, \n";
                        query_insert_LeadDir += $"{Utils.parseStringBD("CardCode")}, \n";
                        query_insert_LeadDir += $"{Utils.parseStringBD("Street")}, \n";
                        query_insert_LeadDir += $"{Utils.parseStringBD("Block")}, \n";
                        query_insert_LeadDir += $"{Utils.parseStringBD("ZipCode")}, \n";
                        query_insert_LeadDir += $"{Utils.parseStringBD("City")}, \n";
                        query_insert_LeadDir += $"{Utils.parseStringBD("County")}, \n";
                        query_insert_LeadDir += $"{Utils.parseStringBD("Country")}, \n";
                        query_insert_LeadDir += $"{Utils.parseStringBD("State")}, \n";
                        query_insert_LeadDir += $"{Utils.parseStringBD("UserSign")}, \n";
                        query_insert_LeadDir += $"{Utils.parseStringBD("LogInstanc")}, \n";
                        query_insert_LeadDir += $"{Utils.parseStringBD("ObjType")}, \n";
                        query_insert_LeadDir += $"{Utils.parseStringBD("LicTradNum")}, \n";
                        query_insert_LeadDir += $"{Utils.parseStringBD("LineNum")}, \n";
                        query_insert_LeadDir += $"{Utils.parseStringBD("TaxCode")}, \n";
                        query_insert_LeadDir += $"{Utils.parseStringBD("Building")}, \n";
                        query_insert_LeadDir += $"{Utils.parseStringBD("AdresType")}, \n";
                        query_insert_LeadDir += $"{Utils.parseStringBD("Address2")}, \n";
                        query_insert_LeadDir += $"{Utils.parseStringBD("Address3")}, \n";
                        query_insert_LeadDir += $"{Utils.parseStringBD("AddrType")}, \n";
                        query_insert_LeadDir += $"{Utils.parseStringBD("StreetNo")}, \n";
                        query_insert_LeadDir += $"{Utils.parseStringBD("AltCrdName")}, \n";
                        query_insert_LeadDir += $"{Utils.parseStringBD("AltTaxId")}, \n";
                        query_insert_LeadDir += $"{Utils.parseStringBD("TaxOffice")}, \n";
                        query_insert_LeadDir += $"{Utils.parseStringBD("GlblLocNum")}, \n";
                        query_insert_LeadDir += $"{Utils.parseStringBD("Ntnlty")}, \n";
                        query_insert_LeadDir += $"{Utils.parseStringBD("DIOTNat")}, \n";
                        query_insert_LeadDir += $"{Utils.parseStringBD("TaaSEnbl")}, \n";
                        query_insert_LeadDir += $"{Utils.parseStringBD("GSTRegnNo")}, \n";
                        query_insert_LeadDir += $"{Utils.parseStringBD("GSTType")}, \n";
                        query_insert_LeadDir += $"{Utils.parseStringBD("CreateDate")}, \n";
                        query_insert_LeadDir += $"{Utils.parseStringBD("CreateTS")}, \n";
                        query_insert_LeadDir += $"{Utils.parseStringBD("EncryptIV")}, \n";
                        query_insert_LeadDir += $"{Utils.parseStringBD("MYFType")} \n";
                        ////Valores:
                        query_insert_LeadDir += ")\n VALUES (";
                        query_insert_LeadDir += $" '{insert_CardName}'\n";//Address
                        query_insert_LeadDir += $", '{insert_CardCode}'\n";//CardCode
                        query_insert_LeadDir += $", '{insert_Address}'\n";//Street
                        query_insert_LeadDir += $", ''\n";//Block
                        query_insert_LeadDir += $", '{insert_ZipCode}'\n";//ZipCode
                        query_insert_LeadDir += $", '{insert_City}'\n";//City
                        query_insert_LeadDir += $", ''\n";//County
                        query_insert_LeadDir += $", '{insert_Country}'\n";//Country
                        query_insert_LeadDir += $", '{insert_State1}'\n";//State
                        query_insert_LeadDir += $", 0\n";//UserSign
                        query_insert_LeadDir += $", 0\n";//LogInstanc
                        query_insert_LeadDir += $", 2\n";//ObjType
                        query_insert_LeadDir += $", ''\n";//LicTradNum
                        query_insert_LeadDir += $", 0\n";//LineNum
                        query_insert_LeadDir += $", 'IVAV16'\n";//TaxCode
                        query_insert_LeadDir += $", ''\n";//Building
                        query_insert_LeadDir += $", 'B'\n";//AdresType
                        query_insert_LeadDir += $", ''\n";//Address2
                        query_insert_LeadDir += $", ''\n";//Address3
                        query_insert_LeadDir += $", ''\n";//AddrType
                        query_insert_LeadDir += $", ''\n";//StreetNo
                        query_insert_LeadDir += $", ''\n";//AltCrdName
                        query_insert_LeadDir += $", ''\n";//AltTaxId
                        query_insert_LeadDir += $", ''\n";//TaxOffice
                        query_insert_LeadDir += $", ''\n";//GlblLocNum
                        query_insert_LeadDir += $", ''\n";//Ntnlty
                        query_insert_LeadDir += $", ''\n";//DIOTNat
                        query_insert_LeadDir += $", 'Y'\n";//TaaSEnbl
                        query_insert_LeadDir += $", ''\n";//GSTRegnNo
                        query_insert_LeadDir += $", 0\n";//GSTType
                        query_insert_LeadDir += $", '{insert_CreateDate}'\n";//CreateDate
                        query_insert_LeadDir += $", '192234'\n";//CreateTS
                        query_insert_LeadDir += $", ''\n";//EncryptIV
                        query_insert_LeadDir += $", ''\n";//MYFType
                        query_insert_LeadDir += ")";

                        //using (StreamWriter writer = new StreamWriter(pathNATIVEdirr, true))
                        //{
                        //    writer.WriteLine(string.Format($"query_insert_envio: \n{query_insert_LeadDir}\n\n"));
                        //    writer.Close();
                        //}
                        bool fgInserDir = DBConn.ExecQueryInsert(query_insert_LeadDir);
                        if (!fgInserDir)
                        {
                            Utils.PrintLog("InsertNativeLead", "0", $"No fue posible realizar la sincronización de la dirección {insert_Address}");
                        }
                        #endregion
                    }
                    else
                    {
                        Utils.PrintLog("InsertNativeLead", "0", $"No fue posible realizar la sincronización del lead {idSyncLead}. query: {query_insert_LeadsDef}");
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                Utils.PrintLog("InsertNativeLead", "1", ex.ToString());
            }
        }
        public void UpdateCardCode(int insert_idSyncLead, int idClient)
        {
            try
            {
                #region UpdateCardCode 
                //string pathNextC = "C:\\LogLeadsRchanNextC.txt";
                //string pathNextCE = "C:\\LogLeadsRchanNextCE.txt";
                //string pathUpDC = "C:\\LogLeadsRchanUpdC.txt";
                //Utils.PrintLog("UpdateCardCode", "1", $"insert_idSyncLead: {insert_idSyncLead}, idClient:{idClient}");
                string query_GetNextCode = $@"SELECT CONCAT({Utils.parseStringBD("BeginStr")}, CONCAT({Utils.parseStringBD("DefESeries")}, {Utils.parseStringBD("NextNumber")})), {Utils.parseStringBD("NextNumber")}";
                query_GetNextCode += $" FROM {Utils.parseStringBD("NNM1")}";
                query_GetNextCode += $" WHERE {Utils.parseStringBD("SeriesName")} = 'LEAD'";
                query_GetNextCode += $";";
                //Utils.PrintLog("UpdateCardCode", "1", $"query_GetNextCode: {query_GetNextCode}");
                DataTable tbl_NextCode = DBConn.ExecQuery(query_GetNextCode);
                if (tbl_NextCode != null && tbl_NextCode.Rows != null && tbl_NextCode.Rows.Count >= 0)
                {
                    foreach (DataRow rowNextCode in tbl_NextCode.Rows)
                    {
                        ///Cadena que se ingresará como CardCode, es el siguiente consecutivo disponible
                        string insert_NextCardCode = (rowNextCode.ItemArray[0].ToString() != "" && rowNextCode.ItemArray[0].ToString() != null) ? rowNextCode.ItemArray[0].ToString() : null;
                        ///Consecutivo disponible, unicamente el número.
                        int insert_ActualCardCode = int.Parse(rowNextCode.ItemArray[1].ToString());

                        string update_CardCode = $"UPDATE {Utils.parseStringBD("zAdi_SyncLeadSAP")}";
                        update_CardCode += $" SET {Utils.parseStringBD("CardCode")} = '{insert_NextCardCode}'";
                        update_CardCode += $" WHERE {Utils.parseStringBD("idSyncLead")} = '{insert_idSyncLead.ToString()}'";
                        //Utils.PrintLog("UpdateCardCode", "1", $"update_CardCode: {update_CardCode}");
                        bool NextCInsert = DBConn.ExecQueryUpdate(update_CardCode, DBConn.ConectionDB.Bitacoras);
                        if (NextCInsert)
                        {

                            //Se suma 1 para preparar el siguiente consecutivo disponible
                            int NextCardCodeInt = (insert_ActualCardCode + 1);

                            string update_MasterCardCode = $"UPDATE {Utils.parseStringBD("NNM1")}";
                            update_MasterCardCode += $" SET {Utils.parseStringBD("NextNumber")} = '{NextCardCodeInt}'";
                            update_MasterCardCode += $" WHERE {Utils.parseStringBD("SeriesName")} = 'LEAD'";

                            bool UpdateNE = DBConn.ExecQueryUpdate(update_MasterCardCode);
                            //Actualizar en ECommerce
                            string quote = "\"";
                            string NextCardCode = (quote + insert_NextCardCode.ToString() + quote);

                            string updateCardCodeE = $"UPDATE zAdi_SyncLead SET CardCode = {NextCardCode} WHERE idSyncLead = {idClient.ToString()}";
                            //Utils.PrintLog("UpdateCardCode", "1", $"updateCardCodeE: {updateCardCodeE}");
                            bool NextCInsertE = DBConnMysql.ExecQueryUpdate(updateCardCodeE);
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                Utils.PrintLog("UpdateCardCode", "1", ex.ToString());
            }
        }
        public void UpdateState(int insert_idSyncLead, string insert_State1)
        {
            try
            {
                #region UpdateState1
                string pathState = "C:\\LogLeadsRchanState.txt";
                string pathStateUP = "C:\\LogLeadsRchanStateUpdSAP.txt";

                string insert_State1SNAccent = (Utils.RemoveAccents(insert_State1) != "" && Utils.RemoveAccents(insert_State1) != null) ? Utils.RemoveAccents(insert_State1) : "";


                ////Recuperar y sustituir la columna de estado por las siglas
                string query_GetState = $@"SELECT TOP 1 {Utils.parseStringBD("Code")}";
                query_GetState += $" FROM {Utils.parseStringBD("OCST")}";
                query_GetState += $" WHERE {Utils.parseStringBD("Name")} = '{insert_State1}' OR {Utils.parseStringBD("Name")} = '{insert_State1SNAccent}'";

                //using (StreamWriter writer = new StreamWriter(pathState, true))
                //{
                //    writer.WriteLine("query SAP HANA: " + query_GetState);
                //    writer.Close();
                //}

                DataTable tbl_State1 = DBConn.ExecQuery(query_GetState);
                if (tbl_State1 != null && tbl_State1.Rows != null && tbl_State1.Rows.Count >= 0)
                {
                    foreach (DataRow rowState in tbl_State1.Rows)
                    {
                        string insert_State = (rowState.ItemArray[0].ToString() != "" && rowState.ItemArray[0].ToString() != null) ? rowState.ItemArray[0].ToString() : null;

                        string update_State1 = $"UPDATE {Utils.parseStringBD("zAdi_SyncLeadSAP")}";
                        update_State1 += $" SET {Utils.parseStringBD("State1")} = '{insert_State}'";
                        update_State1 += $" WHERE {Utils.parseStringBD("idSyncLead")} = '{insert_idSyncLead.ToString()}'";

                        bool StateSearch = DBConn.ExecQueryUpdate(update_State1, DBConn.ConectionDB.Bitacoras);
                        if (StateSearch)
                        {
                            //using (StreamWriter writer = new StreamWriter(pathStateUP, true))
                            //{
                            //    writer.WriteLine("query SAP HANA: " + update_State1);
                            //    writer.Close();
                            //}
                        }
                        DBConn.ExecQueryUpdate(update_State1, DBConn.ConectionDB.Bitacoras);

                        //bool StateUpdate = DBConn.ExecQueryUpdate(update_State1, DBConn.ConectionDB.Bitacoras);
                        //if (StateUpdate)
                        //{
                        //    //using (StreamWriter writer = new StreamWriter(pathState, true))
                        //    //{
                        //    //    writer.WriteLine("query SAP HANA: " + query_GetState);
                        //    //    writer.Close();
                        //    //}
                        //}
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                Utils.PrintLog("UpdateState", "1", ex.ToString());
            }
        }
        #endregion

        public void SyncLeadWAPI()
        {
            try {
                string query_GetBitSAP = $@"SELECT TOP {Utils.rangoRegistros_Leads} *";
                query_GetBitSAP += $" FROM {Utils.parseStringBD("zAdi_SyncLeadSAP")}";
                query_GetBitSAP += $" WHERE {Utils.parseStringBD("action")} = 'INSERT' AND {Utils.parseStringBD("flagSend")} = FALSE AND {Utils.parseStringBD("FlagLead")} = TRUE AND ({Utils.parseStringBD("CardCode")} != 'L-XXXXX' OR {Utils.parseStringBD("CardCode")} != 'X' OR {Utils.parseStringBD("CardCode")} != '---')";

                //Utils.PrintLog("SyncLeadWAPI", " query_GetBitSAP", query_GetBitSAP);
                DataTable DtLeadBit = DBConn.ExecQuery(query_GetBitSAP, DBConn.ConectionDB.Bitacoras);

                if(DtLeadBit != null && DtLeadBit.Rows != null && DtLeadBit.Rows.Count > 0)
                {
                    DIServerApi obapi = new DIServerApi();
                    if (obapi.WSLogin())
                    {

                        foreach (DataRow rowLeads in DtLeadBit.Rows)
                        {
                            string idSyncLead = rowLeads["idSyncLead"].ToString() != "" && rowLeads["idSyncLead"].ToString() != null ? rowLeads["idSyncLead"].ToString() : "0"; ;
                            string idCliente = (rowLeads["idClient"].ToString() != "" && rowLeads["idClient"].ToString() != null) ? rowLeads["idClient"].ToString() : "0";
                            string CardCode = (rowLeads["CardCode"].ToString() != "" && rowLeads["CardCode"].ToString() != null) ? rowLeads["CardCode"].ToString() : "";
                            string CardName = (rowLeads["CardName"].ToString() != "" && rowLeads["CardName"].ToString() != null) ? rowLeads["CardName"].ToString() : "";
                            string CardType = (rowLeads["CardType"].ToString() != "" && rowLeads["CardType"].ToString() != null) ? rowLeads["CardType"].ToString() : "";
                            string Address = (rowLeads["Address"].ToString() != "" && rowLeads["Address"].ToString() != null) ? rowLeads["Address"].ToString() : "";
                            string ZipCode = (rowLeads["ZipCode"].ToString() != "" && rowLeads["ZipCode"].ToString() != null) ? rowLeads["ZipCode"].ToString() : "";
                            string MailAddress = (rowLeads["MailAddress"].ToString() != "" && rowLeads["MailAddress"].ToString() != null) ? rowLeads["MailAddress"].ToString() : "";
                            string Phone1 = (rowLeads["Phone1"].ToString() != "" && rowLeads["Phone1"].ToString() != null) ? rowLeads["Phone1"].ToString() : "";
                            string Contact = (rowLeads["Contact"].ToString() != "" && rowLeads["Contact"].ToString() != null) ? rowLeads["Contact"].ToString() : "";
                            string CURP = (rowLeads["CURP"].ToString() != "" && rowLeads["CURP"].ToString() != null) ? rowLeads["CURP"].ToString() : "";
                            string City = (rowLeads["City"].ToString() != "" && rowLeads["City"].ToString() != null) ? rowLeads["City"].ToString() : "";
                            string Country = (rowLeads["Country"].ToString() != "" && rowLeads["Country"].ToString() != null) ? rowLeads["Country"].ToString() : "";
                            //string CreateDate = (Utils.GetDateFormatToSap(rowLeads.ItemArray[13].ToString()) != "" && Utils.GetDateFormatToSap(rowLeads.ItemArray[13].ToString()) != null) ? Utils.GetDateFormatToSap(rowLeads.ItemArray[13].ToString()) : "";
                            //string UpdateDate = (Utils.GetDateFormatToSap(rowLeads.ItemArray[14].ToString()) != "" && Utils.GetDateFormatToSap(rowLeads.ItemArray[14].ToString()) != null) ? Utils.GetDateFormatToSap(rowLeads.ItemArray[14].ToString()) : "";
                            string Address_2 = (rowLeads["Address_2"].ToString() != "" && rowLeads["Address_2"].ToString() != null) ? rowLeads["Address_2"].ToString() : "";
                            string State1WAccent = (Utils.RemoveAccents(rowLeads["State1"].ToString()) != null && Utils.RemoveAccents(rowLeads["State1"].ToString()) != "") ? Utils.RemoveAccents(rowLeads["State1"].ToString()) : null;
                            string State1 = (Utils.RemoveAccents(rowLeads["State1"].ToString()) != "" && Utils.RemoveAccents(rowLeads["State1"].ToString()) != null) ? Utils.RemoveAccents(rowLeads["State1"].ToString()) : null;
                            string sucursal = (rowLeads["sucursal"].ToString() != "" && rowLeads["sucursal"].ToString() != null) ? rowLeads["sucursal"].ToString() : "";
                            string cfdi = (rowLeads["cfdi"].ToString() != "" && rowLeads["cfdi"].ToString() != null) ? rowLeads["cfdi"].ToString() : "";
                            string asesor = (rowLeads["asesor"].ToString() != "" && rowLeads["asesor"].ToString() != null) ? rowLeads["asesor"].ToString() : "";
                            string user_email = (rowLeads["user_email"].ToString() != "" && rowLeads["user_email"].ToString() != null) ? rowLeads["user_email"].ToString() : "";

                            string billToDefault = string.Empty;
                            if (!string.IsNullOrEmpty(CardName))
                            {
                                if (CardName.Length > 50)
                                    billToDefault = CardName.Substring(0, 50);
                                else
                                    billToDefault = CardName;
                            }

                            string GroupCode = "113"; // Jalisco por default

                            string query_OCRG = string.Empty;

                            query_OCRG += $"SELECT TOP 1";
                            query_OCRG += $" {Utils.parseStringBD("OCRG")}.{Utils.parseStringBD("GroupCode")}";
                            query_OCRG += $" FROM";
                            query_OCRG += $" {Utils.parseStringBD("OCRG")}";
                            query_OCRG += $" LEFT JOIN";
                            query_OCRG += $" {Utils.parseStringBD("OCST")}";
                            query_OCRG += $" ON";
                            query_OCRG += $" {Utils.parseStringBD("OCRG")}.{Utils.parseStringBD("GroupName")} = {Utils.parseStringBD("OCST")}.{Utils.parseStringBD("Name")}";
                            query_OCRG += $" WHERE";
                            query_OCRG += $" {Utils.parseStringBD("OCST")}.{Utils.parseStringBD("Code")} = '{State1}'";

                            //Utils.PrintLog("SyncLeadWAPI", "query_OCRG", query_OCRG);
                            DataTable tbl_OCRG = DBConn.ExecQuery(query_OCRG);
                            if (tbl_OCRG != null && tbl_OCRG.Rows != null && tbl_OCRG.Rows.Count > 0)
                                GroupCode = tbl_OCRG.Rows[0]["GroupCode"].ToString();

                            string SlpCode = "106"; //Servicio a clientes DEFAULT.
                            if(!string.IsNullOrEmpty(asesor) && asesor != "NO TENGO ASESOR")
                            {

                                string query_OSLP = string.Empty;
                                query_OSLP += $"SELECT TOP 1";
                                query_OSLP += $" {Utils.parseStringBD("SlpCode")}";
                                query_OSLP += $" FROM";
                                query_OSLP += $" {Utils.parseStringBD("OSLP")}";
                                query_OSLP += $" WHERE";
                                query_OSLP += $" {Utils.parseStringBD("SlpName")} = '{asesor}' OR";
                                query_OSLP += $" {Utils.parseStringBD("SlpName")} LIKE '%{asesor}%'";

                                DataTable tbl_OSLP = DBConn.ExecQuery(query_OSLP);
                                if (tbl_OSLP != null && tbl_OSLP.Rows != null && tbl_OSLP.Rows.Count > 0)
                                    SlpCode = tbl_OSLP.Rows[0]["SlpCode"].ToString();
                                else
                                    SlpCode = "-1";
                            }

                            string U_B1SYS_MainUsage = "G01";
                            if (!string.IsNullOrEmpty(cfdi))
                            {
                                if(cfdi.Any(x=> x == ' '))
                                    U_B1SYS_MainUsage = cfdi.Substring(0, cfdi.IndexOf(cfdi.First(x => x == ' ')));
                            }



                            //Utils.PrintLog("SyncLeadWAPI", " billToDefault", billToDefault);

                            BOMBPartnes.BOM bOM;
                            bOM = new BOMBPartnes.BOM();
                            bOM.BO = new BOMBPartnes.BOMBO[1];
                            bOM.BO[0] = new BOMBPartnes.BOMBO();
                            bOM.BO[0].AdmInfo = new BOMBPartnes.BOMBOAdmInfo { Object = WSIL.TipoObjeto.oBusinessPartners.ToString() };
                            bOM.BO[0].BusinessPartners = new BOMBPartnes.BOMBORow[1];
                            //bOM.BO[0].BusinessPartners[0] = new BOMBPartnes.BOMBORow
                            //{
                            //    //CardCode = txtCardCode.Text,
                            //    CardName = CardName ?? "",
                            //    FederalTaxID = CURP.ToUpper() ?? "",
                            //    CardType = "cLid",
                            //    Series = 94,
                            //    SeriesSpecified = true,
                            //    Address = Address ?? "",
                            //    ZipCode = ZipCode ?? "",
                            //    Phone1 = Phone1 ?? "",
                            //    ContactPerson = Contact ?? "",
                            //    City = City ?? "",
                            //    Country = Country ?? "",
                            //    EmailAddress = MailAddress ?? "",
                            //    BillToState = State1 ?? "",
                            //    BilltoDefault = billToDefault ?? "",
                            //    Block = Address_2 ?? "",
                            //    Currency = "USD",
                            //    GroupCode = !string.IsNullOrEmpty(GroupCode) ? long.Parse(GroupCode) : 113,
                            //    GroupCodeSpecified = true,
                            //    SalesPersonCode = !string.IsNullOrEmpty(SlpCode) ? long.Parse(SlpCode) : 106,
                            //    SalesPersonCodeSpecified = true,
                            //    PriceListNum = 3,
                            //    PriceListNumSpecified = true,
                            //    U_B1SYS_MainUsage = U_B1SYS_MainUsage?? "G01",
                            //};
                            bOM.BO[0].BusinessPartners[0] = new BOMBPartnes.BOMBORow
                            {
                                //CardCode = txtCardCode.Text,
                                CardName = CardName ?? "",
                                FederalTaxID = CURP.ToUpper() ?? "",
                                CardType = "cLid",
                                Series = 94,
                                SeriesSpecified = true,
                                Phone1 = Phone1 ?? "",
                                ContactPerson = Contact ?? "",
                                EmailAddress = MailAddress ?? "",
                                Currency = "USD",
                                GroupCode = !string.IsNullOrEmpty(GroupCode) ? long.Parse(GroupCode) : 113,
                                GroupCodeSpecified = true,
                                SalesPersonCode = !string.IsNullOrEmpty(SlpCode) ? long.Parse(SlpCode) : 106,
                                SalesPersonCodeSpecified = true,
                                PriceListNum = 3,
                                PriceListNumSpecified = true,
                                U_B1SYS_MainUsage = U_B1SYS_MainUsage ?? "G01",
                                ShipToDefault = billToDefault?? "",
                                //BillToState = State1 ?? "",
                                //BilltoDefault = billToDefault ?? "",
                                //Address = Address ?? "",
                                //ZipCode = ZipCode ?? "",
                                //City = City ?? "",
                                //Country = Country ?? "",
                                //Block = Address_2 ?? ""
                                
                            };
                            bOM.BO[0].BPAddresses = new BOMBPartnes.BOMBORow1[1];
                            bOM.BO[0].BPAddresses[0] = new BOMBPartnes.BOMBORow1
                            {
                                AddressName = billToDefault ?? "",
                                Street =Address?? "",
                                Block = Address_2?? "",
                                ZipCode = ZipCode ?? "",
                                Country = Country?? "",
                                State = State1 ?? "",
                                TaxCode = "IVAV16",
                                AddressType = "bo_ShipTo",
                                City = City ?? ""
                            };
                            bOM.BO[0].ContactEmployees = new BOMBPartnes.BOMBORow2[2];
                            bOM.BO[0].ContactEmployees[0] = new BOMBPartnes.BOMBORow2
                            {
                                Name = Contact ?? "",
                                Phone1 = Phone1 ?? "",
                                E_Mail = user_email ?? ""
                            };
                            bOM.BO[0].ContactEmployees[1] = new BOMBPartnes.BOMBORow2
                            {
                                Name = "Facturación",
                                Phone1 = Phone1 ?? "",
                                E_Mail = MailAddress ?? "",
                                FirstName = CardName ?? "",
                            };



                            string strXML;
                            System.Xml.Serialization.XmlSerializerNamespaces ns;

                            ns = new System.Xml.Serialization.XmlSerializerNamespaces();
                            ns.Add("", "");
                            strXML = DIServerApi.getInstance.ObjToStringXML<BOMBPartnes.BOM>(bOM, ns, true);

                            string bomCreateQuot = DIServerApi.getInstance.FormatXML(strXML);
                            Utils.PrintLog("Leads", $"respuesta:", bomCreateQuot);
                            string cmd = "";
                            string response = obapi.WSAddObject(bomCreateQuot, cmd);
                            string code = obapi.GetCodeResponse(response);
                            if (code != "")
                            {
                                string select_docEntry = $"SELECT TOP 1 {Utils.parseStringBD("DocEntry")} FROM {Utils.parseStringBD("OCRD")} WHERE {Utils.parseStringBD("CardCode")} = '{code}'";
                                DataTable tbl_docEntry = DBConn.ExecQuery(select_docEntry);
                                string docEntry = "0";
                                if (tbl_docEntry != null && tbl_docEntry.Rows != null && tbl_docEntry.Rows.Count > 0)
                                    docEntry = tbl_docEntry.Rows[0]["DocEntry"].ToString();


                                string update = $"UPDATE {Utils.parseStringBD("zAdi_SyncLeadSAP")}";
                                update += $" SET {Utils.parseStringBD("CardCode")} = '{code}', {Utils.parseStringBD("flagSend")} = TRUE, {Utils.parseStringBD("docEntry")} = {docEntry}";
                                update += $" WHERE {Utils.parseStringBD("idSyncLead")} = {idSyncLead}";

                                DBConn.ExecQueryUpdate(update, DBConn.ConectionDB.Bitacoras);
                            }
                            else
                            {
                                response = string.Empty;
                                response = obapi.WSAddObject(bomCreateQuot, cmd);

                                code = string.Empty;
                                code = obapi.GetCodeResponse(response);
                                if (code != "")
                                {
                                    string update = $"UPDATE {Utils.parseStringBD("zAdi_SyncLeadSAP")}";
                                    update += $" SET {Utils.parseStringBD("CardCode")} = '{code}', {Utils.parseStringBD("flagSend")} = TRUE";
                                    update += $" WHERE {Utils.parseStringBD("idSyncLead")} = {idSyncLead}";

                                    DBConn.ExecQueryUpdate(update, DBConn.ConectionDB.Bitacoras);

                                }
                            }
                        }


                        obapi.WSLogout();
                    }
                }
                
            }
            catch (Exception ex)
            {
                Utils.PrintLog("SyncLeadWAPI", "1", ex.ToString());
            }
        }

        public static Leads getInstance => new Leads();
    }
}
