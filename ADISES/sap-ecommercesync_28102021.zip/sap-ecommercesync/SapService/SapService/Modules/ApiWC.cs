﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SapService.Modules
{
    class ApiWC
    {
        int idMaster = 0;
        int id = 0;
        string value = string.Empty;

        Thread Worker = null;
        public static bool AcceptAllCertifications(object sender, System.Security.Cryptography.X509Certificates.X509Certificate certification, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }
        #region v1 httpWebRequest json

        public void UpdateAsyncPriceProductsVariationWCApi2(string idProductMaster, string idVariation, string price)
        {
            try
            {

                var url = $"{Utils.UrlApi}/products/{idProductMaster}/variations/{idVariation}";

                var request = (HttpWebRequest)WebRequest.Create(url);

                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);





                var username = Utils.cvCliente;
                var password = Utils.cvSecreta;
                string encoded = System.Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1")
                                               .GetBytes(username + ":" + password));
                request.Headers.Add("Authorization", "Basic " + encoded);
                string json = "{\"sale_price\": \"" + price + "\", \"price\": \"" + price + "\"}";
                request.Method = "POST";
                request.ContentType = "application/json";
                request.Accept = "application/json";
                using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                {
                    streamWriter.Write(json);
                    streamWriter.Flush();
                    streamWriter.Close();
                }
                using (WebResponse response = request.GetResponse())
                {
                    using (Stream strReader = response.GetResponseStream())
                    {
                        if (strReader == null)
                        {
                            return;
                        }
                        using (StreamReader objReader = new StreamReader(strReader))
                        {

                            string responseBody = objReader.ReadToEnd();
                            JObject data = JObject.Parse(responseBody);
                            // Do something with responseBody
                            //Utils.PrintLog("UpdateAsyncPriceProductsVariationWCApi2:", "data", data.ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("UpdateAsyncPriceProductsVariationWCApi", "1", ex.ToString());
            }
        }

        public void UpdateAsyncStatusProductsVariationWCApi2(string idProductMaster, string idVariation, string status)
        {
            try
            {
                var url = $"{Utils.UrlApi}/products/{idProductMaster}/variations/{idVariation}";
                var request = (HttpWebRequest)WebRequest.Create(url);

                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);

                var username = Utils.cvCliente;
                var password = Utils.cvSecreta;
                string encoded = System.Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1")
                                               .GetBytes(username + ":" + password));
                request.Headers.Add("Authorization", "Basic " + encoded);
                string json = "{\"status\": \"" + status + "\"}";
                request.Method = "POST";
                request.ContentType = "application/json";
                request.Accept = "application/json";
                using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                {
                    streamWriter.Write(json);
                    streamWriter.Flush();
                    streamWriter.Close();
                }
                using (WebResponse response = request.GetResponse())
                {
                    using (Stream strReader = response.GetResponseStream())
                    {
                        if (strReader == null)
                        {
                            return;
                        }
                        using (StreamReader objReader = new StreamReader(strReader))
                        {

                            string responseBody = objReader.ReadToEnd();
                            JObject data = JObject.Parse(responseBody);
                            // Do something with responseBody
                            Utils.PrintLog("UpdateAsyncStatusProductsVariationWCApi2:", "data", data.ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("UpdateAsyncStatusProductsVariationWCApi", "1", ex.ToString());
            }
        }
        public void UpdateProductsWCApi2(string idProduct, string description)
        {
            try
            {
                var url = $"{Utils.UrlApi}/products/{idProduct}";
                var request = (HttpWebRequest)WebRequest.Create(url);
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);
                var username = Utils.cvCliente;
                var password = Utils.cvSecreta;
                string encoded = System.Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1")
                                               .GetBytes(username + ":" + password));
                request.Headers.Add("Authorization", "Basic " + encoded);
                string json = "{\"description\": \"" + description + "\"}";
                request.Method = "POST";
                request.ContentType = "application/json";
                request.Accept = "application/json";
                using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                {
                    streamWriter.Write(json);
                    streamWriter.Flush();
                    streamWriter.Close();
                }
                using (WebResponse response = request.GetResponse())
                {
                    using (Stream strReader = response.GetResponseStream())
                    {
                        if (strReader == null)
                        {
                            return;
                        }
                        using (StreamReader objReader = new StreamReader(strReader))
                        {

                            string responseBody = objReader.ReadToEnd();
                            JObject data = JObject.Parse(responseBody);
                            // Do something with responseBody
                            Utils.PrintLog("UpdateProductsWCApi2:", "data", data.ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("UpdateProductsWCApi", "1", ex.ToString());
            }
        }

        public void UpdateAsyncCategoriesWCApi2(int idTerm, string Name)
        {
            //return;
            try
            {
                var url = $"{Utils.UrlApi}/products/categories/{idTerm}";
                var request = (HttpWebRequest)WebRequest.Create(url);
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);
                var username = Utils.cvCliente;
                var password = Utils.cvSecreta;
                string encoded = System.Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1")
                                               .GetBytes(username + ":" + password));
                request.Headers.Add("Authorization", "Basic " + encoded);
                string json = "{\"name\": \"" + Name + "\"}";
                request.Method = "POST";
                request.ContentType = "application/json";
                request.Accept = "application/json";
                using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                {
                    streamWriter.Write(json);
                    streamWriter.Flush();
                    streamWriter.Close();
                }
                using (WebResponse response = request.GetResponse())
                {
                    using (Stream strReader = response.GetResponseStream())
                    {
                        if (strReader == null)
                        {
                            return;
                        }
                        using (StreamReader objReader = new StreamReader(strReader))
                        {
                            string responseBody = objReader.ReadToEnd();
                            JObject data = JObject.Parse(responseBody);
                            // Do something with responseBody
                            Utils.PrintLog("UpdateAsyncCategoriesWCApi2:", "data", data.ToString());
                        }
                    }
                }
            }
            catch (WebException ex)
            {
                string a = ex.Message;
                string b = ex.ToString();
                Utils.PrintLog("UpdateAsyncCategoriesWCApi other catch:", "en el catch", $"{a} \n {b}");

            }
        }

        #endregion

        #region v1 httpWebRequest json

        public void UpdateAsyncPriceProductsVariationWCApi2()
        {
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);

                var url = $"{Utils.UrlApi}/products/{idMaster}/variations/{id}";
                var request = (HttpWebRequest)WebRequest.Create(url);
                var username = Utils.cvCliente;
                var password = Utils.cvSecreta;
                string encoded = System.Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1")
                                               .GetBytes(username + ":" + password));
                request.Headers.Add("Authorization", "Basic " + encoded);
                string json = "{\"sale_price\": \"" + value + "\", \"price\": \"" + value + "\"}";
                request.Method = "POST";
                request.ContentType = "application/json";
                request.Accept = "application/json";
            try
            {
                using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                {
                    streamWriter.Write(json);
                    streamWriter.Flush();
                    streamWriter.Close();
                }
                using (WebResponse response = request.GetResponse())
                {
                    using (Stream strReader = response.GetResponseStream())
                    {
                        if (strReader == null)
                        {
                            return;
                        }
                        using (StreamReader objReader = new StreamReader(strReader))
                        {

                            string responseBody = objReader.ReadToEnd();
                            JObject data = JObject.Parse(responseBody);
                            // Do something with responseBody
                            //Utils.PrintLog("UpdateAsyncPriceProductsVariationWCApi2:", "data", data.ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("UpdateAsyncStatusProductsVariationWCApi", "", ex.Message);

                //segundo intento de envío
                try
                {
                    using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                    {
                        streamWriter.Write(json);
                        streamWriter.Flush();
                        streamWriter.Close();
                    }
                    using (WebResponse response = request.GetResponse())
                    {
                        using (Stream strReader = response.GetResponseStream())
                        {
                            if (strReader == null)
                            {
                                return;
                            }
                            using (StreamReader objReader = new StreamReader(strReader))
                            {

                                string responseBody = objReader.ReadToEnd();
                                JObject data = JObject.Parse(responseBody);
                                // Do something with responseBody
                                //Utils.PrintLog("UpdateAsyncPriceProductsVariationWCApi2:", "data", data.ToString());
                            }
                        }
                    }
                }
                catch(Exception) { }
            }
        }

        public void UpdateAsyncStatusProductsVariationWCApi2()
        {
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);

                var url = $"{Utils.UrlApi}/products/{idMaster}/variations/{id}";
                var request = (HttpWebRequest)WebRequest.Create(url);
                var username = Utils.cvCliente;
                var password = Utils.cvSecreta;
                string encoded = System.Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1")
                                               .GetBytes(username + ":" + password));
                request.Headers.Add("Authorization", "Basic " + encoded);
                string json = "{\"status\": \"" + value + "\"}";
                request.Method = "POST";
                request.ContentType = "application/json";
                request.Accept = "application/json";
            try
            {
                using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                {
                    streamWriter.Write(json);
                    streamWriter.Flush();
                    streamWriter.Close();
                }
                using (WebResponse response = request.GetResponse())
                {
                    using (Stream strReader = response.GetResponseStream())
                    {
                        if (strReader == null)
                        {
                            return;
                        }
                        using (StreamReader objReader = new StreamReader(strReader))
                        {

                            string responseBody = objReader.ReadToEnd();
                            JObject data = JObject.Parse(responseBody);
                            // Do something with responseBody
                            //Utils.PrintLog("UpdateAsyncStatusProductsVariationWCApi:", "data", data.ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("UpdateAsyncStatusProductsVariationWCApi", "", ex.Message);

                //segundo intento de envío
                try
                {
                    using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                    {
                        streamWriter.Write(json);
                        streamWriter.Flush();
                        streamWriter.Close();
                    }
                    using (WebResponse response = request.GetResponse())
                    {
                        using (Stream strReader = response.GetResponseStream())
                        {
                            if (strReader == null)
                            {
                                return;
                            }
                            using (StreamReader objReader = new StreamReader(strReader))
                            {

                                string responseBody = objReader.ReadToEnd();
                                JObject data = JObject.Parse(responseBody);
                                // Do something with responseBody
                                //Utils.PrintLog("UpdateAsyncStatusProductsVariationWCApi2:", "data", data.ToString());
                            }
                        }
                    }
                }
                catch(Exception) { }
            }
        }
        public void UpdateProductsWCApi2()
        {
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);
                var url = $"{Utils.UrlApi}/products/{id}";
                var request = (HttpWebRequest)WebRequest.Create(url);
                var username = Utils.cvCliente;
                var password = Utils.cvSecreta;
                string encoded = System.Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1")
                                               .GetBytes(username + ":" + password));
                request.Headers.Add("Authorization", "Basic " + encoded);
                string json = "{\"description\": \"" + value + "\"}";
                request.Method = "POST";
                request.ContentType = "application/json";
                request.Accept = "application/json";
            try
            {
                using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                {
                    streamWriter.Write(json);
                    streamWriter.Flush();
                    streamWriter.Close();
                }
                using (WebResponse response = request.GetResponse())
                {
                    using (Stream strReader = response.GetResponseStream())
                    {
                        if (strReader == null)
                        {
                            return;
                        }
                        using (StreamReader objReader = new StreamReader(strReader))
                        {

                            string responseBody = objReader.ReadToEnd();
                            JObject data = JObject.Parse(responseBody);
                            // Do something with responseBody
                            //Utils.PrintLog("UpdateProductsWCApi2:", "data", data.ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("UpdateProductsWCApi2", "", ex.Message);

                //segundo intento de envío
                try
                {
                    using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                    {
                        streamWriter.Write(json);
                        streamWriter.Flush();
                        streamWriter.Close();
                    }
                    using (WebResponse response = request.GetResponse())
                    {
                        using (Stream strReader = response.GetResponseStream())
                        {
                            if (strReader == null)
                            {
                                return;
                            }
                            using (StreamReader objReader = new StreamReader(strReader))
                            {

                                string responseBody = objReader.ReadToEnd();
                                JObject data = JObject.Parse(responseBody);
                                // Do something with responseBody
                                //Utils.PrintLog("UpdateProductsWCApi2:", "data", data.ToString());
                            }
                        }
                    }
                }
                catch(Exception) { }
            }
        }


        public void UpdateAsyncCategoriesWCApi2()
        {
            //return;
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);
                var url = $"{Utils.UrlApi}/products/categories/{id}";
                var request = (HttpWebRequest)WebRequest.Create(url);
                var username = Utils.cvCliente;
                var password = Utils.cvSecreta;
                string encoded = System.Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1")
                                               .GetBytes(username + ":" + password));
                request.Headers.Add("Authorization", "Basic " + encoded);
                string json = "{\"name\": \"" + value + "\"}";
                request.Method = "POST";
                request.ContentType = "application/json";
                request.Accept = "application/json";
            try
            {

                using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                {
                    streamWriter.Write(json);
                    streamWriter.Flush();
                    streamWriter.Close();
                }
                using (WebResponse response = request.GetResponse())
                {
                    using (Stream strReader = response.GetResponseStream())
                    {
                        if (strReader == null)
                        {
                            return;
                        }
                        using (StreamReader objReader = new StreamReader(strReader))
                        {
                            string responseBody = objReader.ReadToEnd();
                            JObject data = JObject.Parse(responseBody);
                            // Do something with responseBody
                            //Utils.PrintLog("UpdateAsyncCategoriesWCApi2:", "data", data.ToString());
                        }
                    }
                }
            }
            catch (WebException ex)
            {
                Utils.PrintLog("UpdateAsyncCategoriesWCApi", "", ex.Message);

                //segundo intento de envío
                try
                {
                    using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                    {
                        streamWriter.Write(json);
                        streamWriter.Flush();
                        streamWriter.Close();
                    }
                    using (WebResponse response = request.GetResponse())
                    {
                        using (Stream strReader = response.GetResponseStream())
                        {
                            if (strReader == null)
                            {
                                return;
                            }
                            using (StreamReader objReader = new StreamReader(strReader))
                            {
                                string responseBody = objReader.ReadToEnd();
                                JObject data = JObject.Parse(responseBody);
                                // Do something with responseBody
                                //Utils.PrintLog("UpdateAsyncCategoriesWCApi2:", "data", data.ToString());
                            }
                        }
                    }
                }
                catch (Exception) { }
            }
        }

        #endregion

        #region NewMethodAPICategories

        public async void UpdateAsyncPriceProductsVariationWCApi(string idProductMaster, string idVariation, string price)
        {
            return;
            //Stopwatch stopWatch = new Stopwatch();
            //stopWatch.Start();
            try
            {

                //Utils.PrintLog($"UpdateAsyncPriceProductsVariationWCApi", "0", $"idProductMaster: {idProductMaster}, idVariation: {idVariation}, price: {price}");
                //Utils.PrintLog("UpdateAsyncPriceProductsVariationWCApi", "0", "***INICIO***");
                var url = $"{Utils.UrlApi}/products/{idProductMaster}/variations/{idVariation}";

                //Utils.PrintLog("UpdateAsyncPriceProductsVariationWCApi", "url", url + " price: " + price);
                var client = new HttpClient();
                ServicePointManager.SecurityProtocol =
                SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                client.BaseAddress = new Uri(url);
                var username = Utils.cvCliente;
                var password = Utils.cvSecreta;

                string encoded = System.Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1")
                                                   .GetBytes(username + ":" + password));

                client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", encoded);
                var parameters = new Dictionary<string, string> { { "sale_price", price }, { "price", price } };
                var encodedContent = new FormUrlEncodedContent(parameters);

                try
                {
                    var response = await client.PostAsync(url, encodedContent).ConfigureAwait(false);
                    if (response.StatusCode == HttpStatusCode.OK)
                    {
                        var responseContent = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                        //Utils.PrintLog("UpdateAsyncPriceProductsVariationWCApi other method:", "en el if", responseContent);
                    }
                    else
                    {
                        Utils.PrintLog("UpdateAsyncPriceProductsVariationWCApi other method:", "en el else", response.StatusCode.ToString());

                    }
                }
                catch (WebException ex)
                {
                    string a = ex.Message;
                    string b = ex.ToString();
                    Utils.PrintLog("UpdateAsyncCategoriesWCApi other catch:", "en el catch", $"{a} \n {b}");

                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("UpdateAsyncPriceProductsVariationWCApi", "1", ex.ToString());
            }
        }

        public async void UpdateAsyncStatusProductsVariationWCApi(string idProductMaster, string idVariation, string status)
        {
            return;
            try
            {
                var url = $"{Utils.UrlApi}/products/{idProductMaster}/variations/{idVariation}";
                //Utils.PrintLog("UpdateAsyncStatusProductsVariationWCApi", "url", url + "status: " + status);

                var client = new HttpClient();
                ServicePointManager.SecurityProtocol =
                SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                client.BaseAddress = new Uri(url);
                var username = Utils.cvCliente;
                var password = Utils.cvSecreta;

                string encoded = System.Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1")
                                                   .GetBytes(username + ":" + password));
                client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", encoded);
                var parameters = new Dictionary<string, string> { { "status", status } };
                var encodedContent = new FormUrlEncodedContent(parameters);

                try
                {
                    var response = await client.PostAsync(url, encodedContent).ConfigureAwait(false);
                    if (response.StatusCode == HttpStatusCode.OK)
                    {
                        var responseContent = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                        //Utils.PrintLog("UpdateAsyncStatusProductsVariationWCApi other method:", "en el if CORRECTO", responseContent);
                    }
                    else
                    {
                        Utils.PrintLog("UpdateAsyncStatusProductsVariationWCApi other method:", "en el else ERROR", response.StatusCode.ToString());

                    }
                }
                catch (WebException ex)
                {
                    string a = ex.Message;
                    string b = ex.ToString();
                    Utils.PrintLog("UpdateAsyncStatusProductsVariationWCApi other catch:", "en el catch", $"{a} \n {b}");

                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("UpdateAsyncStatusProductsVariationWCApi", "1", ex.ToString());
            }
        }
        public async void UpdateProductsWCApi(string idProduct, string description)
        {
            return;
            try
            {
                var url = $"{Utils.UrlApi}/products/{idProduct}";
                //Utils.PrintLog("UpdateProductsWCApi", "url", url + "desc: " + description);

                var client = new HttpClient();
                ServicePointManager.SecurityProtocol =
                SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                client.BaseAddress = new Uri(url);
                var username = Utils.cvCliente;
                var password = Utils.cvSecreta;

                string encoded = System.Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1")
                                                   .GetBytes(username + ":" + password));

                client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", encoded);
                var parameters = new Dictionary<string, string> { { "description", description } };
                var encodedContent = new FormUrlEncodedContent(parameters);

                try
                {
                    var response = await client.PostAsync(url, encodedContent).ConfigureAwait(false);
                    if (response.StatusCode == HttpStatusCode.OK)
                    {
                        var responseContent = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                        //Utils.PrintLog("UpdateProductsWCApi other method:", "en el if", responseContent);
                    }
                    else
                    {
                        Utils.PrintLog("UpdateProductsWCApi other method:", "en el else", response.StatusCode.ToString());

                    }
                }
                catch (WebException ex)
                {
                    string a = ex.Message;
                    string b = ex.ToString();
                    Utils.PrintLog("UpdateProductsWCApi other catch:", "en el catch", $"{a} \n {b}");

                }
            }
            catch (Exception ex)
            {
                Utils.PrintLog("UpdateProductsWCApi", "1", ex.ToString());
            }
        }


        public async void UpdateAsyncCategoriesWCApi(int idTerm, string Name)
        {
            //return;
            try
            {
                var client = new HttpClient();
                var url = $"{Utils.UrlApi}/products/categories/{idTerm}";
                //Utils.PrintLog("UpdateAsyncCategoriesWCApi", "url", url + " - idTerm:" + idTerm + ", Name: " + Name + "--" + Utils.cvCliente + "--" + Utils.cvSecreta);
                ServicePointManager.SecurityProtocol =
                SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;

                client.BaseAddress = new Uri(url);
                var username = Utils.cvCliente;
                var password = Utils.cvSecreta;

                string encoded = System.Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1")
                                                   .GetBytes(username + ":" + password));

                client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", encoded);
                var parameters = new Dictionary<string, string> { { "name", Name } };
                var encodedContent = new FormUrlEncodedContent(parameters);
                try
                {
                    var response = await client.PostAsync(url, encodedContent).ConfigureAwait(false);
                    if (response.StatusCode == HttpStatusCode.OK)
                    {
                        var responseContent = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                        //Utils.PrintLog("UpdateAsyncCategoriesWCApi other method:", "en el if", responseContent);
                    }
                    else
                    {
                        Utils.PrintLog("UpdateAsyncCategoriesWCApi", "else", response.StatusCode.ToString());

                    }
                }
                catch (Exception) { }
                    
            }
            catch (WebException ex)
            {
                string a = ex.Message;
                string b = ex.ToString();
                Utils.PrintLog("UpdateAsyncCategoriesWCApi other catch:", "en el catch", $"{a} \n {b}");

            }
        }

        #endregion

        #region vRestSharp

        public void UpdateAsyncPriceProductsVariationWCApi3(string idProductMaster, string idVariation, string price)
        {
            //return;
            try
            {
                
                //var url = $"{Utils.UrlApi}/products/{idProductMaster}/variations/{idVariation}?Price={price}&sale_price={price}";
                var url = $"{Utils.UrlApi}/products/{idProductMaster}/variations/{idVariation}";
                //Utils.PrintLog("UpdateAsyncPriceProductsVariationWCApi3", url, "Utils.cvCliente: " + Utils.cvSecreta + "Utils.cvSecreta:" + Utils.cvSecreta);

                var client = new RestClient(url);
                client.Timeout = -1;
                var request = new RestRequest(Method.POST);
                var username = Utils.cvCliente;
                var password = Utils.cvSecreta;
                string encoded = System.Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(username + ":" + password));

                request.AddHeader("Content-Type", "application/x-www-form-urlencoded");
                request.AddHeader("Authorization", "Basic " + encoded);
                request.AddParameter("Price", price);
                request.AddParameter("sale_price", price);

                IRestResponse response = client.Execute(request);
                Utils.PrintLog("UpdateAsyncPriceProductsVariationWCApi3", "response", response.Content);

            }
            catch (Exception ex)
            {
                Utils.PrintLog("UpdateAsyncPriceProductsVariationWCApi3", "1", ex.ToString());
            }
        }

        public void UpdateAsyncStatusProductsVariationWCApi3(string idProductMaster, string idVariation, string status)
        {
            //return;

            try
            {
                var url = $"{Utils.UrlApi}/products/{idProductMaster}/variations/{idVariation}";
                //Utils.PrintLog("UpdateAsyncStatusProductsVariationWCApi3", url, "Utils.cvCliente: " + Utils.cvSecreta + "Utils.cvSecreta:" + Utils.cvSecreta);

                var client = new RestClient(url);
                client.Timeout = -1;
                var request = new RestRequest(Method.POST);
                var username = Utils.cvCliente;
                var password = Utils.cvSecreta;
                string encoded = System.Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(username + ":" + password));
                request.AddHeader("Content-Type", "application/x-www-form-urlencoded");
                request.AddHeader("Authorization", "Basic " + encoded);
                request.AddParameter("status", status);
                IRestResponse response = client.Execute(request);
                Utils.PrintLog("UpdateAsyncStatusProductsVariationWCApi3", "response", response.Content);
            }
            catch (Exception ex)
            {
                Utils.PrintLog("UpdateAsyncStatusProductsVariationWCApi3", "1", ex.ToString());
            }
        }
        public void UpdateProductsWCApi3(string idProduct, string description)
        {
            //return;

            try
            {
                //var url = $"{Utils.UrlApi}/products/{idProduct}?description={description}";
                var url = $"{Utils.UrlApi}/products/{idProduct}";
                //Utils.PrintLog("UpdateProductsWCApi3", url, "Utils.cvCliente: " + Utils.cvSecreta + "Utils.cvSecreta:" + Utils.cvSecreta);

                var client = new RestClient(url);
                client.Timeout = -1;
                var request = new RestRequest(Method.POST);
                var username = Utils.cvCliente;
                var password = Utils.cvSecreta;
                string encoded = System.Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(username + ":" + password));
                request.AddHeader("Content-Type", "application/x-www-form-urlencoded");
                request.AddHeader("Authorization", "Basic " + encoded);
                request.AddParameter("description", description);
                IRestResponse response = client.Execute(request);
                Utils.PrintLog("UpdateProductsWCApi3", "response", response.Content);

            }
            catch (Exception ex)
            {
                Utils.PrintLog("UpdateProductsWCApi3", "1", ex.ToString());
            }
        }


        public void UpdateAsyncCategoriesWCApi3(int idTerm, string Name)
        {
            //return;
            try
            {
                //var url = $"{Utils.UrlApi}/products/categories/{idTerm}?name={Name}";
                var url = $"{Utils.UrlApi}/products/categories/{idTerm}";

                //Utils.PrintLog("UpdateAsyncCategoriesWCApi3", url, "Utils.cvCliente: " + Utils.cvSecreta + "Utils.cvSecreta:" + Utils.cvSecreta);

                var client = new RestClient(url);
                client.Timeout = -1;
                var request = new RestRequest(Method.POST);
                var username = Utils.cvCliente;
                var password = Utils.cvSecreta;
                string encoded = System.Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(username + ":" + password));
                request.AddHeader("Content-Type", "application/x-www-form-urlencoded");
                request.AddHeader("Authorization", "Basic " + encoded);
                request.AddParameter("name", Name);
                IRestResponse response = client.Execute(request);
                Utils.PrintLog("UpdateAsyncCategoriesWCApi3", "response", response.Content);
            }
            catch (WebException ex)
            {
                Utils.PrintLog("UpdateAsyncCategoriesWCApi3", "1", ex.ToString());
            }
        }



        #endregion


        #region myAsyncTask
        public void example()
        {

            try
            {
                var url = $"{Utils.UrlApi}/products/categories/{id}";
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);
                var request = (HttpWebRequest)WebRequest.Create(url);
                var username = Utils.cvCliente;
                var password = Utils.cvSecreta;
                string encoded = System.Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1")
                                               .GetBytes(username + ":" + password));
                request.Headers.Add("Authorization", "Basic " + encoded);
                string json = "{\"name\": \"" + value + "\"}";
                request.Method = "POST";
                request.ContentType = "application/json";
                request.Accept = "application/json";
                using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                {
                    streamWriter.Write(json);
                    streamWriter.Flush();
                    streamWriter.Close();
                }
                using (WebResponse response = request.GetResponse())
                {
                    using (Stream strReader = response.GetResponseStream())
                    {
                        if (strReader == null)
                        {
                            return;
                        }
                        using (StreamReader objReader = new StreamReader(strReader))
                        {
                            string responseBody = objReader.ReadToEnd();
                            JObject data = JObject.Parse(responseBody);
                            // Do something with responseBody
                            Utils.PrintLog("UpdateAsyncCategoriesWCApi2:", "data", data.ToString());
                        }
                    }
                }
            }
            catch (WebException ex)
            {
                string a = ex.Message;
                string b = ex.ToString();
                Utils.PrintLog("UpdateAsyncCategoriesWCApi other catch:", "en el catch", ex.ToString());

            }

            if ((Worker != null) /*&& Worker.IsAlive*/)
            {
                //Utils.PrintLog("UpdateAsyncCategoriesWCApi other catch:", "", $"tarea terminada");
                Worker.Abort();
            }
        }

        public void runAsyncTask(API aPI, int idP, int id, string value)
        {
            this.idMaster = idP;
            this.id = id;
            this.value = value;

            switch (aPI)
            {
                case API.UpdateCategorie:
                    ThreadStart start = new ThreadStart(UpdateAsyncCategoriesWCApi2);
                    Worker = new Thread(start);
                    Worker.Start();
                    break;
                case API.UpdateDescription:
                    ThreadStart start2 = new ThreadStart(UpdateProductsWCApi2);
                    Worker = new Thread(start2);
                    Worker.Start();
                    break;
                case API.UpdatePrice:
                    ThreadStart start3 = new ThreadStart(UpdateAsyncPriceProductsVariationWCApi2);
                    Worker = new Thread(start3);
                    Worker.Start();
                    break;
                case API.updateStatus:
                    ThreadStart start4 = new ThreadStart(UpdateAsyncStatusProductsVariationWCApi2);
                    Worker = new Thread(start4);
                    Worker.Start();
                    break;
            }
        }

        #endregion


        public static ApiWC getInstance => new ApiWC();
    }

    public enum API
    {
        updateStatus,
        UpdateDescription,
        UpdatePrice,
        UpdateCategorie
    }
}
