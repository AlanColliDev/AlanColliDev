﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;

namespace SapService.Modules
{
     public class DIServerApi
     {
        //private const string url = "http://192.168.15.113/ws_SAP/DIServer.asmx";
        //private const string token = "iVAsfVBMz0SklEv1qFSmOEMR4rSRSc1dxsioKjXmEVHVnhEuqZ+LvhXnHJjY8ZEWexzIyqrsSViZIi73ZrtpV3lV2UBBJ8KevYpgwNmSGWVBtseoLUT8Ww==";
        //public string session = "";

        private string url = Utils.UrlDIApi;
        private string token = Utils.TokenDIApi;
        public string session = "";

        public bool WSLogin()
        {
            try
            {
                string response;
                WSIL.DIServer DIServer;
                DIServer = new WSIL.DIServer { Url = url };

                //response = DIServer.LoginSSL(txtToken.Text);
                response = DIServer.LoginSSL(token);

                if (WSValidate(response))
                {
                    //Utils.PrintLog("DIServerApiClass", "LINE 22 ", $"Resultado de la conexion Exitosa: {response}");
                    session = response;
                    return true;
                } 
            }
            catch (Exception e)
            {
                Utils.PrintLog("DIServerApiClass", "LINE 28 CATCH ", $"Resultado de la conexion: {e.ToString()}");
            }
            return false;

            //SesionActiva(response);
        }

        public String WsSBObob(string query, string OBjectModel = "ExecuteSQL", string Parameter = "DoQuery")
        {
            try
            {
                WSIL.DIServer DIServer = new WSIL.DIServer { Url = url };
                XmlNode node = DIServer.SBObob(session, OBjectModel, Parameter, query);

                string xmlResponse = FormatXML(node.OuterXml);
                return (!string.IsNullOrEmpty(xmlResponse) ? xmlResponse : "");
            }
            catch (Exception ex)
            {
                return "";
            }
            return "";
        }

        private bool WSValidate(string response)
        {
            WSIL.DIServer DIServer = new WSIL.DIServer { Url = url };

            if (DIServer.Validate(response))
            {
                return true;
            }
            else
            {
                if (DIServer.Validate(response))
                    return true;
                return false;
            }

        }

        public void WSLogout()
        {
            WSIL.DIServer DIServer = new WSIL.DIServer { Url = url };
            string response = DIServer.Logout(session);
            //Utils.PrintLog("DIServerApiClass", "LINE 64 CATCH ", $"Session close: {response}");


        }
        public string WSAddObject(string BOMObject, string Command)
        {
            
            System.Xml.XmlNode xmlNode;

            WSIL.DIServer DIServer = new WSIL.DIServer { Url = url };
            xmlNode = DIServer.AddObject(session, BOMObject, Command);

            //richTxtAddObject.Clear();
            //Utils.PrintLog("DIServerApiClass", "LINE 63 CATCH ", $"Session: {session}");

            string xmlResponse = FormatXML(xmlNode.OuterXml);
            return (!string.IsNullOrEmpty(xmlResponse) ? xmlResponse : "no se creo");
        }

        public int GetIdResponse(string resp)
        {
            XDocument xml = XDocument.Parse(resp);
            XNamespace ns = "http://www.sap.com/SBO/DIS";

            int IdQuot = 0;
            if (xml.Root.Descendants(ns + "AddObjectResponse").Elements(ns + "RetKey").Any())
            {

                IdQuot = (int)xml.Root.Descendants(ns + "AddObjectResponse").Elements(ns + "RetKey").FirstOrDefault();
                //Utils.PrintLog("DIServerApiClass", "LINE 84 GetIdResponse()", $"IdQuot: {IdQuot.ToString()}");

                Console.Write(Convert.ToInt32(IdQuot));
                return IdQuot;
            }
            return 0;

        }

        public string GetCodeResponse(string resp)
        {
            XDocument xml = XDocument.Parse(resp);
            XNamespace ns = "http://www.sap.com/SBO/DIS";

            string Code = "";
            if (xml.Root.Descendants(ns + "AddObjectResponse").Elements(ns + "RetKey").Any())
            {

                Code = xml.Root.Descendants(ns + "AddObjectResponse").Elements(ns + "RetKey").FirstOrDefault().Value;

                //Console.Write(Convert.ToInt32(Code));
                return Code;
            }
            return "";

        }

        public string FormatXML(string xml)
        {
            string result = "";

            System.IO.MemoryStream mStream = new System.IO.MemoryStream();
            System.Xml.XmlTextWriter writer = new System.Xml.XmlTextWriter(mStream, Encoding.Unicode);
            System.Xml.XmlDocument document = new System.Xml.XmlDocument();

            try
            {
                // Load the XmlDocument with the XML.
                document.LoadXml(xml);

                writer.Formatting = System.Xml.Formatting.Indented;

                // Write the XML into a formatting XmlTextWriter
                document.WriteContentTo(writer);
                writer.Flush();
                mStream.Flush();

                // Have to rewind the MemoryStream in order to read
                // its contents.
                mStream.Position = 0;

                // Read MemoryStream contents into a StreamReader.
                System.IO.StreamReader sReader = new System.IO.StreamReader(mStream);

                // Extract the text from the StreamReader.
                string formattedXml = sReader.ReadToEnd();

                result = formattedXml;
            }
            catch (System.Xml.XmlException)
            {
                // Handle the exception
            }

            mStream.Close();
            writer.Close();

            return result;
        }

        public string ObjToStringXML<T>(T objeto, System.Xml.Serialization.XmlSerializerNamespaces ns, Boolean OmitXmlDeclaration = false)
        {
            System.Xml.Serialization.XmlSerializer serializer;
            System.Xml.XmlWriter writer;
            System.IO.StringWriter stream;
            System.Xml.XmlWriterSettings settings;

            settings = new System.Xml.XmlWriterSettings();
            settings.Indent = true;
            settings.OmitXmlDeclaration = OmitXmlDeclaration;

            stream = new System.IO.StringWriter();
            writer = System.Xml.XmlWriter.Create(stream, settings);

            serializer = new System.Xml.Serialization.XmlSerializer(typeof(T));
            serializer.Serialize(writer, objeto, ns);

            return stream.ToString();
        }
        public static DIServerApi getInstance => new DIServerApi();


     }
}
